package org.jfree.chart.plot.flow;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.entity.FlowEntity;
import org.jfree.chart.entity.NodeEntity;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.data.flow.FlowDataset;
import org.jfree.data.flow.NodeKey;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InOrder;

public class FlowPlot_draw_0_6_Test {

    /**
     * Verifies draw method correctly adds NodeEntity to entity collection when info is provided
     */
//     @Test
//     @DisplayName("Verifies draw method correctly adds NodeEntity to entity collection when info is provided")
//     void TC26_draw_addsNodeEntitiesWhenInfoProvided() throws Exception {
        // Arrange
//         FlowDataset mockDataset = mock(FlowDataset.class);
//         FlowPlot flowPlot = new FlowPlot(mockDataset);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = mock(Rectangle2D.class);
//         Point2D point = mock(Point2D.class);
//         PlotState state = mock(PlotState.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entityCollection = mock(EntityCollection.class);
//         when(info.getEntityCollection()).thenReturn(entityCollection);
// 
//         when(mockDataset.getStageCount()).thenReturn(1);
//         when(mockDataset.getSources(0)).thenReturn(java.util.Arrays.asList("Source1", "Source2"));
//         when(mockDataset.getDestinations(0)).thenReturn(java.util.Arrays.asList("Dest1", "Dest2"));
//         when(mockDataset.getFlow(anyInt(), any(), any())).thenReturn(10);
// 
        // Act
//         flowPlot.draw(g2, area, point, state, info);
// 
        // Assert
//         ArgumentCaptor<NodeEntity> nodeEntityCaptor = ArgumentCaptor.forClass(NodeEntity.class);
//         verify(entityCollection, times(2)).add(nodeEntityCaptor.capture());
//         assertEquals(2, nodeEntityCaptor.getAllValues().size(), "Two NodeEntity objects should be added");
//     }

    /**
     * Verifies draw method skips adding FlowEntity when flow is null
     */
//     @Test
//     @DisplayName("Verifies draw method skips adding FlowEntity when flow is null")
//     void TC27_draw_skipsFlowEntitiesForNullFlows() throws Exception {
        // Arrange
//         FlowDataset mockDataset = mock(FlowDataset.class);
//         FlowPlot flowPlot = new FlowPlot(mockDataset);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = mock(Rectangle2D.class);
//         Point2D point = mock(Point2D.class);
//         PlotState state = mock(PlotState.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entityCollection = mock(EntityCollection.class);
//         when(info.getEntityCollection()).thenReturn(entityCollection);
// 
//         when(mockDataset.getStageCount()).thenReturn(1);
//         when(mockDataset.getSources(0)).thenReturn(java.util.Arrays.asList("Source1"));
//         when(mockDataset.getDestinations(0)).thenReturn(java.util.Arrays.asList("Dest1"));
//         when(mockDataset.getFlow(0, "Source1", "Dest1")).thenReturn(null);
// 
        // Act
//         flowPlot.draw(g2, area, point, state, info);
// 
        // Assert
//         ArgumentCaptor<FlowEntity> flowEntityCaptor = ArgumentCaptor.forClass(FlowEntity.class);
//         verify(entityCollection, never()).add(flowEntityCaptor.capture());
//     }

    /**
     * Verifies draw method correctly applies GradientPaint to flows
     */
//     @Test
//     @DisplayName("Verifies draw method correctly applies GradientPaint to flows")
//     void TC28_draw_appliesGradientPaintToFlows() throws Exception {
        // Arrange
//         FlowDataset mockDataset = mock(FlowDataset.class);
//         FlowPlot flowPlot = new FlowPlot(mockDataset);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = mock(Rectangle2D.class);
//         Point2D point = mock(Point2D.class);
//         PlotState state = mock(PlotState.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         when(info.getEntityCollection()).thenReturn(null);
// 
//         when(mockDataset.getStageCount()).thenReturn(1);
//         when(mockDataset.getSources(0)).thenReturn(java.util.Arrays.asList("Source1"));
//         when(mockDataset.getDestinations(0)).thenReturn(java.util.Arrays.asList("Dest1"));
//         when(mockDataset.getFlow(0, "Source1", "Dest1")).thenReturn(10);
//         when(mockDataset.getFlowProperty(any(), anyString())).thenReturn(true);
// 
        // Setup node colors via reflection
//         Map<NodeKey, Color> nodeColorMap = new HashMap<>();
//         nodeColorMap.put(new NodeKey<>(0, "Source1"), Color.BLUE);
//         nodeColorMap.put(new NodeKey<>(0, "Dest1"), Color.RED);
//         setPrivateField(flowPlot, "nodeColorMap", nodeColorMap);
// 
        // Act
//         flowPlot.draw(g2, area, point, state, info);
// 
        // Assert
//         ArgumentCaptor<GradientPaint> gradientPaintCaptor = ArgumentCaptor.forClass(GradientPaint.class);
//         verify(g2).setPaint(gradientPaintCaptor.capture());
//         GradientPaint capturedPaint = gradientPaintCaptor.getValue();
//         assertNotNull(capturedPaint, "GradientPaint should be applied");
//         assertEquals(Color.BLUE, capturedPaint.getColor1(), "GradientPaint should start with source color");
//         assertEquals(new Color(Color.RED.getRed(), Color.RED.getGreen(), Color.RED.getBlue(), 128), capturedPaint.getColor2(), "GradientPaint should end with destination color with 50% opacity");
//     }

    /**
     * Verifies draw method correctly handles semi-transparent flows without affecting other drawings
     */
//     @Test
//     @DisplayName("Verifies draw method correctly handles semi-transparent flows without affecting other drawings")
//     void TC29_draw_semiTransparentFlows_renderCorrectly() throws Exception {
        // Arrange
//         FlowDataset mockDataset = mock(FlowDataset.class);
//         FlowPlot flowPlot = new FlowPlot(mockDataset);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = mock(Rectangle2D.class);
//         Point2D point = mock(Point2D.class);
//         PlotState state = mock(PlotState.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         when(info.getEntityCollection()).thenReturn(null);
// 
//         when(mockDataset.getStageCount()).thenReturn(1);
//         when(mockDataset.getSources(0)).thenReturn(java.util.Arrays.asList("Source1"));
//         when(mockDataset.getDestinations(0)).thenReturn(java.util.Arrays.asList("Dest1"));
//         when(mockDataset.getFlow(0, "Source1", "Dest1")).thenReturn(10);
//         when(mockDataset.getFlowProperty(any(), anyString())).thenReturn(true);
// 
        // Act
//         flowPlot.draw(g2, area, point, state, info);
// 
        // Assert
        // Verify that AlphaComposite is set and restored correctly
//         InOrder inOrder = inOrder(g2);
//         inOrder.verify(g2).setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.75f));
//         inOrder.verify(g2).setComposite(any()); // Restore original composite
//     }

    /**
     * Verifies draw method gracefully handles empty sources list in a stage
     */
//     @Test
//     @DisplayName("Verifies draw method gracefully handles empty sources list in a stage")
//     void TC30_draw_emptySourcesList_skipsProcessing() throws Exception {
        // Arrange
//         FlowDataset mockDataset = mock(FlowDataset.class);
//         FlowPlot flowPlot = new FlowPlot(mockDataset);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = mock(Rectangle2D.class);
//         Point2D point = mock(Point2D.class);
//         PlotState state = mock(PlotState.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         when(info.getEntityCollection()).thenReturn(null);
// 
//         when(mockDataset.getStageCount()).thenReturn(1);
//         when(mockDataset.getSources(0)).thenReturn(java.util.Collections.emptyList());
//         when(mockDataset.getDestinations(0)).thenReturn(java.util.Arrays.asList("Dest1"));
// 
        // Act
//         flowPlot.draw(g2, area, point, state, info);
// 
        // Assert
        // Verify that no processing occurs for empty sources
//         verify(mockDataset, times(1)).getSources(0);
//         verify(mockDataset, never()).getFlow(anyInt(), any(), any());
//     }

    /**
     * Utility method to set private fields via reflection.
     */
    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }
}