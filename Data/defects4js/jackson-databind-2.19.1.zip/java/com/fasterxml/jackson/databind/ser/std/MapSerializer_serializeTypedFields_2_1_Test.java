package com.fasterxml.jackson.databind.ser.std;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.Mockito;
import static org.mockito.Mockito.*;

import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.type.TypeFactory;

public class MapSerializer_serializeTypedFields_2_1_Test {

    @Test
    @DisplayName("serializeTypedFields with suppressableValue not equal to MARKER_FOR_EMPTY and entry values equal to suppressableValue are skipped")
    public void TC15() throws Exception {
        // Arrange
        Map<Object, Object> map = new HashMap<>();
        Object customSuppressable = new Object();
        map.put("key1", customSuppressable);
        map.put("key2", "value2");

        JsonGenerator gen = Mockito.mock(JsonGenerator.class);
        SerializerProvider provider = Mockito.mock(SerializerProvider.class);
        JsonSerializer<Object> keySerializer = Mockito.mock(JsonSerializer.class);
        JsonSerializer<Object> valueSerializer = Mockito.mock(JsonSerializer.class);
        TypeSerializer valueTypeSerializer = Mockito.mock(TypeSerializer.class);

        // Create a JavaType object as it is needed for constructor
        JavaType javaType = TypeFactory.defaultInstance().constructType(Map.class);

        // Instantiate MapSerializer via reflection
        Constructor<MapSerializer> constructor = MapSerializer.class.getDeclaredConstructor(
            Set.class, Set.class, com.fasterxml.jackson.databind.JavaType.class, boolean.class, TypeSerializer.class,
            JsonSerializer.class, JsonSerializer.class
        );
        constructor.setAccessible(true);
        MapSerializer mapSerializer = constructor.newInstance(
            null, null, javaType, false, valueTypeSerializer, keySerializer, valueSerializer
        );

        // Act
        mapSerializer.serializeTypedFields(map, gen, provider, customSuppressable);

        // Assert
        Mockito.verify(keySerializer).serialize("key2", gen, provider);
        Mockito.verify(valueSerializer).serializeWithType("value2", gen, provider, valueTypeSerializer);
        Mockito.verify(keySerializer, never()).serialize("key1", gen, provider);
        Mockito.verify(valueSerializer, never()).serializeWithType(customSuppressable, gen, provider, valueTypeSerializer);
    }

    @Test
    @DisplayName("serializeTypedFields with suppressableValue not equal to MARKER_FOR_EMPTY and entry values not equal to suppressableValue are serialized")
    public void TC16() throws Exception {
        // Arrange
        Map<Object, Object> map = new HashMap<>();
        Object customSuppressable = new Object();
        map.put("key1", "value1");
        map.put("key2", customSuppressable);

        JsonGenerator gen = Mockito.mock(JsonGenerator.class);
        SerializerProvider provider = Mockito.mock(SerializerProvider.class);
        JsonSerializer<Object> keySerializer = Mockito.mock(JsonSerializer.class);
        JsonSerializer<Object> valueSerializer = Mockito.mock(JsonSerializer.class);
        TypeSerializer valueTypeSerializer = Mockito.mock(TypeSerializer.class);

        // Create a JavaType object as it is needed for constructor
        JavaType javaType = TypeFactory.defaultInstance().constructType(Map.class);

        // Instantiate MapSerializer via reflection
        Constructor<MapSerializer> constructor = MapSerializer.class.getDeclaredConstructor(
            Set.class, Set.class, com.fasterxml.jackson.databind.JavaType.class, boolean.class, TypeSerializer.class,
            JsonSerializer.class, JsonSerializer.class
        );
        constructor.setAccessible(true);
        MapSerializer mapSerializer = constructor.newInstance(
            null, null, javaType, false, valueTypeSerializer, keySerializer, valueSerializer
        );

        // Act
        mapSerializer.serializeTypedFields(map, gen, provider, customSuppressable);

        // Assert
        Mockito.verify(keySerializer).serialize("key1", gen, provider);
        Mockito.verify(valueSerializer).serializeWithType("value1", gen, provider, valueTypeSerializer);
        Mockito.verify(keySerializer, never()).serialize("key2", gen, provider);
        Mockito.verify(valueSerializer, never()).serializeWithType(customSuppressable, gen, provider, valueTypeSerializer);
    }
}
