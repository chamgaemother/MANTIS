package org.apache.commons.math3.ode.sampling;

import org.apache.commons.math3.exception.MaxCountExceededException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Generated JUnit 5 test class for StepNormalizer.handleStep.
 */
public class StepNormalizer_handleStep_2_2_Test {

    @Test
    @DisplayName("handleStep with bounds=BOTH, mode=MULTIPLES, and forward=true covering path B0âB3âB5âB6âB9âB10âB12âB13âB16âB17âB18âB19âB20âB22")
    void TC22_handleStep_boundsBOTH_modeMULTIPLES_forwardTrue() throws MaxCountExceededException {
        // GIVEN
        FixedStepHandler handler = mock(FixedStepHandler.class);
        StepNormalizer normalizer = new StepNormalizer(0.5, handler, StepNormalizerMode.MULTIPLES, StepNormalizerBounds.BOTH);
        
        StepInterpolator interpolator = mock(StepInterpolator.class);
        when(interpolator.getPreviousTime()).thenReturn(1.0);
        when(interpolator.getCurrentTime()).thenReturn(2.0);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.1, 0.2});
        when(interpolator.isForward()).thenReturn(true);
        
        // WHEN
        normalizer.handleStep(interpolator, true);
        
        // THEN
        ArgumentCaptor<Double> timeCaptor = ArgumentCaptor.forClass(Double.class);
        ArgumentCaptor<double[]> stateCaptor = ArgumentCaptor.forClass(double[].class);
        ArgumentCaptor<double[]> derivativesCaptor = ArgumentCaptor.forClass(double[].class);
        ArgumentCaptor<Boolean> isLastCaptor = ArgumentCaptor.forClass(Boolean.class);
        
        verify(handler, atLeastOnce()).handleStep(timeCaptor.capture(), stateCaptor.capture(), derivativesCaptor.capture(), isLastCaptor.capture());
        
        assertEquals(2.0, timeCaptor.getValue());
        assertArrayEquals(new double[]{1.0, 2.0}, stateCaptor.getValue());
        assertArrayEquals(new double[]{0.1, 0.2}, derivativesCaptor.getValue());
        assertTrue(isLastCaptor.getValue());
    }

    @Test
    @DisplayName("handleStep with bounds=LAST, mode=MULTIPLES, and forward=false covering path B0âB1âB2âB3âB4âB6âB9âB10âB12âB13âB16âB17âB19âB20âB22")
    void TC23_handleStep_boundsLAST_modeMULTIPLES_forwardFalse() throws MaxCountExceededException {
        // GIVEN
        FixedStepHandler handler = mock(FixedStepHandler.class);
        StepNormalizer normalizer = new StepNormalizer(0.5, handler, StepNormalizerMode.MULTIPLES, StepNormalizerBounds.LAST);
        
        StepInterpolator interpolator = mock(StepInterpolator.class);
        when(interpolator.getPreviousTime()).thenReturn(2.0);
        when(interpolator.getCurrentTime()).thenReturn(1.5);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{2.0, 1.5});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.2, 0.15});
        when(interpolator.isForward()).thenReturn(false);
        
        // WHEN
        normalizer.handleStep(interpolator, true);
        
        // THEN
        ArgumentCaptor<Double> timeCaptor = ArgumentCaptor.forClass(Double.class);
        ArgumentCaptor<double[]> stateCaptor = ArgumentCaptor.forClass(double[].class);
        ArgumentCaptor<double[]> derivativesCaptor = ArgumentCaptor.forClass(double[].class);
        ArgumentCaptor<Boolean> isLastCaptor = ArgumentCaptor.forClass(Boolean.class);
        
        verify(handler, atLeastOnce()).handleStep(timeCaptor.capture(), stateCaptor.capture(), derivativesCaptor.capture(), isLastCaptor.capture());
        
        assertEquals(1.5, timeCaptor.getValue());
        assertArrayEquals(new double[]{2.0, 1.5}, stateCaptor.getValue());
        assertArrayEquals(new double[]{0.2, 0.15}, derivativesCaptor.getValue());
        assertTrue(isLastCaptor.getValue());
    }

    @Test
    @DisplayName("handleStep with bounds=BOTH, mode=INCREMENT, and forward=true covering path B0âB3âB5âB6âB9âB10âB12âB13âB16âB17âB18âB20âB22")
    void TC24_handleStep_boundsBOTH_modeINCREMENT_forwardTrue() throws MaxCountExceededException {
        // GIVEN
        FixedStepHandler handler = mock(FixedStepHandler.class);
        StepNormalizer normalizer = new StepNormalizer(0.5, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.BOTH);
        
        StepInterpolator interpolator = mock(StepInterpolator.class);
        when(interpolator.getPreviousTime()).thenReturn(2.0);
        when(interpolator.getCurrentTime()).thenReturn(2.5);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{2.0, 2.5});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.2, 0.25});
        when(interpolator.isForward()).thenReturn(true);
        
        // WHEN
        normalizer.handleStep(interpolator, true);
        
        // THEN
        ArgumentCaptor<Double> timeCaptor = ArgumentCaptor.forClass(Double.class);
        ArgumentCaptor<double[]> stateCaptor = ArgumentCaptor.forClass(double[].class);
        ArgumentCaptor<double[]> derivativesCaptor = ArgumentCaptor.forClass(double[].class);
        ArgumentCaptor<Boolean> isLastCaptor = ArgumentCaptor.forClass(Boolean.class);
        
        verify(handler, atLeastOnce()).handleStep(timeCaptor.capture(), stateCaptor.capture(), derivativesCaptor.capture(), isLastCaptor.capture());
        
        assertEquals(2.5, timeCaptor.getValue());
        assertArrayEquals(new double[]{2.0, 2.5}, stateCaptor.getValue());
        assertArrayEquals(new double[]{0.2, 0.25}, derivativesCaptor.getValue());
        assertTrue(isLastCaptor.getValue());
    }

    @Test
    @DisplayName("handleStep with bounds=BOTH, mode=INCREMENT, and forward=false covering path B0âB1âB2âB3âB4âB6âB9âB10âB12âB13âB16âB17âB18âB20âB22")
    void TC25_handleStep_boundsBOTH_modeINCREMENT_forwardFalse() throws MaxCountExceededException {
        // GIVEN
        FixedStepHandler handler = mock(FixedStepHandler.class);
        StepNormalizer normalizer = new StepNormalizer(0.5, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.BOTH);
        
        StepInterpolator interpolator = mock(StepInterpolator.class);
        when(interpolator.getPreviousTime()).thenReturn(2.5);
        when(interpolator.getCurrentTime()).thenReturn(2.0);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{2.5, 2.0});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.25, 0.2});
        when(interpolator.isForward()).thenReturn(false);
        
        // WHEN
        normalizer.handleStep(interpolator, true);
        
        // THEN
        ArgumentCaptor<Double> timeCaptor = ArgumentCaptor.forClass(Double.class);
        ArgumentCaptor<double[]> stateCaptor = ArgumentCaptor.forClass(double[].class);
        ArgumentCaptor<double[]> derivativesCaptor = ArgumentCaptor.forClass(double[].class);
        ArgumentCaptor<Boolean> isLastCaptor = ArgumentCaptor.forClass(Boolean.class);
        
        verify(handler, atLeastOnce()).handleStep(timeCaptor.capture(), stateCaptor.capture(), derivativesCaptor.capture(), isLastCaptor.capture());
        
        assertEquals(2.0, timeCaptor.getValue());
        assertArrayEquals(new double[]{2.5, 2.0}, stateCaptor.getValue());
        assertArrayEquals(new double[]{0.25, 0.2}, derivativesCaptor.getValue());
        assertTrue(isLastCaptor.getValue());
    }

    @Test
    @DisplayName("handleStep exception path when StepNormalizerBounds throws an unexpected exception")
    void TC26_handleStep_boundsBOTH_modeINCREMENT_forwardTrue_exception() throws Exception {
        // GIVEN
        FixedStepHandler handler = mock(FixedStepHandler.class);
        StepNormalizer normalizer = new StepNormalizer(0.5, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.BOTH);
        
        // Mock StepNormalizerBounds to throw exception
        StepNormalizerBounds boundsMock = mock(StepNormalizerBounds.class);
        when(boundsMock.lastIncluded()).thenThrow(new RuntimeException("Unexpected exception"));
        
        // Replace bounds in StepNormalizer via reflection
        Field boundsField = StepNormalizer.class.getDeclaredField("bounds");
        boundsField.setAccessible(true);
        boundsField.set(normalizer, boundsMock);
        
        StepInterpolator interpolator = mock(StepInterpolator.class);
        when(interpolator.getPreviousTime()).thenReturn(2.0);
        when(interpolator.getCurrentTime()).thenReturn(2.5);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{2.0, 2.5});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.2, 0.25});
        when(interpolator.isForward()).thenReturn(true);
        
        // WHEN & THEN
        RuntimeException exception = assertThrows(RuntimeException.class, () -> normalizer.handleStep(interpolator, true));
        assertEquals("Unexpected exception", exception.getMessage());
    }
}