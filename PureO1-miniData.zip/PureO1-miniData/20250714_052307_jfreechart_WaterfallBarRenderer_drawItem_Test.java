import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class WaterfallBarRendererTest {

    private WaterfallBarRenderer renderer;
    private Graphics2D g2;
    private CategoryItemRendererState state;
    private Rectangle2D dataArea;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private CategoryDataset dataset;
    private EntityCollection entities;
    private CategoryItemLabelGenerator labelGenerator;

    @BeforeEach
    void setUp() {
        renderer = new WaterfallBarRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(CategoryItemRendererState.class);
        dataArea = mock(Rectangle2D.class);
        plot = mock(CategoryPlot.class);
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(CategoryDataset.class);
        entities = mock(EntityCollection.class);
        labelGenerator = mock(CategoryItemLabelGenerator.class);

        when(state.getSeriesRunningTotal()).thenReturn(100.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(state.getEntityCollection()).thenReturn(entities);
        when(rangeAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(50.0);

        renderer.setDrawBarOutline(true);
        renderer.setMinimumBarLength(1.0);
        renderer.setItemLabelGenerator(labelGenerator);
        renderer.setItemLabelVisible(true);
    }

    @Test
    void testDrawItem_FirstBar() {
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 0)).thenReturn(50.0);
        when(dataset.getRowCount()).thenReturn(1);
        when(renderer.getFirstBarPaint()).thenReturn(Color.BLUE);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verify(g2).setPaint(Color.BLUE);
        verify(g2).fill(any(Rectangle2D.class));
    }

    @Test
    void testDrawItem_LastBar() {
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 2)).thenReturn(150.0);
        when(dataset.getRowCount()).thenReturn(1);
        when(renderer.getLastBarPaint()).thenReturn(Color.RED);
        when(state.getSeriesRunningTotal()).thenReturn(0.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 2, 0);

        verify(g2).setPaint(Color.RED);
        verify(g2).fill(any(Rectangle2D.class));
    }

    @Test
    void testDrawItem_PositiveValue() {
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(100.0);
        when(dataset.getRowCount()).thenReturn(1);
        when(renderer.getPositiveBarPaint()).thenReturn(Color.GREEN);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(g2).setPaint(Color.GREEN);
        verify(g2).fill(any(Rectangle2D.class));
    }

    @Test
    void testDrawItem_NegativeValue() {
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(-50.0);
        when(dataset.getRowCount()).thenReturn(1);
        when(renderer.getNegativeBarPaint()).thenReturn(Color.ORANGE);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(g2).setPaint(Color.ORANGE);
        verify(g2).fill(any(Rectangle2D.class));
    }

    @Test
    void testDrawItem_NullValue() {
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(null);
        when(dataset.getRowCount()).thenReturn(1);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(g2, never()).setPaint(any());
        verify(g2, never()).fill(any(Rectangle2D.class));
    }

    @Test
    void testDrawItem_VerticalOrientation() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(100.0);
        when(dataset.getRowCount()).thenReturn(1);
        when(renderer.getPositiveBarPaint()).thenReturn(Color.GREEN);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(g2).setPaint(Color.GREEN);
        verify(g2).fill(any(Rectangle2D.class));
    }

    @Test
    void testDrawItem_HorizontalOrientation() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(100.0);
        when(dataset.getRowCount()).thenReturn(1);
        when(renderer.getPositiveBarPaint()).thenReturn(Color.GREEN);
        when(domainAxis.getCategorySeriesMiddle(any(), any(), any(), anyDouble(), any(), any()))
                .thenReturn(50.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(g2).setPaint(Color.GREEN);
        verify(g2).fill(any(Rectangle2D.class));
    }

    @Test
    void testDrawItem_GradientPaint() {
        Paint gradientPaint = new Color(0, 0, 0); // Not a GradientPaint
        renderer.setGradientPaintTransformer(null);
        when(renderer.getPositiveBarPaint()).thenReturn(gradientPaint);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(100.0);
        when(dataset.getRowCount()).thenReturn(1);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(g2).setPaint(gradientPaint);
    }

    @Test
    void testDrawItem_BarOutline_Drawn() {
        when(state.getBarWidth()).thenReturn(5.0);
        Stroke stroke = mock(Stroke.class);
        Paint outlinePaint = Color.BLACK;
        when(renderer.getItemOutlineStroke(0, 1)).thenReturn(stroke);
        when(renderer.getItemOutlinePaint(0, 1)).thenReturn(outlinePaint);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(100.0);
        when(dataset.getRowCount()).thenReturn(1);
        when(renderer.getPositiveBarPaint()).thenReturn(Color.GREEN);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(g2).setStroke(stroke);
        verify(g2).setPaint(outlinePaint);
        verify(g2).draw(any(Rectangle2D.class));
    }

    @Test
    void testDrawItem_BarOutline_NotDrawn_SmallWidth() {
        when(state.getBarWidth()).thenReturn(0.5);
        renderer.setDrawBarOutline(true);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(100.0);
        when(dataset.getRowCount()).thenReturn(1);
        when(renderer.getPositiveBarPaint()).thenReturn(Color.GREEN);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(g2, never()).setStroke(any());
        verify(g2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    void testDrawItem_ItemLabelVisible() {
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(100.0);
        when(dataset.getRowCount()).thenReturn(1);
        when(renderer.getPositiveBarPaint()).thenReturn(Color.GREEN);
        when(renderer.isItemLabelVisible(0, 1)).thenReturn(true);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(labelGenerator).generateLabel(dataset, 0, 1);
        verify(renderer).drawItemLabel(g2, dataset, 0, 1, plot, labelGenerator, any(Rectangle2D.class), false);
    }

    @Test
    void testDrawItem_ItemLabelNotVisible() {
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(100.0);
        when(dataset.getRowCount()).thenReturn(1);
        when(renderer.getPositiveBarPaint()).thenReturn(Color.GREEN);
        when(renderer.isItemLabelVisible(0, 1)).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(labelGenerator, never()).generateLabel(any(), anyInt(), anyInt());
        verify(renderer, never()).drawItemLabel(any(), any(), anyInt(), anyInt(), any(), any(), any(), anyBoolean());
    }

    @Test
    void testDrawItem_AddItemEntity() {
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(100.0);
        when(dataset.getRowCount()).thenReturn(1);
        when(renderer.getPositiveBarPaint()).thenReturn(Color.GREEN);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(entities).add(eq(renderer), any(), eq(0), eq(1));
    }

    @Test
    void testDrawItem_NoEntityCollection() {
        when(state.getEntityCollection()).thenReturn(null);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(100.0);
        when(dataset.getRowCount()).thenReturn(1);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(entities, never()).add(any(), any(), anyInt(), anyInt());
    }

    @Test
    void testDrawItem_NullGraphics() {
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(100.0);
        when(dataset.getRowCount()).thenReturn(1);
        assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(null, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);
        });
    }

    @Test
    void testDrawItem_NullDataset() {
        assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, null, 0, 1, 0);
        });
    }

    @Test
    void testDrawItem_SetSeriesRunningTotal_LastColumn() {
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 2)).thenReturn(150.0);
        when(dataset.getRowCount()).thenReturn(1);
        when(state.getSeriesRunningTotal()).thenReturn(100.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 2, 0);

        verify(state).setSeriesRunningTotal(0.0);
    }

    @Test
    void testDrawItem_SetSeriesRunningTotal_Normal() {
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(50.0);
        when(dataset.getRowCount()).thenReturn(1);
        when(state.getSeriesRunningTotal()).thenReturn(100.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(state).setSeriesRunningTotal(150.0);
    }

    @Test
    void testDrawItem_EqualsAndHashCode() {
        WaterfallBarRenderer renderer2 = new WaterfallBarRenderer();
        assertEquals(renderer, renderer2);
        assertEquals(renderer.hashCode(), renderer2.hashCode());

        renderer2.setFirstBarPaint(Color.RED);
        assertNotEquals(renderer, renderer2);
    }

    @Test
    void testDrawItem_Serialization() throws Exception {
        renderer.setFirstBarPaint(Color.BLUE);
        renderer.setLastBarPaint(Color.RED);
        renderer.setPositiveBarPaint(Color.GREEN);
        renderer.setNegativeBarPaint(Color.ORANGE);

        byte[] bytes = SerialUtils.serialize(renderer);
        WaterfallBarRenderer deserialized = (WaterfallBarRenderer) SerialUtils.deserialize(bytes);

        assertEquals(renderer, deserialized);
    }

    @Test
    void testDrawItem_MinimumBarLength() {
        when(state.getBarWidth()).thenReturn(5.0);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(0.5); // Below minimum bar length
        when(dataset.getRowCount()).thenReturn(1);
        when(renderer.getPositiveBarPaint()).thenReturn(Color.GREEN);
        when(rangeAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(10.0, 10.5);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        ArgumentCaptor<Rectangle2D> captor = ArgumentCaptor.forClass(Rectangle2D.class);
        verify(g2).fill(captor.capture());
        Rectangle2D bar = captor.getValue();
        assertTrue(bar.getHeight() >= renderer.getMinimumBarLength());
    }

    @Test
    void testDrawItem_NoOutlinePaintAndStroke() {
        when(state.getBarWidth()).thenReturn(5.0);
        when(renderer.getItemOutlineStroke(0, 1)).thenReturn(null);
        when(renderer.getItemOutlinePaint(0, 1)).thenReturn(null);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(100.0);
        when(dataset.getRowCount()).thenReturn(1);
        when(renderer.getPositiveBarPaint()).thenReturn(Color.GREEN);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(g2, never()).setStroke(any());
        verify(g2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    void testDrawItem_DrawBarOutlineFalse() {
        renderer.setDrawBarOutline(false);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(100.0);
        when(dataset.getRowCount()).thenReturn(1);
        when(renderer.getPositiveBarPaint()).thenReturn(Color.GREEN);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(g2, never()).setStroke(any());
        verify(g2, never()).draw(any(Rectangle2D.class));
    }
}