package org.apache.commons.lang3;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ClassUtils_isAssignable_0_4_Test {

    @Test
    @DisplayName("autoboxing is true, cls is wrapper, toClass is primitive, but conversion returns null; expect false")
    void TC16_autoboxing_true_wrapper_to_primitive_conversion_null() {
        // GIVEN
        Class<?> cls = Void.class;
        Class<?> toClass = boolean.class;
        boolean autoboxing = true;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("cls is non-primitive, toClass is assignable via inheritance; expect true")
    void TC17_nonPrimitive_assignable_via_inheritance() {
        // GIVEN
        Class<?> cls = java.util.ArrayList.class;
        Class<?> toClass = java.util.List.class;
        boolean autoboxing = false;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("cls is non-primitive, toClass is assignable via isAssignableFrom; expect true")
    void TC18_nonPrimitive_isAssignableFrom() {
        // GIVEN
        Class<?> cls = String.class;
        Class<?> toClass = Object.class;
        boolean autoboxing = false;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertTrue(toClass.isAssignableFrom(cls));
    }

    @Test
    @DisplayName("cls is non-primitive, toClass is not assignable via any direct checks; expect false")
    void TC19_nonPrimitive_notAssignable() {
        // GIVEN
        Class<?> cls = String.class;
        Class<?> toClass = StringBuilder.class;
        boolean autoboxing = false;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("cls is primitive, autoboxing is true, and cls is assignable after conversion; expect true")
    void TC20_cls_primitive_autoboxing_true_assignable_after_conversion() {
        // GIVEN
        Class<?> cls = short.class;
        Class<?> toClass = Number.class;
        boolean autoboxing = true;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertTrue(result);
    }
}
