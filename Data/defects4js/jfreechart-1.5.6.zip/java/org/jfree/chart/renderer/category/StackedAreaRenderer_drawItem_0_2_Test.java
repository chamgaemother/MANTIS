package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Method;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.DatasetUtils;
import org.jfree.data.DataUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class StackedAreaRenderer_drawItem_0_2_Test {

    @Test
    @DisplayName("TC06: Draw item with visible series, non-null dataset value, do not render as percentages, and y1 >= 0")
    void testTC06() throws Exception {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer();
        // Reflectively set the private field if necessary
        Method setSeriesVisible = StackedAreaRenderer.class.getDeclaredMethod("setSeriesVisible", int.class, boolean.class);
        setSeriesVisible.setAccessible(true);
        setSeriesVisible.invoke(renderer, 0, true);
        
        renderer.setRenderAsPercentages(false);
        
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getValue(0, 1)).thenReturn(50);
        when(dataset.getValue(0, 0)).thenReturn(30);
        when(dataset.getValue(0, 2)).thenReturn(20);
        
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        
        int row = 0;
        int column = 1;
        int pass = 0;
        
        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        
        // THEN
        verify(g2, atLeastOnce()).setPaint(any());
    }

    @Test
    @DisplayName("TC07: Draw item with visible series, non-null dataset value, do not render as percentages, and y1 < 0")
    void testTC07() throws Exception {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer();
        Method setSeriesVisible = StackedAreaRenderer.class.getDeclaredMethod("setSeriesVisible", int.class, boolean.class);
        setSeriesVisible.setAccessible(true);
        setSeriesVisible.invoke(renderer, 0, true);
        
        renderer.setRenderAsPercentages(false);
        
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getValue(0, 1)).thenReturn(-50);
        when(dataset.getValue(0, 0)).thenReturn(-30);
        when(dataset.getValue(0, 2)).thenReturn(-20);
        
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        
        int row = 0;
        int column = 1;
        int pass = 0;
        
        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        
        // THEN
        verify(g2, atLeastOnce()).setPaint(any());
    }

    @Test
    @DisplayName("TC08: Draw item with dataset.getValue(row, column-1) not null and render as percentages")
    void testTC08() throws Exception {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer();
        Method setSeriesVisible = StackedAreaRenderer.class.getDeclaredMethod("setSeriesVisible", int.class, boolean.class);
        setSeriesVisible.setAccessible(true);
        setSeriesVisible.invoke(renderer, 0, true);
        
        renderer.setRenderAsPercentages(true);
        
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getValue(0, 1)).thenReturn(50);
        when(dataset.getValue(0, 0)).thenReturn(30);
        
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        when(state.getVisibleSeriesArray()).thenReturn(new int[]{0});
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        
        when(DataUtils.calculateColumnTotal(dataset, 1, state.getVisibleSeriesArray())).thenReturn(100.0);
        when(DataUtils.calculateColumnTotal(dataset, 0, state.getVisibleSeriesArray())).thenReturn(60.0);
        
        int row = 0;
        int column = 1;
        int pass = 0;
        
        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        
        // THEN
        verify(dataset, times(2)).getValue(anyInt(), anyInt());
        verify(rangeAxis, atLeastOnce()).valueToJava2D(anyDouble(), any(Rectangle2D.class), any());
    }

    @Test
    @DisplayName("TC09: Draw item with dataset.getValue(row, column+1) not null and render as percentages")
    void testTC09() throws Exception {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer();
        Method setSeriesVisible = StackedAreaRenderer.class.getDeclaredMethod("setSeriesVisible", int.class, boolean.class);
        setSeriesVisible.setAccessible(true);
        setSeriesVisible.invoke(renderer, 0, true);
        
        renderer.setRenderAsPercentages(true);
        
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getValue(0, 1)).thenReturn(50);
        when(dataset.getValue(0, 2)).thenReturn(20);
        
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        when(state.getVisibleSeriesArray()).thenReturn(new int[]{0});
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        
        when(DataUtils.calculateColumnTotal(dataset, 1, state.getVisibleSeriesArray())).thenReturn(100.0);
        when(DataUtils.calculateColumnTotal(dataset, 2, state.getVisibleSeriesArray())).thenReturn(80.0);
        
        int row = 0;
        int column = 1;
        int pass = 0;
        
        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        
        // THEN
        verify(dataset, times(2)).getValue(anyInt(), anyInt());
        verify(rangeAxis, atLeastOnce()).valueToJava2D(anyDouble(), any(Rectangle2D.class), any());
    }

    @Test
    @DisplayName("TC10: Draw item with all dataset values non-null and render as percentages")
    void testTC10() throws Exception {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer();
        Method setSeriesVisible = StackedAreaRenderer.class.getDeclaredMethod("setSeriesVisible", int.class, boolean.class);
        setSeriesVisible.setAccessible(true);
        setSeriesVisible.invoke(renderer, 0, true);
        
        renderer.setRenderAsPercentages(true);
        
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getValue(0, 1)).thenReturn(50);
        
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        when(state.getVisibleSeriesArray()).thenReturn(new int[]{0});
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        
        when(DataUtils.calculateColumnTotal(dataset, 1, state.getVisibleSeriesArray())).thenReturn(100.0);
        when(dataset.getValue(0, 0)).thenReturn(30);
        when(DataUtils.calculateColumnTotal(dataset, 0, state.getVisibleSeriesArray())).thenReturn(60.0);
        when(dataset.getValue(0, 2)).thenReturn(20);
        when(DataUtils.calculateColumnTotal(dataset, 2, state.getVisibleSeriesArray())).thenReturn(80.0);
        
        int row = 0;
        int column = 1;
        int pass = 0;
        
        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        
        // THEN
        verify(dataset, times(3)).getValue(anyInt(), anyInt());
        verify(rangeAxis, atLeastOnce()).valueToJava2D(anyDouble(), any(Rectangle2D.class), any());
    }
}