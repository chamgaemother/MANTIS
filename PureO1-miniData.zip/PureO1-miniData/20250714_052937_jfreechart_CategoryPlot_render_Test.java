import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryCrosshairState;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.DatasetChangeEvent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.ArgumentCaptor;

@ExtendWith(MockitoExtension.class)
public class CategoryPlotTest {

    @Mock
    private Graphics2D g2Mock;

    @Mock
    private CategoryDataset datasetMock;

    @Mock
    private CategoryItemRenderer rendererMock;

    @Mock
    private PlotRenderingInfo plotRenderingInfoMock;

    @Mock
    private CategoryCrosshairState crosshairStateMock;

    @Mock
    private ValueAxis rangeAxisMock;

    @Mock
    private CategoryAxis domainAxisMock;

    @Captor
    private ArgumentCaptor<Double> doubleCaptor;

    private CategoryPlot plot;

    @BeforeEach
    public void setUp() {
        plot = new CategoryPlot();
    }

    @Test
    public void testRender_NullDataset() {
        plot.setDataset(0, null);
        plot.setRenderer(0, rendererMock);

        boolean result = plot.render(g2Mock, new Rectangle2D.Double(), 0, plotRenderingInfoMock, crosshairStateMock);
        assertFalse(result);
        verifyNoInteractions(rendererMock);
    }

    @Test
    public void testRender_EmptyDataset() {
        when(datasetMock.getColumnCount()).thenReturn(0);
        when(datasetMock.getRowCount()).thenReturn(0);
        plot.setDataset(0, datasetMock);
        plot.setRenderer(0, rendererMock);
        doReturn(true).when(rendererMock).hasData(any());

        when(rendererMock.hasData(datasetMock)).thenReturn(false);

        boolean result = plot.render(g2Mock, new Rectangle2D.Double(), 0, plotRenderingInfoMock, crosshairStateMock);
        assertFalse(result);
        verify(rendererMock, times(0)).initialize(any(), any(), any(), anyInt(), any());
    }

    @Test
    public void testRender_HasData_RendererNull() {
        when(datasetMock.getColumnCount()).thenReturn(2);
        when(datasetMock.getRowCount()).thenReturn(2);
        plot.setDataset(0, datasetMock);
        plot.setRenderer(0, null);

        when(rendererMock.hasData(datasetMock)).thenReturn(true);

        boolean result = plot.render(g2Mock, new Rectangle2D.Double(), 0, plotRenderingInfoMock, crosshairStateMock);
        assertFalse(result);
        verify(rendererMock, times(0)).initialize(any(), any(), any(), anyInt(), any());
    }

    @Test
    public void testRender_HasData_RendererNotNull_ASCENDING_ASCENDING_Pass1() {
        when(datasetMock.getColumnCount()).thenReturn(2);
        when(datasetMock.getRowCount()).thenReturn(2);
        plot.setDataset(0, datasetMock);
        plot.setRenderer(0, rendererMock);
        plot.setColumnRenderingOrder(org.jfree.chart.util.SortOrder.ASCENDING);
        plot.setRowRenderingOrder(org.jfree.chart.util.SortOrder.ASCENDING);
        when(rendererMock.getPassCount()).thenReturn(1);
        when(rendererMock.hasData(datasetMock)).thenReturn(true);

        boolean result = plot.render(g2Mock, new Rectangle2D.Double(), 0, plotRenderingInfoMock, crosshairStateMock);
        assertTrue(result);
        verify(rendererMock, times(4)).drawItem(any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), anyInt());
    }

    @Test
    public void testRender_HasData_RendererNotNull_ASCENDING_DESCENDING_Pass1() {
        when(datasetMock.getColumnCount()).thenReturn(2);
        when(datasetMock.getRowCount()).thenReturn(2);
        plot.setDataset(0, datasetMock);
        plot.setRenderer(0, rendererMock);
        plot.setColumnRenderingOrder(org.jfree.chart.util.SortOrder.ASCENDING);
        plot.setRowRenderingOrder(org.jfree.chart.util.SortOrder.DESCENDING);
        when(rendererMock.getPassCount()).thenReturn(1);
        when(rendererMock.hasData(datasetMock)).thenReturn(true);

        boolean result = plot.render(g2Mock, new Rectangle2D.Double(), 0, plotRenderingInfoMock, crosshairStateMock);
        assertTrue(result);
        verify(rendererMock, times(4)).drawItem(any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), anyInt());
    }

    @Test
    public void testRender_HasData_RendererNotNull_DESCENDING_ASCENDING_Pass1() {
        when(datasetMock.getColumnCount()).thenReturn(2);
        when(datasetMock.getRowCount()).thenReturn(2);
        plot.setDataset(0, datasetMock);
        plot.setRenderer(0, rendererMock);
        plot.setColumnRenderingOrder(org.jfree.chart.util.SortOrder.DESCENDING);
        plot.setRowRenderingOrder(org.jfree.chart.util.SortOrder.ASCENDING);
        when(rendererMock.getPassCount()).thenReturn(1);
        when(rendererMock.hasData(datasetMock)).thenReturn(true);

        boolean result = plot.render(g2Mock, new Rectangle2D.Double(), 0, plotRenderingInfoMock, crosshairStateMock);
        assertTrue(result);
        verify(rendererMock, times(4)).drawItem(any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), anyInt());
    }

    @Test
    public void testRender_HasData_RendererNotNull_DESCENDING_DESCENDING_Pass1() {
        when(datasetMock.getColumnCount()).thenReturn(2);
        when(datasetMock.getRowCount()).thenReturn(2);
        plot.setDataset(0, datasetMock);
        plot.setRenderer(0, rendererMock);
        plot.setColumnRenderingOrder(org.jfree.chart.util.SortOrder.DESCENDING);
        plot.setRowRenderingOrder(org.jfree.chart.util.SortOrder.DESCENDING);
        when(rendererMock.getPassCount()).thenReturn(1);
        when(rendererMock.hasData(datasetMock)).thenReturn(true);

        boolean result = plot.render(g2Mock, new Rectangle2D.Double(), 0, plotRenderingInfoMock, crosshairStateMock);
        assertTrue(result);
        verify(rendererMock, times(4)).drawItem(any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), anyInt());
    }

    @Test
    public void testRender_HasData_RendererNotNull_ASCENDING_ASCENDING_PassMultiple() {
        when(datasetMock.getColumnCount()).thenReturn(2);
        when(datasetMock.getRowCount()).thenReturn(2);
        plot.setDataset(0, datasetMock);
        plot.setRenderer(0, rendererMock);
        plot.setColumnRenderingOrder(org.jfree.chart.util.SortOrder.ASCENDING);
        plot.setRowRenderingOrder(org.jfree.chart.util.SortOrder.ASCENDING);
        when(rendererMock.getPassCount()).thenReturn(2);
        when(rendererMock.hasData(datasetMock)).thenReturn(true);

        boolean result = plot.render(g2Mock, new Rectangle2D.Double(), 0, plotRenderingInfoMock, crosshairStateMock);
        assertTrue(result);
        verify(rendererMock, times(8)).drawItem(any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), anyInt());
    }

    @Test
    public void testRender_HasData_RendererNotNull_NoPasses() {
        when(datasetMock.getColumnCount()).thenReturn(2);
        when(datasetMock.getRowCount()).thenReturn(2);
        plot.setDataset(0, datasetMock);
        plot.setRenderer(0, rendererMock);
        when(rendererMock.getPassCount()).thenReturn(0);
        when(rendererMock.hasData(datasetMock)).thenReturn(true);

        boolean result = plot.render(g2Mock, new Rectangle2D.Double(), 0, plotRenderingInfoMock, crosshairStateMock);
        assertTrue(result);
        verify(rendererMock, times(0)).drawItem(any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), anyInt());
    }

    @Test
    public void testRender_HasData_RendererNotNull_SingleRowColumn() {
        when(datasetMock.getColumnCount()).thenReturn(1);
        when(datasetMock.getRowCount()).thenReturn(1);
        plot.setDataset(0, datasetMock);
        plot.setRenderer(0, rendererMock);
        plot.setColumnRenderingOrder(org.jfree.chart.util.SortOrder.ASCENDING);
        plot.setRowRenderingOrder(org.jfree.chart.util.SortOrder.ASCENDING);
        when(rendererMock.getPassCount()).thenReturn(1);
        when(rendererMock.hasData(datasetMock)).thenReturn(true);

        boolean result = plot.render(g2Mock, new Rectangle2D.Double(), 0, plotRenderingInfoMock, crosshairStateMock);
        assertTrue(result);
        verify(rendererMock, times(1)).drawItem(any(), any(), any(), any(), any(), any(), any(), eq(0), eq(0), eq(0));
    }

    @Test
    public void testRender_HasData_RendererNotNull_MinimumColumnsRows() {
        when(datasetMock.getColumnCount()).thenReturn(0);
        when(datasetMock.getRowCount()).thenReturn(2);
        plot.setDataset(0, datasetMock);
        plot.setRenderer(0, rendererMock);
        when(rendererMock.hasData(datasetMock)).thenReturn(false);

        boolean result = plot.render(g2Mock, new Rectangle2D.Double(), 0, plotRenderingInfoMock, crosshairStateMock);
        assertFalse(result);
        verify(rendererMock, times(0)).drawItem(any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), anyInt());
    }

    @Test
    public void testRender_HasData_RendererNotNull_CrosshairStateNull() {
        when(datasetMock.getColumnCount()).thenReturn(2);
        when(datasetMock.getRowCount()).thenReturn(2);
        plot.setDataset(0, datasetMock);
        plot.setRenderer(0, rendererMock);
        plot.setColumnRenderingOrder(org.jfree.chart.util.SortOrder.ASCENDING);
        plot.setRowRenderingOrder(org.jfree.chart.util.SortOrder.ASCENDING);
        when(rendererMock.getPassCount()).thenReturn(1);
        when(rendererMock.hasData(datasetMock)).thenReturn(true);

        boolean result = plot.render(g2Mock, new Rectangle2D.Double(), 0, plotRenderingInfoMock, null);
        assertTrue(result);
        verify(rendererMock, times(4)).drawItem(any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), anyInt());
    }

    @Test
    public void testRender_HasData_RendererNotNull_RendererThrowsException() {
        when(datasetMock.getColumnCount()).thenReturn(2);
        when(datasetMock.getRowCount()).thenReturn(2);
        when(datasetMock.getColumnKey(anyInt())).thenReturn("Category");
        plot.setDataset(0, datasetMock);
        plot.setRenderer(0, rendererMock);
        plot.setColumnRenderingOrder(org.jfree.chart.util.SortOrder.ASCENDING);
        plot.setRowRenderingOrder(org.jfree.chart.util.SortOrder.ASCENDING);
        when(rendererMock.getPassCount()).thenReturn(1);
        when(rendererMock.hasData(datasetMock)).thenReturn(true);
        doThrow(new RuntimeException("Renderer exception")).when(rendererMock).drawItem(any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), anyInt());

        assertThrows(RuntimeException.class, () -> {
            plot.render(g2Mock, new Rectangle2D.Double(), 0, plotRenderingInfoMock, crosshairStateMock);
        });
        verify(rendererMock, times(1)).drawItem(any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), anyInt());
    }

}