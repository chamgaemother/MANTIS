java
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Collections;

import org.apache.commons.compress.harmony.unpack200.IcBands;
import org.apache.commons.compress.harmony.unpack200.IcTuple;
import org.apache.commons.compress.harmony.unpack200.Segment;
import org.apache.commons.compress.harmony.unpack200.bytecode.ClassConstantPool;
import org.apache.commons.compress.harmony.unpack200.bytecode.ConstantPoolEntry;
import org.apache.commons.compress.harmony.unpack200.bytecode.CPClass;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class IcBandsTest {

    private Segment mockSegment;
    private IcBands icBands;
    private ClassConstantPool mockClassConstantPool;

    @BeforeEach
    public void setUp() throws Exception {
        mockSegment = mock(Segment.class);
        when(mockSegment.getCpBands()).thenReturn(mock(CpBands.class));

        // Mock CpBands
        CpBands mockCpBands = mock(CpBands.class);
        when(mockCpBands.getCpClass()).thenReturn(new String[] { "com/example/Outer", "com/example/Inner" });
        when(mockCpBands.getCpUTF8()).thenReturn(new String[] { "InnerName" });
        when(mockSegment.getCpBands()).thenReturn(mockCpBands);

        icBands = new IcBands(mockSegment);

        mockClassConstantPool = mock(ClassConstantPool.class);
    }

    @Test
    public void testGetRelevantIcTuples_NullClassName() {
        assertThrows(NullPointerException.class, () -> {
            icBands.getRelevantIcTuples(null, mockClassConstantPool);
        });
    }

    @Test
    public void testGetRelevantIcTuples_NullClassConstantPool() {
        assertThrows(NullPointerException.class, () -> {
            icBands.getRelevantIcTuples("com/example/Outer", null);
        });
    }

    @Test
    public void testGetRelevantIcTuples_NoRelevantCandidates() throws Exception {
        icBands.read(new ByteArrayInputStream(new byte[0]));
        icBands.unpack();

        when(icBands.getIcTuples()).thenReturn(new IcTuple[0]);

        IcTuple[] result = icBands.getRelevantIcTuples("com/example/Unknown", mockClassConstantPool);
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    @Test
    public void testGetRelevantIcTuples_WithRelevantCandidates() throws Exception {
        IcTuple tuple = mock(IcTuple.class);
        when(tuple.getTupleIndex()).thenReturn(1);
        when(tuple.thisClassString()).thenReturn("com/example/Outer");
        when(tuple.outerClassString()).thenReturn("com/example/Inner");
        when(tuple.outerIsAnonymous()).thenReturn(false);

        icBands.read(new ByteArrayInputStream(new byte[0]));
        icBands.unpack();

        icBands.thisClassToTuple = Collections.singletonMap("com/example/Outer", tuple);
        icBands.outerClassToTuples = Collections.singletonMap("com/example/Outer", Arrays.asList(tuple));
        icBands.icAll = new IcTuple[] { tuple };

        ConstantPoolEntry cpClassEntry = mock(CPClass.class);
        when(cpClassEntry.getName()).thenReturn("com/example/Outer");
        when(mockClassConstantPool.entries()).thenReturn(Arrays.asList(cpClassEntry));

        IcTuple[] result = icBands.getRelevantIcTuples("com/example/Outer", mockClassConstantPool);
        assertNotNull(result);
        assertEquals(1, result.length);
        assertEquals(tuple, result[0]);
    }

    @Test
    public void testGetRelevantIcTuples_CPEntriesEmpty() throws Exception {
        icBands.read(new ByteArrayInputStream(new byte[0]));
        icBands.unpack();

        IcTuple tuple = mock(IcTuple.class);
        icBands.icAll = new IcTuple[] { tuple };
        icBands.thisClassToTuple = Collections.emptyMap();
        icBands.outerClassToTuples = Collections.emptyMap();

        when(mockClassConstantPool.entries()).thenReturn(Collections.emptyList());

        IcTuple[] result = icBands.getRelevantIcTuples("com/example/Outer", mockClassConstantPool);
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    @Test
    public void testGetRelevantIcTuples_CPEntriesNoCPClass() throws Exception {
        icBands.read(new ByteArrayInputStream(new byte[0]));
        icBands.unpack();

        ConstantPoolEntry entry = mock(ConstantPoolEntry.class);
        when(mockClassConstantPool.entries()).thenReturn(Arrays.asList(entry));

        IcTuple[] result = icBands.getRelevantIcTuples("com/example/Outer", mockClassConstantPool);
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    @Test
    public void testGetRelevantIcTuples_CPEntriesWithCPClassInThisClassToTuple() throws Exception {
        IcTuple tuple = mock(IcTuple.class);
        when(tuple.getTupleIndex()).thenReturn(0);
        when(tuple.thisClassString()).thenReturn("com/example/Outer");

        icBands.icAll = new IcTuple[] { tuple };
        icBands.thisClassToTuple = Collections.singletonMap("com/example/Outer", tuple);
        icBands.outerClassToTuples = Collections.emptyMap();

        CPClass cpClass = mock(CPClass.class);
        when(cpClass.name).thenReturn("com/example/Outer");
        when(mockClassConstantPool.entries()).thenReturn(Arrays.asList(cpClass));

        IcTuple[] result = icBands.getRelevantIcTuples("com/example/Outer", mockClassConstantPool);
        assertNotNull(result);
        assertEquals(1, result.length);
        assertEquals(tuple, result[0]);
    }

    @Test
    public void testGetRelevantIcTuples_FixUpAddsParentTuples() throws Exception {
        IcTuple parentTuple = mock(IcTuple.class);
        when(parentTuple.getTupleIndex()).thenReturn(0);
        when(parentTuple.thisClassString()).thenReturn("com/example/Parent");
        when(parentTuple.outerClassString()).thenReturn("com/example/GrandParent");
        when(parentTuple.outerIsAnonymous()).thenReturn(false);

        IcTuple childTuple = mock(IcTuple.class);
        when(childTuple.getTupleIndex()).thenReturn(1);
        when(childTuple.thisClassString()).thenReturn("com/example/Child");
        when(childTuple.outerClassString()).thenReturn("com/example/Parent");
        when(childTuple.outerIsAnonymous()).thenReturn(false);

        icBands.icAll = new IcTuple[] { parentTuple, childTuple };
        icBands.thisClassToTuple = new java.util.HashMap<>();
        icBands.thisClassToTuple.put("com/example/Parent", parentTuple);
        icBands.thisClassToTuple.put("com/example/Child", childTuple);
        icBands.outerClassToTuples = Collections.singletonMap("com/example/Parent", Arrays.asList(childTuple));

        CPClass cpClass = mock(CPClass.class);
        when(cpClass.name).thenReturn("com/example/Child");
        when(mockClassConstantPool.entries()).thenReturn(Arrays.asList(cpClass));

        IcTuple grandParentTuple = mock(IcTuple.class);
        when(grandParentTuple.getTupleIndex()).thenReturn(-1);
        when(grandParentTuple.thisClassString()).thenReturn("com/example/GrandParent");
        when(grandParentTuple.outerClassString()).thenReturn(null);
        when(grandParentTuple.outerIsAnonymous()).thenReturn(false);

        // Adding grand parent to thisClassToTuple
        icBands.thisClassToTuple.put("com/example/GrandParent", grandParentTuple);

        IcTuple[] result = icBands.getRelevantIcTuples("com/example/Parent", mockClassConstantPool);
        assertNotNull(result);
        // Should include parentTuple, childTuple, and grandParentTuple
        assertEquals(3, result.length);
        assertArrayEquals(new IcTuple[] { parentTuple, childTuple, grandParentTuple }, result);
    }

    @Test
    public void testGetRelevantIcTuples_OuterIsAnonymous() throws Exception {
        IcTuple tuple = mock(IcTuple.class);
        when(tuple.getTupleIndex()).thenReturn(1);
        when(tuple.thisClassString()).thenReturn("com/example/Outer$1");
        when(tuple.outerClassString()).thenReturn("com/example/Outer");
        when(tuple.outerIsAnonymous()).thenReturn(true);

        icBands.icAll = new IcTuple[] { tuple };
        icBands.thisClassToTuple = Collections.singletonMap("com/example/Outer$1", tuple);
        icBands.outerClassToTuples = Collections.singletonMap("com/example/Outer", Arrays.asList(tuple));

        ConstantPoolEntry cpClass = mock(CPClass.class);
        when(cpClass.name).thenReturn("com/example/Outer");
        when(mockClassConstantPool.entries()).thenReturn(Arrays.asList(cpClass));

        IcTuple[] result = icBands.getRelevantIcTuples("com/example/Outer", mockClassConstantPool);
        assertNotNull(result);
        // Since outer is anonymous, it should not add parent
        assertEquals(1, result.length);
        assertEquals(tuple, result[0]);
    }

    @Test
    public void testGetRelevantIcTuples_TuplesToAddAlreadyPresent() throws Exception {
        IcTuple tuple = mock(IcTuple.class);
        when(tuple.getTupleIndex()).thenReturn(0);
        when(tuple.thisClassString()).thenReturn("com/example/Outer");
        when(tuple.outerClassString()).thenReturn(null);
        when(tuple.outerIsAnonymous()).thenReturn(false);

        icBands.icAll = new IcTuple[] { tuple };
        icBands.thisClassToTuple = Collections.singletonMap("com/example/Outer", tuple);
        icBands.outerClassToTuples = Collections.singletonMap("com/example/Outer", Arrays.asList(tuple));

        CPClass cpClass = mock(CPClass.class);
        when(cpClass.name()).thenReturn("com/example/Outer");
        when(mockClassConstantPool.entries()).thenReturn(Arrays.asList(cpClass));

        IcTuple[] result = icBands.getRelevantIcTuples("com/example/Outer", mockClassConstantPool);
        assertNotNull(result);
        assertEquals(1, result.length);
        assertEquals(tuple, result[0]);
    }

    @Test
    public void testGetRelevantIcTuples_SortOrder() throws Exception {
        IcTuple tuple1 = mock(IcTuple.class);
        when(tuple1.getTupleIndex()).thenReturn(2);
        when(tuple1.thisClassString()).thenReturn("com/example/Outer$2");
        when(tuple1.outerClassString()).thenReturn("com/example/Outer");
        when(tuple1.outerIsAnonymous()).thenReturn(false);

        IcTuple tuple2 = mock(IcTuple.class);
        when(tuple2.getTupleIndex()).thenReturn(1);
        when(tuple2.thisClassString()).thenReturn("com/example/Outer$1");
        when(tuple2.outerClassString()).thenReturn("com/example/Outer");
        when(tuple2.outerIsAnonymous()).thenReturn(false);

        icBands.icAll = new IcTuple[] { tuple1, tuple2 };
        icBands.thisClassToTuple = new java.util.HashMap<>();
        icBands.thisClassToTuple.put("com/example/Outer$1", tuple2);
        icBands.thisClassToTuple.put("com/example/Outer$2", tuple1);
        icBands.outerClassToTuples = Collections.singletonMap("com/example/Outer", Arrays.asList(tuple1, tuple2));

        CPClass cpClass1 = mock(CPClass.class);
        when(cpClass1.name()).thenReturn("com/example/Outer$1");
        CPClass cpClass2 = mock(CPClass.class);
        when(cpClass2.name()).thenReturn("com/example/Outer$2");
        when(mockClassConstantPool.entries()).thenReturn(Arrays.asList(cpClass1, cpClass2));

        IcTuple[] result = icBands.getRelevantIcTuples("com/example/Outer", mockClassConstantPool);
        assertNotNull(result);
        assertEquals(2, result.length);
        assertEquals(tuple2, result[0]);
        assertEquals(tuple1, result[1]);
    }

    @Test
    public void testGetRelevantIcTuples_MultipleOuterClasses() throws Exception {
        IcTuple tuple1 = mock(IcTuple.class);
        when(tuple1.getTupleIndex()).thenReturn(0);
        when(tuple1.thisClassString()).thenReturn("com/example/Outer1");
        when(tuple1.outerClassString()).thenReturn(null);
        when(tuple1.outerIsAnonymous()).thenReturn(false);

        IcTuple tuple2 = mock(IcTuple.class);
        when(tuple2.getTupleIndex()).thenReturn(1);
        when(tuple2.thisClassString()).thenReturn("com/example/Outer2");
        when(tuple2.outerClassString()).thenReturn(null);
        when(tuple2.outerIsAnonymous()).thenReturn(false);

        icBands.icAll = new IcTuple[] { tuple1, tuple2 };
        icBands.thisClassToTuple = new java.util.HashMap<>();
        icBands.thisClassToTuple.put("com/example/Outer1", tuple1);
        icBands.thisClassToTuple.put("com/example/Outer2", tuple2);
        icBands.outerClassToTuples = new java.util.HashMap<>();
        icBands.outerClassToTuples.put("com/example/Outer1", Arrays.asList(tuple1));
        icBands.outerClassToTuples.put("com/example/Outer2", Arrays.asList(tuple2));

        CPClass cpClass1 = mock(CPClass.class);
        when(cpClass1.name()).thenReturn("com/example/Outer1");
        CPClass cpClass2 = mock(CPClass.class);
        when(cpClass2.name()).thenReturn("com/example/Outer2");
        when(mockClassConstantPool.entries()).thenReturn(Arrays.asList(cpClass1, cpClass2));

        IcTuple[] result1 = icBands.getRelevantIcTuples("com/example/Outer1", mockClassConstantPool);
        assertNotNull(result1);
        assertEquals(1, result1.length);
        assertEquals(tuple1, result1[0]);

        IcTuple[] result2 = icBands.getRelevantIcTuples("com/example/Outer2", mockClassConstantPool);
        assertNotNull(result2);
        assertEquals(1, result2.length);
        assertEquals(tuple2, result2[0]);
    }

    @Test
    public void testGetRelevantIcTuples_DuplicateTuples() throws Exception {
        IcTuple tuple = mock(IcTuple.class);
        when(tuple.getTupleIndex()).thenReturn(0);
        when(tuple.thisClassString()).thenReturn("com/example/Outer");
        when(tuple.outerClassString()).thenReturn(null);
        when(tuple.outerIsAnonymous()).thenReturn(false);

        icBands.icAll = new IcTuple[] { tuple, tuple };
        icBands.thisClassToTuple = Collections.singletonMap("com/example/Outer", tuple);
        icBands.outerClassToTuples = Collections.singletonMap("com/example/Outer", Arrays.asList(tuple, tuple));

        CPClass cpClass = mock(CPClass.class);
        when(cpClass.name()).thenReturn("com/example/Outer");
        when(mockClassConstantPool.entries()).thenReturn(Arrays.asList(cpClass, cpClass));

        IcTuple[] result = icBands.getRelevantIcTuples("com/example/Outer", mockClassConstantPool);
        assertNotNull(result);
        // Despite duplicates, set should contain only one
        assertEquals(1, result.length);
        assertEquals(tuple, result[0]);
    }
}