package org.jfree.chart.renderer.xy;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYBubbleRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.XYZDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class XYBubbleRenderer_drawItem_0_3_Test {

    @Test
    @DisplayName("drawItem draws item label in HORIZONTAL orientation when label is visible")
    public void TC11() throws Exception {
        // GIVEN
        XYBubbleRenderer renderer = spy(new XYBubbleRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getYValue(series, item)).thenReturn(2.0);
        when(dataset.getZValue(series, item)).thenReturn(3.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(renderer.isItemLabelVisible(series, item)).thenReturn(true);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        // Verify that drawItemLabel is called with HORIZONTAL orientation
        verify(renderer, times(1)).drawItemLabel(g2, PlotOrientation.HORIZONTAL, dataset, series, item, anyDouble(), anyDouble(), eq(false));
    }

//     @Test
//     @DisplayName("drawItem adds entity when info and entities are present and circle intersects dataArea")
//     public void TC12() throws Exception {
        // GIVEN
//         XYBubbleRenderer renderer = spy(new XYBubbleRenderer());
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYZDataset dataset = mock(XYZDataset.class);
//         int series = 0;
//         int item = 0;
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int pass = 0;
// 
//         when(renderer.getItemVisible(series, item)).thenReturn(true);
//         when(dataset.getXValue(series, item)).thenReturn(1.0);
//         when(dataset.getYValue(series, item)).thenReturn(2.0);
//         when(dataset.getZValue(series, item)).thenReturn(3.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(renderer.getScaleType()).thenReturn(XYBubbleRenderer.SCALE_ON_DOMAIN_AXIS);
//         when(info.getOwner()).thenReturn(plot);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
// 
//         doNothing().when(renderer).addEntity(entities, any(), eq(dataset), eq(series), eq(item), anyDouble(), anyDouble());
// 
        // WHEN
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
        // THEN
        // Verify that addEntity is called because circle intersects dataArea
//         verify(renderer, times(1)).addEntity(any(), any(), eq(dataset), eq(series), eq(item), anyDouble(), anyDouble());
//     }

//     @Test
//     @DisplayName("drawItem does not add entity when circle does not intersect dataArea")
//     public void TC13() throws Exception {
        // GIVEN
//         XYBubbleRenderer renderer = spy(new XYBubbleRenderer());
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 10, 10);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYZDataset dataset = mock(XYZDataset.class);
//         int series = 0;
//         int item = 0;
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int pass = 0;
// 
//         when(renderer.getItemVisible(series, item)).thenReturn(true);
//         when(dataset.getXValue(series, item)).thenReturn(1.0);
//         when(dataset.getYValue(series, item)).thenReturn(2.0);
//         when(dataset.getZValue(series, item)).thenReturn(3.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(renderer.getScaleType()).thenReturn(XYBubbleRenderer.SCALE_ON_DOMAIN_AXIS);
//         when(info.getOwner()).thenReturn(plot);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
//         doNothing().when(renderer).addEntity(entities, any(), eq(dataset), eq(series), eq(item), anyDouble(), anyDouble());
// 
        // WHEN
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
        // THEN
        // Verify that addEntity is NOT called
//         verify(renderer, never()).addEntity(any(), any(), eq(dataset), eq(series), eq(item), anyDouble(), anyDouble());
//     }

    @Test
    @DisplayName("drawItem does not add entity when info is null")
    public void TC14() {
        // GIVEN
        XYBubbleRenderer renderer = spy(new XYBubbleRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = null;
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getYValue(series, item)).thenReturn(2.0);
        when(dataset.getZValue(series, item)).thenReturn(3.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // WHEN
        assertDoesNotThrow(() -> renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass));

        // THEN
        // No entity should be added since info is null
    }

    @Test
    @DisplayName("drawItem updates crosshair values correctly")
    public void TC15() throws Exception {
        // GIVEN
        XYBubbleRenderer renderer = spy(new XYBubbleRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getYValue(series, item)).thenReturn(2.0);
        when(dataset.getZValue(series, item)).thenReturn(3.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getScaleType()).thenReturn(XYBubbleRenderer.SCALE_ON_DOMAIN_AXIS);
        when(plot.indexOf(dataset)).thenReturn(0);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        // Verify updateCrosshairValues is called
        verify(renderer, times(1)).updateCrosshairValues(eq(crosshairState), eq(1.0), eq(2.0), eq(0), anyDouble(), anyDouble(), eq(PlotOrientation.VERTICAL));
    }

}