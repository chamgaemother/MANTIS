package org.jfree.chart.labels;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;

import static org.junit.jupiter.api.Assertions.*;

class ItemLabelAnchorTest {

    @Nested
    @DisplayName("isInternal Tests for Internal Anchors")
    class InternalAnchorsTests {

        @ParameterizedTest(name = "{0} should be internal")
        @MethodSource("org.jfree.chart.labels.ItemLabelAnchorTest.InternalAnchorsTests#internalAnchorsProvider")
        void testIsInternal_ShouldReturnTrue(ItemLabelAnchor anchor) {
            assertTrue(anchor.isInternal(), anchor.toString() + " should be internal");
        }

        static java.util.stream.Stream<ItemLabelAnchor> internalAnchorsProvider() {
            return java.util.stream.Stream.of(
                ItemLabelAnchor.CENTER,
                ItemLabelAnchor.INSIDE1,
                ItemLabelAnchor.INSIDE2,
                ItemLabelAnchor.INSIDE3,
                ItemLabelAnchor.INSIDE4,
                ItemLabelAnchor.INSIDE5,
                ItemLabelAnchor.INSIDE6,
                ItemLabelAnchor.INSIDE7,
                ItemLabelAnchor.INSIDE8,
                ItemLabelAnchor.INSIDE9,
                ItemLabelAnchor.INSIDE10,
                ItemLabelAnchor.INSIDE11,
                ItemLabelAnchor.INSIDE12
            );
        }
    }

    @Nested
    @DisplayName("isInternal Tests for External Anchors")
    class ExternalAnchorsTests {

        @ParameterizedTest(name = "{0} should not be internal")
        @MethodSource("org.jfree.chart.labels.ItemLabelAnchorTest.ExternalAnchorsTests#externalAnchorsProvider")
        void testIsInternal_ShouldReturnFalse(ItemLabelAnchor anchor) {
            assertFalse(anchor.isInternal(), anchor.toString() + " should not be internal");
        }

        static java.util.stream.Stream<ItemLabelAnchor> externalAnchorsProvider() {
            return java.util.stream.Stream.of(
                ItemLabelAnchor.OUTSIDE1,
                ItemLabelAnchor.OUTSIDE2,
                ItemLabelAnchor.OUTSIDE3,
                ItemLabelAnchor.OUTSIDE4,
                ItemLabelAnchor.OUTSIDE5,
                ItemLabelAnchor.OUTSIDE6,
                ItemLabelAnchor.OUTSIDE7,
                ItemLabelAnchor.OUTSIDE8,
                ItemLabelAnchor.OUTSIDE9,
                ItemLabelAnchor.OUTSIDE10,
                ItemLabelAnchor.OUTSIDE11,
                ItemLabelAnchor.OUTSIDE12
            );
        }
    }

    @Nested
    @DisplayName("isInternal Tests for Custom Anchors")
    class CustomAnchorsTests {

        @Test
        @DisplayName("Custom anchor should not be internal")
        void testIsInternal_CustomAnchor_ShouldReturnFalse() throws Exception {
            // Using reflection to create a new instance
            java.lang.reflect.Constructor<ItemLabelAnchor> constructor =
                ItemLabelAnchor.class.getDeclaredConstructor(String.class);
            constructor.setAccessible(true);
            ItemLabelAnchor customAnchor = constructor.newInstance("ItemLabelAnchor.CUSTOM");
            assertFalse(customAnchor.isInternal(), "Custom anchor should not be internal");
        }
    }

    @Nested
    @DisplayName("isInternal Tests for Null Scenario")
    class NullScenarioTests {

        @Test
        @DisplayName("Calling isInternal on null should throw NullPointerException")
        void testIsInternal_NullAnchor_ShouldThrowException() {
            ItemLabelAnchor anchor = null;
            assertThrows(NullPointerException.class, anchor::isInternal, "Calling isInternal on null should throw NullPointerException");
        }
    }
}