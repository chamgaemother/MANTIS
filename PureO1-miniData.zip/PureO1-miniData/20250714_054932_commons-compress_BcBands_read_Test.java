package org.apache.commons.compress.harmony.unpack200;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;

import org.apache.commons.compress.harmony.pack200.Pack200Exception;
import org.apache.commons.compress.harmony.unpack200.bytecode.Attribute;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class BcBandsTest {

    private BcBands bcBands;
    private Segment segment;
    private Header header;
    private ClassBands classBands;
    private AttrDefinitionBands attrDefinitionBands;
    private CpBands cpBands;

    @BeforeEach
    void setUp() {
        segment = mock(Segment.class);
        header = mock(Header.class);
        classBands = mock(ClassBands.class);
        attrDefinitionBands = mock(AttrDefinitionBands.class);
        cpBands = mock(CpBands.class);

        when(segment.getHeader()).thenReturn(header);
        when(segment.getClassBands()).thenReturn(classBands);
        when(segment.getAttrDefinitionBands()).thenReturn(attrDefinitionBands);
        when(segment.getCpBands()).thenReturn(cpBands);

        bcBands = new BcBands(segment);
    }

    @Test
    void testReadWithNullInputStream() {
        assertThrows(NullPointerException.class, () -> {
            bcBands.read(null);
        });
    }

    @Test
    void testReadWithNoClasses() throws IOException, Pack200Exception {
        when(header.getClassCount()).thenReturn(0);
        InputStream in = new ByteArrayInputStream(new byte[0]);
        bcBands.read(in);
        assertNotNull(bcBands.getBcByte());
        assertEquals(0, bcBands.getBcByte().length);
    }

    @Test
    void testReadWithAbstractAndNativeMethods() throws IOException, Pack200Exception {
        when(header.getClassCount()).thenReturn(1);
        when(classBands.getMethodFlags()).thenReturn(new long[][] { { AttributeLayout.ACC_ABSTRACT, AttributeLayout.ACC_NATIVE } });
        InputStream in = new ByteArrayInputStream(new byte[0]);
        bcBands.read(in);
        assertNotNull(bcBands.getMethodByteCodePacked());
        assertEquals(1, bcBands.getMethodByteCodePacked().length);
        assertEquals(1, bcBands.getMethodByteCodePacked()[0].length);
        assertNull(bcBands.getMethodByteCodePacked()[0][0]);
    }

    @Test
    void testReadWithNonAbstractNonNativeMethods() throws IOException, Pack200Exception {
        when(header.getClassCount()).thenReturn(1);
        when(classBands.getMethodFlags()).thenReturn(new long[][] { { 0 } });
        byte[] byteCode = { 16, 17, 18, 19, 20, (byte) 170 };
        InputStream in = new ByteArrayInputStream(byteCode);
        when(cpBands.getCpClass()).thenReturn(new String[] { "java/lang/Object" });
        when(classBands.getClassThisInts()).thenReturn(new int[] { 0 });
        when(classBands.getClassSuperInts()).thenReturn(new int[] { 0 });
        when(classBands.getCodeMaxNALocals()).thenReturn(new int[] { 10 });
        when(classBands.getCodeMaxStack()).thenReturn(new int[] { 20 });
        when(classBands.getMethodAttributes()).thenReturn(new ArrayList[][] { { new ArrayList<>() } });
        when(classBands.getMethodDescr()).thenReturn(new String[][] { { "()V" } });
        when(classBands.getOrderedCodeAttributes()).thenReturn(new ArrayList[] { new ArrayList<>() });
        bcBands.read(in);
        assertNotNull(bcBands.getBcByte());
        assertTrue(bcBands.getBcByte().length > 0);
    }

    @Test
    void testReadWithInvalidByteCode() throws IOException, Pack200Exception {
        when(header.getClassCount()).thenReturn(1);
        when(classBands.getMethodFlags()).thenReturn(new long[][] { { 0 } });
        byte[] byteCode = { (byte) 255 };
        InputStream in = new ByteArrayInputStream(byteCode);
        when(cpBands.getCpClass()).thenReturn(new String[] { "java/lang/Object" });
        when(classBands.getClassThisInts()).thenReturn(new int[] { 0 });
        when(classBands.getClassSuperInts()).thenReturn(new int[] { 0 });
        when(classBands.getCodeMaxNALocals()).thenReturn(new int[] { 10 });
        when(classBands.getCodeMaxStack()).thenReturn(new int[] { 20 });
        when(classBands.getMethodAttributes()).thenReturn(new ArrayList[][] { { new ArrayList<>() } });
        when(classBands.getMethodDescr()).thenReturn(new String[][] { { "()V" } });
        when(classBands.getOrderedCodeAttributes()).thenReturn(new ArrayList[] { new ArrayList<>() });
        bcBands.read(in);
        // Depending on implementation, it might log or ignore. Just ensure no exception
    }

    @Test
    void testReadWithWideByteCode() throws IOException, Pack200Exception {
        when(header.getClassCount()).thenReturn(1);
        when(classBands.getMethodFlags()).thenReturn(new long[][] { { 0 } });
        byte[] byteCode = { (byte) 196, (byte) 132 }; // wide iinc
        InputStream in = new ByteArrayInputStream(byteCode);
        when(cpBands.getCpClass()).thenReturn(new String[] { "java/lang/Object" });
        when(classBands.getClassThisInts()).thenReturn(new int[] { 0 });
        when(classBands.getClassSuperInts()).thenReturn(new int[] { 0 });
        when(classBands.getCodeMaxNALocals()).thenReturn(new int[] { 10 });
        when(classBands.getCodeMaxStack()).thenReturn(new int[] { 20 });
        when(classBands.getMethodAttributes()).thenReturn(new ArrayList[][] { { new ArrayList<>() } });
        when(classBands.getMethodDescr()).thenReturn(new String[][] { { "()V" } });
        when(classBands.getOrderedCodeAttributes()).thenReturn(new ArrayList[] { new ArrayList<>() });
        bcBands.read(in);
        assertNotNull(bcBands.getBcByte());
    }

    @Test
    void testReadWithSwitchByteCodes() throws IOException, Pack200Exception {
        when(header.getClassCount()).thenReturn(1);
        when(classBands.getMethodFlags()).thenReturn(new long[][] { { 0 } });
        byte[] byteCode = { (byte) 170, (byte) 171 }; // tableswitch, lookupswitch
        InputStream in = new ByteArrayInputStream(byteCode);
        when(cpBands.getCpClass()).thenReturn(new String[] { "java/lang/Object" });
        when(classBands.getClassThisInts()).thenReturn(new int[] { 0 });
        when(classBands.getClassSuperInts()).thenReturn(new int[] { 0 });
        when(classBands.getCodeMaxNALocals()).thenReturn(new int[] { 10 });
        when(classBands.getCodeMaxStack()).thenReturn(new int[] { 20 });
        when(classBands.getMethodAttributes()).thenReturn(new ArrayList[][] { { new ArrayList<>() } });
        when(classBands.getMethodDescr()).thenReturn(new String[][] { { "()V" } });
        when(classBands.getOrderedCodeAttributes()).thenReturn(new ArrayList[] { new ArrayList<>() });
        bcBands.read(in);
        assertNotNull(bcBands.getBcCaseCount());
        assertNotNull(bcBands.getBcCaseValue());
    }

    @Test
    void testReadWithEscapedByteCodes() throws IOException, Pack200Exception {
        when(header.getClassCount()).thenReturn(1);
        when(classBands.getMethodFlags()).thenReturn(new long[][] { { 0 } });
        byte[] byteCode = { (byte) 253, (byte) 254 }; // ref_escape, byte_escape
        InputStream in = new ByteArrayInputStream(byteCode);
        when(cpBands.getCpClass()).thenReturn(new String[] { "java/lang/Object" });
        when(classBands.getClassThisInts()).thenReturn(new int[] { 0 });
        when(classBands.getClassSuperInts()).thenReturn(new int[] { 0 });
        when(classBands.getCodeMaxNALocals()).thenReturn(new int[] { 10 });
        when(classBands.getCodeMaxStack()).thenReturn(new int[] { 20 });
        when(classBands.getMethodAttributes()).thenReturn(new ArrayList[][] { { new ArrayList<>() } });
        when(classBands.getMethodDescr()).thenReturn(new String[][] { { "()V" } });
        when(classBands.getOrderedCodeAttributes()).thenReturn(new ArrayList[] { new ArrayList<>() });
        bcBands.read(in);
        assertNotNull(bcBands.getBcEscRef());
        assertNotNull(bcBands.getBcEscByte());
    }

    @Test
    void testReadWithHandlers() throws IOException, Pack200Exception {
        when(header.getClassCount()).thenReturn(1);
        when(classBands.getMethodFlags()).thenReturn(new long[][] { { 0 } });
        byte[] byteCode = { 16 }; // bipush
        InputStream in = new ByteArrayInputStream(byteCode);
        when(cpBands.getCpClass()).thenReturn(new String[] { "java/lang/Object" });
        when(classBands.getClassThisInts()).thenReturn(new int[] { 0 });
        when(classBands.getClassSuperInts()).thenReturn(new int[] { 0 });
        when(classBands.getCodeMaxNALocals()).thenReturn(new int[] { 10 });
        when(classBands.getCodeMaxStack()).thenReturn(new int[] { 20 });
        when(classBands.getMethodAttributes()).thenReturn(new ArrayList[][] { { new ArrayList<>() } });
        when(classBands.getMethodDescr()).thenReturn(new String[][] { { "()V" } });
        when(classBands.getOrderedCodeAttributes()).thenReturn(new ArrayList[] { new ArrayList<>() });
        when(classBands.getCodeHandlerCount()).thenReturn(new int[] { 1 });
        when(classBands.getCodeHandlerStartP()).thenReturn(new int[][] { { 0 } });
        when(classBands.getCodeHandlerEndPO()).thenReturn(new int[][] { { 10 } });
        when(classBands.getCodeHandlerCatchPO()).thenReturn(new int[][] { { 5 } });
        when(classBands.getCodeHandlerClassRCN()).thenReturn(new int[][] { { 1 } });
        bcBands.read(in);
        assertNotNull(bcBands.getBcByte());
    }

    @Test
    void testReadWithAllBranches() throws IOException, Pack200Exception {
        when(header.getClassCount()).thenReturn(2);
        when(classBands.getMethodFlags()).thenReturn(new long[][] { { 0 }, { AttributeLayout.ACC_ABSTRACT } });
        byte[] byteCode = { 16, 17, 18, (byte) 196, 132, (byte) 170, (byte) 171, (byte) 253, (byte) 254 };
        InputStream in = new ByteArrayInputStream(byteCode);
        when(cpBands.getCpClass()).thenReturn(new String[] { "java/lang/Object", "java/lang/String" });
        when(classBands.getClassThisInts()).thenReturn(new int[] { 0, 1 });
        when(classBands.getClassSuperInts()).thenReturn(new int[] { 0, 1 });
        when(classBands.getCodeMaxNALocals()).thenReturn(new int[] { 10, 0 });
        when(classBands.getCodeMaxStack()).thenReturn(new int[] { 20, 0 });
        when(classBands.getMethodAttributes()).thenReturn(new ArrayList[][] { { new ArrayList<>() }, { new ArrayList<>() } });
        when(classBands.getMethodDescr()).thenReturn(new String[][] { { "()V" }, { "()V" } });
        when(classBands.getOrderedCodeAttributes()).thenReturn(new ArrayList[] { new ArrayList<>() });
        bcBands.read(in);
        assertNotNull(bcBands.getBcByte());
        assertNotNull(bcBands.getBcShort());
        assertNotNull(bcBands.getBcLocal());
        assertNotNull(bcBands.getBcLabel());
        assertNotNull(bcBands.getBcCaseCount());
        assertNotNull(bcBands.getBcCaseValue());
        assertNotNull(bcBands.getBcEscRef());
        assertNotNull(bcBands.getBcEscByte());
    }

    @Test
    void testReadWithIOException() throws IOException, Pack200Exception {
        when(header.getClassCount()).thenReturn(1);
        when(classBands.getMethodFlags()).thenReturn(new long[][] { { 0 } });
        InputStream in = mock(InputStream.class);
        when(in.read()).thenThrow(new IOException("Test IOException"));
        assertThrows(IOException.class, () -> {
            bcBands.read(in);
        });
    }

    @Test
    void testReadWithPack200Exception() throws IOException, Pack200Exception {
        when(header.getClassCount()).thenReturn(1);
        when(classBands.getMethodFlags()).thenReturn(new long[][] { { 0 } });
        byte[] byteCode = { 16 };
        InputStream in = new ByteArrayInputStream(byteCode);
        when(cpBands.getCpClass()).thenReturn(new String[] { "java/lang/Object" });
        when(classBands.getClassThisInts()).thenReturn(new int[] { 0 });
        when(classBands.getClassSuperInts()).thenReturn(new int[] { 0 });
        when(classBands.getCodeMaxNALocals()).thenReturn(new int[] { 10 });
        when(classBands.getCodeMaxStack()).thenReturn(new int[] { 20 });
        when(classBands.getMethodAttributes()).thenReturn(new ArrayList[][] { { new ArrayList<>() } });
        when(classBands.getMethodDescr()).thenReturn(new String[][] { { "()V" } });
        when(classBands.getOrderedCodeAttributes()).thenReturn(new ArrayList[] { new ArrayList<>() });
        // Simulate a Pack200Exception during decodeBandInt
        BcBands spyBcBands = Mockito.spy(bcBands);
        doThrow(new Pack200Exception("Test Exception")).when(spyBcBands).decodeBandInt(anyString(), any(InputStream.class), any(), anyInt());
        assertThrows(Pack200Exception.class, () -> {
            spyBcBands.read(in);
        });
    }

    @Test
    void testReadWithEmptyByteCode() throws IOException, Pack200Exception {
        when(header.getClassCount()).thenReturn(1);
        when(classBands.getMethodFlags()).thenReturn(new long[][] { { 0 } });
        byte[] byteCode = {};
        InputStream in = new ByteArrayInputStream(byteCode);
        when(cpBands.getCpClass()).thenReturn(new String[] { "java/lang/Object" });
        when(classBands.getClassThisInts()).thenReturn(new int[] { 0 });
        when(classBands.getClassSuperInts()).thenReturn(new int[] { 0 });
        when(classBands.getCodeMaxNALocals()).thenReturn(new int[] { 10 });
        when(classBands.getCodeMaxStack()).thenReturn(new int[] { 20 });
        when(classBands.getMethodAttributes()).thenReturn(new ArrayList[][] { { new ArrayList<>() } });
        when(classBands.getMethodDescr()).thenReturn(new String[][] { { "()V" } });
        when(classBands.getOrderedCodeAttributes()).thenReturn(new ArrayList[] { new ArrayList<>() });
        bcBands.read(in);
        assertNotNull(bcBands.getMethodByteCodePacked());
        assertEquals(1, bcBands.getMethodByteCodePacked().length);
        assertEquals(1, bcBands.getMethodByteCodePacked()[0].length);
        assertEquals(0, bcBands.getMethodByteCodePacked()[0][0].length);
    }

    @Test
    void testReadWithMultipleClassesAndMethods() throws IOException, Pack200Exception {
        when(header.getClassCount()).thenReturn(2);
        when(classBands.getMethodFlags()).thenReturn(new long[][] { { 0, AttributeLayout.ACC_NATIVE }, { 0 } });
        byte[] byteCode = { 16, 17, 18, 19 };
        InputStream in = new ByteArrayInputStream(byteCode);
        when(cpBands.getCpClass()).thenReturn(new String[] { "java/lang/Object", "java/lang/String" });
        when(classBands.getClassThisInts()).thenReturn(new int[] { 0, 1 });
        when(classBands.getClassSuperInts()).thenReturn(new int[] { 0, 1 });
        when(classBands.getCodeMaxNALocals()).thenReturn(new int[] { 10, 20 });
        when(classBands.getCodeMaxStack()).thenReturn(new int[] { 30, 40 });
        ArrayList<Attribute> methodAttr = new ArrayList<>();
        when(classBands.getMethodAttributes()).thenReturn(new ArrayList[][] { { methodAttr, new ArrayList<>() }, { new ArrayList<>() } });
        when(classBands.getMethodDescr()).thenReturn(new String[][] { { "()V", "()I" }, { "()Ljava/lang/String;" } });
        when(classBands.getOrderedCodeAttributes()).thenReturn(new ArrayList[] { new ArrayList<>() });
        bcBands.read(in);
        assertNotNull(bcBands.getMethodByteCodePacked());
        assertEquals(2, bcBands.getMethodByteCodePacked().length);
        assertEquals(2, bcBands.getMethodByteCodePacked()[0].length);
        assertEquals(1, bcBands.getMethodByteCodePacked()[1].length);
    }
}