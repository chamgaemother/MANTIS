package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Generated JUnit 5 test class for ColognePhonetic.colognePhonetic method.
 */
public class ColognePhonetic_colognePhonetic_0_1_Test {

    /**
     * TC01: colognePhonetic(null) returns null without processing
     */
    @Test
    @DisplayName("colognePhonetic(null) returns null without processing")
    void testTC01_colognePhonetic_nullInput() {
        // Given
        String input = null;
        ColognePhonetic colognePhonetic = new ColognePhonetic();

        // When
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertNull(result, "Expected null when input is null");
    }

    /**
     * TC02: colognePhonetic empty string returns empty string
     */
    @Test
    @DisplayName("colognePhonetic empty string returns empty string")
    void testTC02_colognePhonetic_emptyString() {
        // Given
        String input = "";
        ColognePhonetic colognePhonetic = new ColognePhonetic();

        // When
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertEquals("", result, "Expected empty string when input is empty");
    }

    /**
     * TC03: colognePhonetic processes string with only vowels correctly
     */
    @Test
    @DisplayName("colognePhonetic processes string with only vowels correctly")
    void testTC03_colognePhonetic_onlyVowels() {
        // Given
        String input = "AEIOUY";
        ColognePhonetic colognePhonetic = new ColognePhonetic();

        // When
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertEquals("0", result, "Expected '0' when input contains only vowels");
    }

    /**
     * TC04: colognePhonetic handles German umlauts correctly during preprocessing
     */
    @Test
    @DisplayName("colognePhonetic handles German umlauts correctly during preprocessing")
    void testTC04_colognePhonetic_germanUmlauts() {
        // Given
        String input = "MÃ¼ller";
        ColognePhonetic colognePhonetic = new ColognePhonetic();

        // When
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertEquals("M0LLER", result, "Expected umlauts to be mapped to their plain equivalents");
    }

    /**
     * TC05: colognePhonetic processes string with 'H' characters correctly
     */
    @Test
    @DisplayName("colognePhonetic processes string with 'H' characters correctly")
    void testTC05_colognePhonetic_includesH() {
        // Given
        String input = "HELLO";
        ColognePhonetic colognePhonetic = new ColognePhonetic();

        // When
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertEquals("H5LL0", result, "Expected 'H' to be handled correctly in the encoding");
    }
}