package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

import java.lang.reflect.Field;

import org.apache.commons.collections4.map.HashedMap;

public class Flat3Map_put_2_1_Test {

    @Test
    @DisplayName("put(null, value) delegates to delegateMap when delegateMap is not null and does not contain null key")
    public void TC23_putNullValueDelegatesWhenDelegateMapNotContainsNullKey() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();
        AbstractHashedMap<Object, Object> delegate = new HashedMap<>();

        // Use reflection to set private field 'delegateMap'
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, delegate);

        // Act
        Object result = map.put(null, "newValue");

        // Assert
        Assertions.assertNull(result, "Expected null return value");

        Assertions.assertEquals("newValue", delegate.get(null), "delegateMap should contain the new null key-value pair");
    }

    @Test
    @DisplayName("put(null, newValue) updates null key in delegateMap when it already contains null key")
    public void TC24_putNullValueUpdatesExistingNullKeyInDelegateMap() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();
        AbstractHashedMap<Object, Object> delegate = new HashedMap<>();
        delegate.put(null, "oldValue");

        // Use reflection to set private field 'delegateMap'
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, delegate);

        // Act
        Object result = map.put(null, "newValue");

        // Assert
        Assertions.assertEquals("oldValue", result, "Expected old value to be returned");
        Assertions.assertEquals("newValue", delegate.get(null), "delegateMap should update the null key value to newValue");
    }
}