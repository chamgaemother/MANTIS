package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Conversion_binaryBeMsb0ToHexDigit_0_1_Test {

    @Test
    @DisplayName("Throws IllegalArgumentException when src array is empty")
    void TC01_ThrowsIllegalArgumentExceptionWhenSrcArrayIsEmpty() {
        boolean[] src = new boolean[0];
        int srcPos = 0;
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            Conversion.binaryBeMsb0ToHexDigit(src, srcPos);
        });
        assertEquals("Cannot convert an empty array.", exception.getMessage());
    }

    @Test
    @DisplayName("Throws IndexOutOfBoundsException when srcPos is out of array bounds")
    void TC02_ThrowsIndexOutOfBoundsExceptionWhenSrcPosIsOutOfArrayBounds() {
        boolean[] src = new boolean[]{true, false};
        int srcPos = 2;
        Exception exception = assertThrows(IndexOutOfBoundsException.class, () -> {
            Conversion.binaryBeMsb0ToHexDigit(src, srcPos);
        });
        assertEquals(srcPos + " is not within array length " + src.length, exception.getMessage());
    }

    @Test
    @DisplayName("Returns '0' when pos < 1 and src[pos] is false")
    void TC03_Returns0WhenPosLessThan1AndSrcPosIsFalse() {
        boolean[] src = new boolean[]{false};
        int srcPos = 0;
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);
        assertEquals('0', result);
    }

    @Test
    @DisplayName("Returns '1' when pos < 1 and src[pos] is true")
    void TC04_Returns1WhenPosLessThan1AndSrcPosIsTrue() {
        boolean[] src = new boolean[]{true};
        int srcPos = 0;
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);
        assertEquals('1', result);
    }

    @Test
    @DisplayName("Returns 'a' when pos >= 3, src[pos-3] is true, src[pos-2] is false, src[pos-1] is false, src[pos] is false")
    void TC05_ReturnsAWhenComplexConditionIsMet() {
        boolean[] src = new boolean[]{false, false, false, true};
        int srcPos = 0;
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);
        assertEquals('a', result);
    }
}