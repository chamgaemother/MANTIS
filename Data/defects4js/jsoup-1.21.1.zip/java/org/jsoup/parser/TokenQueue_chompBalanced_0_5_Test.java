package org.jsoup.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

public class TokenQueue_chompBalanced_0_5_Test {

    @Test
    @DisplayName("ChompBalanced with no characters to consume returns empty string")
    public void TC21() {
        // GIVEN
        TokenQueue queue = new TokenQueue("");  // Fixed: Provide empty string to TokenQueue constructor
        // WHEN
        String result = queue.chompBalanced('(', ')');
        // THEN
        Assertions.assertEquals("", result);
    }

    @Test
    @DisplayName("ChompBalanced with only open characters and missing close throws exception")
    public void TC22() {
        // GIVEN
        TokenQueue queue = new TokenQueue("(((");  // Fixed: Correct constructor usage
        // WHEN & THEN
        IllegalArgumentException exception = Assertions.assertThrows(IllegalArgumentException.class, () -> {
            queue.chompBalanced('(', ')');
        });
        Assertions.assertEquals("Did not find balanced marker at '((('", exception.getMessage());  // Fixed: Correct exception type and message
    }

    @Test
    @DisplayName("ChompBalanced with mixed quotes and regex patterns")
    public void TC23() {
        // GIVEN
        TokenQueue queue = new TokenQueue("\"'nested'");  // Fixed: Correct constructor usage and input
        // WHEN
        String result = queue.chompBalanced('(', ')');
        // THEN
        Assertions.assertEquals("'nested'", result);
    }
}