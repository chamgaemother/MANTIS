package com.fasterxml.jackson.core.io;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class JsonStringEncoderTest {

    private final JsonStringEncoder encoder = JsonStringEncoder.getInstance();

    @Test
    void encodeAsUTF8_NullInput_ShouldThrowNullPointerException() {
        assertThrows(NullPointerException.class, () -> encoder.encodeAsUTF8((String) null));
    }

    @Test
    void encodeAsUTF8_EmptyString_ShouldReturnEmptyByteArray() {
        byte[] result = encoder.encodeAsUTF8("");
        assertArrayEquals(new byte[0], result);
    }

    @Test
    void encodeAsUTF8_ASCII_NoEscaping_ShouldEncodeCorrectly() {
        String input = "Hello, World!";
        byte[] expected = "Hello, World!".getBytes();
        byte[] result = encoder.encodeAsUTF8(input);
        assertArrayEquals(expected, result);
    }

    @Test
    void encodeAsUTF8_ASCII_WithEscaping_ShouldEncodeCorrectly() {
        String input = "Hello\nWorld\t\"Test\"\\End";
        byte[] expected = "\"Hello\\u000aWorld\\u0009\\\"Test\\\"\\\\End\"".getBytes();
        byte[] result = encoder.encodeAsUTF8(input);
        // Since encodeAsUTF8 performs escaping and encoding, manual expected may vary
        // Here we just check the length as precise bytes depend on implementation
        assertNotNull(result);
        assertTrue(result.length > input.length());
    }

    @Test
    void encodeAsUTF8_NonASCIICharacters_ShouldEncodeCorrectly() {
        String input = "Café 漢字";
        byte[] expected = "Café 漢字".getBytes();
        byte[] result = encoder.encodeAsUTF8(input);
        // Without escaping, should match standard UTF-8 encoding
        assertArrayEquals(expected, result);
    }

    @Test
    void encodeAsUTF8_ValidSurrogatePairs_ShouldEncodeCorrectly() {
        String input = "Emoji: \uD83D\uDE00"; // 😀
        byte[] expected = "Emoji: 😀".getBytes();
        byte[] result = encoder.encodeAsUTF8(input);
        assertArrayEquals(expected, result);
    }

    @Test
    void encodeAsUTF8_LoneHighSurrogate_ShouldThrowIllegalArgumentException() {
        String input = "Invalid surrogate: \uD83D";
        Executable executable = () -> encoder.encodeAsUTF8(input);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, executable);
        assertTrue(exception.getMessage().contains("Broken surrogate pair"));
    }

    @Test
    void encodeAsUTF8_LoneLowSurrogate_ShouldThrowIllegalArgumentException() {
        String input = "Invalid surrogate: \uDE00";
        Executable executable = () -> encoder.encodeAsUTF8(input);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, executable);
        assertTrue(exception.getMessage().contains("Broken surrogate pair"));
    }

    @Test
    void encodeAsUTF8_SurrogateBoundaryAtEnd_ShouldThrowIllegalArgumentException() {
        String input = "Ends with high surrogate: \uD83D";
        Executable executable = () -> encoder.encodeAsUTF8(input);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, executable);
        assertTrue(exception.getMessage().contains("Broken surrogate pair"));
    }

    @Test
    void encodeAsUTF8_MaxUnicodeCharacter_ShouldEncodeCorrectly() {
        String input = new String(Character.toChars(0x10FFFF));
        byte[] expected = new String(Character.toChars(0x10FFFF)).getBytes();
        byte[] result = encoder.encodeAsUTF8(input);
        assertArrayEquals(expected, result);
    }

    @Test
    void encodeAsUTF8_AboveMaxUnicode_ShouldThrowIllegalArgumentException() {
        // 0x110000 is above the maximum Unicode code point
        String input = "Invalid code point: " + new String(Character.toChars(0xD800)) + "a";
        Executable executable = () -> encoder.encodeAsUTF8(input);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, executable);
        assertTrue(exception.getMessage().contains("Broken surrogate pair"));
    }

    @Test
    void encodeAsUTF8_LargeString_ShouldEncodeCorrectly() {
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < 10000; i++) {
            sb.append("a");
        }
        String input = sb.toString();
        byte[] expected = input.getBytes();
        byte[] result = encoder.encodeAsUTF8(input);
        assertArrayEquals(expected, result);
    }

    @Test
    void encodeAsUTF8_StringWithAllAsciiControlCharacters_ShouldEncodeCorrectly() {
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < 32; i++) {
            sb.append((char)i);
        }
        String input = sb.toString();
        byte[] result = encoder.encodeAsUTF8(input);
        assertNotNull(result);
        assertEquals(input.length() * 6, result.length); // Each control char is escaped as \u00XX
    }

    @Test
    void encodeAsUTF8_StringWithMixedCharacters_ShouldEncodeCorrectly() {
        String input = "Mix: ASCII, エモジ, 😀, 控えめ";
        byte[] expected = input.getBytes();
        byte[] result = encoder.encodeAsUTF8(input);
        assertArrayEquals(expected, result);
    }
}