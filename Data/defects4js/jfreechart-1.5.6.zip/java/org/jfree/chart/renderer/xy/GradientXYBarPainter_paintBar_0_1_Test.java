package org.jfree.chart.renderer.xy;

import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import static org.mockito.Mockito.*;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

public class GradientXYBarPainter_paintBar_0_1_Test {

    @Test
    @DisplayName("paintBar with Color paint having alpha = 0 results in no drawing")
    public void TC01_paintBar_NoDrawing() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYBarRenderer renderer = mock(XYBarRenderer.class);
        Color transparentColor = new Color(0, 0, 0, 0);
        when(renderer.getItemPaint(0, 0)).thenReturn(transparentColor);
        when(renderer.isDrawBarOutline()).thenReturn(false);

        int row = 0;
        int column = 0;
        Rectangle2D bar = new Rectangle2D.Double(0, 0, 10, 10);
        RectangleEdge base = RectangleEdge.TOP;

        GradientXYBarPainter painter = new GradientXYBarPainter();

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        verify(g2, never()).setPaint(any());
        verify(g2, never()).fill(any());
        verify(g2, never()).setStroke(any());
        verify(g2, never()).draw(any());
    }

    @Test
    @DisplayName("paintBar with Color paint having non-zero alpha and RectangleEdge.TOP without outline")
    public void TC02_paintBar_ColorNonZeroAlpha_TopEdge_NoOutline() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYBarRenderer renderer = mock(XYBarRenderer.class);
        Color color = new Color(100, 150, 200, 255);
        when(renderer.getItemPaint(0, 0)).thenReturn(color);
        when(renderer.isDrawBarOutline()).thenReturn(false);

        int row = 0;
        int column = 0;
        Rectangle2D bar = new Rectangle2D.Double(0, 0, 20, 20);
        RectangleEdge base = RectangleEdge.TOP;

        GradientXYBarPainter painter = new GradientXYBarPainter();

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        // Verify that setPaint and fill are called four times for gradients
        verify(g2, times(4)).setPaint(any(GradientPaint.class));
        verify(g2, times(4)).fill(any(Rectangle2D.class));
        // Verify that outline drawing methods are not called
        verify(g2, never()).setStroke(any());
        verify(g2, never()).draw(any());
    }

    @Test
    @DisplayName("paintBar with Color paint having non-zero alpha, RectangleEdge.TOP with valid outline")
    public void TC03_paintBar_ColorNonZeroAlpha_TopEdge_WithOutline() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYBarRenderer renderer = mock(XYBarRenderer.class);
        Color color = new Color(50, 100, 150, 200);
        Stroke stroke = mock(Stroke.class);
        Paint outlinePaint = Color.BLACK;

        when(renderer.getItemPaint(0, 0)).thenReturn(color);
        when(renderer.isDrawBarOutline()).thenReturn(true);
        when(renderer.getItemOutlineStroke(0, 0)).thenReturn(stroke);
        when(renderer.getItemOutlinePaint(0, 0)).thenReturn(outlinePaint);

        int row = 0;
        int column = 0;
        Rectangle2D bar = new Rectangle2D.Double(5, 5, 15, 15);
        RectangleEdge base = RectangleEdge.TOP;

        GradientXYBarPainter painter = new GradientXYBarPainter();

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        // Verify that setPaint and fill are called four times for gradients
        verify(g2, times(4)).setPaint(any(GradientPaint.class));
        verify(g2, times(4)).fill(any(Rectangle2D.class));
        // Verify that outline is drawn
        verify(g2, times(1)).setStroke(stroke);
        verify(g2, times(1)).setPaint(outlinePaint);
        verify(g2, times(1)).draw(bar);
    }

    @Test
    @DisplayName("paintBar with GradientPaint and non-zero alpha on RectangleEdge.LEFT without outline")
    public void TC04_paintBar_GradientPaintNonZeroAlpha_LeftEdge_NoOutline() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYBarRenderer renderer = mock(XYBarRenderer.class);
        GradientPaint gradientPaint = new GradientPaint(0f, 0f, Color.RED, 10f, 10f, Color.BLUE);
        when(renderer.getItemPaint(0, 0)).thenReturn(gradientPaint);
        when(renderer.isDrawBarOutline()).thenReturn(false);

        int row = 0;
        int column = 0;
        Rectangle2D bar = new Rectangle2D.Double(10, 10, 30, 30);
        RectangleEdge base = RectangleEdge.LEFT;

        GradientXYBarPainter painter = new GradientXYBarPainter();

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        // Verify that setPaint and fill are called four times for gradients
        verify(g2, times(4)).setPaint(any(GradientPaint.class));
        verify(g2, times(4)).fill(any(Rectangle2D.class));
        // Verify that outline drawing methods are not called
        verify(g2, never()).setStroke(any());
        verify(g2, never()).draw(any());
    }

    @Test
    @DisplayName("paintBar with GradientPaint and non-zero alpha on RectangleEdge.RIGHT with outline")
    public void TC05_paintBar_GradientPaintNonZeroAlpha_RightEdge_WithOutline() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYBarRenderer renderer = mock(XYBarRenderer.class);
        GradientPaint gradientPaint = new GradientPaint(0f, 0f, Color.GREEN, 15f, 15f, Color.YELLOW);
        Stroke stroke = mock(Stroke.class);
        Paint outlinePaint = Color.DARK_GRAY;

        when(renderer.getItemPaint(0, 0)).thenReturn(gradientPaint);
        when(renderer.isDrawBarOutline()).thenReturn(true);
        when(renderer.getItemOutlineStroke(0, 0)).thenReturn(stroke);
        when(renderer.getItemOutlinePaint(0, 0)).thenReturn(outlinePaint);

        int row = 0;
        int column = 0;
        Rectangle2D bar = new Rectangle2D.Double(20, 20, 40, 40);
        RectangleEdge base = RectangleEdge.RIGHT;

        GradientXYBarPainter painter = new GradientXYBarPainter();

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        // Verify that setPaint and fill are called four times for gradients
        verify(g2, times(4)).setPaint(any(GradientPaint.class));
        verify(g2, times(4)).fill(any(Rectangle2D.class));
        // Verify that outline is drawn
        verify(g2, times(1)).setStroke(stroke);
        verify(g2, times(1)).setPaint(outlinePaint);
        verify(g2, times(1)).draw(bar);
    }
}