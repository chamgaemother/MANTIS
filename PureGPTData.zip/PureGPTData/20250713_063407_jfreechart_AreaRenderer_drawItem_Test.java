import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.AreaRendererEndType;
import org.jfree.chart.renderer.category.AreaRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class AreaRendererTest {
    private AreaRenderer renderer;
    private Graphics2D g2;
    private CategoryItemRendererState state;
    private Rectangle2D dataArea;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private CategoryDataset dataset;

    @BeforeEach
    public void setUp() {
        renderer = new AreaRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(CategoryItemRendererState.class);
        dataArea = mock(Rectangle2D.class);
        plot = mock(CategoryPlot.class);
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(CategoryDataset.class);

        when(plot.getDomainAxisEdge()).thenReturn(null);
        when(plot.getRangeAxisEdge()).thenReturn(null);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getColumnCount()).thenReturn(5);
    }

    @Test
    public void testDrawItemWithNullValue() {
        when(dataset.getValue(0, 0)).thenReturn(null);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        // Expect no interaction with graphics since the value is null
        verifyNoInteractions(g2);
    }

    @Test
    public void testDrawItemWithTaperEndType() {
        when(dataset.getValue(0, 1)).thenReturn(10.0);
        renderer.setEndType(AreaRendererEndType.TAPER);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);
        // Verify interactions based on implementation - this is just a simple check
        verify(g2, atLeastOnce()).setPaint(any());
    }

    @Test
    public void testDrawItemWithTruncateEndTypeFirstColumn() {
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        renderer.setEndType(AreaRendererEndType.TRUNCATE);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verify(g2, atLeastOnce()).setPaint(any());
    }

    @Test
    public void testDrawItemWithTruncateEndTypeLastColumn() {
        when(dataset.getValue(0, 4)).thenReturn(10.0);
        renderer.setEndType(AreaRendererEndType.TRUNCATE);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 4, 0);
        verify(g2, atLeastOnce()).setPaint(any());
    }

    @Test
    public void testDrawItemWithLevelEndType() {
        when(dataset.getValue(0, 2)).thenReturn(10.0);
        renderer.setEndType(AreaRendererEndType.LEVEL);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 2, 0);
        verify(g2, atLeastOnce()).setPaint(any());
    }

    @Test
    public void testDrawItemNotVisible() {
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verifyNoInteractions(g2);
    }
}