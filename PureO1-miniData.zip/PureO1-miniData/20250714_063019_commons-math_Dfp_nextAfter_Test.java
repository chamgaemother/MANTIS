package org.apache.commons.math3.dfp;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.apache.commons.math3.exception.DimensionMismatchException;

class DfpTest {

    private DfpField field;
    private Dfp zero;
    private Dfp one;
    private Dfp minusOne;
    private Dfp two;
    private Dfp minusTwo;
    private Dfp infinity;
    private Dfp minusInfinity;
    private Dfp nan;

    @BeforeEach
    void setUp() {
        field = new DfpField(5);
        zero = field.getZero();
        one = field.getOne();
        minusOne = one.negate();
        two = one.add(one);
        minusTwo = two.negate();
        infinity = new Dfp(field, (byte) 1, Dfp.INFINITE);
        minusInfinity = new Dfp(field, (byte) -1, Dfp.INFINITE);
        nan = new Dfp(field, (byte) 1, Dfp.QNAN);
    }

    @Test
    void testNextAfterNull() {
        assertThrows(NullPointerException.class, () -> {
            zero.nextAfter(null);
        });
    }

    @Test
    void testNextAfterEquals() {
        Dfp result = one.nextAfter(one);
        assertEquals(one, result, "nextAfter when this equals x should return x");
    }

    @Test
    void testNextAfterLessThan() {
        Dfp result = one.nextAfter(two);
        assertTrue(result.greaterThan(one), "nextAfter when this < x should increment");
    }

    @Test
    void testNextAfterGreaterThan() {
        Dfp result = two.nextAfter(one);
        assertTrue(result.lessThan(two), "nextAfter when this > x should decrement");
    }

    @Test
    void testNextAfterZeroUp() {
        Dfp result = zero.nextAfter(one);
        assertTrue(result.greaterThan(zero), "nextAfter from zero towards positive should be positive");
    }

    @Test
    void testNextAfterZeroDown() {
        Dfp result = zero.nextAfter(minusOne);
        assertTrue(result.lessThan(zero), "nextAfter from zero towards negative should be negative");
    }

    @Test
    void testNextAfterNegativeIncreasing() {
        Dfp result = minusTwo.nextAfter(minusOne);
        assertTrue(result.greaterThan(minusTwo), "nextAfter for negative number towards less negative should increment");
    }

    @Test
    void testNextAfterPositiveDecreasing() {
        Dfp result = two.nextAfter(one);
        assertTrue(result.lessThan(two), "nextAfter for positive number towards smaller should decrement");
    }

    @Test
    void testNextAfterNegativeDecreasing() {
        Dfp result = minusOne.nextAfter(minusTwo);
        assertTrue(result.lessThan(minusOne), "nextAfter for negative number towards more negative should decrement");
    }

    @Test
    void testNextAfterPositiveIncreasing() {
        Dfp result = one.nextAfter(two);
        assertTrue(result.greaterThan(one), "nextAfter for positive number towards more positive should increment");
    }

    @Test
    void testNextAfterInfinity() {
        Dfp result = infinity.nextAfter(one);
        assertTrue(result.lessThan(infinity), "nextAfter from positive infinity towards finite should decrement");
    }

    @Test
    void testNextAfterMinusInfinity() {
        Dfp result = minusInfinity.nextAfter(zero);
        assertTrue(result.greaterThan(minusInfinity), "nextAfter from negative infinity towards finite should increment");
    }

    @Test
    void testNextAfterNaN() {
        Dfp result = nan.nextAfter(one);
        assertTrue(result.isNaN(), "nextAfter from NaN should return NaN");
    }

    @Test
    void testNextAfterOverflow() {
        Dfp large = new Dfp(field, "1E32768");
        Dfp result = large.nextAfter(infinity);
        assertTrue(result.isInfinite() && result.sign > 0, "nextAfter should remain positive infinity on overflow");
    }

    @Test
    void testNextAfterUnderflow() {
        Dfp small = new Dfp(field, "1E-32767");
        Dfp result = small.nextAfter(zero);
        assertTrue(result.equals(zero), "nextAfter should underflow to zero");
    }

    @Test
    void testNextAfterResultInfinite() {
        Dfp result = one.nextAfter(infinity);
        assertTrue(result.greaterThan(one), "nextAfter towards infinity should increment");
    }

    @Test
    void testNextAfterResultZero() {
        Dfp result = one.subtract(one).nextAfter(one);
        assertTrue(result.equals(zero), "nextAfter resulting in zero should handle sign correctly");
    }

    @Test
    void testNextAfterDifferentPrecision() {
        DfpField field2 = new DfpField(4);
        Dfp x = new Dfp(field2, 1);
        assertThrows(IllegalArgumentException.class, () -> {
            one.nextAfter(x);
        }, "nextAfter with different precision should throw exception");
    }

}