package org.apache.commons.collections4.map;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

import org.apache.commons.collections4.map.AbstractHashedMap;
import org.apache.commons.collections4.map.Flat3Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class Flat3Map_get_0_1_Test {

    @Test
    @DisplayName("DelegateMap is not null and get delegates the call")
    public void TC01_delegateMap_not_null() throws Exception {
        // Create instance of Flat3Map
        Flat3Map map = new Flat3Map();

        // Set delegateMap via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        AbstractHashedMap delegateMap = new AbstractHashedMap();
        Object key = "testKey1";
        Object value = "testValue1";
        delegateMap.put(key, value);
        delegateMapField.set(map, delegateMap);

        // Invoke get method
        Object result = map.get(key);

        // Assert
        assertEquals(delegateMap.get(key), result);
    }

    @Test
    @DisplayName("delegateMap is null, key is null, size is 0")
    public void TC02_delegateMap_null_key_null_size_zero() throws Exception {
        // Create instance of Flat3Map
        Flat3Map map = new Flat3Map();

        // Ensure delegateMap is null via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set key to null and size to 0 via reflection
        Object key = null;
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 0);

        // Invoke get method
        Object result = map.get(key);

        // Assert
        assertNull(result);
    }

    @Test
    @DisplayName("delegateMap is null, key is null, size is 1, key1 is null")
    public void TC03_delegateMap_null_key_null_size_one_key1_null() throws Exception {
        // Create instance of Flat3Map
        Flat3Map map = new Flat3Map();

        // Ensure delegateMap is null via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set key to null, size to 1, key1 to null via reflection
        Object key = null;
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);

        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, null);

        // Set value1 via reflection
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        Object value1 = "value1";
        value1Field.set(map, value1);

        // Invoke get method
        Object result = map.get(key);

        // Assert
        assertEquals(value1, result);
    }

    @Test
    @DisplayName("delegateMap is null, key is null, size is 1, key1 is not null")
    public void TC04_delegateMap_null_key_null_size_one_key1_not_null() throws Exception {
        // Create instance of Flat3Map
        Flat3Map map = new Flat3Map();

        // Ensure delegateMap is null via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set key to null, size to 1, key1 to non-null via reflection
        Object key = null;
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);

        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        Object key1 = "nonNullKey1";
        key1Field.set(map, key1);

        // Invoke get method
        Object result = map.get(key);

        // Assert
        assertNull(result);
    }

    @Test
    @DisplayName("delegateMap is null, key is null, size is 2, key2 is null")
    public void TC05_delegateMap_null_key_null_size_two_key2_null() throws Exception {
        // Create instance of Flat3Map
        Flat3Map map = new Flat3Map();

        // Ensure delegateMap is null via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set key to null, size to 2, key2 to null via reflection
        Object key = null;
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, null);

        // Set value2 via reflection
        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        Object value2 = "value2";
        value2Field.set(map, value2);

        // Invoke get method
        Object result = map.get(key);

        // Assert
        assertEquals(value2, result);
    }
}