package org.apache.commons.lang3.text;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import java.text.Format;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ChoiceFormat;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ExtendedMessageFormat_applyPattern_0_2_Test {

    @Test
    @DisplayName("applyPattern with one format element with invalid format description, ensuring format remains null")
    void TC06_applyPattern_with_one_invalid_format_element() throws Exception {
        // GIVEN
        Map<String, FormatFactory> registry = new HashMap<>();
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Value: {0,unknown}", registry);

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            emf.applyPattern("Value: {0,unknown}");
        });
        assertTrue(exception.getMessage().contains("Unreadable format element at position"));
    }

    @Test
    @DisplayName("applyPattern with multiple format elements, mixture of valid and invalid formats")
    void TC07_applyPattern_with_mixed_valid_and_invalid_format_elements() throws Exception {
        // GIVEN
        Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("date", (name, args, locale) -> DateFormat.getDateInstance(DateFormat.DEFAULT, locale));

        ExtendedMessageFormat emf = new ExtendedMessageFormat("Date: {0,date}, Unknown: {1,unknown}", registry);

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            emf.applyPattern("Date: {0,date}, Unknown: {1,unknown}");
        });
        assertTrue(exception.getMessage().contains("Unreadable format element at position"));
    }

    @Test
    @DisplayName("applyPattern with no valid formats found, ensuring containsElements returns false")
    void TC08_applyPattern_with_no_valid_formats() throws Exception {
        // GIVEN
        Map<String, FormatFactory> registry = new HashMap<>();
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Value: {0,invalid}", registry);

        // WHEN
        emf.applyPattern("Value: {0,invalid}");

        // THEN
        Method containsElementsMethod = ExtendedMessageFormat.class.getDeclaredMethod("containsElements", java.util.Collection.class);
        containsElementsMethod.setAccessible(true);
        boolean hasElements = (boolean) containsElementsMethod.invoke(emf, java.util.Arrays.asList(emf.getFormats()));
        assertFalse(hasElements, "containsElements should return false when no valid formats are present");
    }

    @Test
    @DisplayName("applyPattern with valid formats present, ensuring formats are set correctly")
    void TC09_applyPattern_with_valid_formats_present() throws Exception {
        // GIVEN
        Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("date", (name, args, locale) -> DateFormat.getDateInstance(DateFormat.DEFAULT, locale));
        registry.put("number", (name, args, locale) -> NumberFormat.getInstance(locale));

        ExtendedMessageFormat emf = new ExtendedMessageFormat("Date: {0,date}, Number: {1,number}", registry);

        // WHEN
        emf.applyPattern("Date: {0,date}, Number: {1,number}");

        // THEN
        Format[] formats = emf.getFormats();
        assertNotNull(formats[0], "First format should be a valid DateFormat");
        assertNotNull(formats[1], "Second format should be a valid NumberFormat");
    }

    @Test
    @DisplayName("applyPattern with multiple iterations in loop processing multiple format elements")
    void TC10_applyPattern_with_multiple_format_elements() throws Exception {
        // GIVEN
        Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("date", (name, args, locale) -> DateFormat.getDateInstance(DateFormat.DEFAULT, locale));
        registry.put("number", (name, args, locale) -> NumberFormat.getInstance(locale));
        registry.put("choice", (name, args, locale) -> new ChoiceFormat("0#Low|1#Medium|2#High"));

        ExtendedMessageFormat emf = new ExtendedMessageFormat("Start {0,date} middle {1,number} end {2,choice}", registry);

        // WHEN
        emf.applyPattern("Start {0,date} middle {1,number} end {2,choice}");

        // THEN
        Format[] formats = emf.getFormats();
        assertNotNull(formats[0], "First format should be a valid DateFormat");
        assertNotNull(formats[1], "Second format should be a valid NumberFormat");
        assertNotNull(formats[2], "Third format should be a valid ChoiceFormat");
    }
}