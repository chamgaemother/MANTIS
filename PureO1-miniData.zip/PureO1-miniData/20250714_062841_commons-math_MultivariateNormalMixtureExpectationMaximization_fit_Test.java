package org.apache.commons.math3.distribution.fitting;

import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.math3.distribution.MixtureMultivariateNormalDistribution;
import org.apache.commons.math3.distribution.MultivariateNormalDistribution;
import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.linear.SingularMatrixException;
import org.apache.commons.math3.util.Pair;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

class MultivariateNormalMixtureExpectationMaximizationTest {

    @Test
    void testFit_withValidInput_converges() {
        double[][] data = {
                {1.0, 2.0},
                {1.1, 2.1},
                {0.9, 1.9},
                {10.0, 10.0},
                {10.1, 10.1},
                {9.9, 9.9}
        };

        MixtureMultivariateNormalDistribution initialMixture = createInitialMixture(2, 2, data);

        MultivariateNormalMixtureExpectationMaximization em =
                new MultivariateNormalMixtureExpectationMaximization(data);

        assertDoesNotThrow(() -> em.fit(initialMixture, 100, 1e-5));

        MixtureMultivariateNormalDistribution fitted = em.getFittedModel();
        assertNotNull(fitted);
        assertEquals(2, fitted.getComponents().size());
        assertTrue(em.getLogLikelihood() > Double.NEGATIVE_INFINITY);
    }

    @Test
    void testFit_withNullInitialMixture_throwsNullPointerException() {
        double[][] data = {
                {1.0, 2.0},
                {3.0, 4.0}
        };

        MultivariateNormalMixtureExpectationMaximization em =
                new MultivariateNormalMixtureExpectationMaximization(data);

        assertThrows(NullPointerException.class, () -> em.fit(null, 100, 1e-5));
    }

    @Test
    void testFit_withMaxIterationsLessThanOne_throwsNotStrictlyPositiveException() {
        double[][] data = {
                {1.0, 2.0},
                {3.0, 4.0}
        };

        MixtureMultivariateNormalDistribution initialMixture = createInitialMixture(1, 2, data);

        MultivariateNormalMixtureExpectationMaximization em =
                new MultivariateNormalMixtureExpectationMaximization(data);

        assertThrows(NotStrictlyPositiveException.class, () -> em.fit(initialMixture, 0, 1e-5));
    }

    @Test
    void testFit_withThresholdLessThanMin_throwsNotStrictlyPositiveException() {
        double[][] data = {
                {1.0, 2.0},
                {3.0, 4.0}
        };

        MixtureMultivariateNormalDistribution initialMixture = createInitialMixture(1, 2, data);

        MultivariateNormalMixtureExpectationMaximization em =
                new MultivariateNormalMixtureExpectationMaximization(data);

        assertThrows(NotStrictlyPositiveException.class, () -> em.fit(initialMixture, 100, -1e-10));
    }

    @Test
    void testFit_withDimensionMismatch_throwsDimensionMismatchException() {
        double[][] data = {
                {1.0, 2.0},
                {3.0, 4.0}
        };

        // Initial mixture with different dimension
        List<Pair<Double, MultivariateNormalDistribution>> components = new ArrayList<>();
        components.add(new Pair<>(0.5, new MultivariateNormalDistribution(new double[]{1.0}, new double[][]{{1.0}})));
        components.add(new Pair<>(0.5, new MultivariateNormalDistribution(new double[]{3.0}, new double[][]{{1.0}})));
        MixtureMultivariateNormalDistribution initialMixture = new MixtureMultivariateNormalDistribution(components);

        MultivariateNormalMixtureExpectationMaximization em =
                new MultivariateNormalMixtureExpectationMaximization(data);

        assertThrows(DimensionMismatchException.class, () -> em.fit(initialMixture, 100, 1e-5));
    }

    @Test
    void testFit_doesNotConverge_throwsConvergenceException() {
        double[][] data = {
                {1.0, 2.0},
                {3.0, 4.0},
                {5.0, 6.0}
        };

        MixtureMultivariateNormalDistribution initialMixture = createInitialMixture(1, 2, data);

        MultivariateNormalMixtureExpectationMaximization em =
                new MultivariateNormalMixtureExpectationMaximization(data);

        assertThrows(ConvergenceException.class, () -> em.fit(initialMixture, 1, 1e-10));
    }

    @Test
    void testFit_withSingularCovariance_throwsSingularMatrixException() {
        double[][] data = {
                {1.0, 2.0},
                {1.0, 2.0},
                {1.0, 2.0}
        };

        MixtureMultivariateNormalDistribution initialMixture = createInitialMixture(1, 2, data);

        MultivariateNormalMixtureExpectationMaximization em =
                new MultivariateNormalMixtureExpectationMaximization(data);

        assertThrows(SingularMatrixException.class, () -> em.fit(initialMixture, 100, 1e-5));
    }

    @Test
    void testFit_withMaxIterationsEqualsOne() {
        double[][] data = {
                {1.0, 2.0},
                {3.0, 4.0},
                {5.0, 6.0}
        };

        MixtureMultivariateNormalDistribution initialMixture = createInitialMixture(1, 2, data);

        MultivariateNormalMixtureExpectationMaximization em =
                new MultivariateNormalMixtureExpectationMaximization(data);

        assertDoesNotThrow(() -> em.fit(initialMixture, 1, 1e-5));

        MixtureMultivariateNormalDistribution fitted = em.getFittedModel();
        assertNotNull(fitted);
        assertEquals(1, fitted.getComponents().size());
    }

    @Test
    void testFit_withThresholdExactlyReached() {
        double[][] data = {
                {1.0, 2.0},
                {1.1, 2.1},
                {0.9, 1.9}
        };

        MixtureMultivariateNormalDistribution initialMixture = createInitialMixture(1, 2, data);

        MultivariateNormalMixtureExpectationMaximization em =
                new MultivariateNormalMixtureExpectationMaximization(data);

        assertDoesNotThrow(() -> em.fit(initialMixture, 1000, 1e-5));

        double ll = em.getLogLikelihood();
        assertTrue(ll > Double.NEGATIVE_INFINITY);
    }

    @Test
    void testFit_withSingleComponent() {
        double[][] data = {
                {2.0, 3.0},
                {2.1, 3.1},
                {1.9, 2.9}
        };

        MixtureMultivariateNormalDistribution initialMixture = createInitialMixture(1, 2, data);

        MultivariateNormalMixtureExpectationMaximization em =
                new MultivariateNormalMixtureExpectationMaximization(data);

        assertDoesNotThrow(() -> em.fit(initialMixture, 100, 1e-5));

        MixtureMultivariateNormalDistribution fitted = em.getFittedModel();
        assertNotNull(fitted);
        assertEquals(1, fitted.getComponents().size());
        assertEquals(1.0, fitted.getComponents().get(0).getFirst());
    }

    @Test
    void testFit_withMultipleComponents() {
        double[][] data = {
                {1.0, 2.0},
                {1.1, 2.1},
                {0.9, 1.9},
                {10.0, 10.0},
                {10.1, 10.1},
                {9.9, 9.9}
        };

        MixtureMultivariateNormalDistribution initialMixture = createInitialMixture(2, 2, data);

        MultivariateNormalMixtureExpectationMaximization em =
                new MultivariateNormalMixtureExpectationMaximization(data);

        assertDoesNotThrow(() -> em.fit(initialMixture, 1000, 1e-5));

        MixtureMultivariateNormalDistribution fitted = em.getFittedModel();
        assertNotNull(fitted);
        assertEquals(2, fitted.getComponents().size());
    }

    @Test
    void testFit_withZeroDataRows_throwsNotStrictlyPositiveException() {
        double[][] data = {};

        assertThrows(NotStrictlyPositiveException.class, () -> new MultivariateNormalMixtureExpectationMaximization(data));
    }

    @Test
    void testFit_withJaggedData_throwsDimensionMismatchException() {
        double[][] data = {
                {1.0, 2.0},
                {3.0}
        };

        assertThrows(DimensionMismatchException.class, () -> new MultivariateNormalMixtureExpectationMaximization(data));
    }

    @Test
    void testFit_withSingleColumnData_throwsNumberIsTooSmallException() {
        double[][] data = {
                {1.0},
                {2.0}
        };

        assertThrows(NotStrictlyPositiveException.class, () -> new MultivariateNormalMixtureExpectationMaximization(data));
    }

    private MixtureMultivariateNormalDistribution createInitialMixture(int numComponents, int dimension, double[][] data) {
        List<Pair<Double, MultivariateNormalDistribution>> components = new ArrayList<>();
        double weight = 1.0 / numComponents;
        for (int i = 0; i < numComponents; i++) {
            double[] mean = new double[dimension];
            double[][] cov = new double[dimension][dimension];
            for (int d = 0; d < dimension; d++) {
                mean[d] = 0.0;
                cov[d][d] = 1.0;
            }
            components.add(new Pair<>(weight, new MultivariateNormalDistribution(mean, cov)));
        }
        return new MixtureMultivariateNormalDistribution(components);
    }
}