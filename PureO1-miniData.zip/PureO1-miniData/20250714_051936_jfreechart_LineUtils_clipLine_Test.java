package org.jfree.chart.util;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import org.junit.jupiter.api.Test;

public class LineUtilsTest {

    @Test
    void testClipLine_NullLine_ShouldThrowNullPointerException() {
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        assertThrows(NullPointerException.class, () -> {
            LineUtils.clipLine(null, rect);
        });
    }

    @Test
    void testClipLine_NullRect_ShouldThrowNullPointerException() {
        Line2D line = new Line2D.Double(1, 1, 5, 5);
        assertThrows(NullPointerException.class, () -> {
            LineUtils.clipLine(line, null);
        });
    }

    @Test
    void testClipLine_AllCoordinatesFinite_LineInsideRect_ShouldReturnTrueWithoutModification() {
        Line2D.Double line = new Line2D.Double(2, 2, 8, 8);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        boolean result = LineUtils.clipLine(line, rect);
        assertTrue(result);
        assertEquals(2.0, line.getX1());
        assertEquals(2.0, line.getY1());
        assertEquals(8.0, line.getX2());
        assertEquals(8.0, line.getY2());
    }

    @Test
    void testClipLine_AllCoordinatesFinite_LineCompletelyOutsideRectWithNonOverlappingOutcodes_ShouldReturnFalse() {
        Line2D.Double line = new Line2D.Double(-5, -5, -1, -1);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        boolean result = LineUtils.clipLine(line, rect);
        assertFalse(result);
    }

    @Test
    void testClipLine_AllCoordinatesFinite_LinePartiallyInsideRect_ShouldReturnTrue() {
        Line2D.Double line = new Line2D.Double(-5, 5, 15, 5);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        boolean result = LineUtils.clipLine(line, rect);
        assertTrue(result);
        assertEquals(0.0, line.getX1());
        assertEquals(5.0, line.getY1());
        assertEquals(10.0, line.getX2());
        assertEquals(5.0, line.getY2());
    }

    @Test
    void testClipLine_NonFiniteCoordinates_ShouldReturnFalse_WithNaN() {
        Line2D.Double line = new Line2D.Double(Double.NaN, 5, 5, 5);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        boolean result = LineUtils.clipLine(line, rect);
        assertFalse(result);
    }

    @Test
    void testClipLine_NonFiniteCoordinates_ShouldReturnFalse_WithInfinity() {
        Line2D.Double line = new Line2D.Double(0, 0, Double.POSITIVE_INFINITY, 5);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        boolean result = LineUtils.clipLine(line, rect);
        assertFalse(result);
    }

    @Test
    void testClipLine_LineOutsideRectButTouchesEdge_ShouldReturnTrue() {
        Line2D.Double line = new Line2D.Double(-5, 0, 5, 0);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        boolean result = LineUtils.clipLine(line, rect);
        assertTrue(result);
        assertEquals(0.0, line.getX1());
        assertEquals(0.0, line.getY1());
        assertEquals(5.0, line.getX2());
        assertEquals(0.0, line.getY2());
    }

    @Test
    void testClipLine_ClippingAtLeft_ShouldReturnTrue() {
        Line2D.Double line = new Line2D.Double(-5, 5, 5, 5);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        boolean result = LineUtils.clipLine(line, rect);
        assertTrue(result);
        assertEquals(0.0, line.getX1());
        assertEquals(5.0, line.getY1());
        assertEquals(5.0, line.getX2());
        assertEquals(5.0, line.getY2());
    }

    @Test
    void testClipLine_ClippingAtRight_ShouldReturnTrue() {
        Line2D.Double line = new Line2D.Double(5, 5, 15, 5);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        boolean result = LineUtils.clipLine(line, rect);
        assertTrue(result);
        assertEquals(5.0, line.getX1());
        assertEquals(5.0, line.getY1());
        assertEquals(10.0, line.getX2());
        assertEquals(5.0, line.getY2());
    }

    @Test
    void testClipLine_ClippingAtBottom_ShouldReturnTrue() {
        Line2D.Double line = new Line2D.Double(5, 15, 5, 5);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        boolean result = LineUtils.clipLine(line, rect);
        assertTrue(result);
        assertEquals(5.0, line.getX1());
        assertEquals(10.0, line.getY1());
        assertEquals(5.0, line.getX2());
        assertEquals(5.0, line.getY2());
    }

    @Test
    void testClipLine_ClippingAtTop_ShouldReturnTrue() {
        Line2D.Double line = new Line2D.Double(5, -5, 5, 5);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        boolean result = LineUtils.clipLine(line, rect);
        assertTrue(result);
        assertEquals(5.0, line.getX1());
        assertEquals(0.0, line.getY1());
        assertEquals(5.0, line.getX2());
        assertEquals(5.0, line.getY2());
    }

    @Test
    void testClipLine_VerticalLine_Clipping_ShouldReturnTrue() {
        Line2D.Double line = new Line2D.Double(5, -5, 5, 15);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        boolean result = LineUtils.clipLine(line, rect);
        assertTrue(result);
        assertEquals(5.0, line.getX1());
        assertEquals(0.0, line.getY1());
        assertEquals(5.0, line.getX2());
        assertEquals(10.0, line.getY2());
    }

    @Test
    void testClipLine_HorizontalLine_Clipping_ShouldReturnTrue() {
        Line2D.Double line = new Line2D.Double(-5, 5, 15, 5);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        boolean result = LineUtils.clipLine(line, rect);
        assertTrue(result);
        assertEquals(0.0, line.getX1());
        assertEquals(5.0, line.getY1());
        assertEquals(10.0, line.getX2());
        assertEquals(5.0, line.getY2());
    }

    @Test
    void testClipLine_LineCrossingCorner_ShouldReturnTrue() {
        Line2D.Double line = new Line2D.Double(-5, -5, 15, 15);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        boolean result = LineUtils.clipLine(line, rect);
        assertTrue(result);
        // Intersection at (0,0) and (10,10)
        assertEquals(0.0, line.getX1());
        assertEquals(0.0, line.getY1());
        assertEquals(10.0, line.getX2());
        assertEquals(10.0, line.getY2());
    }

    @Test
    void testClipLine_LineWithNoIntersection_ShouldReturnFalse() {
        Line2D.Double line = new Line2D.Double(15, 15, 20, 20);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        boolean result = LineUtils.clipLine(line, rect);
        assertFalse(result);
    }
}