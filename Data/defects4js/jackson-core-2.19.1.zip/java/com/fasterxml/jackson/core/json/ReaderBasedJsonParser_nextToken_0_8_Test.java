package com.fasterxml.jackson.core.json;

import java.io.*;
import java.lang.reflect.*;
import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.JsonParser.Feature;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * JUnit 5 test class for ReaderBasedJsonParser.nextToken()
 */
public class ReaderBasedJsonParser_nextToken_0_8_Test {

    /**
     * Utility method to create a ReaderBasedJsonParser with specified features.
     */
    private ReaderBasedJsonParser createParser(String jsonContent, boolean allowNonNumericNumbers, boolean allowSingleQuotes) throws IOException, NoSuchFieldException, IllegalAccessException {
        JsonFactory factory = new JsonFactory();
        // Configure factory features using reflection
        ReaderBasedJsonParser parser = (ReaderBasedJsonParser) factory.createParser(new StringReader(jsonContent));

        // Enable or disable ALLOW_NON_NUMERIC_NUMBERS feature
        setFeature(parser, Feature.ALLOW_NON_NUMERIC_NUMBERS, allowNonNumericNumbers);

        // Enable or disable ALLOW_SINGLE_QUOTES feature
        setFeature(parser, Feature.ALLOW_SINGLE_QUOTES, allowSingleQuotes);

        return parser;
    }

    /**
     * Utility method to set a feature using reflection.
     */
    private void setFeature(ReaderBasedJsonParser parser, Feature feature, boolean state) throws NoSuchFieldException, IllegalAccessException {
        Field featuresField = ReaderBasedJsonParser.class.getDeclaredField("_features");
        featuresField.setAccessible(true);
        int currentFeatures = featuresField.getInt(parser); // Adjusted type
        if (state) {
            currentFeatures |= feature.getMask();
        } else {
            currentFeatures &= ~feature.getMask();
        }
        featuresField.setInt(parser, currentFeatures); // Adjusted type
    }

    @Test
    @DisplayName("TC36: nextToken() parses 'Infinity' when FEAT_MASK_NON_NUMERIC_NUMBERS is enabled")
    public void TC36_nextToken_Infinity_WithFeatureEnabled() throws Exception {
        // GIVEN
        String json = "{\"number\": Infinity}";
        ReaderBasedJsonParser parser = createParser(json, true, false);

        // WHEN
        JsonToken token = parser.nextToken(); // Start Object
        token = parser.nextToken(); // Field Name
        token = parser.nextToken(); // Field Value

        // THEN
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, token, "Expected VALUE_NUMBER_FLOAT token");
        double value = parser.getDoubleValue();
        assertTrue(Double.isInfinite(value), "Expected the value to be positive infinity");
    }

    @Test
    @DisplayName("TC37: nextToken() handles unexpected character after 't' in 'true'")
    public void TC37_nextToken_InvalidTrueToken() throws Exception {
        // GIVEN
        String json = "{ \"valid\": truE }"; // 'truE' is invalid
        ReaderBasedJsonParser parser = createParser(json, false, false);

        // WHEN & THEN
        JsonParseException exception = assertThrows(JsonParseException.class, () -> {
            parser.nextToken(); // Start Object
            parser.nextToken(); // Field Name
            parser.nextToken(); // Attempt to parse 'truE'
        }, "Expected JsonParseException for invalid 'true' token");

        assertTrue(exception.getMessage().contains("Unrecognized token"), "Exception message should indicate invalid token");
    }

    @Test
    @DisplayName("TC38: nextToken() skips invalid whitespace and continues parsing")
    public void TC38_nextToken_SkipsInvalidWhitespace() throws Exception {
        // GIVEN
        String json = "{ \"key\"\u0001: \"value\" }"; // Contains invalid whitespace character \u0001
        ReaderBasedJsonParser parser = createParser(json, false, false);

        // WHEN
        JsonToken token = parser.nextToken(); // Start Object
        token = parser.nextToken(); // Field Name
        token = parser.nextToken(); // Field Value

        // THEN
        assertEquals(JsonToken.VALUE_STRING, token, "Expected VALUE_STRING token after skipping invalid whitespace");
    }

    @Test
    @DisplayName("TC39: nextToken() handles single quote as field name when allowed")
    public void TC39_nextToken_SingleQuotedFieldNameAllowed() throws Exception {
        // GIVEN
        String json = "{ 'fieldName': 'value' }";
        ReaderBasedJsonParser parser = createParser(json, false, true);

        // WHEN
        JsonToken token = parser.nextToken(); // Start Object
        token = parser.nextToken(); // Field Name

        // THEN
        assertEquals(JsonToken.FIELD_NAME, token, "Expected FIELD_NAME token");
        assertEquals("fieldName", parser.currentName(), "Field name should match");
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken(), "Expected VALUE_STRING token");
    }

    @Test
    @DisplayName("TC40: nextToken() throws exception for single quote as field name when not allowed")
    public void TC40_nextToken_SingleQuotedFieldNameDisallowed() throws Exception {
        // GIVEN
        String json = "{ 'fieldName': 'value' }";
        ReaderBasedJsonParser parser = createParser(json, false, false);

        // WHEN & THEN
        JsonParseException exception = assertThrows(JsonParseException.class, () -> {
            parser.nextToken(); // Start Object
            parser.nextToken(); // Attempt to parse single-quoted field name
        }, "Expected JsonParseException for single-quoted field name when not allowed");

        assertTrue(exception.getMessage().contains("was expecting double-quote"), "Exception message should indicate expecting double-quote");
    }
}
