import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
// package org.jfree.chart;
// 
// import java.lang.reflect.*;
// import static org.mockito.Mockito.*;
// import java.io.*;
// import java.util.*;
// 
// import java.awt.Graphics2D;
// import java.awt.event.MouseEvent;
// import java.awt.geom.Point2D;
// import java.awt.geom.Rectangle2D;
// import java.lang.reflect.Field;
// 
// import static org.junit.jupiter.api.Assertions.*;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.Mockito;
// 
// import java.awt.Graphics;
// import org.jfree.chart.plot.Pannable;
// import org.jfree.chart.plot.Plot;
// import org.jfree.chart.plot.PlotOrientation;
// import org.jfree.chart.plot.Zoomable;
// 
// import javax.swing.JPopupMenu;
// 
// public class ChartPanel_mouseDragged_1_1_Test {
// 
//     @Test
//     @DisplayName("TC04: mouseDragged successfully zooms in on both domain and range axes")
//     public void testMouseDraggedZoomInBothAxes() throws Exception {
//         // Arrange
//         ChartPanel chartPanel = new ChartPanel(Mockito.mock(JFreeChart.class));
// 
//         // Using reflection to set private fields
//         Field popupField = ChartPanel.class.getDeclaredField("popup");
//         popupField.setAccessible(true);
//         popupField.set(chartPanel, null);
// 
//         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//         zoomPointField.setAccessible(true);
//         zoomPointField.set(chartPanel, new Point2D.Double(150, 150));
// 
//         // Mocking plot and its behavior
//         Plot mockPlot = Mockito.mock(Zoomable.class);
//         Mockito.when(mockPlot.isNotify()).thenReturn(true);
//         Mockito.doReturn(true).when(mockPlot).isNotify();
//         Mockito.doReturn(true).when(((Zoomable) mockPlot)).isDomainZoomable();
//         Mockito.doReturn(true).when(((Zoomable) mockPlot)).isRangeZoomable();
// 
//         Field chartField = ChartPanel.class.getDeclaredField("chart");
//         chartField.setAccessible(true);
//         JFreeChart mockChart = Mockito.mock(JFreeChart.class);
//         Mockito.when(mockChart.getPlot()).thenReturn(mockPlot);
//         chartField.set(chartPanel, mockChart);
// 
//         // Mocking repaint method
//         ChartPanel spyChartPanel = Mockito.spy(chartPanel);
// 
//         // Creating a MouseEvent with sufficient movement
//         MouseEvent mouseEvent = Mockito.mock(MouseEvent.class);
//         Mockito.when(mouseEvent.getX()).thenReturn(160);
//         Mockito.when(mouseEvent.getY()).thenReturn(160);
// 
//         // Act
//         spyChartPanel.mouseDragged(mouseEvent);
// 
//         // Assert
//         Mockito.verify((Zoomable) mockPlot, Mockito.times(1)).zoomDomainAxes(Mockito.anyDouble(), Mockito.any(), Mockito.any());
//         Mockito.verify((Zoomable) mockPlot, Mockito.times(1)).zoomRangeAxes(Mockito.anyDouble(), Mockito.any(), Mockito.any());
//         Mockito.verify(spyChartPanel, Mockito.times(1)).repaint();
//     }
// 
//     @Test
//     @DisplayName("TC05: mouseDragged attempts to zoom but movement does not exceed zoomTriggerDistance, resulting in no zoom")
//     public void testMouseDraggedNoZoomDueToInsufficientMovement() throws Exception {
//         // Arrange
//         ChartPanel chartPanel = new ChartPanel(Mockito.mock(JFreeChart.class));
// 
//         // Using reflection to set private fields
//         Field popupField = ChartPanel.class.getDeclaredField("popup");
//         popupField.setAccessible(true);
//         popupField.set(chartPanel, null);
// 
//         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//         zoomPointField.setAccessible(true);
//         zoomPointField.set(chartPanel, new Point2D.Double(100, 100));
// 
//         // Mocking plot and its behavior
//         Plot mockPlot = Mockito.mock(Zoomable.class);
//         Mockito.when(mockPlot.isNotify()).thenReturn(true);
//         Mockito.doReturn(true).when(mockPlot).isNotify();
// 
//         Field chartField = ChartPanel.class.getDeclaredField("chart");
//         chartField.setAccessible(true);
//         JFreeChart mockChart = Mockito.mock(JFreeChart.class);
//         Mockito.when(mockChart.getPlot()).thenReturn(mockPlot);
//         chartField.set(chartPanel, mockChart);
// 
//         // Mocking Graphics2D
//         Graphics g2 = Mockito.mock(Graphics.class);
//         Graphics2D graphics2D = Mockito.mock(Graphics2D.class);
//         Mockito.when(g2.create()).thenReturn(graphics2D);
// 
//         // Creating a MouseEvent with insufficient movement
//         MouseEvent mouseEvent = Mockito.mock(MouseEvent.class);
//         Mockito.when(mouseEvent.getX()).thenReturn(105);
//         Mockito.when(mouseEvent.getY()).thenReturn(105);
// 
//         // Mocking drawZoomRectangle and dispose
//         Method drawZoomRectangleMethod = ChartPanel.class.getDeclaredMethod("drawZoomRectangle", Graphics2D.class, boolean.class);
//         drawZoomRectangleMethod.setAccessible(true);
//         // No zoom should be performed, so drawZoomRectangle should be called to erase
//         chartPanel.mouseDragged(mouseEvent);
// 
//         // Since zoomTriggerDistance is 10 by default, movement of (5,5) is insufficient
//         // Assert
//         // Verify that drawZoomRectangle is called to erase
//         Mockito.verify(graphics2D, Mockito.times(1)).dispose();
//     }
// 
//     @Test
//     @DisplayName("TC06: mouseDragged successfully zooms in on domain axis only")
//     public void testMouseDraggedZoomInDomainAxisOnly() throws Exception {
//         // Arrange
//         ChartPanel chartPanel = new ChartPanel(Mockito.mock(JFreeChart.class));
// 
//         // Using reflection to set private fields
//         Field popupField = ChartPanel.class.getDeclaredField("popup");
//         popupField.setAccessible(true);
//         popupField.set(chartPanel, null);
// 
//         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//         zoomPointField.setAccessible(true);
//         zoomPointField.set(chartPanel, new Point2D.Double(200, 200));
// 
//         // Mocking plot and its behavior
//         Plot mockPlot = Mockito.mock(Zoomable.class);
//         Mockito.when(mockPlot.isNotify()).thenReturn(true);
//         Mockito.doReturn(true).when(mockPlot).isNotify();
//         Mockito.doReturn(true).when(((Zoomable) mockPlot)).isDomainZoomable();
// 
//         Field chartField = ChartPanel.class.getDeclaredField("chart");
//         chartField.setAccessible(true);
//         JFreeChart mockChart = Mockito.mock(JFreeChart.class);
//         Mockito.when(mockChart.getPlot()).thenReturn(mockPlot);
//         chartField.set(chartPanel, mockChart);
// 
//         // Mocking repaint method
//         ChartPanel spyChartPanel = Mockito.spy(chartPanel);
// 
//         // Creating a MouseEvent with sufficient horizontal movement
//         MouseEvent mouseEvent = Mockito.mock(MouseEvent.class);
//         Mockito.when(mouseEvent.getX()).thenReturn(210);
//         Mockito.when(mouseEvent.getY()).thenReturn(200);
// 
//         // Act
//         spyChartPanel.mouseDragged(mouseEvent);
// 
//         // Assert
//         Mockito.verify((Zoomable) mockPlot, Mockito.times(1)).zoomDomainAxes(Mockito.anyDouble(), Mockito.any(), Mockito.any());
//         Mockito.verify(spyChartPanel, Mockito.times(1)).repaint();
//     }
// 
//     @Test
//     @DisplayName("TC07: mouseDragged successfully zooms in on range axis only")
//     public void testMouseDraggedZoomInRangeAxisOnly() throws Exception {
//         // Arrange
//         ChartPanel chartPanel = new ChartPanel(Mockito.mock(JFreeChart.class));
// 
//         // Using reflection to set private fields
//         Field popupField = ChartPanel.class.getDeclaredField("popup");
//         popupField.setAccessible(true);
//         popupField.set(chartPanel, null);
// 
//         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//         zoomPointField.setAccessible(true);
//         zoomPointField.set(chartPanel, new Point2D.Double(250, 250));
// 
//         // Mocking plot and its behavior
//         Plot mockPlot = Mockito.mock(Zoomable.class);
//         Mockito.when(mockPlot.isNotify()).thenReturn(true);
//         Mockito.doReturn(true).when(mockPlot).isNotify();
//         Mockito.doReturn(true).when(((Zoomable) mockPlot)).isRangeZoomable();
// 
//         Field chartField = ChartPanel.class.getDeclaredField("chart");
//         chartField.setAccessible(true);
//         JFreeChart mockChart = Mockito.mock(JFreeChart.class);
//         Mockito.when(mockChart.getPlot()).thenReturn(mockPlot);
//         chartField.set(chartPanel, mockChart);
// 
//         // Mocking repaint method
//         ChartPanel spyChartPanel = Mockito.spy(chartPanel);
// 
//         // Creating a MouseEvent with sufficient vertical movement
//         MouseEvent mouseEvent = Mockito.mock(MouseEvent.class);
//         Mockito.when(mouseEvent.getX()).thenReturn(250);
//         Mockito.when(mouseEvent.getY()).thenReturn(260);
// 
//         // Act
//         spyChartPanel.mouseDragged(mouseEvent);
// 
//         // Assert
//         Mockito.verify((Zoomable) mockPlot, Mockito.times(1)).zoomRangeAxes(Mockito.anyDouble(), Mockito.any(), Mockito.any());
//         Mockito.verify(spyChartPanel, Mockito.times(1)).repaint();
//     }
// 
//     @Test
//     @DisplayName("TC08: mouseDragged attempts to zoom on domain axis only but movement does not exceed zoomTriggerDistance")
//     public void testMouseDraggedZoomInDomainAxisOnlyInsufficientMovement() throws Exception {
//         // Arrange
//         ChartPanel chartPanel = new ChartPanel(Mockito.mock(JFreeChart.class));
// 
//         // Using reflection to set private fields
//         Field popupField = ChartPanel.class.getDeclaredField("popup");
//         popupField.setAccessible(true);
//         popupField.set(chartPanel, null);
// 
//         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//         zoomPointField.setAccessible(true);
//         zoomPointField.set(chartPanel, new Point2D.Double(150, 150));
// 
//         // Mocking plot and its behavior
//         Plot mockPlot = Mockito.mock(Zoomable.class);
//         Mockito.when(mockPlot.isNotify()).thenReturn(true);
//         Mockito.doReturn(true).when(mockPlot).isNotify();
// 
//         Field chartField = ChartPanel.class.getDeclaredField("chart");
//         chartField.setAccessible(true);
//         JFreeChart mockChart = Mockito.mock(JFreeChart.class);
//         Mockito.when(mockChart.getPlot()).thenReturn(mockPlot);
//         chartField.set(chartPanel, mockChart);
// 
//         // Mocking Graphics2D
//         Graphics g2 = Mockito.mock(Graphics.class);
//         Graphics2D graphics2D = Mockito.mock(Graphics2D.class);
//         Mockito.when(g2.create()).thenReturn(graphics2D);
// 
//         // Creating a MouseEvent with insufficient horizontal movement
//         MouseEvent mouseEvent = Mockito.mock(MouseEvent.class);
//         Mockito.when(mouseEvent.getX()).thenReturn(154);
//         Mockito.when(mouseEvent.getY()).thenReturn(150);
// 
//         // Mocking drawZoomRectangle and dispose
//         Method drawZoomRectangleMethod = ChartPanel.class.getDeclaredMethod("drawZoomRectangle", Graphics2D.class, boolean.class);
//         drawZoomRectangleMethod.setAccessible(true);
//         // No zoom should be performed, so drawZoomRectangle should be called to erase
//         chartPanel.mouseDragged(mouseEvent);
// 
//         // Since zoomTriggerDistance is 10 by default, movement of (4,0) is insufficient
//         // Assert
//         // Verify that drawZoomRectangle is called to erase
//         Mockito.verify(graphics2D, Mockito.times(1)).dispose();
//     }
// }