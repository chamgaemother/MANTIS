import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.Pannable;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotOrientation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ChartPanelTest {
    private JFreeChart mockChart;
    private Plot mockPlot;
    private ChartPanel chartPanel;

    @BeforeEach
    public void setUp() {
        mockChart = mock(JFreeChart.class);
        mockPlot = mock(Plot.class);
        when(mockChart.getPlot()).thenReturn(mockPlot);
        chartPanel = new ChartPanel(mockChart);
    }

    @Test
    public void testMouseDraggedPopupMenuShowing() {
        JPopupMenu popup = mock(JPopupMenu.class);
        when(popup.isShowing()).thenReturn(true);
        chartPanel.setPopupMenu(popup);
        MouseEvent event = new MouseEvent(chartPanel, 0, 0, 0, 100, 200, 1, false);
        chartPanel.mouseDragged(event);
        verifyNoInteractions(mockPlot); // No interaction because popup is showing
    }

    @Test
    public void testMouseDraggedPanMode() {
        Pannable mockPannable = mock(Pannable.class);
        when(mockPlot instanceof Pannable).thenReturn(true);
        when(mockPlot.isNotify()).thenReturn(true);
        when((Pannable) mockPlot).thenReturn(mockPannable);
        chartPanel.setDomainZoomable(false);
        chartPanel.setRangeZoomable(false);
        chartPanel.mousePressed(new MouseEvent(chartPanel, 0, 0, MouseEvent.CTRL_DOWN_MASK, 100, 200, 1, false));
        chartPanel.mouseDragged(new MouseEvent(chartPanel, 0, 0, MouseEvent.CTRL_DOWN_MASK, 105, 205, 1, false));
        verify(mockPannable).panDomainAxes(anyDouble(), any(), any());
        verify(mockPannable).panRangeAxes(anyDouble(), any(), any());
        chartPanel.setDomainZoomable(true);
        chartPanel.setRangeZoomable(true);
        chartPanel.setMouseZoomable(false, false);
    }

    @Test
    public void testMouseDraggedWithZoomRectangle() {
        chartPanel.setDomainZoomable(true);
        chartPanel.setRangeZoomable(true);
        chartPanel.mousePressed(new MouseEvent(chartPanel, 0, 0, 0, 100, 200, 1, false));
        when(mockPlot instanceof Pannable).thenReturn(false);
        when(mockPlot.isNotify()).thenReturn(true);
        chartPanel.mouseDragged(new MouseEvent(chartPanel, 0, 0, 0, 150, 250, 1, false));
        assertNotNull(chartPanel.getAnchor());
        verify(mockPlot, never()).setNotify(anyBoolean());
    }

    @Test
    public void testMouseDraggedWithNullZoomPoint() {
        chartPanel.mouseDragged(new MouseEvent(chartPanel, 0, 0, 0, 100, 200, 1, false));
        // Ensure no NullPointerException is thrown
    }
}