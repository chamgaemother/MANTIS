package com.google.gson.stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.StringReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;

public class JsonReader_skipValue_0_2_Test {

    @Test
    @DisplayName("skipValue() skips single-quoted value")
    public void TC06() throws Exception {
        // Initialize JsonReader with a single-quoted value
        String json = "'test'";
        JsonReader reader = new JsonReader(new StringReader(json));

        // Use reflection to set the 'peeked' field to PEEKED_SINGLE_QUOTED (39)
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        peekedField.setInt(reader, 39); // PEEKED_SINGLE_QUOTED

        // Invoke skipValue()
        reader.skipValue();

        // Verify that 'skipQuotedValue' was invoked by checking the 'pos' field has been updated
        Field posField = JsonReader.class.getDeclaredField("pos");
        posField.setAccessible(true);
        int pos = posField.getInt(reader);

        // The single-quoted value 'test' has 6 characters including quotes and escape characters
        assertEquals(6, pos, "Position should be updated after skipping single-quoted value");
    }

    @Test
    @DisplayName("skipValue() skips double-quoted value")
    public void TC07() throws Exception {
        // Initialize JsonReader with a double-quoted value
        String json = "\"test\"";
        JsonReader reader = new JsonReader(new StringReader(json));

        // Use reflection to set the 'peeked' field to PEEKED_DOUBLE_QUOTED (34)
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        peekedField.setInt(reader, 34); // PEEKED_DOUBLE_QUOTED

        // Invoke skipValue()
        reader.skipValue();

        // Verify that 'skipQuotedValue' was invoked by checking the 'pos' field has been updated
        Field posField = JsonReader.class.getDeclaredField("pos");
        posField.setAccessible(true);
        int pos = posField.getInt(reader);

        // The double-quoted value "test" has 6 characters including quotes
        assertEquals(6, pos, "Position should be updated after skipping double-quoted value");
    }

    @Test
    @DisplayName("skipValue() with PEEKED_UNQUOTED_NAME and count is zero")
    public void TC08() throws Exception {
        // Initialize JsonReader with an unquoted name and count = 0
        String json = "name";
        JsonReader reader = new JsonReader(new StringReader(json));

        // Use reflection to set the 'peeked' field to PEEKED_UNQUOTED_NAME
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        peekedField.setInt(reader, 17); // PEEKED_UNQUOTED_NAME (assuming value 17)

        // Initialize 'count' to 0 by ensuring no nested structures
        // Since 'count' is a local variable, we ensure the input does not create nested counts

        // Invoke skipValue()
        reader.skipValue();

        // Verify that 'skipUnquotedValue' was invoked and 'pathNames' is updated to '<skipped>'
        Field pathNamesField = JsonReader.class.getDeclaredField("pathNames");
        pathNamesField.setAccessible(true);
        String[] pathNames = (String[]) pathNamesField.get(reader);

        Field stackSizeField = JsonReader.class.getDeclaredField("stackSize");
        stackSizeField.setAccessible(true);
        int stackSize = stackSizeField.getInt(reader);

        assertEquals("<skipped>", pathNames[stackSize - 1], "pathNames should be updated to '<skipped>'");
    }

    @Test
    @DisplayName("skipValue() with PEEKED_SINGLE_QUOTED_NAME and count is zero")
    public void TC09() throws Exception {
        // Initialize JsonReader with a single-quoted name and count = 0
        String json = "'name'";
        JsonReader reader = new JsonReader(new StringReader(json));

        // Use reflection to set the 'peeked' field to PEEKED_SINGLE_QUOTED_NAME (39)
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        peekedField.setInt(reader, 39); // PEEKED_SINGLE_QUOTED_NAME

        // Initialize 'count' to 0 by ensuring no nested structures

        // Invoke skipValue()
        reader.skipValue();

        // Verify that 'skipQuotedValue' was invoked and 'pathNames' is updated to '<skipped>'
        Field pathNamesField = JsonReader.class.getDeclaredField("pathNames");
        pathNamesField.setAccessible(true);
        String[] pathNames = (String[]) pathNamesField.get(reader);

        Field stackSizeField = JsonReader.class.getDeclaredField("stackSize");
        stackSizeField.setAccessible(true);
        int stackSize = stackSizeField.getInt(reader);

        assertEquals("<skipped>", pathNames[stackSize - 1], "pathNames should be updated to '<skipped>'");
    }

    @Test
    @DisplayName("skipValue() with PEEKED_DOUBLE_QUOTED_NAME and count is zero")
    public void TC10() throws Exception {
        // Initialize JsonReader with a double-quoted name and count = 0
        String json = "\"name\"";
        JsonReader reader = new JsonReader(new StringReader(json));

        // Use reflection to set the 'peeked' field to PEEKED_DOUBLE_QUOTED_NAME (34)
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        peekedField.setInt(reader, 34); // PEEKED_DOUBLE_QUOTED_NAME

        // Initialize 'count' to 0 by ensuring no nested structures

        // Invoke skipValue()
        reader.skipValue();

        // Verify that 'skipQuotedValue' was invoked and 'pathNames' is updated to '<skipped>'
        Field pathNamesField = JsonReader.class.getDeclaredField("pathNames");
        pathNamesField.setAccessible(true);
        String[] pathNames = (String[]) pathNamesField.get(reader);

        Field stackSizeField = JsonReader.class.getDeclaredField("stackSize");
        stackSizeField.setAccessible(true);
        int stackSize = stackSizeField.getInt(reader);

        assertEquals("<skipped>", pathNames[stackSize - 1], "pathNames should be updated to '<skipped>'");
    }
}