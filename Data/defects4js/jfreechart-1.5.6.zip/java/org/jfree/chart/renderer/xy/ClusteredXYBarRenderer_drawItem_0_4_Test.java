package org.jfree.chart.renderer.xy;
import org.jfree.chart.ui.RectangleEdge;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.XYItemLabelGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.BarPainter;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class ClusteredXYBarRenderer_drawItem_0_4_Test {

//     @Test
//     @DisplayName("drawItem handles getShadowsVisible false and pass is 0")
//     void TC16_drawItem_ShadowsNotVisible_Pass0() throws Exception {
        // Arrange
//         ClusteredXYBarRenderer renderer = new ClusteredXYBarRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         BarPainter barPainter = mock(BarPainter.class);
//         when(renderer.getBarPainter()).thenReturn(barPainter);
//         when(renderer.getShadowsVisible()).thenReturn(false);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset,
//                 0, 0, crosshairState, 0);
// 
        // Assert
//         verify(barPainter, never()).paintBarShadow(any(Graphics2D.class), eq(renderer), anyInt(), anyInt(), any(Rectangle2D.class),
//                 any(RectangleEdge.class), anyBoolean());
//     }

//     @Test
//     @DisplayName("drawItem handles pass equals 1 for painting bar")
//     void TC17_drawItem_Pass1_PaintBar() throws Exception {
        // Arrange
//         ClusteredXYBarRenderer renderer = new ClusteredXYBarRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         BarPainter barPainter = mock(BarPainter.class);
//         when(renderer.getBarPainter()).thenReturn(barPainter);
//         when(renderer.getShadowsVisible()).thenReturn(true);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset,
//                 0, 0, crosshairState, 1);
// 
        // Assert
//         verify(barPainter).paintBar(any(Graphics2D.class), eq(renderer), eq(0), eq(0), any(Rectangle2D.class), any(RectangleEdge.class));
//         verify(barPainter, never()).paintBarShadow(any(Graphics2D.class), eq(renderer), anyInt(), anyInt(), any(Rectangle2D.class),
//                 any(RectangleEdge.class), anyBoolean());
//     }

//     @Test
//     @DisplayName("drawItem paints bar and label when item label is visible")
//     void TC18_drawItem_ItemLabelVisible_Pass1() throws Exception {
        // Arrange
//         ClusteredXYBarRenderer renderer = new ClusteredXYBarRenderer();
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         XYItemLabelGenerator labelGenerator = mock(XYItemLabelGenerator.class);
//         when(renderer.getItemLabelGenerator(0, 0)).thenReturn(labelGenerator);
// 
//         BarPainter barPainter = mock(BarPainter.class);
//         when(renderer.getBarPainter()).thenReturn(barPainter);
//         when(renderer.getShadowsVisible()).thenReturn(false);
//         when(renderer.isItemLabelVisible(0, 0)).thenReturn(true);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset,
//                 0, 0, crosshairState, 1);
// 
        // Assert
//         verify(barPainter).paintBar(any(Graphics2D.class), eq(renderer), eq(0), eq(0), any(Rectangle2D.class), any(RectangleEdge.class));
//         verify(labelGenerator).generateLabel(dataset, 0, 0);
//     }

//     @Test
//     @DisplayName("drawItem does not paint label when item label is not visible")
//     void TC19_drawItem_ItemLabelNotVisible_Pass1() throws Exception {
        // Arrange
//         ClusteredXYBarRenderer renderer = new ClusteredXYBarRenderer();
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         BarPainter barPainter = mock(BarPainter.class);
//         when(renderer.getBarPainter()).thenReturn(barPainter);
//         when(renderer.getShadowsVisible()).thenReturn(false);
//         when(renderer.isItemLabelVisible(0, 0)).thenReturn(false);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset,
//                 0, 0, crosshairState, 1);
// 
        // Assert
//         verify(barPainter).paintBar(any(Graphics2D.class), eq(renderer), eq(0), eq(0), any(Rectangle2D.class), any(RectangleEdge.class));
//         verify(renderer, never()).drawItemLabel(any(Graphics2D.class), any(XYDataset.class), anyInt(), anyInt(), any(XYPlot.class), any(XYItemLabelGenerator.class), any(Rectangle2D.class), anyBoolean());
//     }

//     @Test
//     @DisplayName("drawItem adds entity when PlotRenderingInfo is provided and entity collection is not null")
//     void TC20_drawItem_WithPlotRenderingInfo_EntityAdded() throws Exception {
        // Arrange
//         ClusteredXYBarRenderer renderer = new ClusteredXYBarRenderer();
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         EntityCollection entityCollection = mock(EntityCollection.class);
//         PlotRenderingInfo.Owner owner = mock(PlotRenderingInfo.Owner.class);
//         when(info.getOwner()).thenReturn(owner);
//         when(owner.getEntityCollection()).thenReturn(entityCollection);
// 
//         BarPainter barPainter = mock(BarPainter.class);
//         when(renderer.getBarPainter()).thenReturn(barPainter);
//         when(renderer.getShadowsVisible()).thenReturn(false);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset,
//                 0, 0, crosshairState, 1);
// 
        // Assert
//         verify(entityCollection).add(any());
//     }
}