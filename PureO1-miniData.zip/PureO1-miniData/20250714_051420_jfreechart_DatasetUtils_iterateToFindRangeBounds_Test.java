import org.jfree.data.Range;
import org.jfree.data.general.DatasetUtils;
import org.jfree.data.xy.BoxAndWhiskerXYDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.OHLCDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

class DatasetUtilsTest {

    // Mock implementations of various XYDataset types

    static class MockXYDataset implements XYDataset {
        private final int seriesCount;
        private final int itemCount;
        private final double[][] xValues;
        private final double[][] yValues;

        public MockXYDataset(int seriesCount, int itemCount, double[][] xValues, double[][] yValues) {
            this.seriesCount = seriesCount;
            this.itemCount = itemCount;
            this.xValues = xValues;
            this.yValues = yValues;
        }

        @Override
        public int getSeriesCount() {
            return seriesCount;
        }

        @Override
        public Comparable getSeriesKey(int series) {
            return "Series" + series;
        }

        @Override
        public int indexOf(Comparable seriesKey) {
            for (int i = 0; i < seriesCount; i++) {
                if (getSeriesKey(i).equals(seriesKey)) {
                    return i;
                }
            }
            return -1;
        }

        @Override
        public int getItemCount(int series) {
            return itemCount;
        }

        @Override
        public Number getX(int series, int item) {
            return xValues[series][item];
        }

        @Override
        public double getXValue(int series, int item) {
            return xValues[series][item];
        }

        @Override
        public Number getY(int series, int item) {
            return yValues[series][item];
        }

        @Override
        public double getYValue(int series, int item) {
            return yValues[series][item];
        }

        @Override
        public void addChangeListener(org.jfree.data.general.DatasetChangeListener listener) {
            // Not implemented
        }

        @Override
        public void removeChangeListener(org.jfree.data.general.DatasetChangeListener listener) {
            // Not implemented
        }
    }

    static class MockOHLCDataset implements OHLCDataset {
        private final int seriesCount;
        private final int itemCount;
        private final double[][] xValues;
        private final double[][] yValues;
        private final double[][] openValues;
        private final double[][] highValues;
        private final double[][] lowValues;
        private final double[][] closeValues;

        public MockOHLCDataset(int seriesCount, int itemCount, double[][] xValues, double[][] openValues,
                               double[][] highValues, double[][] lowValues, double[][] closeValues) {
            this.seriesCount = seriesCount;
            this.itemCount = itemCount;
            this.xValues = xValues;
            this.openValues = openValues;
            this.highValues = highValues;
            this.lowValues = lowValues;
            this.closeValues = closeValues;
            this.yValues = new double[seriesCount][itemCount];
            for (int s = 0; s < seriesCount; s++) {
                for (int i = 0; i < itemCount; i++) {
                    yValues[s][i] = closeValues[s][i];
                }
            }
        }

        @Override
        public int getSeriesCount() {
            return seriesCount;
        }

        @Override
        public Comparable getSeriesKey(int series) {
            return "OHLCSeries" + series;
        }

        @Override
        public int indexOf(Comparable seriesKey) {
            for (int i = 0; i < seriesCount; i++) {
                if (getSeriesKey(i).equals(seriesKey)) {
                    return i;
                }
            }
            return -1;
        }

        @Override
        public int getItemCount(int series) {
            return itemCount;
        }

        @Override
        public Number getX(int series, int item) {
            return xValues[series][item];
        }

        @Override
        public double getXValue(int series, int item) {
            return xValues[series][item];
        }

        @Override
        public Number getY(int series, int item) {
            return yValues[series][item];
        }

        @Override
        public double getYValue(int series, int item) {
            return yValues[series][item];
        }

        @Override
        public Number getOpen(int series, int item) {
            return openValues[series][item];
        }

        @Override
        public Number getHigh(int series, int item) {
            return highValues[series][item];
        }

        @Override
        public Number getLow(int series, int item) {
            return lowValues[series][item];
        }

        @Override
        public Number getClose(int series, int item) {
            return closeValues[series][item];
        }

        @Override
        public void addChangeListener(org.jfree.data.general.DatasetChangeListener listener) {
            // Not implemented
        }

        @Override
        public void removeChangeListener(org.jfree.data.general.DatasetChangeListener listener) {
            // Not implemented
        }
    }

    static class MockBoxAndWhiskerXYDataset implements BoxAndWhiskerXYDataset {
        private final int seriesCount;
        private final int itemCount;
        private final double[][] xValues;
        private final double[][] minRegularValues;
        private final double[][] maxRegularValues;

        public MockBoxAndWhiskerXYDataset(int seriesCount, int itemCount, double[][] xValues,
                                         double[][] minRegularValues, double[][] maxRegularValues) {
            this.seriesCount = seriesCount;
            this.itemCount = itemCount;
            this.xValues = xValues;
            this.minRegularValues = minRegularValues;
            this.maxRegularValues = maxRegularValues;
        }

        @Override
        public int getSeriesCount() {
            return seriesCount;
        }

        @Override
        public Comparable getSeriesKey(int series) {
            return "BoxWhiskerSeries" + series;
        }

        @Override
        public int indexOf(Comparable seriesKey) {
            for (int i = 0; i < seriesCount; i++) {
                if (getSeriesKey(i).equals(seriesKey)) {
                    return i;
                }
            }
            return -1;
        }

        @Override
        public int getItemCount(int series) {
            return itemCount;
        }

        @Override
        public Number getX(int series, int item) {
            return xValues[series][item];
        }

        @Override
        public double getXValue(int series, int item) {
            return xValues[series][item];
        }

        @Override
        public Number getY(int series, int item) {
            return null; // Not used
        }

        @Override
        public double getYValue(int series, int item) {
            return 0.0; // Not used
        }

        @Override
        public Number getMinRegularValue(int series, int item) {
            return minRegularValues[series][item];
        }

        @Override
        public Number getMaxRegularValue(int series, int item) {
            return maxRegularValues[series][item];
        }

        @Override
        public Number getMeanValue(int series, int item) {
            return null; // Not used
        }

        @Override
        public Number getMedianValue(int series, int item) {
            return null; // Not used
        }

        @Override
        public Number getQ1Value(int series, int item) {
            return null; // Not used
        }

        @Override
        public Number getQ3Value(int series, int item) {
            return null; // Not used
        }

        @Override
        public Number getMinOutlier(int series, int item) {
            return null; // Not used
        }

        @Override
        public Number getMaxOutlier(int series, int item) {
            return null; // Not used
        }

        @Override
        public boolean getSuppressBox(int series, int item) {
            return false; // Not used
        }

        @Override
        public void addChangeListener(org.jfree.data.general.DatasetChangeListener listener) {
            // Not implemented
        }

        @Override
        public void removeChangeListener(org.jfree.data.general.DatasetChangeListener listener) {
            // Not implemented
        }
    }

    static class MockIntervalXYDataset implements IntervalXYDataset {
        private final int seriesCount;
        private final int itemCount;
        private final double[][] xValues;
        private final double[][] startXValues;
        private final double[][] endXValues;
        private final double[][] yValues;
        private final double[][] startYValues;
        private final double[][] endYValues;

        public MockIntervalXYDataset(int seriesCount, int itemCount, double[][] xValues,
                                     double[][] startXValues, double[][] endXValues,
                                     double[][] yValues, double[][] startYValues,
                                     double[][] endYValues) {
            this.seriesCount = seriesCount;
            this.itemCount = itemCount;
            this.xValues = xValues;
            this.startXValues = startXValues;
            this.endXValues = endXValues;
            this.yValues = yValues;
            this.startYValues = startYValues;
            this.endYValues = endYValues;
        }

        @Override
        public int getSeriesCount() {
            return seriesCount;
        }

        @Override
        public Comparable getSeriesKey(int series) {
            return "IntervalSeries" + series;
        }

        @Override
        public int indexOf(Comparable seriesKey) {
            for (int i = 0; i < seriesCount; i++) {
                if (getSeriesKey(i).equals(seriesKey)) {
                    return i;
                }
            }
            return -1;
        }

        @Override
        public int getItemCount(int series) {
            return itemCount;
        }

        @Override
        public Number getX(int series, int item) {
            return xValues[series][item];
        }

        @Override
        public double getXValue(int series, int item) {
            return xValues[series][item];
        }

        @Override
        public Number getY(int series, int item) {
            return yValues[series][item];
        }

        @Override
        public double getYValue(int series, int item) {
            return yValues[series][item];
        }

        @Override
        public Number getStartX(int series, int item) {
            return startXValues[series][item];
        }

        @Override
        public Number getEndX(int series, int item) {
            return endXValues[series][item];
        }

        @Override
        public Number getStartY(int series, int item) {
            return startYValues[series][item];
        }

        @Override
        public Number getEndY(int series, int item) {
            return endYValues[series][item];
        }

        @Override
        public org.jfree.data.xy.IntervalXYDelegate getIntervalXYDelegate() {
            return null; // Not used
        }

        @Override
        public void addChangeListener(org.jfree.data.general.DatasetChangeListener listener) {
            // Not implemented
        }

        @Override
        public void removeChangeListener(org.jfree.data.general.DatasetChangeListener listener) {
            // Not implemented
        }
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with null dataset")
    void testIterateToFindRangeBounds_NullDataset() {
        List<Comparable> visibleSeriesKeys = Collections.emptyList();
        Range xRange = new Range(0.0, 10.0);
        assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateToFindRangeBounds(null, visibleSeriesKeys, xRange, true);
        });
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with null visibleSeriesKeys")
    void testIterateToFindRangeBounds_NullVisibleSeriesKeys() {
        XYDataset dataset = new MockXYDataset(1, 1, new double[][]{{5.0}}, new double[][]{{5.0}});
        Range xRange = new Range(0.0, 10.0);
        assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateToFindRangeBounds(dataset, null, xRange, true);
        });
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with null xRange")
    void testIterateToFindRangeBounds_NullXRange() {
        XYDataset dataset = new MockXYDataset(1, 1, new double[][]{{5.0}}, new double[][]{{5.0}});
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series0");
        assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, null, true);
        });
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with OHLCDataset and includeInterval=true, x in range")
    void testIterateToFindRangeBounds_OHLCDataset_InRange() {
        double[][] xValues = { {5.0, 15.0} };
        double[][] open = { {4.0, 14.0} };
        double[][] high = { {6.0, 16.0} };
        double[][] low = { {3.0, 13.0} };
        double[][] close = { {5.5, 15.5} };
        OHLCDataset dataset = new MockOHLCDataset(1, 2, xValues, open, high, low, close);
        List<Comparable> visibleSeriesKeys = Arrays.asList("OHLCSeries0");
        Range xRange = new Range(4.0, 14.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNotNull(result);
        assertEquals(3.0, result.getLowerBound());
        assertEquals(16.0, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with OHLCDataset and includeInterval=true, x out of range")
    void testIterateToFindRangeBounds_OHLCDataset_OutOfRange() {
        double[][] xValues = { {5.0, 15.0} };
        double[][] open = { {4.0, 14.0} };
        double[][] high = { {6.0, 16.0} };
        double[][] low = { {3.0, 13.0} };
        double[][] close = { {5.5, 15.5} };
        OHLCDataset dataset = new MockOHLCDataset(1, 2, xValues, open, high, low, close);
        List<Comparable> visibleSeriesKeys = Arrays.asList("OHLCSeries0");
        Range xRange = new Range(10.0, 20.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNotNull(result);
        assertEquals(13.0, result.getLowerBound());
        assertEquals(16.0, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with OHLCDataset and includeInterval=false")
    void testIterateToFindRangeBounds_OHLCDataset_IncludeIntervalFalse() {
        double[][] xValues = { {5.0, 15.0} };
        double[][] open = { {4.0, 14.0} };
        double[][] high = { {6.0, 16.0} };
        double[][] low = { {3.0, 13.0} };
        double[][] close = { {5.5, 15.5} };
        OHLCDataset dataset = new MockOHLCDataset(1, 2, xValues, open, high, low, close);
        List<Comparable> visibleSeriesKeys = Arrays.asList("OHLCSeries0");
        Range xRange = new Range(0.0, 10.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, false);
        assertNotNull(result);
        assertEquals(0.0, result.getLowerBound()); // No y-values in range
        assertEquals(0.0, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with BoxAndWhiskerXYDataset and includeInterval=true, x in range")
    void testIterateToFindRangeBounds_BoxAndWhiskerXYDataset_InRange() {
        double[][] xValues = { {5.0, 15.0} };
        double[][] minRegular = { {4.0, 14.0} };
        double[][] maxRegular = { {6.0, 16.0} };
        BoxAndWhiskerXYDataset dataset = new MockBoxAndWhiskerXYDataset(1, 2, xValues, minRegular, maxRegular);
        List<Comparable> visibleSeriesKeys = Arrays.asList("BoxWhiskerSeries0");
        Range xRange = new Range(4.0, 14.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNotNull(result);
        assertEquals(4.0, result.getLowerBound());
        assertEquals(16.0, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with BoxAndWhiskerXYDataset and includeInterval=true, x out of range")
    void testIterateToFindRangeBounds_BoxAndWhiskerXYDataset_OutOfRange() {
        double[][] xValues = { {5.0, 15.0} };
        double[][] minRegular = { {4.0, 14.0} };
        double[][] maxRegular = { {6.0, 16.0} };
        BoxAndWhiskerXYDataset dataset = new MockBoxAndWhiskerXYDataset(1, 2, xValues, minRegular, maxRegular);
        List<Comparable> visibleSeriesKeys = Arrays.asList("BoxWhiskerSeries0");
        Range xRange = new Range(10.0, 20.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNotNull(result);
        assertEquals(0.0, result.getLowerBound()); // No y-values in range
        assertEquals(0.0, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with IntervalXYDataset and includeInterval=true, x in range")
    void testIterateToFindRangeBounds_IntervalXYDataset_InRange() {
        double[][] xValues = { {5.0, 15.0} };
        double[][] startX = { {4.0, 14.0} };
        double[][] endX = { {6.0, 16.0} };
        double[][] yValues = { {10.0, 20.0} };
        double[][] startY = { {9.0, 19.0} };
        double[][] endY = { {11.0, 21.0} };
        IntervalXYDataset dataset = new MockIntervalXYDataset(1, 2, xValues, startX, endX, yValues, startY, endY);
        List<Comparable> visibleSeriesKeys = Arrays.asList("IntervalSeries0");
        Range xRange = new Range(4.0, 14.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNotNull(result);
        assertEquals(9.0, result.getLowerBound());
        assertEquals(21.0, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with IntervalXYDataset and includeInterval=true, x out of range")
    void testIterateToFindRangeBounds_IntervalXYDataset_OutOfRange() {
        double[][] xValues = { {5.0, 15.0} };
        double[][] startX = { {4.0, 14.0} };
        double[][] endX = { {6.0, 16.0} };
        double[][] yValues = { {10.0, 20.0} };
        double[][] startY = { {9.0, 19.0} };
        double[][] endY = { {11.0, 21.0} };
        IntervalXYDataset dataset = new MockIntervalXYDataset(1, 2, xValues, startX, endX, yValues, startY, endY);
        List<Comparable> visibleSeriesKeys = Arrays.asList("IntervalSeries0");
        Range xRange = new Range(10.0, 20.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNotNull(result);
        assertEquals(0.0, result.getLowerBound());
        assertEquals(0.0, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with standard XYDataset and includeInterval=true, x in range")
    void testIterateToFindRangeBounds_StandardXYDataset_InRange() {
        double[][] xValues = { {5.0, 15.0} };
        double[][] yValues = { {10.0, 20.0} };
        XYDataset dataset = new MockXYDataset(1, 2, xValues, yValues);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series0");
        Range xRange = new Range(4.0, 14.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNotNull(result);
        assertEquals(10.0, result.getLowerBound());
        assertEquals(20.0, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with standard XYDataset and includeInterval=false, x in range")
    void testIterateToFindRangeBounds_StandardXYDataset_IncludeIntervalFalse() {
        double[][] xValues = { {5.0, 15.0} };
        double[][] yValues = { {10.0, 20.0} };
        XYDataset dataset = new MockXYDataset(1, 2, xValues, yValues);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series0");
        Range xRange = new Range(4.0, 14.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, false);
        assertNotNull(result);
        assertEquals(10.0, result.getLowerBound());
        assertEquals(20.0, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with standard XYDataset and includeInterval=true, all y-values NaN")
    void testIterateToFindRangeBounds_StandardXYDataset_AllNaN() {
        double[][] xValues = { {5.0, 15.0} };
        double[][] yValues = { {Double.NaN, Double.NaN} };
        XYDataset dataset = new MockXYDataset(1, 2, xValues, yValues);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series0");
        Range xRange = new Range(0.0, 20.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNull(result);
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with standard XYDataset and includeInterval=true, some y-values valid")
    void testIterateToFindRangeBounds_StandardXYDataset_SomeValid() {
        double[][] xValues = { {5.0, 15.0, 25.0} };
        double[][] yValues = { {10.0, Double.NaN, 30.0} };
        XYDataset dataset = new MockXYDataset(1, 3, xValues, yValues);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series0");
        Range xRange = new Range(0.0, 20.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNotNull(result);
        assertEquals(10.0, result.getLowerBound());
        assertEquals(10.0, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with empty visibleSeriesKeys")
    void testIterateToFindRangeBounds_EmptyVisibleSeriesKeys() {
        double[][] xValues = { {5.0, 15.0} };
        double[][] yValues = { {10.0, 20.0} };
        XYDataset dataset = new MockXYDataset(1, 2, xValues, yValues);
        List<Comparable> visibleSeriesKeys = Collections.emptyList();
        Range xRange = new Range(0.0, 20.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNull(result);
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with multiple visibleSeriesKeys and includeInterval=true")
    void testIterateToFindRangeBounds_MultipleVisibleSeries_InRange() {
        double[][] xValues = { {5.0, 15.0}, {10.0, 20.0} };
        double[][] yValues = { {10.0, 20.0}, {15.0, 25.0} };
        XYDataset dataset = new MockXYDataset(2, 2, xValues, yValues);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series0", "Series1");
        Range xRange = new Range(5.0, 20.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNotNull(result);
        assertEquals(10.0, result.getLowerBound());
        assertEquals(25.0, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with multiple visibleSeriesKeys and includeInterval=true, some out of range")
    void testIterateToFindRangeBounds_MultipleVisibleSeries_SomeOutOfRange() {
        double[][] xValues = { {5.0, 15.0, 25.0}, {10.0, 20.0, 30.0} };
        double[][] yValues = { {10.0, 20.0, 30.0}, {15.0, 25.0, 35.0} };
        XYDataset dataset = new MockXYDataset(2, 3, xValues, yValues);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series0", "Series1");
        Range xRange = new Range(0.0, 20.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNotNull(result);
        assertEquals(10.0, result.getLowerBound());
        assertEquals(25.0, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with multiple visibleSeriesKeys and includeInterval=true, all out of range")
    void testIterateToFindRangeBounds_MultipleVisibleSeries_AllOutOfRange() {
        double[][] xValues = { {5.0, 15.0}, {10.0, 20.0} };
        double[][] yValues = { {10.0, 20.0}, {15.0, 25.0} };
        XYDataset dataset = new MockXYDataset(2, 2, xValues, yValues);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series0", "Series1");
        Range xRange = new Range(21.0, 30.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNull(result);
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with OHLCDataset and includeInterval=true, all y-values NaN")
    void testIterateToFindRangeBounds_OHLCDataset_AllNaN() {
        double[][] xValues = { {5.0, 15.0} };
        double[][] open = { {Double.NaN, Double.NaN} };
        double[][] high = { {Double.NaN, Double.NaN} };
        double[][] low = { {Double.NaN, Double.NaN} };
        double[][] close = { {Double.NaN, Double.NaN} };
        OHLCDataset dataset = new MockOHLCDataset(1, 2, xValues, open, high, low, close);
        List<Comparable> visibleSeriesKeys = Arrays.asList("OHLCSeries0");
        Range xRange = new Range(0.0, 20.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNull(result);
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with IntervalXYDataset and includeInterval=true, some y-values NaN")
    void testIterateToFindRangeBounds_IntervalXYDataset_SomeNaN() {
        double[][] xValues = { {5.0, 15.0} };
        double[][] startX = { {4.0, 14.0} };
        double[][] endX = { {6.0, 16.0} };
        double[][] yValues = { {10.0, Double.NaN} };
        double[][] startY = { {9.0, Double.NaN} };
        double[][] endY = { {11.0, Double.NaN} };
        IntervalXYDataset dataset = new MockIntervalXYDataset(1, 2, xValues, startX, endX, yValues, startY, endY);
        List<Comparable> visibleSeriesKeys = Arrays.asList("IntervalSeries0");
        Range xRange = new Range(0.0, 20.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNotNull(result);
        assertEquals(9.0, result.getLowerBound());
        assertEquals(11.0, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with BoxAndWhiskerXYDataset and includeInterval=false")
    void testIterateToFindRangeBounds_BoxAndWhiskerXYDataset_IncludeIntervalFalse() {
        double[][] xValues = { {5.0, 15.0} };
        double[][] minRegular = { {4.0, 14.0} };
        double[][] maxRegular = { {6.0, 16.0} };
        BoxAndWhiskerXYDataset dataset = new MockBoxAndWhiskerXYDataset(1, 2, xValues, minRegular, maxRegular);
        List<Comparable> visibleSeriesKeys = Arrays.asList("BoxWhiskerSeries0");
        Range xRange = new Range(4.0, 14.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, false);
        assertNotNull(result);
        assertEquals(0.0, result.getLowerBound());
        assertEquals(0.0, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with no visible series")
    void testIterateToFindRangeBounds_NoVisibleSeries() {
        double[][] xValues = { {5.0, 15.0} };
        double[][] yValues = { {10.0, 20.0} };
        XYDataset dataset = new MockXYDataset(1, 2, xValues, yValues);
        List<Comparable> visibleSeriesKeys = Arrays.asList("NonExistingSeries");
        Range xRange = new Range(0.0, 20.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNull(result);
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with xRange boundaries included")
    void testIterateToFindRangeBounds_XRangeBoundariesIncluded() {
        double[][] xValues = { {5.0, 15.0, 25.0} };
        double[][] yValues = { {10.0, 20.0, 30.0} };
        XYDataset dataset = new MockXYDataset(1, 3, xValues, yValues);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series0");
        Range xRange = new Range(5.0, 25.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNotNull(result);
        assertEquals(10.0, result.getLowerBound());
        assertEquals(30.0, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with multiple series and overlapping xRanges")
    void testIterateToFindRangeBounds_MultipleSeries_OverlappingRanges() {
        double[][] xValues = { {5.0, 15.0, 25.0}, {10.0, 20.0, 30.0} };
        double[][] yValues = { {10.0, 20.0, 30.0}, {15.0, 25.0, 35.0} };
        XYDataset dataset = new MockXYDataset(2, 3, xValues, yValues);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series0", "Series1");
        Range xRange = new Range(10.0, 25.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNotNull(result);
        assertEquals(15.0, result.getLowerBound());
        assertEquals(35.0, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with non-integer xRange")
    void testIterateToFindRangeBounds_NonIntegerXRange() {
        double[][] xValues = { {5.5, 15.5} };
        double[][] yValues = { {10.5, 20.5} };
        XYDataset dataset = new MockXYDataset(1, 2, xValues, yValues);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series0");
        Range xRange = new Range(5.0, 16.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNotNull(result);
        assertEquals(10.5, result.getLowerBound());
        assertEquals(20.5, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with xRange partially overlapping")
    void testIterateToFindRangeBounds_XRangePartiallyOverlapping() {
        double[][] xValues = { {5.0, 15.0, 25.0} };
        double[][] yValues = { {10.0, 20.0, 30.0} };
        XYDataset dataset = new MockXYDataset(1, 3, xValues, yValues);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series0");
        Range xRange = new Range(10.0, 20.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNotNull(result);
        assertEquals(20.0, result.getLowerBound());
        assertEquals(20.0, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with includeInterval=true and partially overlapping intervals")
    void testIterateToFindRangeBounds_IntervalOverlap() {
        double[][] xValues = { {5.0, 15.0, 25.0} };
        double[][] startX = { {4.0, 14.0, 24.0} };
        double[][] endX = { {6.0, 16.0, 26.0} };
        double[][] yValues = { {10.0, 20.0, 30.0} };
        double[][] startY = { {9.0, 19.0, 29.0} };
        double[][] endY = { {11.0, 21.0, 31.0} };
        IntervalXYDataset dataset = new MockIntervalXYDataset(1, 3, xValues, startX, endX, yValues, startY, endY);
        List<Comparable> visibleSeriesKeys = Arrays.asList("IntervalSeries0");
        Range xRange = new Range(14.5, 25.5);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNotNull(result);
        // For items:
        // Item0: x=5.0, startX=4.0, endX=6.0 → Not in range
        // Item1: x=15.0, startX=14.0, endX=16.0 → In range
        // Item2: x=25.0, startX=24.0, endX=26.0 → In range
        // Y-values for item1: startY=19.0, endY=21.0
        // Y-values for item2: startY=29.0, endY=31.0
        assertEquals(19.0, result.getLowerBound());
        assertEquals(31.0, result.getUpperBound());
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with includeInterval=true and all intervals out of range")
    void testIterateToFindRangeBounds_AllIntervalsOutOfRange() {
        double[][] xValues = { {5.0, 15.0} };
        double[][] startX = { {4.0, 14.0} };
        double[][] endX = { {6.0, 16.0} };
        double[][] yValues = { {10.0, 20.0} };
        double[][] startY = { {9.0, 19.0} };
        double[][] endY = { {11.0, 21.0} };
        IntervalXYDataset dataset = new MockIntervalXYDataset(1, 2, xValues, startX, endX, yValues, startY, endY);
        List<Comparable> visibleSeriesKeys = Arrays.asList("IntervalSeries0");
        Range xRange = new Range(20.0, 30.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNull(result);
    }

    @Test
    @DisplayName("Test iterateToFindRangeBounds with overlapping visibleSeriesKeys")
    void testIterateToFindRangeBounds_OverlappingSeries() {
        double[][] xValues = { {5.0, 15.0}, {10.0, 20.0}, {15.0, 25.0} };
        double[][] yValues = { {10.0, 20.0}, {15.0, 25.0}, {20.0, 30.0} };
        XYDataset dataset = new MockXYDataset(3, 2, xValues, yValues);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series0", "Series1", "Series2");
        Range xRange = new Range(10.0, 20.0);
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, xRange, true);
        assertNotNull(result);
        // Series0: x=5.0 out, x=15.0 in → y=20.0
        // Series1: x=10.0 in, x=20.0 in → y=15.0, y=25.0
        // Series2: x=15.0 in, x=25.0 out → y=20.0
        // Combined y-values in range: 20.0, 15.0, 25.0, 20.0
        // Minimum: 15.0, Maximum: 25.0
        assertEquals(15.0, result.getLowerBound());
        assertEquals(25.0, result.getUpperBound());
    }
}