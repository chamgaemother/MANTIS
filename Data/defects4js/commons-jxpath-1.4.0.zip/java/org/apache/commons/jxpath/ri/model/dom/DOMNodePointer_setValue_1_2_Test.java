package org.apache.commons.jxpath.ri.model.dom;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.mockito.Mockito;
import org.mockito.MockedStatic;

import org.apache.commons.jxpath.ri.model.dom.DOMNodePointer;
import org.w3c.dom.Attr;
import org.w3c.dom.Node;
import org.w3c.dom.Document;
import org.w3c.dom.Text;
import org.w3c.dom.NodeList;

import java.util.Locale;

import static org.mockito.Mockito.*;
import org.apache.commons.jxpath.util.TypeUtils;

public class DOMNodePointer_setValue_1_2_Test {

    @Test
    @DisplayName("setValue with ATTRIBUTE_NODE and empty string removes attribute")
    public void TC22_setValueWithAttributeNodeAndEmptyStringRemovesAttribute() {
        // Arrange
        Attr attrNode = mock(Attr.class);
        Node parent = mock(Node.class);
        when(attrNode.getNodeType()).thenReturn(Node.ATTRIBUTE_NODE);
        when(attrNode.getParentNode()).thenReturn(parent);
        String value = "";
        DOMNodePointer domNodePointer = new DOMNodePointer(attrNode, Locale.ENGLISH);

        // Act
        domNodePointer.setValue(value);

        // Assert
        verify(parent).removeChild(attrNode);
    }

//     @Test
//     @DisplayName("setValue with unknown node type and non-empty string appends new TextNode")
//     public void TC23_setValueWithUnknownNodeTypeAndNonEmptyStringAppendsNewTextNode() {
        // Arrange
//         Node unknownNode = mock(Node.class);
//         when(unknownNode.getNodeType()).thenReturn(999); // Unknown node type
//         Document ownerDoc = mock(Document.class);
//         when(unknownNode.getOwnerDocument()).thenReturn(ownerDoc);
//         String value = "Appended Text";
//         Text newText = mock(Text.class);
//         when(ownerDoc.createTextNode(value)).thenReturn(newText);
//         DOMNodePointer domNodePointer = new DOMNodePointer(unknownNode, Locale.ENGLISH);
// 
        // Act
//         domNodePointer.setValue(value);
// 
        // Assert
//         verify(unknownNode).appendChild(newText);
//     }

//     @Test
//     @DisplayName("setValue with unknown node type and null string does not append")
//     public void TC24_setValueWithUnknownNodeTypeAndNullStringDoesNotAppend() {
        // Arrange
//         Node unknownNode = mock(Node.class);
//         when(unknownNode.getNodeType()).thenReturn(999); // Unknown node type
//         Document ownerDoc = mock(Document.class);
//         when(unknownNode.getOwnerDocument()).thenReturn(ownerDoc);
//         String value = null;
//         DOMNodePointer domNodePointer = new DOMNodePointer(unknownNode, Locale.ENGLISH);
// 
        // Act
//         domNodePointer.setValue(value);
// 
        // Assert
//         verify(unknownNode, never()).appendChild(any(Node.class));
//     }

    @Test
    @DisplayName("setValue with non-text node and conversion failure throws ClassCastException")
    public void TC25_setValueWithNonTextNodeAndConversionFailureThrowsClassCastException() {
        // Arrange
        Node elementNode = mock(Node.class);
        when(elementNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
        NodeList nodeList = mock(NodeList.class);
        when(elementNode.getChildNodes()).thenReturn(nodeList);
        String invalidValue = "Invalid";
        DOMNodePointer domNodePointer = new DOMNodePointer(elementNode, Locale.ENGLISH);

        try (MockedStatic<TypeUtils> mockedTypeUtils = Mockito.mockStatic(TypeUtils.class)) {
            mockedTypeUtils.when(() -> TypeUtils.convert(invalidValue, String.class))
                           .thenThrow(new ClassCastException("Cannot convert value"));

            // Act & Assert
            ClassCastException exception = Assertions.assertThrows(ClassCastException.class, () -> {
                domNodePointer.setValue(invalidValue);
            });
            Assertions.assertEquals("Cannot convert value", exception.getMessage());
        }
    }
}