package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class ClassBands_finaliseBands_0_1_Test {

    @Test
    @DisplayName("Verifies when all major versions differ from the default, all flags are set and major/minor lists updated.")
    public void testAllMajorVersionsDifferFromDefault() throws Exception {
        // Setup class instance and dependencies
        Segment segment = new Segment();
        ClassBands classBands = new ClassBands(segment, 1, 1, false);
        
        // Mock required fields using reflection
        Field segmentHeaderField = ClassBands.class.getDeclaredField("segmentHeader");
        segmentHeaderField.setAccessible(true);
        Segment.SegmentHeader mockSegmentHeader = segment.new SegmentHeader();
        segmentHeaderField.set(classBands, mockSegmentHeader);

        // Initialize major_versions field for the test
        Field majorVersionsField = ClassBands.class.getDeclaredField("major_versions");
        majorVersionsField.setAccessible(true);
        int[] majorVersions = new int[]{55}; // Different from default
        majorVersionsField.set(classBands, majorVersions);

        // Method invocation
        classBands.finaliseBands();

        // Assertions
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] classFlags = (long[]) classFlagsField.get(classBands);
        assertEquals(1 << 24, classFlags[0] & (1 << 24), "Flags should include version mismatch flag");

        // Check classFileVersionMajor list
        Field classFileVersionMajorField = ClassBands.class.getDeclaredField("classFileVersionMajor");
        classFileVersionMajorField.setAccessible(true);
        assertNotNull(classFileVersionMajorField.get(classBands));
        assertEquals(1, ((java.util.List<?>) classFileVersionMajorField.get(classBands)).size(), "Should update classFileVersionMajor list");
    }

    @Test
    @DisplayName("Tests single item edge case when one major version differs.")
    public void testSingleMajorVersionDiffers() throws Exception {
        // Setup class instance and dependencies
        Segment segment = new Segment();
        ClassBands classBands = new ClassBands(segment, 1, 1, false);
        
        // Mock required fields using reflection
        Field segmentHeaderField = ClassBands.class.getDeclaredField("segmentHeader");
        segmentHeaderField.setAccessible(true);
        Segment.SegmentHeader mockSegmentHeader = segment.new SegmentHeader();
        segmentHeaderField.set(classBands, mockSegmentHeader);

        // Initialize major_versions field for the test
        Field majorVersionsField = ClassBands.class.getDeclaredField("major_versions");
        majorVersionsField.setAccessible(true);
        int[] majorVersions = new int[]{55}; // Different from default
        majorVersionsField.set(classBands, majorVersions);

        // Method invocation
        classBands.finaliseBands();

        // Assertions: reflect changes into flags and major list
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] classFlags = (long[]) classFlagsField.get(classBands);
        assertEquals(1 << 24, classFlags[0] & (1 << 24), "Flags should include version mismatch flag");

        Field classFileVersionMajorField = ClassBands.class.getDeclaredField("classFileVersionMajor");
        classFileVersionMajorField.setAccessible(true);
        assertNotNull(classFileVersionMajorField.get(classBands));
        assertEquals(1, ((java.util.List<?>) classFileVersionMajorField.get(classBands)).size(), "Should update classFileVersionMajor list correctly");
    }

    @Test
    @DisplayName("Tests non-updated class flags path when all major_versions equal default major version.")
    public void testAllMajorVersionsAreDefault() throws Exception {
        // Setup class instance and dependencies
        Segment segment = new Segment();
        ClassBands classBands = new ClassBands(segment, 1, 1, false);
        
        // Mock required fields using reflection
        Field segmentHeaderField = ClassBands.class.getDeclaredField("segmentHeader");
        segmentHeaderField.setAccessible(true);
        Segment.SegmentHeader mockSegmentHeader = segment.new SegmentHeader();
        segmentHeaderField.set(classBands, mockSegmentHeader);

        // Initialize major_versions field as default for the test
        int defaultMajorVersion = mockSegmentHeader.getDefaultMajorVersion();
        Field majorVersionsField = ClassBands.class.getDeclaredField("major_versions");
        majorVersionsField.setAccessible(true);
        int[] majorVersions = new int[]{defaultMajorVersion}; // Default
        majorVersionsField.set(classBands, majorVersions);

        // Method invocation
        classBands.finaliseBands();

        // Assertions
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] classFlags = (long[]) classFlagsField.get(classBands);
        assertEquals(0, classFlags[0] & (1 << 24), "Flags should not include version mismatch flag");
    }

    @Test
    @DisplayName("Tests zero handler path when no codeHandlerCount.")
    public void testNoCodeHandlerCount() throws Exception {
        // Setup class instance and dependencies
        Segment segment = new Segment();
        ClassBands classBands = new ClassBands(segment, 1, 1, false);
        
        // Mock required fields using reflection
        Field segmentHeaderField = ClassBands.class.getDeclaredField("segmentHeader");
        segmentHeaderField.setAccessible(true);
        Segment.SegmentHeader mockSegmentHeader = segment.new SegmentHeader();
        segmentHeaderField.set(classBands, mockSegmentHeader);

        // Initialize major_versions and codeHandlerCount fields for the test
        Field majorVersionsField = ClassBands.class.getDeclaredField("major_versions");
        majorVersionsField.setAccessible(true);
        int[] majorVersions = new int[]{55};
        majorVersionsField.set(classBands, majorVersions);

        Field codeHandlerCountField = ClassBands.class.getDeclaredField("codeHandlerCount");
        codeHandlerCountField.setAccessible(true);
        codeHandlerCountField.set(classBands, new IntList()); // Empty list

        // Method invocation
        classBands.finaliseBands();

        // Assertions
        Field codeHeadersField = ClassBands.class.getDeclaredField("codeHeaders");
        codeHeadersField.setAccessible(true);
        int[] codeHeaders = (int[]) codeHeadersField.get(classBands);
        assertEquals(0, codeHeaders.length, "Should not calculate any code headers for no handlers");
    }

    @Test
    @DisplayName("Verifies calculation logic for single handlers.")
    public void testSingleHandlerCalculation() throws Exception {
        // Setup class instance and dependencies
        Segment segment = new Segment();
        ClassBands classBands = new ClassBands(segment, 1, 1, false);
        
        // Mock required fields using reflection
        Field segmentHeaderField = ClassBands.class.getDeclaredField("segmentHeader");
        segmentHeaderField.setAccessible(true);
        Segment.SegmentHeader mockSegmentHeader = segment.new SegmentHeader();
        segmentHeaderField.set(classBands, mockSegmentHeader);

        // Set major_versions and codeHandlerCount fields
        Field majorVersionsField = ClassBands.class.getDeclaredField("major_versions");
        majorVersionsField.setAccessible(true);
        int[] majorVersions = new int[]{55};
        majorVersionsField.set(classBands, majorVersions);

        Field codeHandlerCountField = ClassBands.class.getDeclaredField("codeHandlerCount");
        codeHandlerCountField.setAccessible(true);
        IntList codeHandlerCount = new IntList();
        codeHandlerCount.add(1); // One handler
        codeHandlerCountField.set(classBands, codeHandlerCount);

        Field codeMaxStackField = ClassBands.class.getDeclaredField("codeMaxStack");
        codeMaxStackField.setAccessible(true);
        IntList codeMaxStack = new IntList();
        codeMaxStack.add(10); // maxStack
        codeMaxStackField.set(classBands, codeMaxStack);

        Field codeMaxLocalsField = ClassBands.class.getDeclaredField("codeMaxLocals");
        codeMaxLocalsField.setAccessible(true);
        IntList codeMaxLocals = new IntList();
        codeMaxLocals.add(10); // maxLocals
        codeMaxLocalsField.set(classBands, codeMaxLocals);

        // Method invocation
        classBands.finaliseBands();

        // Assertions
        Field codeHeadersField = ClassBands.class.getDeclaredField("codeHeaders");
        codeHeadersField.setAccessible(true);
        int[] codeHeaders = (int[]) codeHeadersField.get(classBands);
        assertTrue(codeHeaders.length > 0, "Should calculate code header for single handler");
    }
}