package com.fasterxml.jackson.databind.ser.std;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.DatabindException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class MapSerializer_isEmpty_0_1_Test {

    @Test
    @DisplayName("isEmpty returns true when the input map is empty")
    void TC01_isEmpty_WithEmptyMap() throws Exception {
        // Arrange
        MapSerializer mapSerializer = createMapSerializer();
        SerializerProvider provider = mock(SerializerProvider.class);
        Map<String, Object> map = Collections.emptyMap();

        // Access and set private fields via reflection
        Field suppressableValueField = MapSerializer.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(mapSerializer, null);

        Field suppressNullsField = MapSerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        suppressNullsField.set(mapSerializer, false);

        // Act
        boolean result = mapSerializer.isEmpty(provider, map);

        // Assert
        assertEquals(true, result);
    }

    @Test
    @DisplayName("isEmpty returns false when suppressableValue is null and suppressNulls is false")
    void TC02_isEmpty_SuppressableValueNull_SuppressNullsFalse() throws Exception {
        // Arrange
        MapSerializer mapSerializer = createMapSerializer();
        SerializerProvider provider = mock(SerializerProvider.class);
        Map<String, Object> map = new HashMap<>();
        map.put("key1", "value1");

        // Access and set private fields via reflection
        Field suppressableValueField = MapSerializer.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(mapSerializer, null);

        Field suppressNullsField = MapSerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        suppressNullsField.set(mapSerializer, false);

        Field valueSerializerField = MapSerializer.class.getDeclaredField("_valueSerializer");
        valueSerializerField.setAccessible(true);
        valueSerializerField.set(mapSerializer, null);

        // Act
        boolean result = mapSerializer.isEmpty(provider, map);

        // Assert
        assertEquals(false, result);
    }

    @Test
    @DisplayName("isEmpty returns true when all map elements are empty and suppressNulls is true")
    void TC03_isEmpty_AllElementsEmpty_SuppressNullsTrue() throws Exception {
        // Arrange
        MapSerializer mapSerializer = createMapSerializer();
        SerializerProvider provider = mock(SerializerProvider.class);
        Map<String, Object> map = new HashMap<>();
        map.put("key1", "");
        map.put("key2", "");

        // Access and set private fields via reflection
        Field suppressableValueField = MapSerializer.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(mapSerializer, MapSerializer.MARKER_FOR_EMPTY);

        Field suppressNullsField = MapSerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        suppressNullsField.set(mapSerializer, true);

        JsonSerializer<Object> valueSerializer = mock(JsonSerializer.class);
        when(valueSerializer.isEmpty(provider, "")).thenReturn(true);

        Field valueSerializerField = MapSerializer.class.getDeclaredField("_valueSerializer");
        valueSerializerField.setAccessible(true);
        valueSerializerField.set(mapSerializer, valueSerializer);

        // Act
        boolean result = mapSerializer.isEmpty(provider, map);

        // Assert
        assertEquals(true, result);
    }

    @Test
    @DisplayName("isEmpty returns false when at least one element is not empty and suppressNulls is true")
    void TC04_isEmpty_OneNonEmptyElement_SuppressNullsTrue() throws Exception {
        // Arrange
        MapSerializer mapSerializer = createMapSerializer();
        SerializerProvider provider = mock(SerializerProvider.class);
        Map<String, Object> map = new HashMap<>();
        map.put("key1", "value1");
        map.put("key2", "");

        // Access and set private fields via reflection
        Field suppressableValueField = MapSerializer.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(mapSerializer, MapSerializer.MARKER_FOR_EMPTY);

        Field suppressNullsField = MapSerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        suppressNullsField.set(mapSerializer, true);

        JsonSerializer<Object> valueSerializer = mock(JsonSerializer.class);
        when(valueSerializer.isEmpty(provider, "value1")).thenReturn(false);
        when(valueSerializer.isEmpty(provider, "")).thenReturn(true);

        Field valueSerializerField = MapSerializer.class.getDeclaredField("_valueSerializer");
        valueSerializerField.setAccessible(true);
        valueSerializerField.set(mapSerializer, valueSerializer);

        // Act
        boolean result = mapSerializer.isEmpty(provider, map);

        // Assert
        assertEquals(false, result);
    }

    @Test
    @DisplayName("isEmpty returns false when suppressableValue is not null and does not equal the map")
    void TC05_isEmpty_SuppressableValueNotEqualMap() throws Exception {
        // Arrange
        MapSerializer mapSerializer = createMapSerializer();
        SerializerProvider provider = mock(SerializerProvider.class);
        Map<String, Object> map = new HashMap<>();
        map.put("key1", "value1");

        // Access and set private fields via reflection
        Field suppressableValueField = MapSerializer.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(mapSerializer, "SomeOtherValue");

        Field suppressNullsField = MapSerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        suppressNullsField.set(mapSerializer, true);

        Field valueSerializerField = MapSerializer.class.getDeclaredField("_valueSerializer");
        valueSerializerField.setAccessible(true);
        valueSerializerField.set(mapSerializer, null);

        // Act
        boolean result = mapSerializer.isEmpty(provider, map);

        // Assert
        assertEquals(false, result);
    }

    // Helper method to create MapSerializer instance through reflection
    private MapSerializer createMapSerializer() throws Exception {
        Constructor<MapSerializer> constructor = MapSerializer.class.getDeclaredConstructor((Class<?>[]) null);
        constructor.setAccessible(true);
        return constructor.newInstance((Object[]) null);
    }
}