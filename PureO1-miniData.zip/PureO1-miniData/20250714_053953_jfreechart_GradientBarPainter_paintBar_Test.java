import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

class GradientBarPainterTest {

    private GradientBarPainter painter;
    private Graphics2D g2;
    private BarRenderer renderer;
    private RectangularShape bar;

    @BeforeEach
    void setUp() {
        painter = new GradientBarPainter();
        g2 = mock(Graphics2D.class);
        renderer = mock(BarRenderer.class);
        bar = new Rectangle2D.Double(0, 0, 10, 20);
    }

    @Nested
    @DisplayName("paintBar Tests with Color Paint")
    class PaintBarWithColorPaint {

        @Test
        @DisplayName("Should not draw when color alpha is 0")
        void testPaintBar_ColorAlphaZero() {
            Color transparent = new Color(0, 0, 0, 0);
            when(renderer.getItemPaint(0, 0)).thenReturn(transparent);
            painter.paintBar(g2, renderer, 0, 0, bar, RectangleEdge.TOP);
            verify(g2, never()).fill(any(Rectangle2D.class));
            verify(g2, never()).draw(any(Rectangle2D.class));
        }

        @Test
        @DisplayName("Should draw with Color paint and RectangleEdge.TOP")
        void testPaintBar_ColorOpaque_TOP() {
            Color color = new Color(100, 150, 200, 255);
            when(renderer.getItemPaint(0, 0)).thenReturn(color);
            when(renderer.isDrawBarOutline()).thenReturn(false);
            painter.paintBar(g2, renderer, 0, 0, bar, RectangleEdge.TOP);
            verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
            verify(g2, never()).draw(any(Rectangle2D.class));
        }

        @Test
        @DisplayName("Should draw with Color paint and RectangleEdge.BOTTOM with outline")
        void testPaintBar_ColorOpaque_BOTTOM_WithOutline() {
            Color color = new Color(100, 150, 200, 255);
            Stroke stroke = mock(Stroke.class);
            Paint outlinePaint = Color.BLACK;
            when(renderer.getItemPaint(1, 1)).thenReturn(color);
            when(renderer.isDrawBarOutline()).thenReturn(true);
            when(renderer.getItemOutlineStroke(1, 1)).thenReturn(stroke);
            when(renderer.getItemOutlinePaint(1, 1)).thenReturn(outlinePaint);
            RectangularShape barShape = new Rectangle2D.Double(5, 5, 15, 25);
            painter.paintBar(g2, renderer, 1, 1, barShape, RectangleEdge.BOTTOM);
            verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
            verify(g2).setStroke(stroke);
            verify(g2).setPaint(outlinePaint);
            verify(g2).draw(barShape);
        }
    }

    @Nested
    @DisplayName("paintBar Tests with GradientPaint")
    class PaintBarWithGradientPaint {

        @Test
        @DisplayName("Should draw with GradientPaint and RectangleEdge.LEFT")
        void testPaintBar_GradientPaint_LEFT() {
            GradientPaint gradient = new GradientPaint(0, 0, Color.RED, 10, 10, Color.GREEN);
            when(renderer.getItemPaint(2, 2)).thenReturn(gradient);
            when(renderer.isDrawBarOutline()).thenReturn(false);
            RectangularShape barShape = new Rectangle2D.Double(10, 10, 20, 30);
            painter.paintBar(g2, renderer, 2, 2, barShape, RectangleEdge.LEFT);
            verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
            verify(g2, never()).draw(any(Rectangle2D.class));
        }

        @Test
        @DisplayName("Should draw with GradientPaint and RectangleEdge.RIGHT with outline")
        void testPaintBar_GradientPaint_RIGHT_WithOutline() {
            GradientPaint gradient = new GradientPaint(0, 0, Color.RED, 10, 10, Color.GREEN);
            Stroke stroke = mock(Stroke.class);
            Paint outlinePaint = Color.BLACK;
            when(renderer.getItemPaint(3, 3)).thenReturn(gradient);
            when(renderer.isDrawBarOutline()).thenReturn(true);
            when(renderer.getItemOutlineStroke(3, 3)).thenReturn(stroke);
            when(renderer.getItemOutlinePaint(3, 3)).thenReturn(outlinePaint);
            RectangularShape barShape = new Rectangle2D.Double(15, 15, 25, 35);
            painter.paintBar(g2, renderer, 3, 3, barShape, RectangleEdge.RIGHT);
            verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
            verify(g2).setStroke(stroke);
            verify(g2).setPaint(outlinePaint);
            verify(g2).draw(barShape);
        }
    }

    @Nested
    @DisplayName("paintBar Tests with Non-Color Paint")
    class PaintBarWithNonColorPaint {

        @Test
        @DisplayName("Should default to BLUE when Paint is not Color or GradientPaint")
        void testPaintBar_NonColorNonGradientPaint() {
            Paint customPaint = mock(Paint.class);
            when(renderer.getItemPaint(4, 4)).thenReturn(customPaint);
            when(renderer.isDrawBarOutline()).thenReturn(false);
            RectangularShape barShape = new Rectangle2D.Double(20, 20, 30, 40);
            painter.paintBar(g2, renderer, 4, 4, barShape, RectangleEdge.TOP);
            verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
        }
    }

    @Nested
    @DisplayName("paintBar Outline Tests")
    class PaintBarOutlineTests {

        @Test
        @DisplayName("Should not draw outline when isDrawBarOutline is false")
        void testPaintBar_OutlineFalse() {
            Color color = Color.BLUE;
            when(renderer.getItemPaint(5, 5)).thenReturn(color);
            when(renderer.isDrawBarOutline()).thenReturn(false);
            RectangularShape barShape = new Rectangle2D.Double(25, 25, 35, 45);
            painter.paintBar(g2, renderer, 5, 5, barShape, RectangleEdge.BOTTOM);
            verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
            verify(g2, never()).draw(any(Rectangle2D.class));
        }

        @Test
        @DisplayName("Should not draw outline when stroke is null")
        void testPaintBar_OutlineStrokeNull() {
            Color color = Color.BLUE;
            when(renderer.getItemPaint(6, 6)).thenReturn(color);
            when(renderer.isDrawBarOutline()).thenReturn(true);
            when(renderer.getItemOutlineStroke(6, 6)).thenReturn(null);
            when(renderer.getItemOutlinePaint(6, 6)).thenReturn(Color.BLACK);
            RectangularShape barShape = new Rectangle2D.Double(30, 30, 40, 50);
            painter.paintBar(g2, renderer, 6, 6, barShape, RectangleEdge.LEFT);
            verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
            verify(g2, never()).draw(any(Rectangle2D.class));
        }

        @Test
        @DisplayName("Should not draw outline when outline paint is null")
        void testPaintBar_OutlinePaintNull() {
            Color color = Color.BLUE;
            Stroke stroke = mock(Stroke.class);
            when(renderer.getItemPaint(7, 7)).thenReturn(color);
            when(renderer.isDrawBarOutline()).thenReturn(true);
            when(renderer.getItemOutlineStroke(7, 7)).thenReturn(stroke);
            when(renderer.getItemOutlinePaint(7, 7)).thenReturn(null);
            RectangularShape barShape = new Rectangle2D.Double(35, 35, 45, 55);
            painter.paintBar(g2, renderer, 7, 7, barShape, RectangleEdge.RIGHT);
            verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
            verify(g2, never()).draw(any(Rectangle2D.class));
        }
    }

    @Nested
    @DisplayName("paintBar Boundary and Null Tests")
    class PaintBarBoundaryAndNullTests {

        @Test
        @DisplayName("Should handle bar with zero width and height")
        void testPaintBar_ZeroWidthHeight() {
            Color color = Color.BLUE;
            when(renderer.getItemPaint(8, 8)).thenReturn(color);
            when(renderer.isDrawBarOutline()).thenReturn(false);
            RectangularShape zeroBar = new Rectangle2D.Double(0, 0, 0, 0);
            painter.paintBar(g2, renderer, 8, 8, zeroBar, RectangleEdge.TOP);
            verify(g2, atLeastOnce()).fill(zeroBar);
        }

        @Test
        @DisplayName("Should throw NullPointerException when Graphics2D is null")
        void testPaintBar_Graphics2DNull() {
            Color color = Color.BLUE;
            when(renderer.getItemPaint(9, 9)).thenReturn(color);
            assertThrows(NullPointerException.class, () -> {
                painter.paintBar(null, renderer, 9, 9, bar, RectangleEdge.BOTTOM);
            });
        }

        @Test
        @DisplayName("Should throw NullPointerException when Renderer is null")
        void testPaintBar_RendererNull() {
            assertThrows(NullPointerException.class, () -> {
                painter.paintBar(g2, null, 10, 10, bar, RectangleEdge.LEFT);
            });
        }

        @Test
        @DisplayName("Should throw NullPointerException when Bar is null")
        void testPaintBar_BarNull() {
            Color color = Color.BLUE;
            when(renderer.getItemPaint(11, 11)).thenReturn(color);
            assertThrows(NullPointerException.class, () -> {
                painter.paintBar(g2, renderer, 11, 11, null, RectangleEdge.RIGHT);
            });
        }

        @Test
        @DisplayName("Should throw NullPointerException when RectangleEdge is null")
        void testPaintBar_RectangleEdgeNull() {
            Color color = Color.BLUE;
            when(renderer.getItemPaint(12, 12)).thenReturn(color);
            assertThrows(NullPointerException.class, () -> {
                painter.paintBar(g2, renderer, 12, 12, bar, null);
            });
        }
    }

    @Nested
    @DisplayName("paintBar With Different Base Edges")
    class PaintBarDifferentBaseEdges {

        @ParameterizedTest(name = "Base Edge: {0}")
        @DisplayName("Should handle all RectangleEdge values")
        void testPaintBar_AllRectangleEdge(RectangleEdge edge) {
            Color color = Color.GREEN;
            when(renderer.getItemPaint(13, 13)).thenReturn(color);
            when(renderer.isDrawBarOutline()).thenReturn(false);
            RectangularShape barShape = new Rectangle2D.Double(40, 40, 50, 60);
            painter.paintBar(g2, renderer, 13, 13, barShape, edge);
            verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
        }

        static RectangleEdge[] edges() {
            return RectangleEdge.values();
        }
    }
}