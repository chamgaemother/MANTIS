package org.apache.commons.compress.harmony.unpack200;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;

import org.apache.commons.compress.harmony.unpack200.bytecode.AnnotationDefaultAttribute;
import org.apache.commons.compress.harmony.unpack200.bytecode.AnnotationsAttribute.Annotation;
import org.apache.commons.compress.harmony.unpack200.bytecode.ElementValue;
import org.apache.commons.compress.harmony.unpack200.bytecode.RuntimeVisibleorInvisibleAnnotationsAttribute;
import org.apache.commons.compress.harmony.unpack200.bytecode.RuntimeVisibleorInvisibleParameterAnnotationsAttribute;
import org.apache.commons.compress.harmony.unpack200.bytecode.Attribute;
import org.apache.commons.compress.harmony.unpack200.bytecode.CPUTF8;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class MetadataBandGroupTest {

    private MetadataBandGroup metadataBandGroup;
    private CpBands cpBandsMock;
    private CPUTF8 rvaUTF8Mock;
    private CPUTF8 riaUTF8Mock;
    private CPUTF8 rvpaUTF8Mock;
    private CPUTF8 ripaUTF8Mock;

    @BeforeEach
    public void setUp() {
        cpBandsMock = mock(CpBands.class);
        rvaUTF8Mock = mock(CPUTF8.class);
        riaUTF8Mock = mock(CPUTF8.class);
        rvpaUTF8Mock = mock(CPUTF8.class);
        ripaUTF8Mock = mock(CPUTF8.class);

        MetadataBandGroup.setRvaAttributeName(rvaUTF8Mock);
        MetadataBandGroup.setRiaAttributeName(riaUTF8Mock);
        MetadataBandGroup.setRvpaAttributeName(rvpaUTF8Mock);
        MetadataBandGroup.setRipaAttributeName(ripaUTF8Mock);
    }

    @Test
    public void testGetAttributes_WithNullAttributesAndNameRU_RVA() {
        metadataBandGroup = new MetadataBandGroup("RVA", cpBandsMock);
        metadataBandGroup.name_RU = new CPUTF8[] { mock(CPUTF8.class) };
        metadataBandGroup.anno_N = new int[] { 1 };
        metadataBandGroup.type_RS = new CPUTF8[][] { new CPUTF8[] { mock(CPUTF8.class) } };
        metadataBandGroup.pair_N = new int[][] { new int[] { 1 } };
        metadataBandGroup.T = new int[] { 'I' };
        metadataBandGroup.caseI_KI = new CPInteger[] { mock(CPInteger.class) };

        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertNotNull(attributes);
        assertEquals(1, attributes.size());
        assertTrue(attributes.get(0) instanceof RuntimeVisibleorInvisibleAnnotationsAttribute);
    }

    @Test
    public void testGetAttributes_WithNullAttributesAndNameRU_RIA() {
        metadataBandGroup = new MetadataBandGroup("RIA", cpBandsMock);
        metadataBandGroup.name_RU = new CPUTF8[] { mock(CPUTF8.class) };
        metadataBandGroup.anno_N = new int[] { 1 };
        metadataBandGroup.type_RS = new CPUTF8[][] { new CPUTF8[] { mock(CPUTF8.class) } };
        metadataBandGroup.pair_N = new int[][] { new int[] { 1 } };
        metadataBandGroup.T = new int[] { 'I' };
        metadataBandGroup.caseI_KI = new CPInteger[] { mock(CPInteger.class) };

        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertNotNull(attributes);
        assertEquals(1, attributes.size());
        assertTrue(attributes.get(0) instanceof RuntimeVisibleorInvisibleAnnotationsAttribute);
    }

    @Test
    public void testGetAttributes_WithNullAttributesAndNameRU_RVPA() {
        metadataBandGroup = new MetadataBandGroup("RVPA", cpBandsMock);
        metadataBandGroup.name_RU = new CPUTF8[] { mock(CPUTF8.class) };
        metadataBandGroup.param_NB = new int[] { 1 };
        metadataBandGroup.anno_N = new int[] { 1 };
        metadataBandGroup.pair_N = new int[][] { new int[] { 1 } };
        metadataBandGroup.type_RS = new CPUTF8[][] { new CPUTF8[] { mock(CPUTF8.class) } };
        metadataBandGroup.T = new int[] { 'I' };
        metadataBandGroup.caseI_KI = new CPInteger[] { mock(CPInteger.class) };

        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertNotNull(attributes);
        assertEquals(1, attributes.size());
        assertTrue(attributes.get(0) instanceof RuntimeVisibleorInvisibleParameterAnnotationsAttribute);
    }

    @Test
    public void testGetAttributes_WithNullAttributesAndNameRU_RIPA() {
        metadataBandGroup = new MetadataBandGroup("RIPA", cpBandsMock);
        metadataBandGroup.name_RU = new CPUTF8[] { mock(CPUTF8.class) };
        metadataBandGroup.param_NB = new int[] { 1 };
        metadataBandGroup.anno_N = new int[] { 1 };
        metadataBandGroup.pair_N = new int[][] { new int[] { 1 } };
        metadataBandGroup.type_RS = new CPUTF8[][] { new CPUTF8[] { mock(CPUTF8.class) } };
        metadataBandGroup.T = new int[] { 'I' };
        metadataBandGroup.caseI_KI = new CPInteger[] { mock(CPInteger.class) };

        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertNotNull(attributes);
        assertEquals(1, attributes.size());
        assertTrue(attributes.get(0) instanceof RuntimeVisibleorInvisibleParameterAnnotationsAttribute);
    }

    @Test
    public void testGetAttributes_WithNullAttributesAndTypeAD() {
        metadataBandGroup = new MetadataBandGroup("AD", cpBandsMock);
        metadataBandGroup.name_RU = null;
        metadataBandGroup.T = new int[] { 'I' };
        metadataBandGroup.caseI_KI = new CPInteger[] { mock(CPInteger.class) };

        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertNotNull(attributes);
        assertEquals(1, attributes.size());
        assertTrue(attributes.get(0) instanceof AnnotationDefaultAttribute);
    }

    @Test
    public void testGetAttributes_WithNullAttributesAndNameRU_NotAD() {
        metadataBandGroup = new MetadataBandGroup("NON_AD", cpBandsMock);
        metadataBandGroup.name_RU = null;
        metadataBandGroup.T = new int[] { 'I' };
        metadataBandGroup.caseI_KI = new CPInteger[] { mock(CPInteger.class) };

        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertNotNull(attributes);
        assertTrue(attributes.isEmpty());
    }

    @Test
    public void testGetAttributes_WithInitializedAttributes() {
        metadataBandGroup = new MetadataBandGroup("RVA", cpBandsMock);
        metadataBandGroup.attributes = Arrays.asList(mock(Attribute.class), mock(Attribute.class));

        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertNotNull(attributes);
        assertEquals(2, attributes.size());
    }

    @Test
    public void testGetAttributes_WithEmptyNameRU_RVA() {
        metadataBandGroup = new MetadataBandGroup("RVA", cpBandsMock);
        metadataBandGroup.name_RU = new CPUTF8[0];
        metadataBandGroup.anno_N = new int[0];
        metadataBandGroup.type_RS = new CPUTF8[0][];
        metadataBandGroup.pair_N = new int[0][];
        metadataBandGroup.T = new int[0];
        metadataBandGroup.caseI_KI = new CPInteger[0];

        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertNotNull(attributes);
        assertTrue(attributes.isEmpty());
    }

    @Test
    public void testGetAttributes_WithMultipleAnnotations_RVA() {
        metadataBandGroup = new MetadataBandGroup("RVA", cpBandsMock);
        metadataBandGroup.name_RU = new CPUTF8[] { mock(CPUTF8.class), mock(CPUTF8.class) };
        metadataBandGroup.anno_N = new int[] { 1, 2 };
        metadataBandGroup.type_RS = new CPUTF8[][] { 
            new CPUTF8[] { mock(CPUTF8.class) }, 
            new CPUTF8[] { mock(CPUTF8.class), mock(CPUTF8.class) } 
        };
        metadataBandGroup.pair_N = new int[][] { 
            new int[] { 1 }, 
            new int[] { 1, 2 } 
        };
        metadataBandGroup.T = new int[] { 'I', 'D', 'F' };
        metadataBandGroup.caseI_KI = new CPInteger[] { mock(CPInteger.class) };
        metadataBandGroup.caseD_KD = new CPDouble[] { mock(CPDouble.class) };
        metadataBandGroup.caseF_KF = new CPFloat[] { mock(CPFloat.class) };

        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertNotNull(attributes);
        assertEquals(2, attributes.size());
        assertTrue(attributes.get(0) instanceof RuntimeVisibleorInvisibleAnnotationsAttribute);
        assertTrue(attributes.get(1) instanceof RuntimeVisibleorInvisibleAnnotationsAttribute);
    }

    @Test
    public void testGetAttributes_WithParameterAnnotations_RVPA() {
        metadataBandGroup = new MetadataBandGroup("RVPA", cpBandsMock);
        metadataBandGroup.name_RU = new CPUTF8[] { mock(CPUTF8.class), mock(CPUTF8.class) };
        metadataBandGroup.param_NB = new int[] { 2 };
        metadataBandGroup.anno_N = new int[] { 1, 1 };
        metadataBandGroup.pair_N = new int[][] { new int[] { 1 }, new int[] { 1 } };
        metadataBandGroup.type_RS = new CPUTF8[][] { new CPUTF8[] { mock(CPUTF8.class) }, new CPUTF8[] { mock(CPUTF8.class) } };
        metadataBandGroup.T = new int[] { 'I', 'D' };
        metadataBandGroup.caseI_KI = new CPInteger[] { mock(CPInteger.class) };
        metadataBandGroup.caseD_KD = new CPDouble[] { mock(CPDouble.class) };

        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertNotNull(attributes);
        assertEquals(2, attributes.size());
        assertTrue(attributes.get(0) instanceof RuntimeVisibleorInvisibleParameterAnnotationsAttribute);
        assertTrue(attributes.get(1) instanceof RuntimeVisibleorInvisibleParameterAnnotationsAttribute);
    }

    @Test
    public void testGetAttributes_AnnotationDefaultAttribute_AD() {
        metadataBandGroup = new MetadataBandGroup("AD", cpBandsMock);
        metadataBandGroup.name_RU = null;
        metadataBandGroup.T = new int[] { 'B', 'C', 'I', 'S', 'Z' };
        metadataBandGroup.caseI_KI = new CPInteger[] { mock(CPInteger.class), mock(CPInteger.class), mock(CPInteger.class), mock(CPInteger.class), mock(CPInteger.class) };

        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertNotNull(attributes);
        assertEquals(5, attributes.size());
        for (Attribute attr : attributes) {
            assertTrue(attr instanceof AnnotationDefaultAttribute);
        }
    }

    @Test
    public void testGetAttributes_WithNestedAnnotations_RVA() {
        metadataBandGroup = new MetadataBandGroup("RVA", cpBandsMock);
        metadataBandGroup.name_RU = new CPUTF8[] { mock(CPUTF8.class) };
        metadataBandGroup.anno_N = new int[] { 1 };
        metadataBandGroup.type_RS = new CPUTF8[][] { new CPUTF8[] { mock(CPUTF8.class) } };
        metadataBandGroup.pair_N = new int[][] { new int[] { 2 } };
        metadataBandGroup.T = new int[] { '@', 'I', '@', 'D' };
        metadataBandGroup.nesttype_RS = new CPUTF8[] { mock(CPUTF8.class), mock(CPUTF8.class) };
        metadataBandGroup.nestpair_N = new int[] { 1, 1 };
        metadataBandGroup.nestname_RU = new CPUTF8[] { mock(CPUTF8.class), mock(CPUTF8.class) };
        metadataBandGroup.caseI_KI = new CPInteger[] { mock(CPInteger.class) };
        metadataBandGroup.caseD_KD = new CPDouble[] { mock(CPDouble.class) };

        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertNotNull(attributes);
        assertEquals(1, attributes.size());
        assertTrue(attributes.get(0) instanceof RuntimeVisibleorInvisibleAnnotationsAttribute);
    }

    @Test
    public void testGetAttributes_WithNullTypeAndNameRU() {
        metadataBandGroup = new MetadataBandGroup(null, cpBandsMock);
        metadataBandGroup.name_RU = null;
        metadataBandGroup.T = new int[] { 'I' };
        metadataBandGroup.caseI_KI = new CPInteger[] { mock(CPInteger.class) };

        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertNotNull(attributes);
        assertTrue(attributes.isEmpty());
    }

    @Test
    public void testGetAttributes_WithEmptyT_AD() {
        metadataBandGroup = new MetadataBandGroup("AD", cpBandsMock);
        metadataBandGroup.name_RU = null;
        metadataBandGroup.T = new int[0];
        metadataBandGroup.caseI_KI = new CPInteger[0];

        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertNotNull(attributes);
        assertTrue(attributes.isEmpty());
    }
}