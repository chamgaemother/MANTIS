package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.labels.XYItemLabelGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.TableXYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class StackedXYBarRenderer_drawItem_1_1_Test {

    @Test
    @DisplayName("drawItem handles renderAsPercentages=true with total stack zero, avoiding division by zero")
    void TC25_drawItem_handlesRenderAsPercentagesWithZeroTotal() {
        // Arrange
        StackedXYBarRenderer renderer = new StackedXYBarRenderer();
        renderer.setRenderAsPercentages(true);

        IntervalXYDataset mockDataset = mock(IntervalXYDataset.class);
        TableXYDataset tableDataset = mock(TableXYDataset.class);
        when(mockDataset instanceof TableXYDataset).thenReturn(true);
        when(mockDataset instanceof IntervalXYDataset).thenReturn(true);
        when(mockDataset.getYValue(anyInt(), anyInt())).thenReturn(0.0);

        Graphics2D mockGraphics = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Act & Assert
        assertDoesNotThrow(() -> {
            renderer.drawItem(mockGraphics, null, dataArea, info, plot, domainAxis, rangeAxis, mockDataset, 0, 0, crosshairState, 1);
        });
    }

    @Test
    @DisplayName("drawItem renders correctly when Y value is zero and renderAsPercentages=false")
    void TC26_drawItem_rendersCorrectlyWithZeroYValue() {
        // Arrange
        StackedXYBarRenderer renderer = new StackedXYBarRenderer();
        renderer.setRenderAsPercentages(false);

        IntervalXYDataset mockDataset = mock(IntervalXYDataset.class);
        when(mockDataset.getYValue(anyInt(), anyInt())).thenReturn(0.0);

        Graphics2D mockGraphics = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Act & Assert
        assertDoesNotThrow(() -> {
            renderer.drawItem(mockGraphics, null, dataArea, info, plot, domainAxis, rangeAxis, mockDataset, 0, 0, crosshairState, 1);
        });
    }
}