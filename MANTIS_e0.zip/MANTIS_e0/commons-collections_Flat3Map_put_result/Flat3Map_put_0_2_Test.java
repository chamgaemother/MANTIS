package org.apache.commons.collections4.map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class Flat3Map_put_0_2_Test {

    @Test
    @DisplayName("put when delegateMap is null, key is non-null, size is 1, and key matches key1 updates value1")
    void test_TC06_put_existing_key1_updates_value1() throws Exception {
        // GIVEN
        Flat3Map<String, String> map = new Flat3Map<>();
        map.put("Key1", "Value1");

        String key = "Key1";
        String value = "Value1Updated";

        // WHEN
        String result = map.put(key, value);

        // THEN
        assertEquals("Value1", result, "Old value should be returned");

        // Reflectively access private fields
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        int size = (int) sizeField.get(map);
        assertEquals(1, size, "Size should remain 1");

        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        String updatedValue1 = (String) value1Field.get(map);
        assertEquals("Value1Updated", updatedValue1, "value1 should be updated to 'Value1Updated'");
    }

    @Test
    @DisplayName("put when delegateMap is null, key is non-null, size is 1, and key does not match adds key2")
    void test_TC07_put_new_non_existing_key2() throws Exception {
        // GIVEN
        Flat3Map<String, String> map = new Flat3Map<>();
        map.put("Key1", "Value1");

        String key = "Key2";
        String value = "Value2";

        // WHEN
        String result = map.put(key, value);

        // THEN
        assertNull(result, "Result should be null when adding a new key");

        // Reflectively access private fields
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        int size = (int) sizeField.get(map);
        assertEquals(2, size, "Size should be incremented to 2");

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        String storedKey2 = (String) key2Field.get(map);
        assertEquals("Key2", storedKey2, "key2 should be 'Key2'");
    }

    @Test
    @DisplayName("put when delegateMap is null, key is non-null, size is 2, and key matches key2 updates value2")
    void test_TC08_put_existing_key2_updates_value2() throws Exception {
        // GIVEN
        Flat3Map<String, String> map = new Flat3Map<>();
        map.put("Key1", "Value1");
        map.put("Key2", "Value2");

        String key = "Key2";
        String value = "Value2Updated";

        // WHEN
        String result = map.put(key, value);

        // THEN
        assertEquals("Value2", result, "Old value should be returned");

        // Reflectively access private fields
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        int size = (int) sizeField.get(map);
        assertEquals(2, size, "Size should remain 2");

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        String updatedValue2 = (String) value2Field.get(map);
        assertEquals("Value2Updated", updatedValue2, "value2 should be updated to 'Value2Updated'");
    }

    @Test
    @DisplayName("put when delegateMap is null, key is non-null, size is 2, and key does not match adds key3")
    void test_TC09_put_new_non_existing_key3() throws Exception {
        // GIVEN
        Flat3Map<String, String> map = new Flat3Map<>();
        map.put("Key1", "Value1");
        map.put("Key2", "Value2");

        String key = "Key3";
        String value = "Value3";

        // WHEN
        String result = map.put(key, value);

        // THEN
        assertNull(result, "Result should be null when adding a new key");

        // Reflectively access private fields
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        int size = (int) sizeField.get(map);
        assertEquals(3, size, "Size should be incremented to 3");

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        String storedKey3 = (String) key3Field.get(map);
        assertEquals("Key3", storedKey3, "key3 should be 'Key3'");
    }

    @Test
    @DisplayName("put when delegateMap is null, key is non-null, size is 3, and key matches key3 updates value3")
    void test_TC10_put_existing_key3_updates_value3() throws Exception {
        // GIVEN
        Flat3Map<String, String> map = new Flat3Map<>();
        map.put("Key3", "Value3");

        String key = "Key3";
        String value = "Value3Updated";

        // WHEN
        String result = map.put(key, value);

        // THEN
        assertEquals("Value3", result, "Old value should be returned");

        // Reflectively access private fields
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        int size = (int) sizeField.get(map);
        assertEquals(3, size, "Size should remain 3");

        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        String updatedValue3 = (String) value3Field.get(map);
        assertEquals("Value3Updated", updatedValue3, "value3 should be updated to 'Value3Updated'");
    }
}