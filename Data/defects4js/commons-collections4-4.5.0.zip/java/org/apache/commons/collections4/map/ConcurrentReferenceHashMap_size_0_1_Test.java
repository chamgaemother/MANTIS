package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.EnumSet;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ConcurrentReferenceHashMap_size_0_1_Test {

    @Test
    @DisplayName("Size computed successfully without any concurrent modifications on the first attempt")
    public void TC01_sizeWithoutConcurrentModifications() throws Exception {
        // Initialize ConcurrentReferenceHashMap using the builder pattern
        ConcurrentReferenceHashMap<Object, Object> map =
                ConcurrentReferenceHashMap.<Object, Object>builder()
                        .setInitialCapacity(16)
                        .setLoadFactor(0.75f)
                        .setConcurrencyLevel(16)
                        .setKeyReferenceType(ConcurrentReferenceHashMap.ReferenceType.WEAK)
                        .setValueReferenceType(ConcurrentReferenceHashMap.ReferenceType.STRONG)
                        .get();

        // Use reflection to access and set the 'segments' field
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        
        Object[] segments = (Object[]) segmentsField.get(map);

        // Set fixed counts for each segment
        long expectedSum = 0;
        for (Object segment : segments) {
            Field countField = segment.getClass().getDeclaredField("count");
            countField.setAccessible(true);
            countField.setInt(segment, 100); // Example fixed count
            expectedSum += 100;
        }

        // Invoke the size method
        Method sizeMethod = ConcurrentReferenceHashMap.class.getDeclaredMethod("size");
        sizeMethod.setAccessible(true);
        int size = (int) sizeMethod.invoke(map);

        // Assert the size
        assertEquals(expectedSum, size, "The size should match the sum of segment counts.");
    }

    @Test
    @DisplayName("Size computation requires one retry due to a single concurrent modification")
    public void TC02_sizeWithOneConcurrentModification() throws Exception {
        // Initialize ConcurrentReferenceHashMap using the builder pattern
        ConcurrentReferenceHashMap<Object, Object> map =
                ConcurrentReferenceHashMap.<Object, Object>builder()
                        .setInitialCapacity(16)
                        .setLoadFactor(0.75f)
                        .setConcurrencyLevel(16)
                        .setKeyReferenceType(ConcurrentReferenceHashMap.ReferenceType.WEAK)
                        .setValueReferenceType(ConcurrentReferenceHashMap.ReferenceType.STRONG)
                        .get();

        // Use reflection to access and set the 'segments' field
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        
        Object[] segments = (Object[]) segmentsField.get(map);

        // Set initial counts and modCounts
        long expectedSum = 0;
        for (int i = 0; i < segments.length; i++) {
            Field countField = segments[i].getClass().getDeclaredField("count");
            Field modCountField = segments[i].getClass().getDeclaredField("modCount");
            countField.setAccessible(true);
            modCountField.setAccessible(true);
            countField.setInt(segments[i], 100); // Fixed count
            modCountField.setInt(segments[i], 1); // Initial modCount
            expectedSum += 100;
        }

        // Simulate a concurrent modification on the first attempt
        // In reality, this would involve multi-threading, but for simplicity, we'll manually modify modCount
        Field modCountField = segments[0].getClass().getDeclaredField("modCount");
        modCountField.setAccessible(true);
        modCountField.setInt(segments[0], 2); // Modify modCount to trigger a retry

        // Invoke the size method
        Method sizeMethod = ConcurrentReferenceHashMap.class.getDeclaredMethod("size");
        sizeMethod.setAccessible(true);
        int size = (int) sizeMethod.invoke(map);

        // Assert the size after retry
        assertEquals(expectedSum, size, "The size should be correctly computed after one retry.");
    }

    @Test
    @DisplayName("Size computation retries up to RETRIES_BEFORE_LOCK and then resorts to locking due to continuous modifications")
    public void TC03_sizeWithContinuousConcurrentModifications() throws Exception {
        // Initialize ConcurrentReferenceHashMap using the builder pattern
        ConcurrentReferenceHashMap<Object, Object> map =
                ConcurrentReferenceHashMap.<Object, Object>builder()
                        .setInitialCapacity(16)
                        .setLoadFactor(0.75f)
                        .setConcurrencyLevel(16)
                        .setKeyReferenceType(ConcurrentReferenceHashMap.ReferenceType.WEAK)
                        .setValueReferenceType(ConcurrentReferenceHashMap.ReferenceType.STRONG)
                        .get();

        // Use reflection to access and set the 'segments' field
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        
        Object[] segments = (Object[]) segmentsField.get(map);

        // Continuously modify segments to exceed RETRIES_BEFORE_LOCK
        for (int i = 0; i < segments.length; i++) {
            Field countField = segments[i].getClass().getDeclaredField("count");
            Field modCountField = segments[i].getClass().getDeclaredField("modCount");
            countField.setAccessible(true);
            modCountField.setAccessible(true);
            countField.setInt(segments[i], 100); // Fixed count
            modCountField.setInt(segments[i], 2); // Continuous modification
        }

        // Invoke the size method
        Method sizeMethod = ConcurrentReferenceHashMap.class.getDeclaredMethod("size");
        sizeMethod.setAccessible(true);
        int size = (int) sizeMethod.invoke(map);

        // Calculate expected sum
        long expectedSum = 0;
        for (Object segment : segments) {
            Field countField = segment.getClass().getDeclaredField("count");
            countField.setAccessible(true);
            expectedSum += countField.getInt(segment);
        }

        // Assert the size after locking
        assertEquals((int) expectedSum, size, "The size should be correctly computed after locking all segments.");
    }

    @Test
    @DisplayName("Size exceeds Integer.MAX_VALUE and correctly returns Integer.MAX_VALUE")
    public void TC04_sizeExceedsIntegerMaxValue() throws Exception {
        // Initialize ConcurrentReferenceHashMap using the builder pattern
        ConcurrentReferenceHashMap<Object, Object> map =
                ConcurrentReferenceHashMap.<Object, Object>builder()
                        .setInitialCapacity(16)
                        .setLoadFactor(0.75f)
                        .setConcurrencyLevel(16)
                        .setKeyReferenceType(ConcurrentReferenceHashMap.ReferenceType.WEAK)
                        .setValueReferenceType(ConcurrentReferenceHashMap.ReferenceType.STRONG)
                        .get();

        // Use reflection to access and set the 'segments' field
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        
        Object[] segments = (Object[]) segmentsField.get(map);

        // Set counts to exceed Integer.MAX_VALUE
        long expectedSum = 0;
        for (int i = 0; i < segments.length; i++) {
            Field countField = segments[i].getClass().getDeclaredField("count");
            Field modCountField = segments[i].getClass().getDeclaredField("modCount");
            countField.setAccessible(true);
            modCountField.setAccessible(true);
            countField.setInt(segments[i], Integer.MAX_VALUE); // Set each count to Integer.MAX_VALUE
            modCountField.setInt(segments[i], 1); // Stable modCount
            expectedSum += (long) Integer.MAX_VALUE;
        }
        // To ensure sum exceeds Integer.MAX_VALUE, set at least two segments
        expectedSum += 1;

        // Invoke the size method
        Method sizeMethod = ConcurrentReferenceHashMap.class.getDeclaredMethod("size");
        sizeMethod.setAccessible(true);
        int size = (int) sizeMethod.invoke(map);

        // Assert that size equals Integer.MAX_VALUE
        assertEquals(Integer.MAX_VALUE, size, "The size should be capped at Integer.MAX_VALUE when it exceeds the maximum value.");
    }

    @Test
    @DisplayName("Size is zero when all segment counts are zero")
    public void TC05_sizeIsZeroWhenAllSegmentsEmpty() throws Exception {
        // Initialize ConcurrentReferenceHashMap using the builder pattern
        ConcurrentReferenceHashMap<Object, Object> map =
                ConcurrentReferenceHashMap.<Object, Object>builder()
                        .setInitialCapacity(16)
                        .setLoadFactor(0.75f)
                        .setConcurrencyLevel(16)
                        .setKeyReferenceType(ConcurrentReferenceHashMap.ReferenceType.WEAK)
                        .setValueReferenceType(ConcurrentReferenceHashMap.ReferenceType.STRONG)
                        .get();

        // Use reflection to access and set the 'segments' field
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        
        Object[] segments = (Object[]) segmentsField.get(map);

        // Set all segment counts to zero
        for (Object segment : segments) {
            Field countField = segment.getClass().getDeclaredField("count");
            Field modCountField = segment.getClass().getDeclaredField("modCount");
            countField.setAccessible(true);
            modCountField.setAccessible(true);
            countField.setInt(segment, 0); // Set count to zero
            modCountField.setInt(segment, 1); // Stable modCount
        }

        // Invoke the size method
        Method sizeMethod = ConcurrentReferenceHashMap.class.getDeclaredMethod("size");
        sizeMethod.setAccessible(true);
        int size = (int) sizeMethod.invoke(map);

        // Assert that size is zero
        assertEquals(0, size, "The size should be zero when all segments are empty.");
    }
}