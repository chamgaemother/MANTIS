import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpField;
import org.apache.commons.math3.dfp.DfpMath;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class DfpMathPowTest {

    private static final DfpField field = new DfpField(20);

    @Test
    public void testPowZeroExponent() {
        Dfp base = field.newDfp(2.0);
        Dfp exponent = field.newDfp(0.0);
        Dfp result = DfpMath.pow(base, exponent);
        Assertions.assertEquals(field.newDfp(1.0), result);
    }

    @Test
    public void testPowExponentOne() {
        Dfp base = field.newDfp(-3.0);
        Dfp exponent = field.newDfp(1.0);
        Dfp result = DfpMath.pow(base, exponent);
        Assertions.assertEquals(base, result);
    }

    @Test
    public void testPowBaseZeroPositiveExponent() {
        Dfp base = field.newDfp(0.0);
        Dfp exponent = field.newDfp(4.0);
        Dfp result = DfpMath.pow(base, exponent);
        Assertions.assertEquals(field.newDfp(0.0), result);
    }

    @Test
    public void testPowBaseZeroNegativeExponent() {
        Dfp base = field.newDfp(0.0);
        Dfp exponent = field.newDfp(-4.0);
        Dfp result = DfpMath.pow(base, exponent);
        Assertions.assertTrue(result.isInfinite());
    }

    @Test
    public void testPowBaseNegativeZeroOddExponent() {
        Dfp base = field.newDfp(-0.0);
        Dfp exponent = field.newDfp(3.0);
        Dfp result = DfpMath.pow(base, exponent);
        Assertions.assertEquals(field.newDfp(0.0).negate(), result);
    }

    @Test
    public void testPowBaseNegativeZeroEvenExponent() {
        Dfp base = field.newDfp(-0.0);
        Dfp exponent = field.newDfp(4.0);
        Dfp result = DfpMath.pow(base, exponent);
        Assertions.assertEquals(field.newDfp(0.0), result);
    }

    @Test
    public void testPowBasePositiveInfinityNegativeExponent() {
        Dfp base = field.newDfp((byte)1, Dfp.INFINITE);
        Dfp exponent = field.newDfp(-4.0);
        Dfp result = DfpMath.pow(base, exponent);
        Assertions.assertEquals(field.newDfp(0.0), result);
    }

    @Test
    public void testPowBaseNegativeInfinityOddExponent() {
        Dfp base = field.newDfp((byte)-1, Dfp.INFINITE);
        Dfp exponent = field.newDfp(3.0);
        Dfp result = DfpMath.pow(base, exponent);
        Assertions.assertTrue(result.isInfinite() && result.lessThan(field.newDfp(0.0)));
    }

    @Test
    public void testPowBaseNegativeInfinityEvenExponent() {
        Dfp base = field.newDfp((byte)-1, Dfp.INFINITE);
        Dfp exponent = field.newDfp(4.0);
        Dfp result = DfpMath.pow(base, exponent);
        Assertions.assertTrue(result.isInfinite() && result.greaterThan(field.newDfp(0.0)));
    }

    @Test
    public void testPowBaseNegativeInfinityNegativeExponent() {
        Dfp base = field.newDfp((byte)-1, Dfp.INFINITE);
        Dfp exponent = field.newDfp(-4.0);
        Dfp result = DfpMath.pow(base, exponent);
        Assertions.assertEquals(field.newDfp(0.0), result);
    }
    
    @Test
    public void testPowWithIncompatibleFields() {
        Dfp base = field.newDfp(2.0);
        DfpField differentField = new DfpField(10);
        Dfp exponent = differentField.newDfp(3.0);
        Dfp result = DfpMath.pow(base, exponent);
        Assertions.assertTrue(result.isNaN());
    }

    @ParameterizedTest
    @CsvSource({
        "2.0, 3.0, 8.0",
        "4.0, 0.5, 2.0",
        "-2.0, 3.0, -8.0"
    })
    public void testGeneralPow(double baseValue, double exponentValue, double expectedValue) {
        Dfp base = field.newDfp(baseValue);
        Dfp exponent = field.newDfp(exponentValue);
        Dfp expectedResult = field.newDfp(expectedValue);
        Dfp result = DfpMath.pow(base, exponent);
        Assertions.assertTrue(result.subtract(expectedResult).abs().lessThan(field.newDfp(1e-8)));
    }

    @Test
    public void testPowWithNanInputs() {
        Dfp nanDfp = field.newDfp((byte)1, Dfp.QNAN);
        Dfp base = field.newDfp(4.0);
        Dfp result = DfpMath.pow(base, nanDfp);
        Assertions.assertTrue(result.isNaN());
    }
}