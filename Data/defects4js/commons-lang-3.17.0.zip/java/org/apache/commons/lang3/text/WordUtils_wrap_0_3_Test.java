package org.apache.commons.lang3.text;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class WordUtils_wrap_0_3_Test {

    @Test
    @DisplayName("wrap handles single word longer than wrapLength with wrapLongWords=true by breaking the word")
    void TC11() throws Exception {
        // Given
        String str = "Supercalifragilisticexpialidocious";
        int wrapLength = 10;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = " ";

        // When
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // Then
        String expected = "Supercalif\nragilistic\nexpialidoc\nious";
        assertEquals(expected, result, "The long word should be broken with line breaks every 10 characters.");
    }

    @Test
    @DisplayName("wrap handles single word longer than wrapLength with wrapLongWords=false without breaking the word")
    void TC12() throws Exception {
        // Given
        String str = "Supercalifragilisticexpialidocious";
        int wrapLength = 10;
        String newLineStr = "\n";
        boolean wrapLongWords = false;
        String wrapOn = " ";

        // When
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // Then
        assertFalse(result.contains("\n"), "Result should not contain any line breaks within the word.");
        assertTrue(result.length() > wrapLength, "The word should extend beyond the wrap length.");
    }

    @Test
    @DisplayName("wrap handles multiple lines with varying lengths and wrapLongWords=true")
    void TC13() throws Exception {
        // Given
        String str = "The quick brown fox jumps over the lazy dog";
        int wrapLength = 10;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = " ";

        // When
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // Then
        String expected = "The quick\nbrown fox\njumps over\nthe lazy\ndog";
        assertEquals(expected, result, "Each line should be wrapped correctly based on wrapLength.");
    }

    @Test
    @DisplayName("wrap handles multiple lines with varying lengths and wrapLongWords=false")
    void TC14() throws Exception {
        // Given
        String str = "The quick brown fox jumps over the lazy dog";
        int wrapLength = 10;
        String newLineStr = "\n";
        boolean wrapLongWords = false;
        String wrapOn = " ";

        // When
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // Then
        String expected = "The quick\nbrown fox\njumps over\nthe lazy\ndog";
        assertEquals(expected, result, "Lines should be wrapped at spaces without breaking words.");
    }

    @Test
    @DisplayName("wrap handles wrapOn regex patterns correctly")
    void TC15() throws Exception {
        // Given
        String str = "one,two;three.four";
        int wrapLength = 5;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = "[,;.]+";

        // When
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // Then
        String expected = "one\n,two;\nthree.\nfour";
        assertEquals(expected, result, "Text should be wrapped based on regex patterns provided in wrapOn.");
    }
}