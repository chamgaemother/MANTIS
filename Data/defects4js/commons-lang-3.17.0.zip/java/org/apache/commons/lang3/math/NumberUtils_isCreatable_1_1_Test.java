package org.apache.commons.lang3.math;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class NumberUtils_isCreatable_1_1_Test {

    @Test
    @DisplayName("isCreatable(#1A3F) returns true for a valid hexadecimal number with '#' prefix")
    public void TC28_isCreatable_validHexWithHashPrefix() {
        // GIVEN
        String input = "#1A3F";
        
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        
        // THEN
        assertTrue(result, "Expected '#1A3F' to be creatable as a hexadecimal number.");
    }

    @Test
    @DisplayName("isCreatable(#GHI) returns false for invalid hexadecimal characters with '#' prefix")
    public void TC29_isCreatable_invalidHexCharactersWithHashPrefix() {
        // GIVEN
        String input = "#GHI";
        
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        
        // THEN
        assertFalse(result, "Expected '#GHI' to be not creatable due to invalid hexadecimal characters.");
    }

    @Test
    @DisplayName("isCreatable(0x1a3f) returns true for a valid lowercase hexadecimal number")
    public void TC30_isCreatable_validLowercaseHexadecimal() {
        // GIVEN
        String input = "0x1a3f";
        
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        
        // THEN
        assertTrue(result, "Expected '0x1a3f' to be creatable as a lowercase hexadecimal number.");
    }

    @Test
    @DisplayName("isCreatable(0X1A3F) returns true for a valid uppercase hexadecimal number")
    public void TC31_isCreatable_validUppercaseHexadecimal() {
        // GIVEN
        String input = "0X1A3F";
        
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        
        // THEN
        assertTrue(result, "Expected '0X1A3F' to be creatable as an uppercase hexadecimal number.");
    }

    @Test
    @DisplayName("isCreatable(07) returns true for a valid octal number with single digit after '0'")
    public void TC32_isCreatable_validSingleDigitOctal() {
        // GIVEN
        String input = "07";
        
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        
        // THEN
        assertTrue(result, "Expected '07' to be creatable as a single-digit octal number.");
    }

}