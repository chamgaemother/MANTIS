package org.apache.commons.math3.special;

import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class BesselJ_rjBesl_1_5_Test {

    @Test
    @DisplayName("rjBesl throws MathIllegalArgumentException when alpha=1.0, violating (alpha < 1)")
    void testTC16() {
        // Given
        double x = 10.0;
        double alpha = 1.0;
        int nb = 3;

        // When & Then
        assertThrows(MathIllegalArgumentException.class, () -> {
            BesselJ.rjBesl(x, alpha, nb);
        }, "Expected MathIllegalArgumentException when alpha=1.0");
    }

    @Test
    @DisplayName("rjBesl throws MathIllegalArgumentException when alpha=-0.5, violating (alpha >= 0)")
    void testTC17() {
        // Given
        double x = 10.0;
        double alpha = -0.5;
        int nb = 3;

        // When & Then
        assertThrows(MathIllegalArgumentException.class, () -> {
            BesselJ.rjBesl(x, alpha, nb);
        }, "Expected MathIllegalArgumentException when alpha=-0.5");
    }

    @Test
    @DisplayName("rjBesl throws ConvergenceException when computation fails to converge")
    void testTC18() {
        // Given
        double x = 1e308;
        double alpha = 0.5;
        int nb = 100;

        // When & Then
        assertThrows(ConvergenceException.class, () -> {
            BesselJ.rjBesl(x, alpha, nb);
        }, "Expected ConvergenceException for large x and nb=100");
    }

    @Test
    @DisplayName("rjBesl processes nb=2 with x=0, ensuring correct initialization and handling of zero argument")
    void testTC19() {
        // Given
        double x = 0.0;
        double alpha = 0.2;
        int nb = 2;

        // When
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);

        // Then
        assertNotNull(result, "Result should not be null");
        assertEquals(2, result.getVals().length, "Values array length should be 2");
        assertEquals(2, result.getnVals(), "nVals should be 2");
        assertAll("Check all BesselJ values are zero",
            () -> assertEquals(0.0, result.getVals()[0], "First value should be 0.0"),
            () -> assertEquals(0.0, result.getVals()[1], "Second value should be 0.0")
        );
    }

    @Test
    @DisplayName("rjBesl handles nb=3 with alpha near zero, ensuring accurate computation with minimal iterations")
    void testTC20() {
        // Given
        double x = 5.0;
        double alpha = 1e-10;
        int nb = 3;

        // When
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);

        // Then
        assertNotNull(result, "Result should not be null");
        assertEquals(3, result.getVals().length, "Values array length should be 3");
        assertEquals(3, result.getnVals(), "nVals should be 3");
        // Additional assertions based on expected BesselJ values
        // Example: assertEquals(expectedValue, result.getVals()[0], delta);
        // Example: assertEquals(expectedValue, result.getVals()[1], delta);
        // Example: assertEquals(expectedValue, result.getVals()[2], delta);
    }
}