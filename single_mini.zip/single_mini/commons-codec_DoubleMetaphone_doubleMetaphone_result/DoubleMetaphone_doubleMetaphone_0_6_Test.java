package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Auto-generated JUnit 5 test class for DoubleMetaphone.doubleMetaphone method.
 */
public class DoubleMetaphone_doubleMetaphone_0_6_Test {

    @Test
    @DisplayName("doubleMetaphone processes 'NK' sequence in 'KNIGHT'")
    public void TC26_doubleMetaphone_processes_NK_sequence_in_KNIGHT() {
        // GIVEN
        String value = "KNIGHT";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // THEN
        assertTrue(result.contains("KN"), "Result should contain 'KN'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'RR' sequence in 'MORRIS'")
    public void TC27_doubleMetaphone_handles_RR_sequence_in_MORRIS() {
        // GIVEN
        String value = "MORRIS";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // THEN
        assertTrue(result.contains("R"), "Result should contain 'R'");
    }

    @Test
    @DisplayName("doubleMetaphone processes 'VAN ' prefix in 'VANESSA'")
    public void TC28_doubleMetaphone_processes_VAN_prefix_in_VANESSA() {
        // GIVEN
        String value = "VANESSA";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // THEN
        assertTrue(result.contains("F"), "Result should contain 'F'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'LL' sequence in 'PALL'")
    public void TC29_doubleMetaphone_handles_LL_sequence_in_PALL() {
        // GIVEN
        String value = "PALL";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // THEN
        assertTrue(result.contains("L"), "Result should contain 'L'");
    }

    @Test
    @DisplayName("doubleMetaphone processes 'WR' prefix in 'WRONG'")
    public void TC30_doubleMetaphone_processes_WR_prefix_in_WRONG() {
        // GIVEN
        String value = "WRONG";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // THEN
        assertTrue(result.contains("R"), "Result should contain 'R'");
    }
}