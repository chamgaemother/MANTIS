import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.special.BesselJ;
import org.apache.commons.math3.util.FastMath;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class BesselJTest {

    @Test
    void testSmallX() {
        BesselJ.BesselJResult result = BesselJ.rjBesl(1e-10, 0.5, 2);
        assertNotNull(result);
        assertEquals(2, result.getnVals());
        assertTrue(result.getVals()[0] > 0);
    }
    
    @Test
    void testLargeX() {
        BesselJ.BesselJResult result = BesselJ.rjBesl(30, 0.5, 2);
        assertNotNull(result);
        assertEquals(2, result.getnVals());
    }

    @Test
    void testAlphaZero() {
        BesselJ.BesselJResult result = BesselJ.rjBesl(5, 0.0, 2);
        assertNotNull(result);
        assertEquals(2, result.getnVals());
    }

    @Test
    void testAlphaOne() {
        BesselJ.BesselJResult result = BesselJ.rjBesl(5, 1.0 - 1e-10, 2);
        assertNotNull(result);
        assertEquals(2, result.getnVals());
    }

    @Test
    void testInvalidNb() {
        BesselJ.BesselJResult result = BesselJ.rjBesl(10, 0.5, 0);
        assertNotNull(result);
        assertTrue(result.getnVals() < 0);
    }

    @Test
    void testNegativeAlpha() {
        assertThrows(MathIllegalArgumentException.class, () -> BesselJ.rjBesl(10, -0.1, 2));
    }

    @Test
    void testAlphaGreaterThanOne() {
        assertThrows(MathIllegalArgumentException.class, () -> BesselJ.rjBesl(10, 1.1, 2));
    }

    @Test
    void testLargeNb() {
        BesselJ.BesselJResult result = BesselJ.rjBesl(10, 0.5, 100);
        assertNotNull(result);
        assertTrue(result.getnVals() > 0);
    }
    
    @Test
    void testBoundaryX() {
        BesselJ.BesselJResult result = BesselJ.rjBesl(BesselJ.X_MAX, 0.5, 2);
        assertNotNull(result);
        assertEquals(2, result.getnVals());
    }

    @Test
    void testXExceedsMax() {
        assertThrows(MathIllegalArgumentException.class, () -> BesselJ.rjBesl(BesselJ.X_MAX + 1, 0.5, 2));
    }

    @Test
    void testXEqualsZero() {
        BesselJ.BesselJResult result = BesselJ.rjBesl(0, 0.5, 2);
        assertNotNull(result);
        assertEquals(2, result.getnVals());
    }

    @Test
    void testConvergenceOnHighNb() {
        assertThrows(ConvergenceException.class, () -> BesselJ.value(5, 0.1, 10000));
    }

    @Test
    void testXGreaterThanReductionLimit() {
        BesselJ.BesselJResult result = BesselJ.rjBesl(35, 0.5, 3);
        assertNotNull(result);
        assertEquals(3, result.getnVals());
    }
}