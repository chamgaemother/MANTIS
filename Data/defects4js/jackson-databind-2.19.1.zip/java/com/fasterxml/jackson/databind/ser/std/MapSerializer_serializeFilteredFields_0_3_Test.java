package com.fasterxml.jackson.databind.ser.std;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.PropertyFilter;
import com.fasterxml.jackson.databind.JsonSerializer;

public class MapSerializer_serializeFilteredFields_0_3_Test {

    @Test
    @DisplayName("serializeFilteredFields encounters exception in filter.serializeAsField")
    void TC11_serializeFilteredFields_exceptionInSerializeAsField() throws Exception {
        // Arrange
        Map<Object, Object> value = new HashMap<>();
        value.put("key1", "value1");

        JsonGenerator gen = mock(JsonGenerator.class);
        SerializerProvider provider = mock(SerializerProvider.class);
        PropertyFilter filter = mock(PropertyFilter.class);
        Object suppressableValue = null;

        JsonSerializer<Object> valueSerializer = mock(JsonSerializer.class);

        // Create instance of MapSerializer
        MapSerializer mapSerializer = new MapSerializer(null, null, null, false, null, null, null);

        // Use reflection to set private fields
        Field fieldValueSerializer = MapSerializer.class.getDeclaredField("_valueSerializer");
        fieldValueSerializer.setAccessible(true);
        fieldValueSerializer.set(mapSerializer, valueSerializer);

        // Make filter.serializeAsField throw an exception
        doThrow(new RuntimeException("Serialization error")).when(filter).serializeAsField(any(), any(), any(), any());

        // Spy on mapSerializer to verify wrapAndThrow
        MapSerializer spyMapSerializer = spy(mapSerializer);

        // Act
        try {
            spyMapSerializer.serializeFilteredFields(value, gen, provider, filter, suppressableValue);
        } catch (Exception e) {
            // Expected exception
        }

        // Assert
        verify(spyMapSerializer).wrapAndThrow(eq(provider), any(RuntimeException.class), eq(value), eq("key1"));
    }

    @Test
    @DisplayName("serializeFilteredFields with checkEmpty false and valueSer.isEmpty returns false")
    void TC12_serializeFilteredFields_valueNotEmpty() throws Exception {
        // Arrange
        Map<Object, Object> value = new HashMap<>();
        value.put("key1", new NonEmptyObject());

        JsonGenerator gen = mock(JsonGenerator.class);
        SerializerProvider provider = mock(SerializerProvider.class);
        PropertyFilter filter = mock(PropertyFilter.class);
        Object suppressableValue = null;

        // Create instance of MapSerializer
        MapSerializer mapSerializer = new MapSerializer(null, null, null, false, null, null, null);

        // Use reflection to set private fields
        Field fieldSuppressNulls = MapSerializer.class.getDeclaredField("_suppressNulls");
        fieldSuppressNulls.setAccessible(true);
        fieldSuppressNulls.set(mapSerializer, false);

        JsonSerializer<Object> valueSerializer = mock(JsonSerializer.class);
        Field fieldValueSerializer = MapSerializer.class.getDeclaredField("_valueSerializer");
        fieldValueSerializer.setAccessible(true);
        fieldValueSerializer.set(mapSerializer, valueSerializer);

        when(valueSerializer.isEmpty(eq(provider), any())).thenReturn(false);

        // Act
        mapSerializer.serializeFilteredFields(value, gen, provider, filter, suppressableValue);

        // Assert
        verify(filter).serializeAsField(eq(value), eq(gen), eq(provider), any());
    }

    @Test
    @DisplayName("serializeFilteredFields with checkEmpty true and valueSer.isEmpty returns false")
    void TC13_serializeFilteredFields_valueNotEmptyWithCheckEmpty() throws Exception {
        // Arrange
        Map<Object, Object> value = new HashMap<>();
        value.put("key1", new NonEmptyObject());

        JsonGenerator gen = mock(JsonGenerator.class);
        SerializerProvider provider = mock(SerializerProvider.class);
        PropertyFilter filter = mock(PropertyFilter.class);
        Object suppressableValue = MapSerializer.MARKER_FOR_EMPTY;

        // Create instance of MapSerializer
        MapSerializer mapSerializer = new MapSerializer(null, null, null, false, null, null, null);

        // Use reflection to set private fields
        Field fieldSuppressNulls = MapSerializer.class.getDeclaredField("_suppressNulls");
        fieldSuppressNulls.setAccessible(true);
        fieldSuppressNulls.set(mapSerializer, false);

        JsonSerializer<Object> valueSerializer = mock(JsonSerializer.class);
        Field fieldValueSerializer = MapSerializer.class.getDeclaredField("_valueSerializer");
        fieldValueSerializer.setAccessible(true);
        fieldValueSerializer.set(mapSerializer, valueSerializer);

        when(valueSerializer.isEmpty(eq(provider), any())).thenReturn(false);

        // Act
        mapSerializer.serializeFilteredFields(value, gen, provider, filter, suppressableValue);

        // Assert
        verify(filter).serializeAsField(eq(value), eq(gen), eq(provider), any());
    }

    @Test
    @DisplayName("serializeFilteredFields with multiple iterations, mixed entry conditions")
    void TC14_serializeFilteredFields_multipleEntriesMixedConditions() throws Exception {
        // Arrange
        Map<Object, Object> value = new HashMap<>();
        value.put("key1", "value1");
        value.put("key2", null);
        value.put(null, "value3");

        JsonGenerator gen = mock(JsonGenerator.class);
        SerializerProvider provider = mock(SerializerProvider.class);
        PropertyFilter filter = mock(PropertyFilter.class);
        Object suppressableValue = MapSerializer.MARKER_FOR_EMPTY;

        InclusionChecker inclusionChecker = mock(InclusionChecker.class);
        when(inclusionChecker.shouldIgnore("key2")).thenReturn(false);

        // Create instance of MapSerializer
        MapSerializer mapSerializer = new MapSerializer(null, null, null, false, null, null, null);

        // Use reflection to set private fields
        Field fieldInclusionChecker = MapSerializer.class.getDeclaredField("_inclusionChecker");
        fieldInclusionChecker.setAccessible(true);
        fieldInclusionChecker.set(mapSerializer, inclusionChecker);

        Field fieldSuppressNulls = MapSerializer.class.getDeclaredField("_suppressNulls");
        fieldSuppressNulls.setAccessible(true);
        fieldSuppressNulls.set(mapSerializer, false);

        JsonSerializer<Object> keySerializer = mock(JsonSerializer.class);
        Field fieldKeySerializer = MapSerializer.class.getDeclaredField("_keySerializer");
        fieldKeySerializer.setAccessible(true);
        fieldKeySerializer.set(mapSerializer, keySerializer);

        JsonSerializer<Object> valueSerializer = mock(JsonSerializer.class);
        Field fieldValueSerializer = MapSerializer.class.getDeclaredField("_valueSerializer");
        fieldValueSerializer.setAccessible(true);
        fieldValueSerializer.set(mapSerializer, valueSerializer);

        when(provider.getDefaultNullValueSerializer()).thenReturn(mock(JsonSerializer.class));

        // Act
        mapSerializer.serializeFilteredFields(value, gen, provider, filter, suppressableValue);

        // Assert
        verify(filter, times(2)).serializeAsField(eq(value), eq(gen), eq(provider), any());
    }

    // Dummy NonEmptyObject class for testing purposes
    private static class NonEmptyObject {
        // Add fields or methods if needed
    }

    // Dummy InclusionChecker interface for testing purposes
    private interface InclusionChecker {
        boolean shouldIgnore(Object key);
    }
}