import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class BcBandsTest {

    private BcBands bcBands;
    private CpBands cpBands;
    private Segment segment;

    @BeforeEach
    public void setup() {
        cpBands = mock(CpBands.class);
        segment = mock(Segment.class);
        bcBands = new BcBands(cpBands, segment, 5);
    }

    @Test
    public void testVisitLdcInsnWithNullConstant() {
        assertThrows(IllegalArgumentException.class, () -> bcBands.visitLdcInsn(null));
    }

    @Test
    public void testVisitLdcInsnWithIntAndWideIndex() {
        CPInt constant = mock(CPInt.class);
        when(cpBands.getConstant(any())).thenReturn(constant);
        when(segment.lastConstantHadWideIndex()).thenReturn(true);
        
        bcBands.visitLdcInsn(123);

        assertEquals(1, bcBands.bcIntref.size());
        assertEquals(constant, bcBands.bcIntref.get(0));
    }

    @Test
    public void testVisitLdcInsnWithIntAndNotWideIndex() {
        CPInt constant = mock(CPInt.class);
        when(cpBands.getConstant(any())).thenReturn(constant);
        when(segment.lastConstantHadWideIndex()).thenReturn(false);
        
        bcBands.visitLdcInsn(123);

        assertEquals(1, bcBands.bcIntref.size());
        assertEquals(constant, bcBands.bcIntref.get(0));
    }

    @Test
    public void testVisitLdcInsnWithLongConstant() {
        CPLong constant = mock(CPLong.class);
        when(cpBands.getConstant(any())).thenReturn(constant);
        when(segment.lastConstantHadWideIndex()).thenReturn(true);
        
        bcBands.visitLdcInsn(123L);
        
        assertEquals(1, bcBands.bcLongRef.size());
        assertEquals(constant, bcBands.bcLongRef.get(0));
    }

    @Test
    public void testVisitLdcInsnWithDoubleConstant() {
        CPDouble constant = mock(CPDouble.class);
        when(cpBands.getConstant(any())).thenReturn(constant);
        when(segment.lastConstantHadWideIndex()).thenReturn(true);

        bcBands.visitLdcInsn(123.123);

        assertEquals(1, bcBands.bcDoubleRef.size());
        assertEquals(constant, bcBands.bcDoubleRef.get(0));
    }

    @Test
    public void testVisitLdcInsnWithStringConstant() {
        CPString constant = mock(CPString.class);
        when(cpBands.getConstant(any())).thenReturn(constant);
        when(segment.lastConstantHadWideIndex()).thenReturn(false);

        bcBands.visitLdcInsn("test");

        assertEquals(1, bcBands.bcStringRef.size());
        assertEquals(constant, bcBands.bcStringRef.get(0));
    }

    @Test
    public void testVisitLdcInsnWithClassConstant() {
        CPClass constant = mock(CPClass.class);
        when(cpBands.getConstant(any())).thenReturn(constant);
        when(segment.lastConstantHadWideIndex()).thenReturn(false);

        bcBands.visitLdcInsn(Object.class);

        assertEquals(1, bcBands.bcClassRef.size());
        assertEquals(constant, bcBands.bcClassRef.get(0));
    }

    @Test
    public void testVisitLdcInsnWithFloatConstant() {
        CPFloat constant = mock(CPFloat.class);
        when(cpBands.getConstant(any())).thenReturn(constant);
        when(segment.lastConstantHadWideIndex()).thenReturn(false);

        bcBands.visitLdcInsn(123.45f);

        assertEquals(1, bcBands.bcFloatRef.size());
        assertEquals(constant, bcBands.bcFloatRef.get(0));
    }
}