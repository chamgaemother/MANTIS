package com.fasterxml.jackson.core.filter;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class FilteringParserDelegate_nextToken_0_2_Test {

    @Test
    @DisplayName("Processes START_ARRAY token and includes all elements")
    public void TC06_nextToken_processes_START_ARRAY_and_includes_all_elements() throws Exception {
        // GIVEN
        JsonParser delegate = mock(JsonParser.class);
        when(delegate.nextToken()).thenReturn(JsonToken.START_ARRAY);

        // Pass proper parameters for constructor
        FilteringParserDelegate parser = new FilteringParserDelegate(
                delegate,
                TokenFilter.INCLUDE_ALL,
                TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH,
                false
        );

        // WHEN
        JsonToken result = parser.nextToken();

        // THEN
        assertEquals(JsonToken.START_ARRAY, result);
    }

    @Test
    @DisplayName("Processes FIELD_NAME token and includes the property")
    public void TC07_nextToken_processes_FIELD_NAME_and_includes_property() throws Exception {
        // GIVEN
        JsonParser delegate = mock(JsonParser.class);
        when(delegate.nextToken()).thenReturn(JsonToken.FIELD_NAME);
        when(delegate.currentName()).thenReturn("validField");

        // Pass proper parameters for constructor
        FilteringParserDelegate parser = new FilteringParserDelegate(
                delegate,
                TokenFilter.INCLUDE_ALL,
                TokenFilter.Inclusion.ONLY_INCLUDE_ALL,
                false
        );

        // WHEN
        JsonToken result = parser.nextToken();

        // THEN
        assertEquals(JsonToken.FIELD_NAME, result);
    }

    @Test
    @DisplayName("Skips children when _itemFilter is null for START_OBJECT")
    public void TC08_nextToken_skips_children_when_itemFilter_null_for_START_OBJECT() throws Exception {
        // GIVEN
        JsonParser delegate = mock(JsonParser.class);
        when(delegate.nextToken()).thenReturn(JsonToken.START_OBJECT, null);

        // Pass proper parameters for constructor
        FilteringParserDelegate parser = new FilteringParserDelegate(
                delegate,
                null, // _itemFilter is intentionally null here
                TokenFilter.Inclusion.ONLY_INCLUDE_ALL,
                false
        );

        // WHEN
        JsonToken result = parser.nextToken();

        // THEN
        verify(delegate).skipChildren();
        assertNull(result);
    }

    @Test
    @DisplayName("Includes scalar value when _itemFilter includes it")
    public void TC09_nextToken_includes_scalar_value_when_itemFilter_includes_it() throws Exception {
        // GIVEN
        JsonParser delegate = mock(JsonParser.class);
        when(delegate.nextToken()).thenReturn(JsonToken.VALUE_STRING);

        // Pass proper parameters for constructor
        FilteringParserDelegate parser = new FilteringParserDelegate(
                delegate,
                TokenFilter.INCLUDE_ALL,
                TokenFilter.Inclusion.ONLY_INCLUDE_ALL,
                false
        );

        // WHEN
        JsonToken result = parser.nextToken();

        // THEN
        assertEquals(JsonToken.VALUE_STRING, result);
    }

    @Test
    @DisplayName("Processes END_OBJECT token and updates _headContext")
    public void TC10_nextToken_processes_END_OBJECT_and_updates_headContext() throws Exception {
        // GIVEN
        JsonParser delegate = mock(JsonParser.class);
        when(delegate.nextToken()).thenReturn(JsonToken.END_OBJECT);

        // Mock TokenFilterContext
        TokenFilterContext headContext = mock(TokenFilterContext.class);
        TokenFilterContext parentContext = mock(TokenFilterContext.class);
        when(headContext.getParent()).thenReturn(parentContext);
        when(headContext.isStartHandled()).thenReturn(true);
        when(headContext.getFilter()).thenReturn(TokenFilter.INCLUDE_ALL);

        // Pass proper parameters for constructor
        FilteringParserDelegate parser = new FilteringParserDelegate(
                delegate,
                TokenFilter.INCLUDE_ALL,
                TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH,
                false
        );

        // Set _headContext to headContext
        Field headContextField = FilteringParserDelegate.class.getDeclaredField("_headContext");
        headContextField.setAccessible(true);
        headContextField.set(parser, headContext);

        // WHEN
        JsonToken result = parser.nextToken();

        // THEN
        assertEquals(JsonToken.END_OBJECT, result);
        assertSame(parentContext, headContextField.get(parser));
    }
}