package org.apache.commons.math3.analysis.interpolation;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.apache.commons.math3.exception.DimensionMismatchException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class BicubicSplineInterpolator_interpolate_1_2_Test {

    @Test
    @DisplayName("Interpolate with empty fval subarrays, expecting DimensionMismatchException")
    void test_TC20() {
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {4.0, 5.0};
        double[][] fval = {
            {},
            {10.0, 11.0},
            {13.0, 14.0}
        };
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();

        assertThrows(DimensionMismatchException.class, () -> {
            interpolator.interpolate(xval, yval, fval);
        });
    }

}