package org.joda.time.format;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.DateTimeFieldType;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

public class ISODateTimeFormat_forFields_0_2_Test {

    @Test
    @DisplayName("Test with fields containing only year (workingFields.contains(year) == true), expecting yyyy format")
    void TC06_fields_year_only_returns_YYYY() throws Exception {
        // Arrange
        Collection<DateTimeFieldType> fields = Arrays.asList(DateTimeFieldType.year());
        boolean extended = false;
        boolean strictISO = true;

        // Act
        DateTimeFormatter formatter = ISODateTimeFormat.forFields(fields, extended, strictISO);

        // Assert
        assertNotNull(formatter); // Ensure formatter is not null
        assertEquals("yyyy", formatter.print(0).replaceAll("\\D", ""));
    }

    @Test
    @DisplayName("Test with fields containing monthOfYear and dayOfMonth (workingFields.contains(monthOfYear) == true and workingFields.contains(dayOfMonth) == true), expecting --MM-DD format")
    void TC07_fields_monthOfYear_dayOfMonth_returns_YYYY_MM_DD() throws Exception {
        // Arrange
        Collection<DateTimeFieldType> fields = Arrays.asList(DateTimeFieldType.monthOfYear(), DateTimeFieldType.dayOfMonth());
        boolean extended = true;
        boolean strictISO = false;

        // Act
        DateTimeFormatter formatter = ISODateTimeFormat.forFields(fields, extended, strictISO);

        // Assert
        assertNotNull(formatter); // Ensure formatter is not null
        assertEquals("0225", formatter.print(0).substring(1, 5));
    }

    @Test
    @DisplayName("Test with fields containing weekOfWeekyear and weekyear without dayOfWeek (workingFields.contains(weekOfWeekyear) == true and workingFields.contains(dayOfWeek) == false), expecting yyyy-WWW format")
    void TC08_fields_weekOfWeekyear_weekyear_returns_YYYY_WWW() throws Exception {
        // Arrange
        Collection<DateTimeFieldType> fields = Arrays.asList(DateTimeFieldType.weekOfWeekyear(), DateTimeFieldType.weekyear());
        boolean extended = true;
        boolean strictISO = true;

        // Act
        DateTimeFormatter formatter = ISODateTimeFormat.forFields(fields, extended, strictISO);

        // Assert
        assertNotNull(formatter); // Ensure formatter is not null
        assertEquals("2021W01", formatter.print(0));
    }

    @Test
    @DisplayName("Test when bld.canBuildFormatter() returns false, expecting IllegalArgumentException")
    void TC09_invalid_fields_canBuildFormatter_false_throws_illegalargumentexception() {
        // Arrange fields that lead to an invalid formatter
        Collection<DateTimeFieldType> fields = Arrays.asList(DateTimeFieldType.hourOfDay(), DateTimeFieldType.minuteOfHour());
        boolean extended = true;
        boolean strictISO = true;

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            ISODateTimeFormat.forFields(fields, extended, strictISO);
        });

        assertEquals("No valid ISO8601 format for fields: [hourOfDay, minuteOfHour]", exception.getMessage());
    }

    @Test
    @DisplayName("Test with unmodifiable fields collection causing UnsupportedOperationException during retainAll, expecting formatter to be returned")
    void TC10_unmodifiable_fields_retainAll_throws_unsupportedoperationexception() {
        // Arrange
        Collection<DateTimeFieldType> fields = Collections.unmodifiableList(Arrays.asList(DateTimeFieldType.year(), DateTimeFieldType.monthOfYear()));
        boolean extended = true;
        boolean strictISO = true;

        // Act
        DateTimeFormatter formatter = ISODateTimeFormat.forFields(fields, extended, strictISO);

        // Assert
        assertNotNull(formatter);
    }
}