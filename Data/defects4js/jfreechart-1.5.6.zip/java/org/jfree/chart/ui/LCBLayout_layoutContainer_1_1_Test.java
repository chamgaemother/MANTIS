
package org.jfree.chart.ui;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.awt.Container;
import java.awt.Component;
import java.awt.Dimension;
import java.lang.reflect.Field;

public class LCBLayout_layoutContainer_1_1_Test {

    @Test
    @DisplayName("layoutContainer updates rowHeight when a component's preferred height exceeds the current row height")
    public void TC12_layoutContainer_updatesRowHeightForTallerComponents() throws Exception {
        // Arrange
        LCBLayout layout = new LCBLayout(2);
        Container parent = new Container();
        Component comp1 = new Component() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(100, 50);
            }
        };
        Component comp2 = new Component() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(100, 80); // Taller component
            }
        };
        parent.add(comp1);
        parent.add(comp2);
        
        // Act
        layout.layoutContainer(parent);
        
        // Assert
        Field rowHeightField = LCBLayout.class.getDeclaredField("rowHeight");
        rowHeightField.setAccessible(true);
        int[] rowHeight = (int[]) rowHeightField.get(layout);
        assertTrue(rowHeight[0] >= 80, "rowHeight[0] should be >= 80");
    }

    @Test
    @DisplayName("layoutContainer does not update rowHeight when component's preferred height is less than or equal to current row height")
    public void TC13_layoutContainer_retainsRowHeightForShorterComponents() throws Exception {
        // Arrange
        LCBLayout layout = new LCBLayout(2);
        Container parent = new Container();
        Component comp1 = new Component() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(100, 60);
            }
        };
        Component comp2 = new Component() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(100, 50); // Shorter or equal component
            }
        };
        parent.add(comp1);
        parent.add(comp2);
        
        // Act
        layout.layoutContainer(parent);
        
        // Assert
        Field rowHeightField = LCBLayout.class.getDeclaredField("rowHeight");
        rowHeightField.setAccessible(true);
        int[] rowHeight = (int[]) rowHeightField.get(layout);
        assertEquals(60, rowHeight[0], "rowHeight[0] should remain at 60");
    }

    @Test
    @DisplayName("layoutContainer correctly adjusts second column's width when i46 is not equal to 0")
    public void TC14_layoutContainer_adjustsSecondColumnWidthWhen_i46_not_0() throws Exception {
        // Arrange
        LCBLayout layout = new LCBLayout(1);
        Container parent = new Container();
        Component comp1 = new Component() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(100, 50);
            }
        };
        Component comp2 = new Component() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(150, 50);
            }
        };
        Component comp3 = new Component() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(120, 50);
            }
        };
        parent.add(comp1);
        parent.add(comp2);
        parent.add(comp3);
        parent.setSize(500, 200);
        
        // Act
        layout.layoutContainer(parent);
        
        // Assert
        Field colWidthField = LCBLayout.class.getDeclaredField("colWidth");
        colWidthField.setAccessible(true);
        int[] colWidth = (int[]) colWidthField.get(layout);
        assertTrue(colWidth[1] > 150, "Second column's width should be greater than 150");
    }

    @Test
    @DisplayName("layoutContainer does not adjust second column's width when i46 is equal to 0")
    public void TC15_layoutContainer_doesNotAdjustSecondColumnWidthWhen_i46_0() throws Exception {
        // Arrange
        LCBLayout layout = new LCBLayout(1);
        Container parent = new Container();
        Component comp1 = new Component() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(100, 50);
            }
        };
        Component comp2 = new Component() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(150, 50);
            }
        };
        Component comp3 = new Component() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(120, 50);
            }
        };
        parent.add(comp1);
        parent.add(comp2);
        parent.add(comp3);
        parent.setSize(300, 200);
        
        // Act
        layout.layoutContainer(parent);
        
        // Assert
        Field colWidthField = LCBLayout.class.getDeclaredField("colWidth");
        colWidthField.setAccessible(true);
        int[] colWidth = (int[]) colWidthField.get(layout);
        assertEquals(150, colWidth[1], "Second column's width should remain at 150");
    }

    @Test
    @DisplayName("layoutContainer correctly adjusts second column's width when i46 is not equal to 1")
    public void TC16_layoutContainer_adjustsSecondColumnWidthWhen_i46_not_1() throws Exception {
        // Arrange
        LCBLayout layout = new LCBLayout(1);
        Container parent = new Container();
        Component comp1 = new Component() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(100, 50);
            }
        };
        Component comp2 = new Component() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(150, 50);
            }
        };
        Component comp3 = new Component() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(120, 50);
            }
        };
        parent.add(comp1);
        parent.add(comp2);
        parent.add(comp3);
        parent.setSize(500, 200);
        
        // Act
        layout.layoutContainer(parent);
        
        // Assert
        Field colWidthField = LCBLayout.class.getDeclaredField("colWidth");
        colWidthField.setAccessible(true);
        int[] colWidth = (int[]) colWidthField.get(layout);
        assertTrue(colWidth[1] > 150, "Second column's width should be greater than 150");
    }

}