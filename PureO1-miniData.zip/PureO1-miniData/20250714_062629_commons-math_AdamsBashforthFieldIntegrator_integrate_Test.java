import org.apache.commons.math3.Field;
import org.apache.commons.math3.RealFieldElement;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.linear.FieldMatrix;
import org.apache.commons.math3.ode.FieldExpandableODE;
import org.apache.commons.math3.ode.FieldODEState;
import org.apache.commons.math3.ode.FieldODEStateAndDerivative;
import org.apache.commons.math3.ode.FirstOrderFieldIntegrator;
import org.apache.commons.math3.ode.FirstOrderFieldODE;
import org.apache.commons.math3.util.MathArrays;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.mockito.Mockito;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AdamsBashforthFieldIntegratorTest {

    private static class MockFieldElement implements RealFieldElement<MockFieldElement> {
        private final double value;

        public MockFieldElement(double value) {
            this.value = value;
        }

        @Override
        public double getReal() {
            return value;
        }

        @Override
        public MockFieldElement add(MockFieldElement a) {
            return new MockFieldElement(this.value + a.value);
        }

        @Override
        public MockFieldElement subtract(MockFieldElement a) {
            return new MockFieldElement(this.value - a.value);
        }

        @Override
        public MockFieldElement multiply(MockFieldElement a) {
            return new MockFieldElement(this.value * a.value);
        }

        @Override
        public MockFieldElement multiply(double a) {
            return new MockFieldElement(this.value * a);
        }

        @Override
        public MockFieldElement divide(MockFieldElement a) {
            return new MockFieldElement(this.value / a.value);
        }

        @Override
        public MockFieldElement reciprocal() {
            return new MockFieldElement(1.0 / this.value);
        }

        @Override
        public MockFieldElement negate() {
            return new MockFieldElement(-this.value);
        }

        @Override
        public MockFieldElement abs() {
            return new MockFieldElement(Math.abs(this.value));
        }

        @Override
        public MockFieldElement signum() {
            return new MockFieldElement(Math.signum(this.value));
        }

        @Override
        public MockFieldElement copySign(MockFieldElement sign) {
            return new MockFieldElement(Math.copySign(this.value, sign.value));
        }

        @Override
        public int getFieldType() {
            return 0;
        }

        @Override
        public boolean isNaN() {
            return Double.isNaN(this.value);
        }

        @Override
        public boolean isInfinite() {
            return Double.isInfinite(this.value);
        }

        @Override
        public MockFieldElement getField() {
            return this;
        }

        @Override
        public double getRealPart() {
            return value;
        }

        @Override
        public MockFieldElement getImaginaryPart() {
            return new MockFieldElement(0.0);
        }

        @Override
        public MockFieldElement addProduct(MockFieldElement a, MockFieldElement b) {
            return new MockFieldElement(this.value + a.value * b.value);
        }

        @Override
        public MockFieldElement absSq() {
            return new MockFieldElement(this.value * this.value);
        }

        @Override
        public int compareTo(MockFieldElement o) {
            return Double.compare(this.value, o.value);
        }

        @Override
        public MockFieldElement getZero() {
            return new MockFieldElement(0.0);
        }

        @Override
        public MockFieldElement getOne() {
            return new MockFieldElement(1.0);
        }

        @Override
        public MockFieldElement newInstance(double value) {
            return new MockFieldElement(value);
        }
    }

    @Test
    public void testIntegrateWithNullEquations() {
        Field field = new MockFieldElement(0.0).getField();
        AdamsBashforthFieldIntegrator<MockFieldElement> integrator =
                new AdamsBashforthFieldIntegrator<>(field, 2, 0.1, 1.0, 1e-6, 1e-6);

        FieldExpandableODE<MockFieldElement> equations = null;
        FieldODEState<MockFieldElement> initialState = mock(FieldODEState.class);
        MockFieldElement finalTime = new MockFieldElement(1.0);

        assertThrows(NullPointerException.class, () -> integrator.integrate(equations, initialState, finalTime));
    }

    @Test
    public void testIntegrateWithNullInitialState() {
        Field field = new MockFieldElement(0.0).getField();
        AdamsBashforthFieldIntegrator<MockFieldElement> integrator =
                new AdamsBashforthFieldIntegrator<>(field, 2, 0.1, 1.0, 1e-6, 1e-6);

        FieldExpandableODE<MockFieldElement> equations = mock(FieldExpandableODE.class);
        FieldODEState<MockFieldElement> initialState = null;
        MockFieldElement finalTime = new MockFieldElement(1.0);

        assertThrows(NullPointerException.class, () -> integrator.integrate(equations, initialState, finalTime));
    }

    @Test
    public void testIntegrateWithNullFinalTime() {
        Field field = new MockFieldElement(0.0).getField();
        AdamsBashforthFieldIntegrator<MockFieldElement> integrator =
                new AdamsBashforthFieldIntegrator<>(field, 2, 0.1, 1.0, 1e-6, 1e-6);

        FieldExpandableODE<MockFieldElement> equations = mock(FieldExpandableODE.class);
        FieldODEState<MockFieldElement> initialState = mock(FieldODEState.class);
        MockFieldElement finalTime = null;

        assertThrows(NullPointerException.class, () -> integrator.integrate(equations, initialState, finalTime));
    }

    @Test
    public void testIntegrateWithFinalTimeEqualToInitialTime() throws Exception {
        Field field = new MockFieldElement(0.0).getField();
        AdamsBashforthFieldIntegrator<MockFieldElement> integrator =
                new AdamsBashforthFieldIntegrator<>(field, 2, 0.1, 1.0, 1e-6, 1e-6);

        FieldExpandableODE<MockFieldElement> equations = mock(FieldExpandableODE.class);
        FieldODEState<MockFieldElement> initialState = mock(FieldODEState.class);
        when(initialState.getTime()).thenReturn(new MockFieldElement(1.0));
        MockFieldElement finalTime = new MockFieldElement(1.0);

        assertThrows(NumberIsTooSmallException.class, () -> integrator.integrate(equations, initialState, finalTime));
    }

    @Test
    public void testIntegrateWithOrderTooSmall() {
        Field field = new MockFieldElement(0.0).getField();
        Executable executable = () -> new AdamsBashforthFieldIntegrator<>(field, 1, 0.1, 1.0, 1e-6, 1e-6);
        assertThrows(NumberIsTooSmallException.class, executable);
    }

    @Test
    public void testIntegrateWithInvalidStepper() throws Exception {
        Field field = new MockFieldElement(0.0).getField();
        AdamsBashforthFieldIntegrator<MockFieldElement> integrator =
                new AdamsBashforthFieldIntegrator<>(field, 2, 0.1, 1.0, 1e-6, 1e-6);

        FieldExpandableODE<MockFieldElement> equations = mock(FieldExpandableODE.class);
        when(equations.getMapper()).thenReturn(Mockito.mock(org.apache.commons.math3.linear.FieldMatrixPreservingVisitor.class));

        FieldODEState<MockFieldElement> initialState = mock(FieldODEState.class);
        when(initialState.getTime()).thenReturn(new MockFieldElement(0.0));

        MockFieldElement finalTime = new MockFieldElement(1.0);

        when(equations.getMapper().mapState(initialState)).thenThrow(new DimensionMismatchException(0, 1));

        assertThrows(DimensionMismatchException.class, () -> integrator.integrate(equations, initialState, finalTime));
    }

    @Test
    public void testIntegrateSuccessfully() throws Exception {
        Field field = new MockFieldElement(0.0).getField();
        AdamsBashforthFieldIntegrator<MockFieldElement> integrator =
                new AdamsBashforthFieldIntegrator<>(field, 2, 0.1, 1.0, 1e-6, 1e-6);

        // Mock ODE
        FirstOrderFieldODE<MockFieldElement> ode = (t, y, yDot) -> {
            yDot[0] = new MockFieldElement(1.0);
        };

        FieldExpandableODE<MockFieldElement> equations = new FieldExpandableODE<>(ode);

        // Initial state y(0) = 0
        FieldODEState<MockFieldElement> initialState = new FieldODEState<>(new MockFieldElement(0.0), new MockFieldElement(0.0));

        MockFieldElement finalTime = new MockFieldElement(1.0);

        FieldODEStateAndDerivative<MockFieldElement> finalState = integrator.integrate(equations, initialState, finalTime);

        assertNotNull(finalState);
        assertEquals(1.0, finalState.getTime().getReal(), 1e-6);
        assertEquals(1.0, finalState.getPrimaryState()[0].getReal(), 1e-6);
    }

    @Test
    public void testIntegrateWithStepRejection() throws Exception {
        Field field = new MockFieldElement(0.0).getField();

        // Create integrator with very strict tolerances to force step rejection
        AdamsBashforthFieldIntegrator<MockFieldElement> integrator =
                new AdamsBashforthFieldIntegrator<>(field, 2, 0.01, 0.1, 1e-12, 1e-12);

        // Mock ODE that returns a large derivative to cause error
        FirstOrderFieldODE<MockFieldElement> ode = (t, y, yDot) -> {
            yDot[0] = new MockFieldElement(1e6);
        };

        FieldExpandableODE<MockFieldElement> equations = new FieldExpandableODE<>(ode);

        // Initial state y(0) = 0
        FieldODEState<MockFieldElement> initialState = new FieldODEState<>(new MockFieldElement(0.0), new MockFieldElement(0.0));

        MockFieldElement finalTime = new MockFieldElement(0.1);

        assertThrows(MaxCountExceededException.class, () -> integrator.integrate(equations, initialState, finalTime));
    }

    @Test
    public void testIntegrateWithNegativeStep() throws Exception {
        Field field = new MockFieldElement(0.0).getField();
        AdamsBashforthFieldIntegrator<MockFieldElement> integrator =
                new AdamsBashforthFieldIntegrator<>(field, 3, 0.1, 1.0, 1e-6, 1e-6);

        // Mock ODE
        FirstOrderFieldODE<MockFieldElement> ode = (t, y, yDot) -> {
            yDot[0] = new MockFieldElement(-1.0);
        };

        FieldExpandableODE<MockFieldElement> equations = new FieldExpandableODE<>(ode);

        // Initial state y(1) = 1
        FieldODEState<MockFieldElement> initialState = new FieldODEState<>(new MockFieldElement(1.0), new MockFieldElement(1.0));

        MockFieldElement finalTime = new MockFieldElement(0.0); // backward integration

        FieldODEStateAndDerivative<MockFieldElement> finalState = integrator.integrate(equations, initialState, finalTime);

        assertNotNull(finalState);
        assertEquals(0.0, finalState.getTime().getReal(), 1e-6);
        assertEquals(0.0, finalState.getPrimaryState()[0].getReal(), 1e-6);
    }

    @Test
    public void testIntegrateWithDiscontinuousEvent() throws Exception {
        Field field = new MockFieldElement(0.0).getField();
        AdamsBashforthFieldIntegrator<MockFieldElement> integrator =
                new AdamsBashforthFieldIntegrator<>(field, 3, 0.1, 1.0, 1e-6, 1e-6);

        // Mock ODE
        FirstOrderFieldODE<MockFieldElement> ode = (t, y, yDot) -> {
            yDot[0] = new MockFieldElement(1.0);
        };

        FieldExpandableODE<MockFieldElement> equations = new FieldExpandableODE<>(ode);

        // Add event handler that stops integration at t=0.5
        equations.addEventDetector(new org.apache.commons.math3.ode.events.EventHandler<MockFieldElement>() {
            @Override
            public org.apache.commons.math3.ode.events.EventHandler.Action eventOccurred(FieldODEStateAndDerivative<MockFieldElement> s, boolean increasing) {
                return org.apache.commons.math3.ode.events.EventHandler.Action.STOP;
            }

            @Override
            public double g(FieldODEStateAndDerivative<MockFieldElement> s) {
                return s.getTime().getReal() - 0.5;
            }

            @Override
            public org.apache.commons.math3.ode.events.EventHandler.Action resetState(FieldODEStateAndDerivative<MockFieldElement> oldState) {
                return org.apache.commons.math3.ode.events.EventHandler.Action.RESET_STATE;
            }
        }, 1);

        // Initial state y(0) = 0
        FieldODEState<MockFieldElement> initialState = new FieldODEState<>(new MockFieldElement(0.0), new MockFieldElement(0.0));

        MockFieldElement finalTime = new MockFieldElement(1.0);

        FieldODEStateAndDerivative<MockFieldElement> finalState = integrator.integrate(equations, initialState, finalTime);

        assertNotNull(finalState);
        assertEquals(0.5, finalState.getTime().getReal(), 1e-6);
        assertEquals(0.5, finalState.getPrimaryState()[0].getReal(), 1e-6);
    }

    @Test
    public void testIntegrateWithZeroStep() throws Exception {
        Field field = new MockFieldElement(0.0).getField();
        // Set minStep to zero to check boundary
        AdamsBashforthFieldIntegrator<MockFieldElement> integrator =
                new AdamsBashforthFieldIntegrator<>(field, 2, 0.0, 1.0, 1e-6, 1e-6);

        // Mock ODE
        FirstOrderFieldODE<MockFieldElement> ode = (t, y, yDot) -> {
            yDot[0] = new MockFieldElement(1.0);
        };

        FieldExpandableODE<MockFieldElement> equations = new FieldExpandableODE<>(ode);

        // Initial state y(0) = 0
        FieldODEState<MockFieldElement> initialState = new FieldODEState<>(new MockFieldElement(0.0), new MockFieldElement(0.0));

        MockFieldElement finalTime = new MockFieldElement(0.0);

        // Since finalTime == initialTime and minStep is zero, should throw exception
        assertThrows(NumberIsTooSmallException.class, () -> integrator.integrate(equations, initialState, finalTime));
    }

    @Test
    public void testIntegrateWithMaximumStep() throws Exception {
        Field field = new MockFieldElement(0.0).getField();
        // Set maxStep to small value to force step limit
        AdamsBashforthFieldIntegrator<MockFieldElement> integrator =
                new AdamsBashforthFieldIntegrator<>(field, 3, 0.1, 0.2, 1e-6, 1e-6);

        // Mock ODE
        FirstOrderFieldODE<MockFieldElement> ode = (t, y, yDot) -> {
            yDot[0] = new MockFieldElement(1.0);
        };

        FieldExpandableODE<MockFieldElement> equations = new FieldExpandableODE<>(ode);

        // Initial state y(0) = 0
        FieldODEState<MockFieldElement> initialState = new FieldODEState<>(new MockFieldElement(0.0), new MockFieldElement(0.0));

        MockFieldElement finalTime = new MockFieldElement(0.5);

        FieldODEStateAndDerivative<MockFieldElement> finalState = integrator.integrate(equations, initialState, finalTime);

        assertNotNull(finalState);
        assertEquals(0.5, finalState.getTime().getReal(), 1e-6);
        assertEquals(0.5, finalState.getPrimaryState()[0].getReal(), 1e-6);
    }

    @Test
    public void testIntegrateWithLargeOrder() throws Exception {
        Field field = new MockFieldElement(0.0).getField();
        // Use a larger number of steps
        AdamsBashforthFieldIntegrator<MockFieldElement> integrator =
                new AdamsBashforthFieldIntegrator<>(field, 5, 0.1, 1.0, 1e-6, 1e-6);

        // Mock ODE
        FirstOrderFieldODE<MockFieldElement> ode = (t, y, yDot) -> {
            yDot[0] = new MockFieldElement(Math.sin(t.getReal()));
        };

        FieldExpandableODE<MockFieldElement> equations = new FieldExpandableODE<>(ode);

        // Initial state y(0) = 0
        FieldODEState<MockFieldElement> initialState = new FieldODEState<>(new MockFieldElement(0.0), new MockFieldElement(0.0));

        MockFieldElement finalTime = new MockFieldElement(Math.PI);

        FieldODEStateAndDerivative<MockFieldElement> finalState = integrator.integrate(equations, initialState, finalTime);

        assertNotNull(finalState);
        assertEquals(Math.PI, finalState.getTime().getReal(), 1e-3);
        // y(pi) ~ 2
        assertEquals(2.0, finalState.getPrimaryState()[0].getReal(), 1e-1);
    }

    @Test
    public void testIntegrateWithDimensionMismatch() throws Exception {
        Field field = new MockFieldElement(0.0).getField();
        AdamsBashforthFieldIntegrator<MockFieldElement> integrator =
                new AdamsBashforthFieldIntegrator<>(field, 2, 0.1, 1.0, 1e-6, 1e-6);

        // Mock ODE with 2-dimensional state
        FirstOrderFieldODE<MockFieldElement> ode = (t, y, yDot) -> {
            yDot[0] = new MockFieldElement(1.0);
            yDot[1] = new MockFieldElement(2.0);
        };

        FieldExpandableODE<MockFieldElement> equations = new FieldExpandableODE<>(ode);

        // Initial state with 1-dimensional state
        FieldODEState<MockFieldElement> initialState = new FieldODEState<>(new MockFieldElement(0.0), new MockFieldElement[]{ new MockFieldElement(0.0) });

        MockFieldElement finalTime = new MockFieldElement(1.0);

        assertThrows(DimensionMismatchException.class, () -> integrator.integrate(equations, initialState, finalTime));
    }

    @Test
    public void testIntegrateWithMaximalStepReached() throws Exception {
        Field field = new MockFieldElement(0.0).getField();
        // Set maxStep very small to cause MaxCountExceededException
        AdamsBashforthFieldIntegrator<MockFieldElement> integrator =
                new AdamsBashforthFieldIntegrator<>(field, 2, 1e-6, 1e-6, 1e-6, 1e-6);

        // Mock ODE with constant derivative
        FirstOrderFieldODE<MockFieldElement> ode = (t, y, yDot) -> {
            yDot[0] = new MockFieldElement(1.0);
        };

        FieldExpandableODE<MockFieldElement> equations = new FieldExpandableODE<>(ode);

        // Initial state y(0) = 0
        FieldODEState<MockFieldElement> initialState = new FieldODEState<>(new MockFieldElement(0.0), new MockFieldElement[]{ new MockFieldElement(0.0) });

        MockFieldElement finalTime = new MockFieldElement(1.0);

        assertThrows(MaxCountExceededException.class, () -> integrator.integrate(equations, initialState, finalTime));
    }

    @Test
    public void testIntegrateWithNoBracketing() throws Exception {
        Field field = new MockFieldElement(0.0).getField();
        AdamsBashforthFieldIntegrator<MockFieldElement> integrator =
                new AdamsBashforthFieldIntegrator<>(field, 2, 0.1, 1.0, 1e-6, 1e-6);

        // Mock ODE
        FirstOrderFieldODE<MockFieldElement> ode = (t, y, yDot) -> {
            yDot[0] = new MockFieldElement(1.0);
        };

        FieldExpandableODE<MockFieldElement> equations = new FieldExpandableODE<>(ode);

        // Add event handler with no bracketing
        equations.addEventDetector(new org.apache.commons.math3.ode.events.EventHandler<MockFieldElement>() {
            @Override
            public org.apache.commons.math3.ode.events.EventHandler.Action eventOccurred(FieldODEStateAndDerivative<MockFieldElement> s, boolean increasing) {
                return org.apache.commons.math3.ode.events.EventHandler.Action.STOP;
            }

            @Override
            public double g(FieldODEStateAndDerivative<MockFieldElement> s) {
                return s.getTime().getReal() + 1.0; // Never zero
            }

            @Override
            public org.apache.commons.math3.ode.events.EventHandler.Action resetState(FieldODEStateAndDerivative<MockFieldElement> oldState) {
                return org.apache.commons.math3.ode.events.EventHandler.Action.CONTINUE;
            }
        }, 1);

        // Initial state y(0) = 0
        FieldODEState<MockFieldElement> initialState = new FieldODEState<>(new MockFieldElement(0.0), new MockFieldElement[]{ new MockFieldElement(0.0) });

        MockFieldElement finalTime = new MockFieldElement(1.0);

        FieldODEStateAndDerivative<MockFieldElement> finalState = integrator.integrate(equations, initialState, finalTime);

        assertNotNull(finalState);
        assertEquals(1.0, finalState.getTime().getReal(), 1e-6);
        assertEquals(1.0, finalState.getPrimaryState()[0].getReal(), 1e-6);
    }

}