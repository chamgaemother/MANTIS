package org.jfree.chart.renderer.xy;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Method;
import java.util.Collections;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.jfree.data.xy.XYDataset;
import org.mockito.ArgumentCaptor;

public class XYBoxAndWhiskerRenderer_drawVerticalItem_0_1_Test {

    @Test
    @DisplayName("drawVerticalItem with null PlotRenderingInfo (r0 == null)")   
    public void TC01_drawVerticalItem_with_null_PlotRenderingInfo() throws Exception {
        // GIVEN
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = null;
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;
    
        // WHEN
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Mock the XYBoxAndWhiskerRenderer to verify interactions
        XYBoxAndWhiskerRenderer spyRenderer = spy(renderer);

        // THEN
        Method addEntityMethod = XYBoxAndWhiskerRenderer.class.getDeclaredMethod("addEntity", EntityCollection.class, 
                Rectangle2D.class, XYDataset.class, int.class, int.class, double.class, double.class);
        addEntityMethod.setAccessible(true);

        // Execute the method
        spyRenderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, 
                rangeAxis, dataset, series, item, crosshairState, pass);

        // Verify that the addEntity was never called
        verify(spyRenderer, never()).addEntity(any(EntityCollection.class), any(Rectangle2D.class), 
                any(XYDataset.class), anyInt(), anyInt(), anyDouble(), anyDouble());
    }

    @Test
    @DisplayName("drawVerticalItem with non-null PlotRenderingInfo and yOutliers is null")
    public void TC02_drawVerticalItem_with_non_null_PlotRenderingInfo_and_yOutliers_is_null() throws Exception {
        // GIVEN
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 1;
        int item = 1;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 1;

        EntityCollection entityCollection = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entityCollection);
        when(dataset.getOutliers(series, item)).thenReturn(null);

        // WHEN
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        ArgumentCaptor<EntityCollection> entityCaptor = ArgumentCaptor.forClass(EntityCollection.class);
        verify(info.getOwner()).getEntityCollection();
        verify(entityCollection, never()).add(any());  // assumes it should not add entities when outliers are null
    }

    @Test
    @DisplayName("drawVerticalItem with yOutliers as empty list")
    public void TC03_drawVerticalItem_with_yOutliers_as_empty_list() throws Exception {
        // GIVEN
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 2;
        int item = 2;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 2;

        EntityCollection entityCollection = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entityCollection);
        when(dataset.getOutliers(series, item)).thenReturn(Collections.emptyList());

        // WHEN
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        verify(dataset).getOutliers(series, item); // ensuring method is invoked
        verify(info.getOwner()).getEntityCollection();
        ArgumentCaptor<EntityCollection> entityCaptor = ArgumentCaptor.forClass(EntityCollection.class);
        verify(entityCollection, never()).add(any());  // given empty list, it shouldn't interact
    }

    @Test
    @DisplayName("drawVerticalItem with yAverage as null")
    public void TC04_drawVerticalItem_with_yAverage_as_null() throws Exception {
        // GIVEN
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 3;
        int item = 3;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 3;

        when(dataset.getMeanValue(series, item)).thenReturn(null);

        // WHEN
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        verify(dataset).getMeanValue(series, item); // ensure it's checked
        verify(g2, never()).fill(any()); // since mean is null, no fill should occur 
    }

    @Test
    @DisplayName("drawVerticalItem with yAverage within dataArea bounds")
    public void TC05_drawVerticalItem_with_yAverage_within_dataArea_bounds() throws Exception {
        // GIVEN
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 4;
        int item = 4;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 4;

        // Mock dataset to return valid yAverage
        when(dataset.getMeanValue(series, item)).thenReturn(50.0);

        // Mock rangeAxis to return values within dataArea bounds
        when(rangeAxis.valueToJava2D(50.0, dataArea, plot.getRangeAxisEdge())).thenReturn(100.0);
        when(rangeAxis.getUpperBound()).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(200.0, dataArea, plot.getRangeAxisEdge())).thenReturn(250.0);
        when(rangeAxis.getLowerBound()).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, plot.getRangeAxisEdge())).thenReturn(-50.0);

        // WHEN
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        verify(dataset).getMeanValue(series, item);
        // Ensure ellipse is drawn given the interest area
        verify(g2, times(1)).fill(any());
    }
}
