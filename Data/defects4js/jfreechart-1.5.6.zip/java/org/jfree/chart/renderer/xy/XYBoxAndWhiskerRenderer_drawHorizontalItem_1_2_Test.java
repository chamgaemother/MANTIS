package org.jfree.chart.renderer.xy;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYBoxAndWhiskerRenderer;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Ellipse2D;

import static org.mockito.Mockito.*;

public class XYBoxAndWhiskerRenderer_drawHorizontalItem_1_2_Test {

    @Test
    @DisplayName("drawHorizontalItem with r0 not null, r23 is not null, z0 is false, ensuring specific artifacts are drawn")
    public void TC26_drawHorizontalItem_r0_not_null_r23_not_null_z0_false_specific_artifacts() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        renderer.setFillBox(true);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 2;
        int item = 2;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int rendererIndex = 2;

        // Mock dataset behavior with r23 not null
        when(dataset.getX(series, item)).thenReturn(20.0);
        when(dataset.getMaxRegularValue(series, item)).thenReturn(30.0);
        when(dataset.getMinRegularValue(series, item)).thenReturn(15.0);
        when(dataset.getMedianValue(series, item)).thenReturn(22.0);
        when(dataset.getMeanValue(series, item)).thenReturn(21.0);
        when(dataset.getQ1Value(series, item)).thenReturn(18.0);
        when(dataset.getQ3Value(series, item)).thenReturn(24.0);
        when(dataset.getItemCount(series)).thenReturn(10);

        // Mock plot orientation to vertical (z0 = false)
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);

        // Act
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);

        // Assert
        // Verify that lines (e.g., median line) and ellipses (e.g., average marker) are drawn
        verify(g2, atLeastOnce()).draw(any(Line2D.class));
        verify(g2, atLeastOnce()).draw(any(Ellipse2D.class));

        // Additionally, verify that filling occurs if fillBox is true
        verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
    }
}