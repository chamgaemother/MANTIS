package com.fasterxml.jackson.databind.util;

import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ISO8601Utils_parse_0_4_Test {

    @Test
    @DisplayName("Parse throws ParseException for invalid timezone indicator")
    void TC16_ParseThrowsParseExceptionForInvalidTimezoneIndicator() {
        // GIVEN
        String date = "2023-10-05T14:30:00X";
        ParsePosition pos = new ParsePosition(0);

        // WHEN & THEN
        IndexOutOfBoundsException exception = assertThrows(IndexOutOfBoundsException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
        assertTrue(exception.getMessage().contains("mismatching time zone indicator"));
    }

    @Test
    @DisplayName("Parse throws ParseException when time zone offset is invalid format")
    void TC17_ParseThrowsParseExceptionWhenTimeZoneOffsetIsInvalidFormat() {
        // GIVEN
        String date = "2023-10-05T14:30:00+25:00";
        ParsePosition pos = new ParsePosition(0);

        // WHEN & THEN
        IndexOutOfBoundsException exception = assertThrows(IndexOutOfBoundsException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
        assertTrue(exception.getMessage().contains("mismatching timezone"));
    }

    @Test
    @DisplayName("Parse successfully handles date with 'T' but no time component")
    void TC18_ParseSuccessfullyHandlesDateWithTButNoTimeComponent() throws ParseException {
        // GIVEN
        String date = "2023-10-05T";
        ParsePosition pos = new ParsePosition(0);

        // WHEN
        Date result = ISO8601Utils.parse(date, pos);

        // THEN
        Calendar expectedCalendar = new GregorianCalendar(2023, Calendar.OCTOBER, 5);
        Date expectedDate = expectedCalendar.getTime();
        assertEquals(expectedDate, result);
        assertEquals(date.length(), pos.getIndex());
    }

    @Test
    @DisplayName("Parse throws ParseException when 'T' is present but time components are incomplete")
    void TC19_ParseThrowsParseExceptionWhenTPresentButTimeComponentsAreIncomplete() {
        // GIVEN
        String date = "2023-10-05T14";
        ParsePosition pos = new ParsePosition(0);

        // WHEN & THEN
        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
        assertTrue(exception.getMessage().contains("incomplete time"));
    }

    @Test
    @DisplayName("Parse successfully parses date with minimal timezone offset without colon")
    void TC20_ParseSuccessfullyParsesDateWithMinimalTimezoneOffsetWithoutColon() throws ParseException {
        // GIVEN
        String date = "2023-10-05T14:30:00+0200";
        ParsePosition pos = new ParsePosition(0);

        // WHEN
        Date result = ISO8601Utils.parse(date, pos);

        // THEN
        Calendar expectedCalendar = new GregorianCalendar(TimeZone.getTimeZone("GMT+0200"));
        expectedCalendar.set(Calendar.YEAR, 2023);
        expectedCalendar.set(Calendar.MONTH, Calendar.OCTOBER);
        expectedCalendar.set(Calendar.DAY_OF_MONTH, 5);
        expectedCalendar.set(Calendar.HOUR_OF_DAY, 14);
        expectedCalendar.set(Calendar.MINUTE, 30);
        expectedCalendar.set(Calendar.SECOND, 0);
        expectedCalendar.set(Calendar.MILLISECOND, 0);
        Date expectedDate = expectedCalendar.getTime();
        assertEquals(expectedDate, result);
        assertEquals(date.length(), pos.getIndex());
    }
}