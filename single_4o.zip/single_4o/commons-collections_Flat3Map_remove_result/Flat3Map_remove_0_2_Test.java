package org.apache.commons.collections4.map;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.Objects;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class Flat3Map_remove_0_2_Test {

    @Test
    @DisplayName("Remove with non-null key when size is greater than zero, no hash or key match")
    void testRemoveWithNonNullKeyNoMatch() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();
        setSize(map, 2);
        setKeyValue(map, "key1", "value1", 1, "key2", "value2", 2);

        Object result = map.remove("unrelated");
        assertNull(result, "The result should be null since the key does not match any map entries.");
    }

    @Test
    @DisplayName("Remove with null key when size is 2, match at position 1")
    void testRemoveWithNullKeyMatchAtPosition1() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();
        setSize(map, 2);
        setKeyValue(map, null, "v1", 1, "key2", "v2", 2);

        Object result = map.remove(null);
        assertEquals("v1", result, "The result should be the value at position 1.");
    }

    @Test
    @DisplayName("Remove with null key when size is 1, match")
    void testRemoveWithNullKeySize1Match() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();
        setSize(map, 1);
        setKeyValue(map, null, "value1", 1, null, null, 0);

        Object result = map.remove(null);
        assertEquals("value1", result, "The result should be the only value in the map.");
    }

    @Test
    @DisplayName("Remove with null key when size is greater than zero, key matches at position 2")
    void testRemoveWithNullKeyMatchAtPosition2() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();
        setSize(map, 2);
        setKeyValue(map, "key1", "v1", 1, null, "v2", 2);

        Object result = map.remove(null);
        assertEquals("v2", result, "The result should be the value at position 2.");
    }

    @Test
    @DisplayName("Remove with non-null key, hash matches at position 1")
    void testRemoveWithNonNullKeyHashMatches() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();
        setSize(map, 2);
        setKeyValue(map, "key1", "v1", "key1".hashCode(), "key2", "v2", "key2".hashCode());

        Object result = map.remove("key1");
        assertEquals("v1", result, "The result should be the value at position 1.");
    }

    private void setSize(Flat3Map<Object, Object> map, int size) throws Exception {
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, size);
    }

    private void setKeyValue(Flat3Map<Object, Object> map, Object k1, Object v1, int h1, Object k2, Object v2, int h2) throws Exception {
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, k1);

        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, v1);

        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, h1);

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, k2);

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, v2);

        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, h2);
    }
}