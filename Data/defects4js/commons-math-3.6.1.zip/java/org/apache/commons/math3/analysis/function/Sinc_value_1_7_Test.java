package org.apache.commons.math3.analysis.function;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Sinc_value_1_7_Test {

    @Test
    @DisplayName("value(NaN) with normalized=true handles NaN input gracefully")
    void test_TC23() {
        // GIVEN
        Sinc sinc = new Sinc(true);
        
        // WHEN
        double result = sinc.value(Double.NaN);
        
        // THEN
        assertTrue(Double.isNaN(result), "Expected result to be NaN when input is NaN with normalization");
    }

    @Test
    @DisplayName("value(Infinity) with normalized=true handles Infinity input gracefully")
    void test_TC24() {
        // GIVEN
        Sinc sinc = new Sinc(true);
        
        // WHEN
        double result = sinc.value(Double.POSITIVE_INFINITY);
        
        // THEN
        assertTrue(Double.isNaN(result), "Expected result to be NaN when input is Infinity with normalization");
    }
}