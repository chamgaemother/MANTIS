
package com.fasterxml.jackson.databind.deser.impl;
import java.lang.reflect.*;
import java.io.*;

import java.util.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.deser.SettableBeanProperty;

public class ManagedReferenceProperty_setAndReturn_0_2_Test {

    @Test
    @DisplayName("value is Object[] with multiple elements including nulls, _backProperty.set is called for non-null elements")
    void TC06() throws Exception {
        // GIVEN
        Object element1 = new Object();
        Object element2 = null;
        Object element3 = new Object();
        Object[] value = new Object[] { element1, element2, element3 };
        Object instance = new Object();

        // Mock dependencies
        SettableBeanProperty backProperty = mock(SettableBeanProperty.class);
        SettableBeanProperty delegate = mock(SettableBeanProperty.class);
        Object expectedResult = new Object();
        when(delegate.setAndReturn(eq(instance), eq(value))).thenReturn(expectedResult);

        // Create ManagedReferenceProperty instance
        ManagedReferenceProperty property = new ManagedReferenceProperty(delegate, "refName", backProperty, true);

        // WHEN
        Object result = property.setAndReturn(instance, value);

        // THEN
        verify(backProperty, times(1)).set(eq(element1), eq(instance));
        verify(backProperty, times(1)).set(eq(element3), eq(instance));
        verify(delegate, times(1)).setAndReturn(eq(instance), eq(value));
        assertEquals(expectedResult, result);
    }

    @Test
    @DisplayName("value is a Collection with zero elements, no _backProperty.set calls")
    void TC07() throws Exception {
        // GIVEN
        Collection<Object> value = new ArrayList<>();
        Object instance = new Object();

        // Mock dependencies
        SettableBeanProperty backProperty = mock(SettableBeanProperty.class);
        SettableBeanProperty delegate = mock(SettableBeanProperty.class);
        Object expectedResult = new Object();
        when(delegate.setAndReturn(eq(instance), eq(value))).thenReturn(expectedResult);

        // Create ManagedReferenceProperty instance
        ManagedReferenceProperty property = new ManagedReferenceProperty(delegate, "refName", backProperty, true);

        // WHEN
        Object result = property.setAndReturn(instance, value);

        // THEN
        verify(backProperty, never()).set(any(), any());
        verify(delegate, times(1)).setAndReturn(eq(instance), eq(value));
        assertEquals(expectedResult, result);
    }

    @Test
    @DisplayName("value is a Collection with one null element, _backProperty.set is not called")
    void TC08() throws Exception {
        // GIVEN
        Collection<Object> value = Arrays.asList((Object) null);
        Object instance = new Object();

        // Mock dependencies
        SettableBeanProperty backProperty = mock(SettableBeanProperty.class);
        SettableBeanProperty delegate = mock(SettableBeanProperty.class);
        Object expectedResult = new Object();
        when(delegate.setAndReturn(eq(instance), eq(value))).thenReturn(expectedResult);

        // Create ManagedReferenceProperty instance
        ManagedReferenceProperty property = new ManagedReferenceProperty(delegate, "refName", backProperty, true);

        // WHEN
        Object result = property.setAndReturn(instance, value);

        // THEN
        verify(backProperty, never()).set(any(), any());
        verify(delegate, times(1)).setAndReturn(eq(instance), eq(value));
        assertEquals(expectedResult, result);
    }

    @Test
    @DisplayName("value is a Collection with one non-null element, _backProperty.set is called once")
    void TC09() throws Exception {
        // GIVEN
        Object element = new Object();
        Collection<Object> value = Arrays.asList(element);
        Object instance = new Object();

        // Mock dependencies
        SettableBeanProperty backProperty = mock(SettableBeanProperty.class);
        SettableBeanProperty delegate = mock(SettableBeanProperty.class);
        Object expectedResult = new Object();
        when(delegate.setAndReturn(eq(instance), eq(value))).thenReturn(expectedResult);

        // Create ManagedReferenceProperty instance
        ManagedReferenceProperty property = new ManagedReferenceProperty(delegate, "refName", backProperty, true);

        // WHEN
        Object result = property.setAndReturn(instance, value);

        // THEN
        verify(backProperty, times(1)).set(eq(element), eq(instance));
        verify(delegate, times(1)).setAndReturn(eq(instance), eq(value));
        assertEquals(expectedResult, result);
    }

    @Test
    @DisplayName("value is a Collection with multiple elements including nulls, _backProperty.set is called for non-null elements")
    void TC10() throws Exception {
        // GIVEN
        Object element1 = new Object();
        Object element2 = null;
        Object element3 = new Object();
        Collection<Object> value = Arrays.asList(element1, element2, element3);
        Object instance = new Object();

        // Mock dependencies
        SettableBeanProperty backProperty = mock(SettableBeanProperty.class);
        SettableBeanProperty delegate = mock(SettableBeanProperty.class);
        Object expectedResult = new Object();
        when(delegate.setAndReturn(eq(instance), eq(value))).thenReturn(expectedResult);

        // Create ManagedReferenceProperty instance
        ManagedReferenceProperty property = new ManagedReferenceProperty(delegate, "refName", backProperty, true);

        // WHEN
        Object result = property.setAndReturn(instance, value);

        // THEN
        verify(backProperty, times(1)).set(eq(element1), eq(instance));
        verify(backProperty, times(1)).set(eq(element3), eq(instance));
        verify(delegate, times(1)).setAndReturn(eq(instance), eq(value));
        assertEquals(expectedResult, result);
    }
}