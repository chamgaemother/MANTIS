package com.fasterxml.jackson.core.filter;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.filter.FilteringParserDelegate;
import com.fasterxml.jackson.core.filter.TokenFilterContext;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class FilteringParserDelegate_nextToken_0_1_Test {

    @Test
    @DisplayName("Returns null when _allowMultipleMatches is false, _currToken is scalar, _exposedContext is null, _headContext is not start handled, inclusion is ONLY_INCLUDE_ALL, and _itemFilter is INCLUDE_ALL")
    void TC01_returnsNullUnderSpecificConditions() throws Exception {
        // Arrange
        JsonParser delegateMock = mock(JsonParser.class);
        TokenFilter includeAllFilter = mock(TokenFilter.class);
        FilteringParserDelegate parser = new FilteringParserDelegate(delegateMock, includeAllFilter,
                TokenFilter.Inclusion.ONLY_INCLUDE_ALL, false);

        setField(parser, "_currToken", JsonToken.VALUE_STRING);
        setField(parser, "_exposedContext", null);

        TokenFilterContext headContextMock = mock(TokenFilterContext.class);
        when(headContextMock.isStartHandled()).thenReturn(false);
        setField(parser, "_headContext", headContextMock);

        setField(parser, "_itemFilter", includeAllFilter);

        when(includeAllFilter.includeValue(delegateMock)).thenReturn(true);

        // Act
        JsonToken result = parser.nextToken();

        // Assert
        assertNull(result, "Expected nextToken to return null under specified conditions");
    }

    @Test
    @DisplayName("Processes buffered tokens when _exposedContext is not null and returns the next token from buffer")
    void TC02_returnsBufferedTokenWhenExposedContextIsPresent() throws Exception {
        // Arrange
        JsonParser delegateMock = mock(JsonParser.class);
        TokenFilter includeAllFilter = mock(TokenFilter.class);
        FilteringParserDelegate parser = new FilteringParserDelegate(delegateMock, includeAllFilter,
                TokenFilter.Inclusion.ONLY_INCLUDE_ALL, false);

        JsonToken bufferedToken = JsonToken.FIELD_NAME;
        TokenFilterContext exposedContextMock = mock(TokenFilterContext.class);
        when(exposedContextMock.nextTokenToRead()).thenReturn(bufferedToken);
        setField(parser, "_exposedContext", exposedContextMock);

        // Act
        JsonToken result = parser.nextToken();

        // Assert
        assertEquals(JsonToken.FIELD_NAME, result, "Expected nextToken to return the buffered FIELD_NAME token");
    }

    @Test
    @DisplayName("Throws exception when chain of filtered context is broken")
    void TC03_throwsExceptionWhenContextChainIsBroken() throws Exception {
        // Arrange
        JsonParser delegateMock = mock(JsonParser.class);
        TokenFilter includeAllFilter = mock(TokenFilter.class);
        FilteringParserDelegate parser = new FilteringParserDelegate(delegateMock, includeAllFilter,
                TokenFilter.Inclusion.ONLY_INCLUDE_ALL, false);

        TokenFilterContext brokenContextMock = mock(TokenFilterContext.class);
        when(brokenContextMock.findChildOf(any())).thenReturn(null);
        setField(parser, "_exposedContext", brokenContextMock);

        // Act & Assert
        Exception exception = assertThrows(Exception.class, parser::nextToken, "Expected nextToken to throw an exception when context chain is broken");
        assertTrue(exception.getMessage().contains("Unexpected problem: chain of filtered context broken"), "Exception message should indicate a broken context chain");
    }

    @Test
    @DisplayName("Handles JsonToken.NOT_AVAILABLE by throwing an exception")
    void TC04_throwsExceptionOnJsonTokenNotAvailable() throws Exception {
        // Arrange
        JsonParser delegateMock = mock(JsonParser.class);
        TokenFilter includeAllFilter = mock(TokenFilter.class);
        when(delegateMock.nextToken()).thenReturn(JsonToken.NOT_AVAILABLE);
        FilteringParserDelegate parser = new FilteringParserDelegate(delegateMock, includeAllFilter,
                TokenFilter.Inclusion.ONLY_INCLUDE_ALL, false);

        // Act & Assert
        Exception exception = assertThrows(Exception.class, parser::nextToken, "Expected nextToken to throw an exception when JsonToken.NOT_AVAILABLE is received");
        assertTrue(exception.getMessage().contains("`JsonToken.NOT_AVAILABLE` received"), "Exception message should indicate NOT_AVAILABLE token issue");
    }

    @Test
    @DisplayName("Returns END_ARRAY token when processing buffered context in array")
    void TC05_returnsEndArrayFromBuffer() throws Exception {
        // Arrange
        JsonParser delegateMock = mock(JsonParser.class);
        TokenFilter includeAllFilter = mock(TokenFilter.class);
        FilteringParserDelegate parser = new FilteringParserDelegate(delegateMock, includeAllFilter,
                TokenFilter.Inclusion.ONLY_INCLUDE_ALL, false);

        TokenFilterContext exposedContextMock = mock(TokenFilterContext.class);
        when(exposedContextMock.nextTokenToRead()).thenReturn(JsonToken.END_ARRAY);
        setField(parser, "_exposedContext", exposedContextMock);

        // Act
        JsonToken result = parser.nextToken();

        // Assert
        assertEquals(JsonToken.END_ARRAY, result, "Expected nextToken to return END_ARRAY token from buffer");
    }

    /**
     * Utility method to set private fields via reflection.
     *
     * @param target    The object whose field should be modified.
     * @param fieldName The name of the field.
     * @param value     The value to set.
     * @throws Exception if the field cannot be accessed or modified.
     */
    private void setField(Object target, String fieldName, Object value) throws Exception {
        Field field = null;
        Class<?> clazz = target.getClass();
        while (clazz != null) {
            try {
                field = clazz.getDeclaredField(fieldName);
                break;
            } catch (NoSuchFieldException e) {
                clazz = clazz.getSuperclass();
            }
        }
        if (field == null) {
            throw new NoSuchFieldException("Field " + fieldName + " not found in " + target.getClass());
        }
        field.setAccessible(true);
        field.set(target, value);
    }
}