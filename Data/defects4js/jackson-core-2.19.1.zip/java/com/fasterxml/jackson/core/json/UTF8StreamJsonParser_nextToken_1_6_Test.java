package com.fasterxml.jackson.core.json;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import com.fasterxml.jackson.core.util.BufferRecycler;
import com.fasterxml.jackson.core.io.IOContext;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class UTF8StreamJsonParser_nextToken_1_6_Test {

    @Test
    @DisplayName("nextToken throws exception on trailing comma in array when feature is disabled")
    void TC31_nextToken_ThrowsException_OnTrailingCommaInArray() throws IOException {
        // GIVEN
        String json = "[1,2,3,]";
        InputStream input = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        ObjectCodec codec = null; // Can be null or a mock if needed
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        IOContext ctxt = new IOContext(new BufferRecycler(), input, false);
        
        // Disable ALLOW_TRAILING_COMMA
        int features = 0;
        
        byte[] inputBuffer = new byte[8192]; // Example buffer size
        int start = 0;
        int end = start;
        
        UTF8StreamJsonParser parser = new UTF8StreamJsonParser(ctxt, features, input, codec, sym, inputBuffer, start, end, 0, true);
        
        parser.nextToken(); // [
        parser.nextToken(); // 1
        parser.nextToken(); // 2
        parser.nextToken(); // 3
        
        // THEN
        assertThrows(JsonParseException.class, () -> parser.nextToken(), "Expected JsonParseException due to trailing comma");
    }

    @Test
    @DisplayName("nextToken throws exception on trailing comma in object when feature is disabled")
    void TC32_nextToken_ThrowsException_OnTrailingCommaInObject() throws IOException {
        // GIVEN
        String json = "{\"a\":1, \"b\":2,}";
        InputStream input = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        ObjectCodec codec = null;
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        IOContext ctxt = new IOContext(new BufferRecycler(), input, false);
        
        // Disable ALLOW_TRAILING_COMMA
        int features = 0;
        
        byte[] inputBuffer = new byte[8192];
        int start = 0;
        int end = start;
        
        UTF8StreamJsonParser parser = new UTF8StreamJsonParser(ctxt, features, input, codec, sym, inputBuffer, start, end, 0, true);
        
        parser.nextToken(); // {
        parser.nextToken(); // "a"
        parser.nextToken(); // 1
        parser.nextToken(); // "b"
        parser.nextToken(); // 2
        
        // THEN
        assertThrows(JsonParseException.class, () -> parser.nextToken(), "Expected JsonParseException due to trailing comma");
    }

    @Test
    @DisplayName("nextToken correctly parses 'NaN' when ALLOW_NON_NUMERIC_NUMBERS is enabled")
    void TC33_nextToken_ParsesNaN_WhenFeatureEnabled() throws IOException {
        // GIVEN
        String json = "NaN";
        InputStream input = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        ObjectCodec codec = null;
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        IOContext ctxt = new IOContext(new BufferRecycler(), input, false);
        
        // Enable ALLOW_NON_NUMERIC_NUMBERS
        int features = 0;
        
        byte[] inputBuffer = new byte[8192];
        int start = 0;
        int end = start;
        
        UTF8StreamJsonParser parser = new UTF8StreamJsonParser(ctxt, features, input, codec, sym, inputBuffer, start, end, 0, true);
        
        // WHEN
        JsonToken token = parser.nextToken();
        
        // THEN
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, token, "Expected VALUE_NUMBER_FLOAT for NaN");
        // Additional check for NaN can be done if getDoubleValue() is accessible
    }

    @Test
    @DisplayName("nextToken correctly parses 'Infinity' when ALLOW_NON_NUMERIC_NUMBERS is enabled")
    void TC34_nextToken_ParsesInfinity_WhenFeatureEnabled() throws IOException {
        // GIVEN
        String json = "Infinity";
        InputStream input = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        ObjectCodec codec = null;
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        IOContext ctxt = new IOContext(new BufferRecycler(), input, false);
        
        // Enable ALLOW_NON_NUMERIC_NUMBERS
        int features = 0;
        
        byte[] inputBuffer = new byte[8192];
        int start = 0;
        int end = start;
        
        UTF8StreamJsonParser parser = new UTF8StreamJsonParser(ctxt, features, input, codec, sym, inputBuffer, start, end, 0, true);
        
        // WHEN
        JsonToken token = parser.nextToken();
        
        // THEN
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, token, "Expected VALUE_NUMBER_FLOAT for Infinity");
        // Additional check for Infinity can be done if getDoubleValue() is accessible
    }

    @Test
    @DisplayName("nextToken throws exception when parsing 'NaN' and ALLOW_NON_NUMERIC_NUMBERS is disabled")
    void TC35_nextToken_ThrowsException_OnNaN_WhenFeatureDisabled() throws IOException {
        // GIVEN
        String json = "NaN";
        InputStream input = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        ObjectCodec codec = null;
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        IOContext ctxt = new IOContext(new BufferRecycler(), input, false);
        
        // Disable ALLOW_NON_NUMERIC_NUMBERS
        int features = 0;
        
        byte[] inputBuffer = new byte[8192];
        int start = 0;
        int end = start;
        
        UTF8StreamJsonParser parser = new UTF8StreamJsonParser(ctxt, features, input, codec, sym, inputBuffer, start, end, 0, true);
        
        // WHEN & THEN
        assertThrows(JsonParseException.class, () -> parser.nextToken(), "Expected JsonParseException for invalid token NaN");
    }
}
