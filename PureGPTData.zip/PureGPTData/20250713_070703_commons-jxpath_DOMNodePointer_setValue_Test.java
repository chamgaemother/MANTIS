import org.apache.commons.jxpath.ri.model.dom.DOMNodePointer;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.util.TypeUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DOMNodePointerTest {

    private Document document;
    private Element element;

    @BeforeEach
    void setUp() throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        document = builder.newDocument();
        element = document.createElement("root");
        document.appendChild(element);
    }

    @Test
    void testSetValueWithStringOnTextNode() {
        Text textNode = document.createTextNode("initial");
        element.appendChild(textNode);
        DOMNodePointer pointer = new DOMNodePointer(textNode, null);
        
        // Set new string value
        pointer.setValue("newValue");
        assertEquals("newValue", textNode.getNodeValue());
       
        // Set empty string, should remove text node
        pointer.setValue("");
        assertNull(textNode.getParentNode());
    }

    @Test
    void testSetValueWithElementNode() {
        String originalValue = "original";
        String childTag = "child";
        
        // Prepare child element with text and its setup
        Element child = document.createElement(childTag);
        Text originalText = document.createTextNode(originalValue);
        child.appendChild(originalText);
        element.appendChild(child);
        
        DOMNodePointer pointer = new DOMNodePointer(element, null);

        // Assert original state
        assertEquals(childTag, element.getFirstChild().getNodeName());
        assertEquals(originalValue, child.getTextContent());
        
        // Remove children
        pointer.setValue("");
        assertEquals(0, element.getChildNodes().getLength());

        // Add a node with children
        String newValue = "newValue";
        Element newChild = document.createElement(childTag);
        Text newText = document.createTextNode(newValue);
        newChild.appendChild(newText);
        pointer.setValue(newChild);
        
        // Check new state
        assertEquals(childTag, element.getFirstChild().getNodeName());
        assertEquals(newValue, element.getFirstChild().getTextContent());
    }

    @Test
    void testSetValueWithProcessingInstruction() {
        ProcessingInstruction pi = document.createProcessingInstruction("target", "data");
        element.appendChild(pi);
        DOMNodePointer pointer = new DOMNodePointer(pi, null);
        
        // Set a new value
        pointer.setValue("newData");
        assertEquals("newData", pi.getData());
    }

    @Test
    void testSetValueWithNull() {
        Text textNode = document.createTextNode("someText");
        element.appendChild(textNode);
        DOMNodePointer pointer = new DOMNodePointer(textNode, null);
        
        // Convert null to string and expect no exceptions
        pointer.setValue(null);
        assertNull(textNode.getParentNode());
    }

    @Test
    void testSetValueOnCDATA() {
        CDATASection cdata = document.createCDATASection("cdata");
        element.appendChild(cdata);
        DOMNodePointer pointer = new DOMNodePointer(cdata, null);
        
        // Change CDATA value
        pointer.setValue("newCData");
        assertEquals("newCData", cdata.getData());
        
        // Set empty string, should remove CDATA node
        pointer.setValue("");
        assertNull(cdata.getParentNode());
    }

    @Test
    void testSetValueWithNonNode() {
        Comment comment = document.createComment("A comment");
        element.appendChild(comment);
        DOMNodePointer pointer = new DOMNodePointer(element, null);
        
        // Replace children with new non-node value treated as string
        pointer.setValue(comment);
        assertTrue(element.getFirstChild() instanceof Comment);
    }
}