import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;
import java.util.Collection;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.renderer.xy.XYAreaRenderer;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class XYAreaRendererTest {

    private XYAreaRenderer renderer;
    private Graphics2D graphics;
    private Rectangle2D dataArea;
    private XYPlot plot;
    private NumberAxis domainAxis;
    private NumberAxis rangeAxis;
    private XYSeriesCollection dataset;
    private CrosshairState crosshairState;
    private PlotRenderingInfo plotInfo;
    private XYItemRendererState state;

    @BeforeEach
    public void setUp() {
        renderer = new XYAreaRenderer(XYAreaRenderer.AREA_AND_SHAPES);
        graphics = mock(Graphics2D.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        plot = mock(XYPlot.class);
        domainAxis = new NumberAxis();
        rangeAxis = new NumberAxis();
        dataset = new XYSeriesCollection();
        crosshairState = new CrosshairState();
        plotInfo = new PlotRenderingInfo(null);
        state = renderer.initialise(graphics, dataArea, plot, dataset, plotInfo);

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT);
    }

    @Test
    public void testDrawItem_SingleItemSeries() {
        XYSeries series = new XYSeries("Series 1");
        series.add(1.0, 5.0);
        dataset.addSeries(series);
        renderer.drawItem(graphics, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
    }

    @Test
    public void testDrawItem_TwoItemSeries_EndPoint() {
        XYSeries series = new XYSeries("Series 1");
        series.add(1.0, 5.0);
        series.add(2.0, 6.0);
        dataset.addSeries(series);
        renderer.drawItem(graphics, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }

    @Test
    public void testDrawItem_NanYValue() {
        XYSeries series = new XYSeries("Series 1");
        series.add(1.0, Double.NaN);
        series.add(2.0, 6.0);
        dataset.addSeries(series);
        renderer.drawItem(graphics, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }

    @Test
    public void testDrawItem_OnlyNegativeValues() {
        XYSeries series = new XYSeries("Series 1");
        series.add(1.0, -5.0);
        series.add(2.0, -6.0);
        dataset.addSeries(series);
        renderer.drawItem(graphics, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }

    @Test
    public void testDrawItem_NullCrosshairState() {
        XYSeries series = new XYSeries("Series 1");
        series.add(1.0, 5.0);
        series.add(2.0, 6.0);
        dataset.addSeries(series);
        renderer.drawItem(graphics, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 1, null, 0);
    }

    @Test
    public void testDrawItem_NoAreaPlot() {
        renderer = new XYAreaRenderer(XYAreaRenderer.LINES);
        XYSeries series = new XYSeries("Series 1");
        series.add(1.0, 5.0);
        series.add(2.0, 6.0);
        dataset.addSeries(series);
        renderer.drawItem(graphics, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }

    @Test
    public void testDrawItem_NoLines() {
        renderer = new XYAreaRenderer(XYAreaRenderer.SHAPES);
        XYSeries series = new XYSeries("Series 1");
        series.add(1.0, 5.0);
        series.add(2.0, 6.0);
        dataset.addSeries(series);
        renderer.drawItem(graphics, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }
}