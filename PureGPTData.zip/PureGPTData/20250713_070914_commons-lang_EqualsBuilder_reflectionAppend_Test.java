import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.EqualsExclude;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class EqualsBuilderTest {

    static class Person {
        @EqualsExclude
        private int id;
        private String name;
        private String[] tags;
        private Double salary;

        public Person(int id, String name, String[] tags, Double salary) {
            this.id = id;
            this.name = name;
            this.tags = tags;
            this.salary = salary;
        }
    }

    static class SubPerson extends Person {
        private String address;

        public SubPerson(int id, String name, String[] tags, Double salary, String address) {
            super(id, name, tags, salary);
            this.address = address;
        }
    }

    @Test
    public void testReflectionAppendWithSameInstance() {
        Person person = new Person(1, "John", new String[]{"tag1"}, 50.0);
        EqualsBuilder builder = new EqualsBuilder();
        builder.reflectionAppend(person, person);
        assertTrue(builder.isEquals(), "Reflection append should return true for the same instance");
    }

    @Test
    public void testReflectionAppendWithNull() {
        EqualsBuilder builder = new EqualsBuilder();
        builder.reflectionAppend(null, new Person(1, "John", new String[]{"tag1"}, 50.0));
        assertFalse(builder.isEquals(), "Reflection append should return false for null lhs");
        
        builder = new EqualsBuilder();
        builder.reflectionAppend(new Person(1, "John", new String[]{"tag1"}, 50.0), null);
        assertFalse(builder.isEquals(), "Reflection append should return false for null rhs");
    }

    @Test
    public void testReflectionAppendWithUnequalObjects() {
        Person person1 = new Person(1, "John", new String[]{"tag1"}, 50.0);
        Person person2 = new Person(2, "Jane", new String[]{"tag1"}, 60.0);
        EqualsBuilder builder = new EqualsBuilder();
        builder.reflectionAppend(person1, person2);
        assertFalse(builder.isEquals(), "Reflection append should return false for unequal objects");
    }

    @Test
    public void testReflectionAppendWithEqualObjects() {
        Person person1 = new Person(1, "John", new String[]{"tag1"}, 50.0);
        Person person2 = new Person(1, "John", new String[]{"tag1"}, 50.0);
        EqualsBuilder builder = new EqualsBuilder();
        builder.reflectionAppend(person1, person2);
        assertTrue(builder.isEquals(), "Reflection append should return true for equal objects");
    }

    @Test
    public void testReflectionAppendWithDifferentClasses() {
        Person person = new Person(1, "John", new String[]{"tag1"}, 50.0);
        SubPerson subPerson = new SubPerson(1, "John", new String[]{"tag1"}, 50.0, "123 St");
        EqualsBuilder builder = new EqualsBuilder();
        builder.reflectionAppend(person, subPerson);
        assertFalse(builder.isEquals(), "Reflection append should return false for different classes");
    }

    @Test
    public void testReflectionAppendWithExcludedFields() throws Exception {
        Field idField = Person.class.getDeclaredField("id");
        Field[] fields = {idField};
        idField.setAccessible(true);
        Person person1 = new Person(1, "John", new String[]{"tag1"}, 50.0);
        Person person2 = new Person(2, "John", new String[]{"tag1"}, 50.0);
        EqualsBuilder builder = new EqualsBuilder();
        builder.setExcludeFields("id").reflectionAppend(person1, person2);
        assertTrue(builder.isEquals(), "Reflection append should ignore excluded fields");
    }
}