import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.json.ByteSourceJsonBootstrapper;
import com.fasterxml.jackson.core.io.IOContext;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class ByteSourceJsonBootstrapperTest {

    @Test
    void testDetectEncodingWithBOM_UTF8() throws IOException {
        IOContext context = mock(IOContext.class);
        byte[] utf8Bom = new byte[]{(byte) 0xEF, (byte) 0xBB, (byte) 0xBF, ' '};
        ByteArrayInputStream in = new ByteArrayInputStream(utf8Bom);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, in);

        assertEquals(JsonEncoding.UTF8, bootstrapper.detectEncoding());
    }

    @Test
    void testDetectEncodingWithBOM_UTF16BE() throws IOException {
        IOContext context = mock(IOContext.class);
        byte[] utf16beBom = new byte[]{(byte) 0xFE, (byte) 0xFF, ' ', ' '};
        ByteArrayInputStream in = new ByteArrayInputStream(utf16beBom);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, in);

        assertEquals(JsonEncoding.UTF16_BE, bootstrapper.detectEncoding());
    }

    @Test
    void testDetectEncodingWithBOM_UTF16LE() throws IOException {
        IOContext context = mock(IOContext.class);
        byte[] utf16leBom = new byte[]{(byte) 0xFF, (byte) 0xFE, ' ', ' '};
        ByteArrayInputStream in = new ByteArrayInputStream(utf16leBom);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, in);

        assertEquals(JsonEncoding.UTF16_LE, bootstrapper.detectEncoding());
    }

    @Test
    void testDetectEncodingWithBOM_UTF32BE() throws IOException {
        IOContext context = mock(IOContext.class);
        byte[] utf32beBom = new byte[]{0x00, 0x00, (byte) 0xFE, (byte) 0xFF, ' '};
        ByteArrayInputStream in = new ByteArrayInputStream(utf32beBom);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, in);

        assertEquals(JsonEncoding.UTF32_BE, bootstrapper.detectEncoding());
    }

    @Test
    void testDetectEncodingWithBOM_UTF32LE() throws IOException {
        IOContext context = mock(IOContext.class);
        byte[] utf32leBom = new byte[]{(byte) 0xFF, (byte) 0xFE, 0x00, 0x00, ' '};
        ByteArrayInputStream in = new ByteArrayInputStream(utf32leBom);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, in);

        assertEquals(JsonEncoding.UTF32_LE, bootstrapper.detectEncoding());
    }

    @Test
    void testDetectEncodingWithoutBOM_UTF8() throws IOException {
        IOContext context = mock(IOContext.class);
        byte[] utf8Data = new byte[]{' ', ' ', ' ', ' '};
        ByteArrayInputStream in = new ByteArrayInputStream(utf8Data);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, in);

        assertEquals(JsonEncoding.UTF8, bootstrapper.detectEncoding());
    }

    @Test
    void testDetectEncodingWithUTF16BEContent() throws IOException {
        IOContext context = mock(IOContext.class);
        byte[] utf16beData = new byte[]{0x00, 0x61, 0x00, 0x62}; // 'a', 'b' in UTF-16BE
        ByteArrayInputStream in = new ByteArrayInputStream(utf16beData);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, in);

        assertEquals(JsonEncoding.UTF16_BE, bootstrapper.detectEncoding());
    }

    @Test
    void testDetectEncodingWithUTF16LEContent() throws IOException {
        IOContext context = mock(IOContext.class);
        byte[] utf16leData = new byte[]{0x61, 0x00, 0x62, 0x00}; // 'a', 'b' in UTF-16LE
        ByteArrayInputStream in = new ByteArrayInputStream(utf16leData);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, in);

        assertEquals(JsonEncoding.UTF16_LE, bootstrapper.detectEncoding());
    }
}