package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

public class DfpMath_pow_1_1_Test {

//    @Test
//    @DisplayName("pow(x, Integer.MAX_VALUE) correctly computes x raised to the largest positive integer")
//    void TC39_pow_Integer_MAX_VALUE() {
//        // GIVEN
//        DfpField field = new DfpField(20);
//        Dfp x = new Dfp(field, "2.0");
//        int a = Integer.MAX_VALUE;
//
//        // WHEN
//        Dfp result = DfpMath.pow(x, a);
//
//        // THEN
//        Dfp expected = DfpMath.exp(DfpMath.log(x).multiply(new Dfp(field, a)));
//        Assertions.assertEquals(expected, result);
//    }

//    @Test
//    @DisplayName("pow(x, Integer.MIN_VALUE) handles negation overflow and returns 1")
//    void TC40_pow_Integer_MIN_VALUE() {
//        // GIVEN
//        DfpField field = new DfpField(20);
//        Dfp x = new Dfp(field, "2.0");
//        int a = Integer.MIN_VALUE;
//
//        // WHEN
//        Dfp result = DfpMath.pow(x, a);
//
//        // THEN
//        Assertions.assertEquals(field.getOne(), result, "pow(x, Integer.MIN_VALUE) should return 1");
//    }

//    @Test
//    @DisplayName("pow(x, 15) executes multiple loop iterations and returns correct result")
//    void TC41_pow_15() {
//        // GIVEN
//        DfpField field = new DfpField(20);
//        Dfp x = new Dfp(field, "2.0");
//        int a = 15;
//
//        // WHEN
//        Dfp result = DfpMath.pow(x, a);
//
//        // THEN
//        Dfp expected = DfpMath.exp(DfpMath.log(x).multiply(new Dfp(field, a)));
//        Assertions.assertEquals(expected, result);
//    }

//    @Test
//    @DisplayName("pow(x, -2) correctly computes the inverse of x squared")
//    void TC42_pow_neg2() {
//        // GIVEN
//        DfpField field = new DfpField(20);
//        Dfp x = new Dfp(field, "4.0");
//        int a = -2;
//
//        // WHEN
//        Dfp result = DfpMath.pow(x, a);
//
//        // THEN
//        Dfp expected = x.getOne().divide(x.multiply(x));
//        Assertions.assertEquals(expected, result);
//    }

//    @Test
//    @DisplayName("pow(x, -3) correctly computes the inverse of x cubed with odd exponent")
//    void TC43_pow_neg3() {
//        // GIVEN
//        DfpField field = new DfpField(20);
//        Dfp x = new Dfp(field, "3.0");
//        int a = -3;
//
//        // WHEN
//        Dfp result = DfpMath.pow(x, a);
//
//        // THEN
//        Dfp expected = x.getOne().divide(x.multiply(x).multiply(x)).negate();
//        Assertions.assertEquals(expected, result);
//    }
}