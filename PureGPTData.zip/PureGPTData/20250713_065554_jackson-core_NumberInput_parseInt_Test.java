import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class NumberInputTest {

    @Test
    void parseInt_ShouldParseSimplePositiveNumber() {
        assertEquals(123, NumberInput.parseInt("123"));
    }

    @Test
    void parseInt_ShouldParseSimpleNegativeNumber() {
        assertEquals(-456, NumberInput.parseInt("-456"));
    }

    @Test
    void parseInt_ShouldParseZero() {
        assertEquals(0, NumberInput.parseInt("0"));
    }

    @Test
    void parseInt_ShouldHandlePositiveSign() {
        assertEquals(789, NumberInput.parseInt("+789"));
    }

    @Test
    void parseInt_ShouldDefaultToJDKParseIfTooLongNegative() {
        assertEquals(-2147483647, NumberInput.parseInt("-2147483647"));
    }

    @Test
    void parseInt_ShouldDefaultToJDKParseIfTooLongPositive() {
        assertEquals(2147483647, NumberInput.parseInt("2147483647"));
    }

    @Test
    void parseInt_ShouldHandleLeadingZeroes() {
        assertEquals(345, NumberInput.parseInt("0345"));
    }

    @Test
    void parseInt_ShouldHandleInvalidCharacterFallbackToParse() {
        assertThrows(NumberFormatException.class, () -> NumberInput.parseInt("12a34"));
    }

    @Test
    void parseInt_ShouldHandleSingleDigit() {
        assertEquals(8, NumberInput.parseInt("8"));
    }

    @Test
    void parseInt_ShouldHandleEmptyString() {
        assertThrows(NumberFormatException.class, () -> NumberInput.parseInt(""));
    }

    @Test
    void parseInt_ShouldParseUpToNineDigitsPositive() {
        assertEquals(999999999, NumberInput.parseInt("999999999"));
    }

    @Test
    void parseInt_ShouldParseUpToNineDigitsNegative() {
        assertEquals(-999999999, NumberInput.parseInt("-999999999"));
    }

    @Test
    void parseInt_ShouldFailForTenDigitNumberPositive() {
        assertThrows(NumberFormatException.class, () -> NumberInput.parseInt("1000000000"));
    }

    @Test
    void parseInt_ShouldFailForTenDigitNumberNegative() {
        assertThrows(NumberFormatException.class, () -> NumberInput.parseInt("-1000000000"));
    }
}