package org.jfree.chart.util;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class LineUtils_clipLine_0_4_Test {

    @Test
    @DisplayName("Clip line with one endpoint outside and non-finite dx")
    void TC16_clipLine_nonFinite_dx() {
        // GIVEN
        Line2D.Double line = new Line2D.Double(Double.NaN, 10.0, 20.0, 30.0);
        Rectangle2D.Double rect = new Rectangle2D.Double(0.0, 0.0, 100.0, 100.0);

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertFalse(result, "Expected clipLine to return false for non-finite dx.");
        assertEquals(Double.NaN, line.getX1(), "Line's x1 should remain unchanged.");
        assertEquals(10.0, line.getY1(), "Line's y1 should remain unchanged.");
        assertEquals(20.0, line.getX2(), "Line's x2 should remain unchanged.");
        assertEquals(30.0, line.getY2(), "Line's y2 should remain unchanged.");
    }

    @Test
    @DisplayName("Clip line with multiple iterations required for clipping")
    void TC17_clipLine_multiple_iterations() {
        // GIVEN
        Line2D.Double line = new Line2D.Double(-50.0, -50.0, 150.0, 150.0);
        Rectangle2D.Double rect = new Rectangle2D.Double(0.0, 0.0, 100.0, 100.0);

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertTrue(result, "Expected clipLine to return true after multiple iterations.");
        assertEquals(0.0, line.getX1(), 0.0001, "Line's x1 should be clipped to the rectangle's boundary.");
        assertEquals(0.0, line.getY1(), 0.0001, "Line's y1 should be clipped to the rectangle's boundary.");
        assertEquals(100.0, line.getX2(), 0.0001, "Line's x2 should be clipped to the rectangle's boundary.");
        assertEquals(100.0, line.getY2(), 0.0001, "Line's y2 should be clipped to the rectangle's boundary.");
    }

    @Test
    @DisplayName("Clip line with both endpoints exactly on the top and bottom boundaries")
    void TC18_clipLine_endpoints_on_top_bottom() {
        // GIVEN
        Line2D.Double line = new Line2D.Double(50.0, 0.0, 50.0, 100.0);
        Rectangle2D.Double rect = new Rectangle2D.Double(0.0, 0.0, 100.0, 100.0);

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertTrue(result, "Expected clipLine to return true when endpoints are on boundaries.");
        assertEquals(50.0, line.getX1(), 0.0001, "Line's x1 should remain unchanged.");
        assertEquals(0.0, line.getY1(), 0.0001, "Line's y1 should remain unchanged.");
        assertEquals(50.0, line.getX2(), 0.0001, "Line's x2 should remain unchanged.");
        assertEquals(100.0, line.getY2(), 0.0001, "Line's y2 should remain unchanged.");
    }

    @Test
    @DisplayName("Clip line where second clipping modifies the line to be inside the rectangle")
    void TC19_clipLine_multiple_sides_clipping() {
        // GIVEN
        Line2D.Double line = new Line2D.Double(-10.0, 50.0, 150.0, 150.0);
        Rectangle2D.Double rect = new Rectangle2D.Double(0.0, 0.0, 100.0, 100.0);

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertTrue(result, "Expected clipLine to return true after clipping on multiple sides.");
        assertEquals(0.0, line.getX1(), 0.0001, "Line's x1 should be clipped to the rectangle's left boundary.");
        assertEquals(50.0, line.getY1(), 0.0001, "Line's y1 should remain unchanged.");
        assertEquals(100.0, line.getX2(), 0.0001, "Line's x2 should be clipped to the rectangle's right boundary.");
        assertEquals(100.0, line.getY2(), 0.0001, "Line's y2 should be clipped to the rectangle's bottom boundary.");
    }

    @Test
    @DisplayName("Clip line with one endpoint on the top boundary and one outside")
    void TC20_clipLine_endpoint_on_top_outside() {
        // GIVEN
        Line2D.Double line = new Line2D.Double(50.0, 0.0, 150.0, 50.0);
        Rectangle2D.Double rect = new Rectangle2D.Double(0.0, 0.0, 100.0, 100.0);

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertTrue(result, "Expected clipLine to return true after clipping one endpoint.");
        assertEquals(50.0, line.getX1(), 0.0001, "Line's x1 should remain unchanged.");
        assertEquals(0.0, line.getY1(), 0.0001, "Line's y1 should remain on the top boundary.");
        assertEquals(100.0, line.getX2(), 0.0001, "Line's x2 should be clipped to the rectangle's right boundary.");
        assertEquals(50.0, line.getY2(), 0.0001, "Line's y2 should remain unchanged within the rectangle.");
    }
}