// package org.jfree.chart.renderer.category;
// import java.lang.reflect.*;
// import java.io.*;
// import java.util.*;
// 
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.DisplayName;
// import org.mockito.Mockito;
// 
// import java.awt.Graphics2D;
// import java.awt.geom.Rectangle2D;
// import java.awt.geom.Ellipse2D;
// import java.awt.geom.Line2D;
// import java.awt.Paint;
// import java.awt.Stroke;
// import java.awt.Shape;
// import java.awt.geom.Point2D;
// import java.lang.reflect.Method;
// import java.lang.reflect.Field;
// import java.util.Arrays;
// import java.util.List;
// 
// import org.jfree.chart.plot.CategoryPlot;
// import org.jfree.chart.axis.CategoryAxis;
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.data.category.CategoryDataset;
// import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
// 
// import static org.mockito.Mockito.*;
// import static org.junit.jupiter.api.Assertions.*;
// 
// public class BoxAndWhiskerRenderer_drawVerticalItem_1_2_Test {
// 
//     @Test
//     @DisplayName("drawVerticalItem with mean not visible")
//     void TC06_drawVerticalItem_with_mean_not_visible() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = new CategoryItemRendererState();
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
// 
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDataset(0)).thenReturn(dataset);
//         when(dataset.getQ1Value(0, 0)).thenReturn(10);
//         when(dataset.getQ3Value(0, 0)).thenReturn(20);
//         when(dataset.getMaxRegularValue(0, 0)).thenReturn(25);
//         when(dataset.getMinRegularValue(0, 0)).thenReturn(5);
//         when(dataset.getMeanValue(0, 0)).thenReturn(15.0);
//         when(dataset.getMedianValue(0, 0)).thenReturn(15.0);
//         when(dataset.getOutliers(0, 0)).thenReturn(null);
// 
//         // Act
//         BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
//         renderer.setFillBox(true);
//         renderer.setMeanVisible(false);
//         renderer.setMedianVisible(true);
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
// 
//         // Assert
//         verify(g2, never()).fill(any(Ellipse2D.class)); // Mean marker should not be drawn
//         verify(g2, atLeastOnce()).draw(any(Line2D.class)); // Median line should be drawn
//     }
// 
//     @Test
//     @DisplayName("drawVerticalItem with median not visible")
//     void TC07_drawVerticalItem_with_median_not_visible() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = new CategoryItemRendererState();
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
// 
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDataset(0)).thenReturn(dataset);
//         when(dataset.getQ1Value(0, 0)).thenReturn(10);
//         when(dataset.getQ3Value(0, 0)).thenReturn(20);
//         when(dataset.getMaxRegularValue(0, 0)).thenReturn(25);
//         when(dataset.getMinRegularValue(0, 0)).thenReturn(5);
//         when(dataset.getMeanValue(0, 0)).thenReturn(15.0);
//         when(dataset.getMedianValue(0, 0)).thenReturn(15.0);
//         when(dataset.getOutliers(0, 0)).thenReturn(null);
// 
//         // Act
//         BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
//         renderer.setFillBox(true);
//         renderer.setMeanVisible(true);
//         renderer.setMedianVisible(false);
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
// 
//         // Assert
//         verify(g2).fill(any(Rectangle2D.class)); // Box should be filled
//         verify(g2).fill(any(Ellipse2D.class)); // Mean marker should be drawn
//         verify(g2, never()).draw(any(Line2D.class)); // Median line should not be drawn
//     }
// 
//     @Test
//     @DisplayName("drawVerticalItem with outliers exactly on regular bounds")
//     void TC08_drawVerticalItem_outliers_on_regular_bounds() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = new CategoryItemRendererState();
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
// 
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDataset(0)).thenReturn(dataset);
//         when(dataset.getQ1Value(0, 0)).thenReturn(10);
//         when(dataset.getQ3Value(0, 0)).thenReturn(20);
//         when(dataset.getMaxRegularValue(0, 0)).thenReturn(25);
//         when(dataset.getMinRegularValue(0, 0)).thenReturn(5);
//         when(dataset.getMeanValue(0, 0)).thenReturn(15.0);
//         when(dataset.getMedianValue(0, 0)).thenReturn(15.0);
//         List<Double> outliers = Arrays.asList(25.0, 5.0);
//         when(dataset.getOutliers(0, 0)).thenReturn(outliers);
//         when(dataset.getMinOutlier(0, 0)).thenReturn(5.0);
//         when(dataset.getMaxOutlier(0, 0)).thenReturn(25.0);
// 
//         // Act
//         BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
//         renderer.setFillBox(true);
//         renderer.setUseOutlinePaintForWhiskers(false);
//         renderer.setMeanVisible(true);
//         renderer.setMedianVisible(true);
//         renderer.setMaxOutlierVisible(true);
//         renderer.setMinOutlierVisible(true);
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
// 
//         // Assert
//         verify(g2).draw(any(Ellipse2D.class)); // Outliers should be drawn as Ellipse2D
//         verify(g2, never()).drawHighFarOut(anyDouble(), any(Graphics2D.class), anyDouble(), anyDouble());
//         verify(g2, never()).drawLowFarOut(anyDouble(), any(Graphics2D.class), anyDouble(), anyDouble());
//     }
// 
//     @Test
//     @DisplayName("drawVerticalItem with yOutliers list null")
//     void TC09_drawVerticalItem_yOutliers_null() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = new CategoryItemRendererState();
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
// 
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDataset(0)).thenReturn(dataset);
//         when(dataset.getQ1Value(0, 0)).thenReturn(10);
//         when(dataset.getQ3Value(0, 0)).thenReturn(20);
//         when(dataset.getMaxRegularValue(0, 0)).thenReturn(25);
//         when(dataset.getMinRegularValue(0, 0)).thenReturn(5);
//         when(dataset.getMeanValue(0, 0)).thenReturn(15.0);
//         when(dataset.getMedianValue(0, 0)).thenReturn(15.0);
//         when(dataset.getOutliers(0, 0)).thenReturn(null);
// 
//         // Act
//         BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
//         renderer.setFillBox(true);
//         renderer.setMeanVisible(true);
//         renderer.setMedianVisible(true);
//         renderer.setMaxOutlierVisible(true);
//         renderer.setMinOutlierVisible(true);
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
// 
//         // Assert
//         verify(g2, never()).draw(any(Outlier.class)); // No outliers should be drawn
//     }
// 
//     @Test
//     @DisplayName("drawVerticalItem with high far out outliers visible")
//     void TC10_drawVerticalItem_high_far_out_outliers_visible() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = new CategoryItemRendererState();
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
// 
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDataset(0)).thenReturn(dataset);
//         when(dataset.getQ1Value(1, 1)).thenReturn(15);
//         when(dataset.getQ3Value(1, 1)).thenReturn(25);
//         when(dataset.getMaxRegularValue(1, 1)).thenReturn(30);
//         when(dataset.getMinRegularValue(1, 1)).thenReturn(10);
//         when(dataset.getMeanValue(1, 1)).thenReturn(20.0);
//         when(dataset.getMedianValue(1, 1)).thenReturn(20.0);
//         List<Double> outliers = Arrays.asList(35.0, 40.0, 5.0, 3.0);
//         when(dataset.getOutliers(1, 1)).thenReturn(outliers);
//         when(dataset.getMinOutlier(1, 1)).thenReturn(3.0);
//         when(dataset.getMaxOutlier(1, 1)).thenReturn(45.0);
// 
//         // Act
//         BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
//         renderer.setFillBox(true);
//         renderer.setUseOutlinePaintForWhiskers(true);
//         renderer.setMeanVisible(true);
//         renderer.setMedianVisible(true);
//         renderer.setMaxOutlierVisible(true);
//         renderer.setMinOutlierVisible(true);
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1);
// 
//         // Assert
//         verify(renderer, times(1)).drawHighFarOut(anyDouble(), eq(g2), anyDouble(), anyDouble());
//         verify(renderer, times(1)).drawLowFarOut(anyDouble(), eq(g2), anyDouble(), anyDouble());
//         verify(g2, atLeast(2)).draw(any(Ellipse2D.class)); // Multiple outliers drawn
//     }
// }