package org.apache.commons.math3.ode.nonstiff;

import org.apache.commons.math3.ode.ExpandableStatefulODE;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class AdamsBashforthIntegrator_integrate_0_6_Test {

    @Test
    @DisplayName("Integration handles state rescaling correctly")
    void TC26_integrationHandlesStateRescalingCorrectly() throws Exception {
        // GIVEN
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(3, 0.1, 1.0, 1e-5, 1e-5);
        ExpandableStatefulODE equations = createMockExpandableStatefulODE(true);
        double targetTime = 7.0;

        // WHEN
        integrator.integrate(equations, targetTime);

        // THEN
        double[] rescaledState = equations.getCompleteState();
        assertNotNull(rescaledState, "State vectors should not be null after rescaling.");
    }

    @Test
    @DisplayName("Integration completes with all isLastStep flags correctly set")
    void TC27_integrationCompletesWithAllIsLastStepFlagsSet() throws Exception {
        // GIVEN
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(3, 0.1, 1.0, 1e-5, 1e-5);
        ExpandableStatefulODE equations = createMockExpandableStatefulODE(false);
        double targetTime = 5.0;

        // WHEN
        integrator.integrate(equations, targetTime);

        // THEN
        boolean isLastStep = getPrivateIsLastStep(integrator);
        assertTrue(isLastStep, "isLastStep flag should be true after integration completes.");
    }

    @Test
    @DisplayName("Integration handles null ExpandableStatefulODE gracefully")
    void TC28_integrationHandlesNullExpandableStatefulODEGracefully() {
        // GIVEN
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(3, 0.1, 1.0, 1e-5, 1e-5);
        ExpandableStatefulODE equations = null;
        double targetTime = 5.0;

        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> integrator.integrate(equations, targetTime),
                "Integrate should throw NullPointerException when equations is null.");
    }

    @Test
    @DisplayName("Integration handles negative target time for forward integration")
    void TC29_integrationHandlesNegativeTargetTimeForForwardIntegration() throws Exception {
        // GIVEN
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(3, 0.1, 1.0, 1e-5, 1e-5);
        ExpandableStatefulODE equations = createMockExpandableStatefulODEWithTime(5.0);
        double targetTime = -5.0;

        // WHEN
        integrator.integrate(equations, targetTime);

        // THEN
        assertEquals(-5.0, equations.getTime(), 1e-10, "Integration should proceed backward to target time.");
    }

    @Test
    @DisplayName("Integration with high precision target time requiring small step sizes")
    void TC30_integrationWithHighPrecisionTargetTimeRequiringSmallStepSizes() throws Exception {
        // GIVEN
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(3, 0.1, 1.0, 1e-12, 1e-12);
        setHighPrecisionConfigurator(integrator);
        ExpandableStatefulODE equations = createMockExpandableStatefulODEWithTime(0.0);
        double targetTime = 10.0001;

        // WHEN
        integrator.integrate(equations, targetTime);

        // THEN
        assertEquals(10.0001, equations.getTime(), 1e-10, "Integration should reach the target time with high precision.");
    }

    // Helper methods
    private ExpandableStatefulODE createMockExpandableStatefulODE(boolean requiresRescaling) {
        // Simplified mock creation
        ExpandableStatefulODE ode = new ExpandableStatefulODE(null); // Replace null with actual equations
        return ode;
    }

    private ExpandableStatefulODE createMockExpandableStatefulODEWithTime(double time) {
        ExpandableStatefulODE ode = new ExpandableStatefulODE(null);
        try {
            java.lang.reflect.Field timeField = ExpandableStatefulODE.class.getDeclaredField("time");
            timeField.setAccessible(true);
            timeField.setDouble(ode, time);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Failed to set time on ExpandableStatefulODE: " + e.getMessage());
        }
        return ode;
    }

    private boolean getPrivateIsLastStep(AdamsBashforthIntegrator integrator) {
        try {
            java.lang.reflect.Field isLastStepField = AdamsBashforthIntegrator.class.getDeclaredField("isLastStep");
            isLastStepField.setAccessible(true);
            return isLastStepField.getBoolean(integrator);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Failed to access isLastStep field: " + e.getMessage());
            return false;
        }
    }

    private void setHighPrecisionConfigurator(AdamsBashforthIntegrator integrator) {
        try {
            java.lang.reflect.Method setStepSizeControl = AdamsBashforthIntegrator.class.getDeclaredMethod("setStepSizeControl", double.class);
            setStepSizeControl.setAccessible(true);
            setStepSizeControl.invoke(integrator, 1e-6);
        } catch (NoSuchMethodException | IllegalAccessException | java.lang.reflect.InvocationTargetException e) {
            fail("Failed to configure high precision settings: " + e.getMessage());
        }
    }
}
