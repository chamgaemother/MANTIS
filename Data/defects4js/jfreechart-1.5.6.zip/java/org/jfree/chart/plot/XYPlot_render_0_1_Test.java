package org.jfree.chart.plot;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.jfree.chart.util.Args;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class XYPlot_render_0_1_Test {

    @Test
    @DisplayName("Render method returns false when dataset is null")
    public void testRenderWithNullDataset() {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        int index = 0;
        PlotRenderingInfo info = new PlotRenderingInfo(null);
        CrosshairState crosshairState = new CrosshairState();
        XYPlot plot = new XYPlot();
        plot.setDataset(index, null);

        // WHEN
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // THEN
        assertFalse(result, "Expected render method to return false when dataset is null");
    }

    @Test
    @DisplayName("Render method returns false when dataset is empty")
    public void testRenderWithEmptyDataset() {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        int index = 0;
        PlotRenderingInfo info = new PlotRenderingInfo(null);
        CrosshairState crosshairState = new CrosshairState();
        XYPlot plot = new XYPlot();
        XYDataset emptyDataset = mock(XYDataset.class);
        when(emptyDataset.getSeriesCount()).thenReturn(0);
        plot.setDataset(index, emptyDataset);

        // WHEN
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // THEN
        assertFalse(result, "Expected render method to return false when dataset is empty");
    }

    @Test
    @DisplayName("Render method returns true when dataset is present but xAxis is null")
    public void testRenderWithNullXAxis() {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        int index = 0;
        PlotRenderingInfo info = new PlotRenderingInfo(null);
        CrosshairState crosshairState = new CrosshairState();
        XYPlot plot = new XYPlot();
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        plot.setDataset(index, dataset);

        // Setting a null domain axis directly
        plot.setDomainAxis(0, null);
        plot.setRangeAxis(0, mock(ValueAxis.class));

        // WHEN
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // THEN
        assertTrue(result, "Expected render method to return true when dataset is present but xAxis is null");
    }

    @Test
    @DisplayName("Render method returns true when dataset is present but yAxis is null")
    public void testRenderWithNullYAxis() {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        int index = 0;
        PlotRenderingInfo info = new PlotRenderingInfo(null);
        CrosshairState crosshairState = new CrosshairState();
        XYPlot plot = new XYPlot();
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        plot.setDataset(index, dataset);
        plot.setDomainAxis(0, mock(ValueAxis.class));

        // Setting a null range axis directly
        plot.setRangeAxis(0, null);

        // WHEN
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // THEN
        assertTrue(result, "Expected render method to return true when dataset is present but yAxis is null");
    }

    @Test
    @DisplayName("Render method proceeds with rendering when dataset and both axes are present")
    public void testRenderWithCompleteDatasetAndAxes() {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        int index = 0;
        PlotRenderingInfo info = new PlotRenderingInfo(null);
        CrosshairState crosshairState = new CrosshairState();
        XYPlot plot = new XYPlot();
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(2);
        plot.setDataset(index, dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        ValueAxis yAxis = mock(ValueAxis.class);
        plot.setDomainAxis(0, xAxis);
        plot.setRangeAxis(0, yAxis);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        XYItemRendererState rendererState = mock(XYItemRendererState.class);

        // Ensure the renderer is directly set for the test
        plot.setRenderer(index, renderer);

        when(renderer.getPassCount()).thenReturn(1);
        when(renderer.initialise(g2, dataArea, plot, dataset, info)).thenReturn(rendererState);

        // We use the mockito doReturn rather than when due to the mock setup
        when(plot.getSeriesRenderingOrder()).thenReturn(SeriesRenderingOrder.FORWARD);

        // WHEN
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // THEN
        assertTrue(result, "Expected render method to proceed with rendering when dataset and both axes are present");
        verify(renderer, atLeastOnce()).drawItem(any(), any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), any(), anyInt());
    }
}