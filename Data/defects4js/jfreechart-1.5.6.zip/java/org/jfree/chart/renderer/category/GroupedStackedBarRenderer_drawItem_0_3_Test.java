package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class GroupedStackedBarRenderer_drawItem_0_3_Test {

//     @Test
//     @DisplayName("drawItem adds item entity when EntityCollection is present")
//     void TC11() throws Exception {
        // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
//         EntityCollection entities = mock(EntityCollection.class);
// 
//         int row = 0;
//         int column = 0;
//         int pass = 0;
// 
//         when(state.getEntityCollection()).thenReturn(entities);
//         when(dataset.getValue(row, column)).thenReturn(10.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(rangeAxis.isInverted()).thenReturn(false);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(), eq(plot.getRangeAxisEdge()))).thenReturn(50.0);
//         when(state.getBarWidth()).thenReturn(10.0);
// 
//         GroupedStackedBarRenderer renderer = new GroupedStackedBarRenderer();
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
// 
        // Assert
//         ArgumentCaptor<Object> captor = ArgumentCaptor.forClass(Object.class);
//         verify(entities).add(captor.capture());
//         assertNotNull(captor.getValue(), "Entity should be added to EntityCollection");
//     }

    @Test
    @DisplayName("drawItem handles inverted and positive value with VERTICAL orientation")
    void TC12() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 1;
        int column = 1;
        int pass = 1;

        when(dataset.getValue(row, column)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(true);
        when(rangeAxis.valueToJava2D(anyDouble(), any(), eq(plot.getRangeAxisEdge()))).thenReturn(100.0);
        when(state.getBarWidth()).thenReturn(15.0);

        GroupedStackedBarRenderer renderer = new GroupedStackedBarRenderer();

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    @DisplayName("drawItem handles non-inverted axis with negative value in HORIZONTAL orientation")
    void TC13() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 2;
        int column = 2;
        int pass = 2;

        when(dataset.getValue(row, column)).thenReturn(-15.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(anyDouble(), any(), eq(plot.getRangeAxisEdge()))).thenReturn(75.0);
        when(state.getBarWidth()).thenReturn(12.0);

        GroupedStackedBarRenderer renderer = new GroupedStackedBarRenderer();

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        verify(g2, atLeastOnce()).fill(any());
    }

    @Test
    @DisplayName("drawItem handles multiple groups with matching and non-matching group keys")
    void TC14() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 3;
        int column = 3;
        int pass = 3;

        when(dataset.getValue(row, column)).thenReturn(25.0);
        when(dataset.getRowKey(anyInt())).thenReturn("Group1", "Group2", "Group1", "Group3");
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(anyDouble(), any(), eq(plot.getRangeAxisEdge()))).thenReturn(60.0);
        when(state.getBarWidth()).thenReturn(20.0);

        GroupedStackedBarRenderer renderer = spy(new GroupedStackedBarRenderer());

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        verify(renderer, atLeastOnce()).calculateBarW0(any(), any(), any(), any(), any(), anyInt(), anyInt());
    }

    @Test
    @DisplayName("drawItem handles item label visibility based on isItemLabelVisible returning false")
    void TC15() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        EntityCollection entities = mock(EntityCollection.class);

        int row = 4;
        int column = 4;
        int pass = 4;

        when(state.getEntityCollection()).thenReturn(entities);
        when(dataset.getValue(row, column)).thenReturn(30.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(anyDouble(), any(), eq(plot.getRangeAxisEdge()))).thenReturn(90.0);
        when(state.getBarWidth()).thenReturn(18.0);
        when(dataset.getRowKey(anyInt())).thenReturn("Group1", "Group1", "Group2", "Group1", "Group1");

        GroupedStackedBarRenderer renderer = spy(new GroupedStackedBarRenderer());

        // Mock getItemLabelGenerator to return a generator
        CategoryItemLabelGenerator generator = mock(CategoryItemLabelGenerator.class);
        doReturn(generator).when(renderer).getItemLabelGenerator(row, column);
        doReturn(false).when(renderer).isItemLabelVisible(row, column);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        verify(renderer, never()).drawItemLabel(any(), any(), anyInt(), anyInt(), any(), any(), any(), anyBoolean());
    }
}