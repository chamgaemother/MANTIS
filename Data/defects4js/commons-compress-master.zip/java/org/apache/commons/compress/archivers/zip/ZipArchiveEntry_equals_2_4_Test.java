package org.apache.commons.compress.archivers.zip;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import java.lang.reflect.Method;

public class ZipArchiveEntry_equals_2_4_Test {
    @Test
    @DisplayName("equals() returns true when both ZipArchiveEntries have identical localFileDataExtra arrays")
    void TC46_equals_with_identical_localFileDataExtra_arrays() throws Exception {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        byte[] localExtra = {5, 6, 7};
        entry1.setExtra(localExtra);
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        entry2.setExtra(localExtra);
        // WHEN
        boolean result = entry1.equals(entry2);
        // THEN
        assertTrue(result, "equals() should return true when localFileDataExtra arrays are identical");
    }

    @Test
    @DisplayName("equals() returns false when localHeaderOffset differs between ZipArchiveEntries")
    void TC47_equals_with_different_localHeaderOffsets() throws Exception {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        // Use reflection to set protected method setLocalHeaderOffset
        Method setLocalHeaderOffset = ZipArchiveEntry.class.getDeclaredMethod("setLocalHeaderOffset", long.class);
        setLocalHeaderOffset.setAccessible(true);
        setLocalHeaderOffset.invoke(entry1, 100L);
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        setLocalHeaderOffset.invoke(entry2, 200L);
        // WHEN
        boolean result = entry1.equals(entry2);
        // THEN
        assertFalse(result, "equals() should return false when localHeaderOffsets differ");
    }

    @Test
    @DisplayName("equals() returns true when both ZipArchiveEntries have identical localHeaderOffsets")
    void TC48_equals_with_identical_localHeaderOffsets() throws Exception {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        Method setLocalHeaderOffset = ZipArchiveEntry.class.getDeclaredMethod("setLocalHeaderOffset", long.class);
        setLocalHeaderOffset.setAccessible(true);
        setLocalHeaderOffset.invoke(entry1, 100L);
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        setLocalHeaderOffset.invoke(entry2, 100L);
        // WHEN
        boolean result = entry1.equals(entry2);
        // THEN
        assertTrue(result, "equals() should return true when both localHeaderOffsets are identical");
    }

    @Test
    @DisplayName("equals() returns false when dataOffset differs between ZipArchiveEntries")
    void TC49_equals_with_different_dataOffsets() throws Exception {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        Method setDataOffset = ZipArchiveEntry.class.getDeclaredMethod("setDataOffset", long.class);
        setDataOffset.setAccessible(true);
        setDataOffset.invoke(entry1, 300L);
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        setDataOffset.invoke(entry2, 400L);
        // WHEN
        boolean result = entry1.equals(entry2);
        // THEN
        assertFalse(result, "equals() should return false when dataOffsets differ");
    }

    @Test
    @DisplayName("equals() returns true when both ZipArchiveEntries have identical dataOffsets")
    void TC50_equals_with_identical_dataOffsets() throws Exception {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        Method setDataOffset = ZipArchiveEntry.class.getDeclaredMethod("setDataOffset", long.class);
        setDataOffset.setAccessible(true);
        setDataOffset.invoke(entry1, 300L);
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        setDataOffset.invoke(entry2, 300L);
        // WHEN
        boolean result = entry1.equals(entry2);
        // THEN
        assertTrue(result, "equals() should return true when both dataOffsets are identical");
    }
}