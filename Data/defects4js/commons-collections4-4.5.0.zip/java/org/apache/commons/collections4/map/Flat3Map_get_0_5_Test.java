package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class Flat3Map_get_0_5_Test {

    @Test
    @DisplayName("Delegate map is null, key is not null, size=3, no hash matches")
    void TC21_delegateMap_null_key_not_null_size3_noHashMatch() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map map = new Flat3Map();

        // Use reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        // Set key1, key2, key3 with non-matching hash codes
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "key2");

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "key3");

        // Set hash codes to ensure no matches
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, "nonMatchingKey".hashCode() + 1);

        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, "nonMatchingKey".hashCode() + 2);

        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.setInt(map, "nonMatchingKey".hashCode() + 3);

        // Invoke get method
        Object result = map.get("nonMatchingKey");

        // Assert the result is null
        assertNull(result);
    }

    @Test
    @DisplayName("Delegate map is null, key is not null, size greater than 3")
    void TC22_delegateMap_null_key_not_null_sizeGreaterThan3() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map map = new Flat3Map();

        // Use reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 4);

        // Set key1, key2, key3 with arbitrary values
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "key2");

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "key3");

        // Invoke get method with any key
        Object result = map.get("anyKey");

        // Assert the result is null
        assertNull(result);
    }

    @Test
    @DisplayName("Delegate map is null, key is null, size=3 with key2=null and key3 not null")
    void TC23_delegateMap_null_key_null_size3_key2_null_key3_not_null() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map map = new Flat3Map();

        // Use reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        // Set key1, key2, key3
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "value1");

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, null);

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "key3");

        // Set value1, value2, value3
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, "value1");

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, "value2");

        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        value3Field.set(map, "value3");

        // Invoke get method with null key
        Object result = map.get(null);

        // Assert the result equals value2
        assertEquals("value2", result);
    }
}