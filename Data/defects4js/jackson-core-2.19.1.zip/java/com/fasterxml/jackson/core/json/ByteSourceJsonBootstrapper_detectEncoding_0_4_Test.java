package com.fasterxml.jackson.core.json;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.util.BufferRecycler;
import com.fasterxml.jackson.core.util.VersionUtil;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayInputStream;
import java.lang.reflect.Field;

public class ByteSourceJsonBootstrapper_detectEncoding_0_4_Test {

    private ByteSourceJsonBootstrapper initializeBootstrapper(
        byte[] inputBuffer, int _bytesPerChar, boolean _bigEndian) throws Exception {
        IOContext ctxt = new IOContext(new BufferRecycler(), new ByteArrayInputStream(inputBuffer), false);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(ctxt, inputBuffer, 0, inputBuffer.length);

        setPrivateField(bootstrapper, "_bytesPerChar", _bytesPerChar);
        setPrivateField(bootstrapper, "_bigEndian", _bigEndian);

        return bootstrapper;
    }

    private void setPrivateField(Object instance, String fieldName, Object value) throws Exception {
        Field field = instance.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(instance, value);
    }

    @Test
    @DisplayName("switch on _bytesPerChar with value 2 and _bigEndian=true sets encoding to UTF16_BE")
    void TC16() throws Exception {
        ByteSourceJsonBootstrapper bootstrapper = initializeBootstrapper(new byte[]{(byte)0xFE, (byte)0xFF}, 2, true);
        JsonEncoding encoding = bootstrapper.detectEncoding();

        assertEquals(JsonEncoding.UTF16_BE, encoding);
    }

    @Test
    @DisplayName("switch on _bytesPerChar with value 2 and _bigEndian=false sets encoding to UTF16_LE")
    void TC17() throws Exception {
        ByteSourceJsonBootstrapper bootstrapper = initializeBootstrapper(new byte[]{(byte)0xFF, (byte)0xFE}, 2, false);
        JsonEncoding encoding = bootstrapper.detectEncoding();

        assertEquals(JsonEncoding.UTF16_LE, encoding);
    }

    @Test
    @DisplayName("switch on _bytesPerChar with value 4 and _bigEndian=true sets encoding to UTF32_BE")
    void TC18() throws Exception {
        ByteSourceJsonBootstrapper bootstrapper = initializeBootstrapper(new byte[]{0x00, 0x00, (byte)0xFE, (byte)0xFF}, 4, true);
        JsonEncoding encoding = bootstrapper.detectEncoding();

        assertEquals(JsonEncoding.UTF32_BE, encoding);
    }

    @Test
    @DisplayName("switch on _bytesPerChar with value 4 and _bigEndian=false sets encoding to UTF32_LE")
    void TC19() throws Exception {
        ByteSourceJsonBootstrapper bootstrapper = initializeBootstrapper(new byte[]{(byte)0xFF, (byte)0xFE, 0x00, 0x00}, 4, false);
        JsonEncoding encoding = bootstrapper.detectEncoding();

        assertEquals(JsonEncoding.UTF32_LE, encoding);
    }

    @Test
    @DisplayName("switch on _bytesPerChar with invalid value throws internal exception")
    void TC20() throws Exception {
        ByteSourceJsonBootstrapper bootstrapper = initializeBootstrapper(new byte[]{}, 3, false);

        assertThrows(RuntimeException.class, () -> bootstrapper.detectEncoding());
    }
}