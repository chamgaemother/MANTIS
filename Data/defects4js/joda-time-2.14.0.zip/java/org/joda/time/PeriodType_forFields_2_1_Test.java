package org.joda.time;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.Objects;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class PeriodType_forFields_2_1_Test {

    /**
     * Utility method to access the private static cTypes field using reflection.
     */
    private Map<PeriodType, Object> getCache() throws Exception {
        Field cTypesField = PeriodType.class.getDeclaredField("cTypes");
        cTypesField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<PeriodType, Object> cache = (Map<PeriodType, Object>) cTypesField.get(null);
        return cache;
    }

    /**
     * Utility method to clear the cache using reflection.
     */
    private void clearCache() throws Exception {
        Map<PeriodType, Object> cache = getCache();
        cache.clear();
    }

    @Test
    @DisplayName("forFields with a new combination of supported fields not present in cache creates and caches the new PeriodType")
    public void TC16_forFields_NewCombinationCreatesAndCaches() throws Exception {
        // GIVEN
        DurationFieldType[] types = { DurationFieldType.hours(), DurationFieldType.minutes() };
        clearCache();
        Map<PeriodType, Object> cache = getCache();
        assertFalse(cache.containsKey(new PeriodType(null, types, null)), "Cache should not contain the given types combination");
        
        // WHEN
        PeriodType result = PeriodType.forFields(types);
        
        // THEN
        assertTrue(result.isSupported(DurationFieldType.hours()), "Result should support hours");
        assertTrue(result.isSupported(DurationFieldType.minutes()), "Result should support minutes");
        assertFalse(result.isSupported(DurationFieldType.years()), "Result should not support years");
        assertTrue(cache.containsKey(result), "Cache should contain the new PeriodType");
    }

    @Test
    @DisplayName("forFields with supported fields in different order retrieves the correct PeriodType from cache")
    public void TC17_forFields_DifferentOrderRetrievesFromCache() throws Exception {
        // GIVEN
        DurationFieldType[] types1 = { DurationFieldType.minutes(), DurationFieldType.hours() };
        DurationFieldType[] types2 = { DurationFieldType.hours(), DurationFieldType.minutes() };
        PeriodType cachedType = PeriodType.forFields(types1);
        
        // WHEN
        PeriodType result = PeriodType.forFields(types2);
        
        // THEN
        assertSame(cachedType, result, "PeriodType instances should be the same irrespective of the order of fields");
    }

    @Test
    @DisplayName("forFields with types array containing unsupported fields throws IllegalArgumentException")
    public void TC18_forFields_UnsupportedFieldsThrowException() {
        // GIVEN
        DurationFieldType[] types = { DurationFieldType.years(), DurationFieldType.centuries() };
        
        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            PeriodType.forFields(types);
        }, "Expected forFields to throw, but it didn't");
        assertEquals("PeriodType does not support fields: [centuries]", exception.getMessage(), "Exception message should match");
    }

    @Test
    @DisplayName("forFields with all supported fields not cached creates and caches the standard PeriodType")
    public void TC19_forFields_AllSupportedFieldsCreatesStandard() throws Exception {
        // GIVEN
        DurationFieldType[] types = {
            DurationFieldType.years(),
            DurationFieldType.months(),
            DurationFieldType.weeks(),
            DurationFieldType.days(),
            DurationFieldType.hours(),
            DurationFieldType.minutes(),
            DurationFieldType.seconds(),
            DurationFieldType.millis()
        };
        clearCache();
        Map<PeriodType, Object> cache = getCache();
        assertFalse(cache.containsKey(PeriodType.standard()), "Cache should not contain the standard PeriodType");
        
        // WHEN
        PeriodType result = PeriodType.forFields(types);
        
        // THEN
        assertEquals(PeriodType.standard(), result, "Result should be the standard PeriodType");
        assertTrue(cache.containsKey(PeriodType.standard()), "Cache should contain the standard PeriodType");
    }

    @Test
    @DisplayName("forFields with a single unsupported field throws IllegalArgumentException")
    public void TC20_forFields_SingleUnsupportedFieldThrowsException() {
        // GIVEN
        DurationFieldType[] types = { DurationFieldType.weeks(), DurationFieldType.centuries() };
        
        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            PeriodType.forFields(types);
        }, "Expected forFields to throw, but it didn't");
        assertEquals("PeriodType does not support fields: [centuries]", exception.getMessage(), "Exception message should match");
    }

}