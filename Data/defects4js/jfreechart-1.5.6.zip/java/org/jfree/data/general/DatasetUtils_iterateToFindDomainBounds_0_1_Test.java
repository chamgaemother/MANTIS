package org.jfree.data.general;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.mockito.Mockito;
import org.jfree.data.Range;
import org.jfree.data.general.DatasetUtils;
import org.jfree.data.xy.XYDataset;
import java.util.List;
import java.util.Arrays;
import java.util.Collections;

public class DatasetUtils_iterateToFindDomainBounds_0_1_Test {

    @Test
    @DisplayName("Throws IllegalArgumentException when dataset is null")
    public void TC01_null_dataset() {
        // GIVEN
        XYDataset dataset = null;
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        boolean includeInterval = false;

        // WHEN & THEN
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, includeInterval);
        });
    }

    @Test
    @DisplayName("Throws IllegalArgumentException when visibleSeriesKeys is null")
    public void TC02_null_visibleSeriesKeys() {
        // GIVEN
        XYDataset dataset = Mockito.mock(XYDataset.class);
        List<Comparable> visibleSeriesKeys = null;
        boolean includeInterval = false;

        // WHEN & THEN
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, includeInterval);
        });
    }

    @Test
    @DisplayName("Returns null when includeInterval is false and visibleSeriesKeys is empty")
    public void TC03_no_visibleSeriesKeys() {
        // GIVEN
        XYDataset dataset = Mockito.mock(XYDataset.class);
        List<Comparable> visibleSeriesKeys = Collections.emptyList();
        boolean includeInterval = false;

        // WHEN
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        Assertions.assertNull(result);
    }

    @Test
    @DisplayName("Returns null when includeInterval is false and series has no items")
    public void TC04_no_items_in_series() {
        // GIVEN
        XYDataset dataset = Mockito.mock(XYDataset.class);
        Comparable seriesKey = "Series1";
        List<Comparable> visibleSeriesKeys = Arrays.asList(seriesKey);
        Mockito.when(dataset.indexOf(seriesKey)).thenReturn(0);
        Mockito.when(dataset.getItemCount(0)).thenReturn(0);
        boolean includeInterval = false;

        // WHEN
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        Assertions.assertNull(result);
    }

    @Test
    @DisplayName("Returns Range when includeInterval is false and series has valid x values")
    public void TC05_valid_x_values() {
        // GIVEN
        XYDataset dataset = Mockito.mock(XYDataset.class);
        Comparable seriesKey = "Series1";
        List<Comparable> visibleSeriesKeys = Arrays.asList(seriesKey);
        Mockito.when(dataset.indexOf(seriesKey)).thenReturn(0);
        Mockito.when(dataset.getItemCount(0)).thenReturn(2);
        Mockito.when(dataset.getXValue(0, 0)).thenReturn(10.0);
        Mockito.when(dataset.getXValue(0, 1)).thenReturn(20.0);
        boolean includeInterval = false;

        // WHEN
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        Assertions.assertEquals(new Range(10.0, 20.0), result);
    }
}