package org.jfree.chart.ui;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.jfree.chart.ui.LCBLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.lang.reflect.Field;

public class LCBLayout_layoutContainer_1_2_Test {

    @Test
    @DisplayName("layoutContainer does not adjust second column's width when i46 is equal to 1")
    public void TC17_layoutContainer_doesNotAdjustSecondColumnWidthWhen_i46_is_1() throws Exception {
        // Arrange
        LCBLayout layout = new LCBLayout(1);
        Container parent = new Container();

        Component comp1 = new Component() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(100, 50);
            }
        };

        Component comp2 = new Component() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(150, 50);
            }
        };

        Component comp3 = new Component() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(120, 50);
            }
        };

        parent.add(comp1);
        parent.add(comp2);
        parent.add(comp3);
        parent.setSize(300, 200);

        // Act
        layout.layoutContainer(parent);

        // Access colWidth via reflection
        Field colWidthField = LCBLayout.class.getDeclaredField("colWidth");
        colWidthField.setAccessible(true);
        int[] colWidth = (int[]) colWidthField.get(layout);

        // Assert
        Assertions.assertEquals(150, colWidth[1], "The second column's width should remain unchanged at 150");
    }
}