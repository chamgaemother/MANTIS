import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.commons.math3.analysis.differentiation.DSCompiler;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class DSCompilerTest {

    @BeforeEach
    void resetCompilerCache() throws Exception {
        Field compilersField = DSCompiler.class.getDeclaredField("compilers");
        compilersField.setAccessible(true);
        AtomicReference<DSCompiler[][]> compilers =
                (AtomicReference<DSCompiler[][]>) compilersField.get(null);
        compilers.set(null);
    }

    @Test
    @DisplayName("Test getCompiler with parameters=0 and order=0 when cache is null")
    void testGetCompiler_Parameters0_Order0_CacheNull() {
        assertDoesNotThrow(() -> {
            DSCompiler compiler = DSCompiler.getCompiler(0, 0);
            assertNotNull(compiler);
            assertEquals(0, compiler.getFreeParameters());
            assertEquals(0, compiler.getOrder());
            assertEquals(1, compiler.getSize());
            assertEquals(0, compiler.getPartialDerivativeIndex(new int[] {0}));
        });
    }

    @Test
    @DisplayName("Test getCompiler with parameters=1 and order=1 when cache is null")
    void testGetCompiler_Parameters1_Order1_CacheNull() {
        assertDoesNotThrow(() -> {
            DSCompiler compiler = DSCompiler.getCompiler(1, 1);
            assertNotNull(compiler);
            assertEquals(1, compiler.getFreeParameters());
            assertEquals(1, compiler.getOrder());
            assertEquals(2, compiler.getSize());
            assertEquals(0, compiler.getPartialDerivativeIndex(new int[] {0}));
            assertEquals(1, compiler.getPartialDerivativeIndex(new int[] {1}));
        });
    }

    @Test
    @DisplayName("Test getCompiler returns cached compiler")
    void testGetCompiler_CacheHit() throws Exception {
        DSCompiler firstCompiler = DSCompiler.getCompiler(2, 2);
        DSCompiler secondCompiler = DSCompiler.getCompiler(2, 2);
        assertSame(firstCompiler, secondCompiler, "Should return the same cached compiler");
    }

    @Test
    @DisplayName("Test getCompiler creates new compiler when cache miss")
    void testGetCompiler_CacheMiss() throws Exception {
        DSCompiler compiler1 = DSCompiler.getCompiler(1, 1);
        DSCompiler compiler2 = DSCompiler.getCompiler(2, 2);
        assertNotSame(compiler1, compiler2, "Different compilers should be created for different parameters and orders");
    }

    @Test
    @DisplayName("Test getCompiler with parameters=0 and order=1")
    void testGetCompiler_Parameters0_Order1() {
        assertThrows(NumberIsTooLargeException.class, () -> {
            DSCompiler.getCompiler(0, 1);
        });
    }

    @Test
    @DisplayName("Test getCompiler with parameters=1 and order=0")
    void testGetCompiler_Parameters1_Order0() {
        assertDoesNotThrow(() -> {
            DSCompiler compiler = DSCompiler.getCompiler(1, 0);
            assertNotNull(compiler);
            assertEquals(1, compiler.getFreeParameters());
            assertEquals(0, compiler.getOrder());
            assertEquals(1, compiler.getSize());
            assertEquals(0, compiler.getPartialDerivativeIndex(new int[] {0}));
        });
    }

    @Test
    @DisplayName("Test getCompiler with maximum parameters and order")
    void testGetCompiler_MaxParametersAndOrder() {
        assertDoesNotThrow(() -> {
            int parameters = 3;
            int order = 3;
            DSCompiler compiler = DSCompiler.getCompiler(parameters, order);
            assertNotNull(compiler);
            assertEquals(parameters, compiler.getFreeParameters());
            assertEquals(order, compiler.getOrder());
            assertTrue(compiler.getSize() > 0);
        });
    }

    @Test
    @DisplayName("Test getCompiler with negative parameters")
    void testGetCompiler_NegativeParameters() {
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            DSCompiler.getCompiler(-1, 1);
        });
    }

    @Test
    @DisplayName("Test getCompiler with negative order")
    void testGetCompiler_NegativeOrder() {
        assertThrows(NumberIsTooLargeException.class, () -> {
            DSCompiler.getCompiler(1, -1);
        });
    }

    @Test
    @DisplayName("Test getCompiler with both parameters and order as zero")
    void testGetCompiler_Parameters0_Order0_Again() {
        assertDoesNotThrow(() -> {
            DSCompiler compiler = DSCompiler.getCompiler(0, 0);
            assertNotNull(compiler);
            assertEquals(0, compiler.getFreeParameters());
            assertEquals(0, compiler.getOrder());
            assertEquals(1, compiler.getSize());
            assertEquals(0, compiler.getPartialDerivativeIndex(new int[] {0}));
        });
    }
}