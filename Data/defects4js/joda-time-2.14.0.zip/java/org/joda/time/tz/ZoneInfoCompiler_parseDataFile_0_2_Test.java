package org.joda.time.tz;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

public class ZoneInfoCompiler_parseDataFile_0_2_Test {

    @Test
    @DisplayName("parseDataFile throws IllegalArgumentException for incomplete ZONE_LOOKUP tokens")
    void TC06_throwIllegalArgumentExceptionForIncompleteZoneLookup() throws Exception {
        // GIVEN
        BufferedReader in = new BufferedReader(new StringReader("Zone Europe/London"));
        boolean z9 = false;
        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // WHEN & THEN
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            compiler.parseDataFile(in, z9);
        });
        assertEquals("Attempting to create a Zone from an incomplete tokenizer", exception.getMessage());
    }

    @Test
    @DisplayName("parseDataFile processes LINK_LOOKUP token with alias 'WET'")
    void TC07_processLinkLookupWithAliasWET() throws Exception {
        // GIVEN
        BufferedReader in = new BufferedReader(new StringReader("Link RealWET WET"));
        boolean z9 = false;
        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // WHEN
        compiler.parseDataFile(in, z9);

        // THEN
        Field goodLinksField = ZoneInfoCompiler.class.getDeclaredField("iGoodLinks");
        goodLinksField.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<String> iGoodLinks = (List<String>) goodLinksField.get(compiler);
        assertTrue(iGoodLinks.contains("RealWET"));
        assertTrue(iGoodLinks.contains("WET"));
    }

    @Test
    @DisplayName("parseDataFile processes LINK_LOOKUP token alias 'MET' mapping to 'CET'")
    void TC08_processLinkLookupWithAliasMET() throws Exception {
        // GIVEN
        BufferedReader in = new BufferedReader(new StringReader("Link RealMET MET"));
        boolean z9 = false;
        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // WHEN
        compiler.parseDataFile(in, z9);

        // THEN
        Field backLinksField = ZoneInfoCompiler.class.getDeclaredField("iBackLinks");
        backLinksField.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<String> iBackLinks = (List<String>) backLinksField.get(compiler);
        assertTrue(iBackLinks.contains("CET"));
        assertTrue(iBackLinks.contains("MET"));
    }

    @Test
    @DisplayName("parseDataFile processes LINK_LOOKUP token with alias starting with 'Etc/'")
    void TC09_processLinkLookupWithAliasStartingEtc() throws Exception {
        // GIVEN
        BufferedReader in = new BufferedReader(new StringReader("Link RealEtc/UTC Etc/UTC"));
        boolean z9 = true;
        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // WHEN
        compiler.parseDataFile(in, z9);

        // THEN
        Field backLinksField = ZoneInfoCompiler.class.getDeclaredField("iBackLinks");
        backLinksField.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<String> iBackLinks = (List<String>) backLinksField.get(compiler);
        assertTrue(iBackLinks.contains("RealEtc/UTC"));
        assertTrue(iBackLinks.contains("Etc/UTC"));
    }

//     @Test
//     @DisplayName("parseDataFile processes multiple valid lines with mixed tokens")
//     void TC10_processMultipleMixedTokens() throws Exception {
        // GIVEN
//         String input = "Rule summer 1980 2000 - Apr lastSun 2:00 1:00 D\nZone Europe/London GMT0\nLink RealWET WET";
//         BufferedReader in = new BufferedReader(new StringReader(input));
//         boolean z9 = false;
//         ZoneInfoCompiler compiler = new ZoneInfoCompiler();
// 
        // WHEN
//         compiler.parseDataFile(in, z9);
// 
        // THEN
        // Verify iRuleSets
//         Field ruleSetsField = ZoneInfoCompiler.class.getDeclaredField("iRuleSets");
//         ruleSetsField.setAccessible(true);
//         @SuppressWarnings("unchecked")
//         Map<String, ZoneInfoCompiler.RuleSet> iRuleSets = (Map<String, ZoneInfoCompiler.RuleSet>) ruleSetsField.get(compiler);
//         assertTrue(iRuleSets.containsKey("summer"));
// 
        // Verify iZones
//         Field zonesField = ZoneInfoCompiler.class.getDeclaredField("iZones");
//         zonesField.setAccessible(true);
//         @SuppressWarnings("unchecked")
//         List<ZoneInfoCompiler.Zone> iZones = (List<ZoneInfoCompiler.Zone>) zonesField.get(compiler);
//         assertFalse(iZones.isEmpty());
// 
        // Verify iGoodLinks
//         Field goodLinksField = ZoneInfoCompiler.class.getDeclaredField("iGoodLinks");
//         goodLinksField.setAccessible(true);
//         @SuppressWarnings("unchecked")
//         List<String> iGoodLinks = (List<String>) goodLinksField.get(compiler);
//         assertTrue(iGoodLinks.contains("RealWET"));
//         assertTrue(iGoodLinks.contains("WET"));
//     }
}