package org.jfree.chart.plot;

import java.lang.reflect.Field;
import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.jfree.data.Range;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class MeterPlot_draw_2_2_Test {
    @Test
    @DisplayName("Draw method with foregroundAlpha set to 0.5 and dataset value within range")
    public void TC26_draw_with_foregroundAlpha_0_5() throws Exception {
        // GIVEN
        MeterPlot plot = new MeterPlot();
        // Using reflection to set foregroundAlpha if it's not directly accessible
        Field foregroundAlphaField = MeterPlot.class.getDeclaredField("foregroundAlpha");
        foregroundAlphaField.setAccessible(true);
        foregroundAlphaField.set(plot, 0.5f);  // Fix access to the field

        ValueDataset dataset = new DefaultValueDataset(60);
        plot.setDataset(dataset);
        plot.setRange(new Range(0, 100));

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 200);
        Point2D anchor = mock(Point2D.class);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        // WHEN
        plot.draw(g2, area, anchor, state, info);

        // THEN
        // Verifying correct composite setup
        verify(g2).setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
        // Ensure key drawing methods are invoked
        verify(g2, atLeastOnce()).fill(any(Polygon.class));
        verify(g2, atLeastOnce()).fill(any(Ellipse2D.class));
    }
}
