
package com.fasterxml.jackson.core;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.mockito.Mockito;
import static org.mockito.Mockito.*;

public class JsonPointer_forPath_0_3_Test {

    @Test
    @DisplayName("Context is in object with valid property name")
    public void testTC11() throws Exception {
        // GIVEN
        JsonStreamContext context = Mockito.mock(JsonStreamContext.class);
        when(context.inObject()).thenReturn(true);
        when(context.hasPathSegment()).thenReturn(true);
        when(context.getCurrentName()).thenReturn("name");
        when(context.getParent()).thenReturn(null); // Assuming single level

        boolean includeRoot = false;

        // WHEN
        JsonPointer result = JsonPointer.forPath(context, includeRoot);

        // THEN
        Assertions.assertNotNull(result, "Resulting JsonPointer should not be null");
        Assertions.assertTrue(result.toString().contains("/name"), "JsonPointer should include '/name'");
    }

    @Test
    @DisplayName("Context is in object with empty property name")
    public void testTC12() throws Exception {
        // GIVEN
        JsonStreamContext context = Mockito.mock(JsonStreamContext.class);
        when(context.inObject()).thenReturn(true);
        when(context.hasPathSegment()).thenReturn(true);
        when(context.getCurrentName()).thenReturn("");
        when(context.getParent()).thenReturn(null); // Assuming single level

        boolean includeRoot = false;

        // WHEN
        JsonPointer result = JsonPointer.forPath(context, includeRoot);

        // THEN
        Assertions.assertNotNull(result, "Resulting JsonPointer should not be null");
        Assertions.assertTrue(result.toString().contains("/"), "JsonPointer should handle empty property name as '/'");
    }

    @Test
    @DisplayName("Context is in array with multiple indices")
    public void testTC13() throws Exception {
        // GIVEN
        JsonStreamContext context = Mockito.mock(JsonStreamContext.class);
        JsonStreamContext parentContext1 = Mockito.mock(JsonStreamContext.class);
        JsonStreamContext parentContext2 = Mockito.mock(JsonStreamContext.class);

        // Mocking multiple array indices
        when(context.inArray()).thenReturn(true);
        when(context.hasPathSegment()).thenReturn(true);
        when(context.getCurrentIndex()).thenReturn(2);
        when(context.getParent()).thenReturn(parentContext1);

        when(parentContext1.inArray()).thenReturn(true);
        when(parentContext1.hasPathSegment()).thenReturn(true);
        when(parentContext1.getCurrentIndex()).thenReturn(1);
        when(parentContext1.getParent()).thenReturn(parentContext2);

        when(parentContext2.inArray()).thenReturn(true);
        when(parentContext2.hasPathSegment()).thenReturn(true);
        when(parentContext2.getCurrentIndex()).thenReturn(0);
        when(parentContext2.getParent()).thenReturn(null);

        boolean includeRoot = false;

        // WHEN
        JsonPointer result = JsonPointer.forPath(context, includeRoot);

        // THEN
        Assertions.assertNotNull(result, "Resulting JsonPointer should not be null");
        Assertions.assertEquals("/0/1/2", result.toString(), "JsonPointer should include all array indices '/0/1/2'");
    }

    @Test
    @DisplayName("Context within deeply nested objects and arrays with includeRoot=true")
    public void testTC14() throws Exception {
        // GIVEN
        JsonStreamContext context = Mockito.mock(JsonStreamContext.class);
        JsonStreamContext parentContext1 = Mockito.mock(JsonStreamContext.class);
        JsonStreamContext parentContext2 = Mockito.mock(JsonStreamContext.class);
        JsonStreamContext parentContext3 = Mockito.mock(JsonStreamContext.class);

        // Mocking deeply nested structures
        // Leaf context
        when(context.inObject()).thenReturn(true);
        when(context.hasPathSegment()).thenReturn(true);
        when(context.getCurrentName()).thenReturn("element");
        when(context.getParent()).thenReturn(parentContext1);

        // Parent context1: array
        when(parentContext1.inArray()).thenReturn(true);
        when(parentContext1.hasPathSegment()).thenReturn(true);
        when(parentContext1.getCurrentIndex()).thenReturn(3);
        when(parentContext1.getParent()).thenReturn(parentContext2);

        // Parent context2: object
        when(parentContext2.inObject()).thenReturn(true);
        when(parentContext2.hasPathSegment()).thenReturn(true);
        when(parentContext2.getCurrentName()).thenReturn("array");
        when(parentContext2.getParent()).thenReturn(parentContext3);

        // Parent context3: root
        when(parentContext3.inObject()).thenReturn(true);
        when(parentContext3.inRoot()).thenReturn(true);
        when(parentContext3.hasCurrentIndex()).thenReturn(true);
        when(parentContext3.hasPathSegment()).thenReturn(true);
        when(parentContext3.getCurrentName()).thenReturn("root");
        when(parentContext3.getParent()).thenReturn(null);

        boolean includeRoot = true;

        // WHEN
        JsonPointer result = JsonPointer.forPath(context, includeRoot);

        // THEN
        Assertions.assertNotNull(result, "Resulting JsonPointer should not be null");
        Assertions.assertEquals("/root/array/3/element", result.toString(), "JsonPointer should represent the full nested path including root '/root/array/3/element'");
    }

    @Test
    @DisplayName("Context has parent segments leading to EMPTY JsonPointer")
    public void testTC15() throws Exception {
        // GIVEN
        JsonStreamContext context = Mockito.mock(JsonStreamContext.class);
        when(context.hasPathSegment()).thenReturn(true);
        when(context.inObject()).thenReturn(false);
        when(context.inArray()).thenReturn(false);
        when(context.getParent()).thenReturn(null);

        boolean includeRoot = false;

        // WHEN
        JsonPointer result = JsonPointer.forPath(context, includeRoot);

        // THEN
        Assertions.assertSame(JsonPointer.EMPTY, result, "Expected EMPTY JsonPointer to be returned");
    }
}