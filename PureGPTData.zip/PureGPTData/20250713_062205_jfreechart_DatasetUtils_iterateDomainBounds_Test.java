import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

import org.jfree.data.Range;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.Test;

class DatasetUtilsTest {

    @Test
    void testIterateDomainBounds_NullDataset() {
        assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateDomainBounds(null, true);
        });
    }

    @Test
    void testIterateDomainBounds_EmptyDataset() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(0);
        Range result = DatasetUtils.iterateDomainBounds(dataset, true);
        assertNull(result);
    }

    @Test
    void testIterateDomainBounds_SingleValue() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);

        Range result = DatasetUtils.iterateDomainBounds(dataset, false);
        assertEquals(new Range(1.0, 1.0), result);
    }

    @Test
    void testIterateDomainBounds_MultipleValues() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(3.0);

        Range result = DatasetUtils.iterateDomainBounds(dataset, false);
        assertEquals(new Range(1.0, 3.0), result);
    }

    @Test
    void testIterateDomainBounds_IntervalDataset() {
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
        when(dataset.getEndXValue(0, 0)).thenReturn(1.5);
        when(dataset.getXValue(0, 1)).thenReturn(3.0);
        when(dataset.getStartXValue(0, 1)).thenReturn(2.5);
        when(dataset.getEndXValue(0, 1)).thenReturn(3.5);

        Range result = DatasetUtils.iterateDomainBounds(dataset, true);
        assertEquals(new Range(0.5, 3.5), result);

        result = DatasetUtils.iterateDomainBounds(dataset, false);
        assertEquals(new Range(1.0, 3.0), result);
    }

    @Test
    void testIterateDomainBounds_NaNValues() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getXValue(0, 2)).thenReturn(Double.NaN);

        Range result = DatasetUtils.iterateDomainBounds(dataset, false);
        assertEquals(new Range(2.0, 2.0), result);
    }

    @Test
    void testIterateDomainBounds_OnlyNaNValues() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
        when(dataset.getXValue(0, 2)).thenReturn(Double.NaN);

        Range result = DatasetUtils.iterateDomainBounds(dataset, false);
        assertNull(result);
    }
}