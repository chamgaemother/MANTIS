package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class DfpMath_pow_1_2_Test {

    @Test
    @DisplayName("pow(x, 1) correctly returns x without entering loop")
    public void TC44() throws Exception {
        // GIVEN
        DfpField field = new DfpField(20);
        Dfp x = new Dfp(field, "5.0");
        int a = 1;

        // WHEN
        Dfp result = DfpMath.pow(x, a);

        // THEN
        assertEquals(x, result, "pow(x, 1) should return x");
    }

    @Test
    @DisplayName("pow(x, 2) correctly computes x squared through one loop iteration")
    public void TC45() throws Exception {
        // GIVEN
        DfpField field = new DfpField(20);
        Dfp x = new Dfp(field, "3.0");
        int a = 2;

        // WHEN
        Dfp result = DfpMath.pow(x, a);

        // THEN
        Dfp expected = x.multiply(x);
        assertEquals(expected, result, "pow(x, 2) should return x squared");
    }

    @Test
    @DisplayName("pow(x, -1) correctly computes the inverse of x")
    public void TC46() throws Exception {
        // GIVEN
        DfpField field = new DfpField(20);
        Dfp x = new Dfp(field, "4.0");
        int a = -1;

        // WHEN
        Dfp result = DfpMath.pow(x, a);

        // THEN
        Dfp expected = x.getOne().divide(x);
        assertEquals(expected, result, "pow(x, -1) should return the inverse of x");
    }

    @Test
    @DisplayName("pow(x, 16) executes multiple loop iterations and returns x raised to 16")
    public void TC47() throws Exception {
        // GIVEN
        DfpField field = new DfpField(20);
        Dfp x = new Dfp(field, "2.0");
        int a = 16;

        // WHEN
        Dfp result = DfpMath.pow(x, a);

        // THEN
        Dfp expected = DfpMath.exp(DfpMath.log(x).multiply(new Dfp(field, a)));
        assertEquals(expected, result, "pow(x, 16) should return x raised to the 16th power");
    }
}