package org.jfree.chart.renderer.xy;

import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.Test;

public class StackedXYAreaRenderer2Test {

    @Test
    public void testDrawItem_PositiveValue() {
        StackedXYAreaRenderer2 renderer = new StackedXYAreaRenderer2();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        TableXYDataset dataset = mock(TableXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(2.0);
        when(dataset.getItemCount(anyInt())).thenReturn(3);
        when(plot.getOrientation()).thenReturn(XYPlot.DEFAULT_ORIENTATION);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }

    @Test
    public void testDrawItem_NegativeValue() {
        StackedXYAreaRenderer2 renderer = new StackedXYAreaRenderer2();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        TableXYDataset dataset = mock(TableXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(-2.0);
        when(dataset.getItemCount(anyInt())).thenReturn(3);
        when(plot.getOrientation()).thenReturn(XYPlot.DEFAULT_ORIENTATION);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 1, crosshairState, 0);
    }

    @Test
    public void testDrawItem_ZeroValue() {
        StackedXYAreaRenderer2 renderer = new StackedXYAreaRenderer2();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        TableXYDataset dataset = mock(TableXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(0.0);
        when(dataset.getItemCount(anyInt())).thenReturn(3);
        when(plot.getOrientation()).thenReturn(XYPlot.DEFAULT_ORIENTATION);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 2, 1, crosshairState, 0);
    }

    @Test
    public void testDrawItem_NaNValue() {
        StackedXYAreaRenderer2 renderer = new StackedXYAreaRenderer2();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        TableXYDataset dataset = mock(TableXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(Double.NaN);
        when(dataset.getItemCount(anyInt())).thenReturn(3);
        when(plot.getOrientation()).thenReturn(XYPlot.DEFAULT_ORIENTATION);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 3, 1, crosshairState, 0);
    }
}