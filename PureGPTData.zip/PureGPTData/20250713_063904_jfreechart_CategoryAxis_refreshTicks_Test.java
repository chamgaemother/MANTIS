import static org.junit.jupiter.api.Assertions.*;

import org.jfree.chart.axis.*;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.chart.util.ShapeUtils;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.text.TextBlock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

class CategoryAxisTest {

    private CategoryAxis axis;
    private Graphics2D g2;
    private AxisState state;
    private Rectangle2D dataArea;

    @BeforeEach
    void setUp() {
        axis = new CategoryAxis();
        g2 = Mockito.mock(Graphics2D.class);
        state = new AxisState();
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
    }

    @Test
    void testRefreshTicksWithNullDataArea() {
        ArrayList<?> ticks = new ArrayList<>();
        assertEquals(ticks, axis.refreshTicks(g2, state, new Rectangle2D.Double(0, 0, -1, -1), RectangleEdge.BOTTOM));
        assertEquals(ticks, axis.refreshTicks(g2, state, new Rectangle2D.Double(0, 0, 100, -1), RectangleEdge.BOTTOM));
    }

    @Test
    void testRefreshTicksWithEmptyCategories() {
        CategoryPlot plot = Mockito.mock(CategoryPlot.class);
        Mockito.when(plot.getCategoriesForAxis(axis)).thenReturn(null);
        axis.setPlot(plot);

        java.util.List<?> ticks = axis.refreshTicks(g2, state, dataArea, RectangleEdge.BOTTOM);
        assertTrue(ticks.isEmpty());
    }

    @Test
    void testRefreshTicksWithTopEdge() {
        validateTicksForEdge(RectangleEdge.TOP);
    }

    @Test
    void testRefreshTicksWithBottomEdge() {
        validateTicksForEdge(RectangleEdge.BOTTOM);
    }

    @Test
    void testRefreshTicksWithLeftEdge() {
        validateTicksForEdge(RectangleEdge.LEFT);
    }

    @Test
    void testRefreshTicksWithRightEdge() {
        validateTicksForEdge(RectangleEdge.RIGHT);
    }

    private void validateTicksForEdge(RectangleEdge edge) {
        CategoryPlot plot = new CategoryPlot();
        axis.setPlot(plot);

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(1.0, "Row 1", "Column 1");
        dataset.addValue(2.0, "Row 2", "Column 2");
        plot.setDataset(dataset);
        
        Mockito.when(g2.getFontMetrics()).thenReturn(new FontMetrics(new Font("Serif", Font.PLAIN, 12)) {});
        
        java.util.List<?> ticks = axis.refreshTicks(g2, state, dataArea, edge);
        assertNotNull(ticks);
    }
}