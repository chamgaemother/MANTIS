package com.fasterxml.jackson.core.json;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer;
import com.fasterxml.jackson.core.util.TextBuffer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import static org.junit.jupiter.api.Assertions.*;

class ReaderBasedJsonParserTest {

    private ReaderBasedJsonParser createParser(String json) throws IOException {
        IOContext ctxt = new IOContext(null, null, true);
        Reader reader = new StringReader(json);
        ObjectCodec codec = null;
        CharsToNameCanonicalizer sym = CharsToNameCanonicalizer.builder().build();
        return new ReaderBasedJsonParser(ctxt, 0, reader, codec, sym);
    }

    @Test
    void testNextToken_ObjectStart() throws IOException {
        ReaderBasedJsonParser parser = createParser("{");
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_ArrayStart() throws IOException {
        ReaderBasedJsonParser parser = createParser("[");
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        assertEquals(JsonToken.END_ARRAY, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_StringValue() throws IOException {
        ReaderBasedJsonParser parser = createParser("\"value\"");
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_NumberValue_Int() throws IOException {
        ReaderBasedJsonParser parser = createParser("123");
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(123, parser.getIntValue());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_NumberValue_Float() throws IOException {
        ReaderBasedJsonParser parser = createParser("123.45");
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, parser.nextToken());
        assertEquals(123.45, parser.getDoubleValue());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_BooleanValue_True() throws IOException {
        ReaderBasedJsonParser parser = createParser("true");
        assertEquals(JsonToken.VALUE_TRUE, parser.nextToken());
        assertTrue(parser.getBooleanValue());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_BooleanValue_False() throws IOException {
        ReaderBasedJsonParser parser = createParser("false");
        assertEquals(JsonToken.VALUE_FALSE, parser.nextToken());
        assertFalse(parser.getBooleanValue());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_NullValue() throws IOException {
        ReaderBasedJsonParser parser = createParser("null");
        assertEquals(JsonToken.VALUE_NULL, parser.nextToken());
        assertNull(parser.getValueAsString());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_FieldName() throws IOException {
        ReaderBasedJsonParser parser = createParser("{\"name\": \"value\"}");
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("name", parser.getCurrentName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_NestedObject() throws IOException {
        ReaderBasedJsonParser parser = createParser("{\"name\": {\"inner\": \"value\"}}");
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("name", parser.getCurrentName());
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("inner", parser.getCurrentName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_NestedArray() throws IOException {
        ReaderBasedJsonParser parser = createParser("[1, [2, 3], 4]");
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(1, parser.getIntValue());
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(2, parser.getIntValue());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(3, parser.getIntValue());
        assertEquals(JsonToken.END_ARRAY, parser.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(4, parser.getIntValue());
        assertEquals(JsonToken.END_ARRAY, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_InvalidJSON_UnquotedField() throws IOException {
        ReaderBasedJsonParser parser = createParser("{name: \"value\"}");
        Exception exception = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(exception.getMessage().contains("was expecting double-quote to start field name"));
    }

    @Test
    void testNextToken_TrailingComma_Object() throws IOException {
        ReaderBasedJsonParser parser = createParser("{\"name\": \"value\",}");
        parser._features |= ReaderBasedJsonParser.FEAT_MASK_TRAILING_COMMA;
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("name", parser.getCurrentName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_TrailingComma_Array() throws IOException {
        ReaderBasedJsonParser parser = createParser("[1,2,]");
        parser._features |= ReaderBasedJsonParser.FEAT_MASK_TRAILING_COMMA;
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(1, parser.getIntValue());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(2, parser.getIntValue());
        assertEquals(JsonToken.END_ARRAY, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_EOF() throws IOException {
        ReaderBasedJsonParser parser = createParser("");
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_FieldNameWithEscape() throws IOException {
        ReaderBasedJsonParser parser = createParser("{\"na\\\"me\": \"value\"}");
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("na\"me", parser.getCurrentName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_SingleQuotes() throws IOException {
        ReaderBasedJsonParser parser = createParser("{'name': 'value'}");
        parser._features |= ReaderBasedJsonParser.FEAT_MASK_ALLOW_SINGLE_QUOTES;
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("name", parser.getCurrentName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_LeadingZero() throws IOException {
        ReaderBasedJsonParser parser = createParser("0123");
        Exception exception = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(exception.getMessage().contains("expected digit"));
    }

    @Test
    void testNextToken_EmptyObject() throws IOException {
        ReaderBasedJsonParser parser = createParser("{}");
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_EmptyArray() throws IOException {
        ReaderBasedJsonParser parser = createParser("[]");
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        assertEquals(JsonToken.END_ARRAY, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_MultipleValuesInRoot() throws IOException {
        ReaderBasedJsonParser parser = createParser("true false null");
        assertEquals(JsonToken.VALUE_TRUE, parser.nextToken());
        assertEquals(JsonToken.VALUE_FALSE, parser.nextToken());
        assertEquals(JsonToken.VALUE_NULL, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_UnexpectedCharacter() throws IOException {
        ReaderBasedJsonParser parser = createParser("@");
        JsonParseException exception = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(exception.getMessage().contains("expected a valid value"));
    }

    @Test
    void testNextToken_Comment() throws IOException {
        ReaderBasedJsonParser parser = createParser("{\"name\": /* comment */ \"value\"}");
        parser._features |= ReaderBasedJsonParser.FEAT_MASK_ALLOW_JAVA_COMMENTS;
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("name", parser.getCurrentName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_YAMLComment() throws IOException {
        ReaderBasedJsonParser parser = createParser("{\"name\": # comment\n\"value\"}");
        parser._features |= ReaderBasedJsonParser.FEAT_MASK_ALLOW_YAML_COMMENTS;
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("name", parser.getCurrentName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_NonNumericNaN() throws IOException {
        ReaderBasedJsonParser parser = createParser("NaN");
        parser._features |= ReaderBasedJsonParser.FEAT_MASK_NON_NUM_NUMBERS;
        assertEquals(JsonToken.VALUE_EMBEDDED_OBJECT, parser.nextToken());
        assertTrue(Double.isNaN((Double) parser.getEmbeddedObject()));
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_NonNumericInfinity() throws IOException {
        ReaderBasedJsonParser parser = createParser("Infinity");
        parser._features |= ReaderBasedJsonParser.FEAT_MASK_NON_NUM_NUMBERS;
        assertEquals(JsonToken.VALUE_EMBEDDED_OBJECT, parser.nextToken());
        assertEquals(Double.POSITIVE_INFINITY, parser.getEmbeddedObject());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_NonStandardNumberWithoutFeature() throws IOException {
        ReaderBasedJsonParser parser = createParser("NaN");
        Exception exception = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(exception.getMessage().contains("Non-standard token 'NaN'"));
    }

    @Test
    void testNextToken_NumberWithPlusSign() throws IOException {
        ReaderBasedJsonParser parser = createParser("+123");
        parser._features |= ReaderBasedJsonParser.FEAT_MASK_ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS;
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(123, parser.getIntValue());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_NumberWithPlusSignNotAllowed() throws IOException {
        ReaderBasedJsonParser parser = createParser("+123");
        Exception exception = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(exception.getMessage().contains("JSON spec does not allow numbers to have plus signs"));
    }

    @Test
    void testNextToken_FloatStartingWithDot() throws IOException {
        ReaderBasedJsonParser parser = createParser(".123");
        parser._features |= ReaderBasedJsonParser.FEAT_MASK_ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS;
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, parser.nextToken());
        assertEquals(0.123, parser.getDoubleValue());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_FloatStartingWithDotNotAllowed() throws IOException {
        ReaderBasedJsonParser parser = createParser(".123");
        Exception exception = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(exception.getMessage().contains("expected a valid numeric value"));
    }

    @Test
    void testNextToken_FloatWithTrailingDotAllowed() throws IOException {
        ReaderBasedJsonParser parser = createParser("123.");
        parser._features |= ReaderBasedJsonParser.FEAT_MASK_ALLOW_TRAILING_DECIMAL_POINT_FOR_NUMBERS;
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, parser.nextToken());
        assertEquals(123.0, parser.getDoubleValue());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_FloatWithTrailingDotNotAllowed() throws IOException {
        ReaderBasedJsonParser parser = createParser("123.");
        Exception exception = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(exception.getMessage().contains("Decimal point not followed by a digit"));
    }

    @Test
    void testNextToken_BinaryValue() throws IOException {
        ReaderBasedJsonParser parser = createParser("\"SGVsbG8=\""); // "Hello" in base64
        parser.nextToken();
        byte[] binary = parser.getBinaryValue(com.fasterxml.jackson.core.Base64Variants.getDefaultVariant());
        assertArrayEquals("Hello".getBytes(), binary);
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_IncompleteString() throws IOException {
        ReaderBasedJsonParser parser = createParser("\"value");
        Exception exception = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(exception.getMessage().contains("was expecting closing quote for a string value"));
    }

    @Test
    void testNextToken_InvalidEscapeInString() throws IOException {
        ReaderBasedJsonParser parser = createParser("\"val\\xue\"");
        Exception exception = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(exception.getMessage().contains("invalid escape sequence"));
    }

    @Test
    void testNextToken_UnexpectedEndInNumber() throws IOException {
        ReaderBasedJsonParser parser = createParser("123.4");
        parser._inputEnd = 5; // Simulate end after '4'
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, parser.nextToken());
        assertEquals(123.4, parser.getDoubleValue());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_MultipleFields() throws IOException {
        ReaderBasedJsonParser parser = createParser("{\"a\":1,\"b\":2,\"c\":3}");
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("a", parser.getCurrentName());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(1, parser.getIntValue());

        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("b", parser.getCurrentName());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(2, parser.getIntValue());

        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("c", parser.getCurrentName());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(3, parser.getIntValue());

        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    void testNextToken_MissingValue() throws IOException {
        ReaderBasedJsonParser parser = createParser("{\"a\":}");
        parser._features |= ReaderBasedJsonParser.FEAT_MASK_ALLOW_MISSING;
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("a", parser.getCurrentName());
        assertEquals(JsonToken.VALUE_NULL, parser.nextToken());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }
}