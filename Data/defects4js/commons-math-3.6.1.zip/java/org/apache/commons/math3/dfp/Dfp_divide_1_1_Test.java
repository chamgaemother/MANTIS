
package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Constructor;

public class Dfp_divide_1_1_Test {

    @Test
    @DisplayName("Division of a finite negative dividend by a positive finite divisor resulting in a negative finite quotient")
    public void testTC06_divideNegativeDividendByPositiveDivisor() throws Exception {
        // Initialize DfpField with radix digits=10
        DfpField field = new DfpField(10);

        // Access the protected constructor of Dfp using reflection
        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, double.class);
        constructor.setAccessible(true);

        // Create dividend and divisor instances
        Dfp dividend = constructor.newInstance(field, -100.0);
        Dfp divisor = constructor.newInstance(field, 25.0);

        // Perform division
        Dfp result = dividend.divide(divisor);

        // Assert the result
        assertEquals(-4.0, result.toDouble(), 1e-10, "Quotient should be -4.0");
    }

    @Test
    @DisplayName("Division where a finite dividend less than divisor results in zero due to truncation")
    public void testTC07_divideFiniteDividendLessThanDivisor() throws Exception {
        // Initialize DfpField with radix digits=10
        DfpField field = new DfpField(10);

        // Access the protected constructor of Dfp using reflection
        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, double.class);
        constructor.setAccessible(true);

        // Create dividend and divisor instances
        Dfp dividend = constructor.newInstance(field, 1.0);
        Dfp divisor = constructor.newInstance(field, 100.0);

        // Perform division
        Dfp result = dividend.divide(divisor);

        // Assert the result
        assertTrue(result.isZero(), "Quotient should be zero");
    }

    @Test
    @DisplayName("Division where dividend is zero and divisor is negative finite resulting in negative zero")
    public void testTC08_divideZeroByNegativeDivisor() throws Exception {
        // Initialize DfpField with radix digits=10
        DfpField field = new DfpField(10);

        // Access the protected constructor of Dfp using reflection
        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, double.class);
        constructor.setAccessible(true);

        // Create dividend and divisor instances
        Dfp dividend = constructor.newInstance(field, 0.0);
        Dfp divisor = constructor.newInstance(field, -50.0);

        // Perform division
        Dfp result = dividend.divide(divisor);

        // Assert the result is zero
        assertTrue(result.isZero(), "Quotient should be zero");

        // Assert the sign of zero is negative
        assertEquals(Double.doubleToLongBits(-0.0), Double.doubleToLongBits(result.toDouble()), "Quotient should be negative zero");
    }

    @Test
    @DisplayName("Division with dividend as the smallest positive finite value and divisor as one, verifying boundary precision")
    public void testTC09_divideSmallestPositiveByOne() throws Exception {
        // Initialize DfpField with radix digits=10
        DfpField field = new DfpField(10);

        // Access the protected constructor of Dfp using reflection
        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, double.class);
        constructor.setAccessible(true);

        // Create dividend as the smallest positive finite value and divisor as one
        Dfp dividend = constructor.newInstance(field, Double.MIN_VALUE);
        Dfp divisor = field.getOne();

        // Perform division
        Dfp result = dividend.divide(divisor);

        // Assert the result equals the dividend
        assertEquals(dividend.toDouble(), result.toDouble(), 1e-20, "Quotient should equal dividend");
    }

    @Test
    @DisplayName("Division where both dividend and divisor are negative finite resulting in a positive quotient")
    public void testTC10_divideNegativeDividendByNegativeDivisor() throws Exception {
        // Initialize DfpField with radix digits=10
        DfpField field = new DfpField(10);

        // Access the protected constructor of Dfp using reflection
        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, double.class);
        constructor.setAccessible(true);

        // Create dividend and divisor instances
        Dfp dividend = constructor.newInstance(field, -100.0);
        Dfp divisor = constructor.newInstance(field, -25.0);

        // Perform division
        Dfp result = dividend.divide(divisor);

        // Assert the result is positive finite
        assertEquals(4.0, result.toDouble(), 1e-10, "Quotient should be 4.0");
    }

}