package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class BarRenderer_drawItem_0_7_Test {
    @Test
    @DisplayName("drawItem handles dataset with single column and single row")
    void TC32_drawItem_withSingleColumnAndRow() throws Exception {
        // Arrange
        BarRenderer renderer = new BarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 50, 50);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(5);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(renderer.getMinimumBarLength()).thenReturn(0.0);
        when(renderer.getShadowsVisible()).thenReturn(false);
        when(renderer.isItemLabelVisible(0, 0)).thenReturn(false);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        // Assert
        // Verify that one bar is drawn
        verify(g2, times(1)).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("drawItem handles dataset with zero columns and zero rows")
    void TC33_drawItem_withEmptyDataset() throws Exception {
        // Arrange
        BarRenderer renderer = new BarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 0, 0);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        when(state.getVisibleSeriesIndex(anyInt())).thenReturn(-1);
        when(dataset.getRowCount()).thenReturn(0);
        when(dataset.getColumnCount()).thenReturn(0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        // Assert
        // Verify that no drawing operations are performed
        verify(g2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("drawItem handles dataset with extremely large values")
    void TC34_drawItem_withExtremelyLargeValues() throws Exception {
        // Arrange
        BarRenderer renderer = new BarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 1000, 1000);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(Double.MAX_VALUE);
        when(dataset.getValue(0, 1)).thenReturn(Double.MIN_VALUE);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(renderer.getMinimumBarLength()).thenReturn(1.0);
        when(renderer.getShadowsVisible()).thenReturn(true);
        when(renderer.isItemLabelVisible(0, 0)).thenReturn(false);
        when(renderer.isItemLabelVisible(0, 1)).thenReturn(false);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 1);

        // Assert
        // Verify that bars are drawn without rendering issues
        verify(g2, atLeast(2)).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("drawItem handles dataset with NaN values gracefully")
    void TC35_drawItem_withNaNValues() throws Exception {
        // Arrange
        BarRenderer renderer = new BarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        // First value is valid, second is NaN
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(state.getVisibleSeriesIndex(1)).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(2);
        when(dataset.getColumnCount()).thenReturn(2);
        when(dataset.getValue(0, 0)).thenReturn(10);
        when(dataset.getValue(0, 1)).thenReturn(Double.NaN);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(renderer.getMinimumBarLength()).thenReturn(0.0);
        when(renderer.getShadowsVisible()).thenReturn(false);
        when(renderer.isItemLabelVisible(0, 0)).thenReturn(false);
        when(renderer.isItemLabelVisible(0, 1)).thenReturn(false);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 1);

        // Assert
        // Verify that only the valid bar is drawn
        verify(g2, times(1)).draw(any(Rectangle2D.class));
    }
}