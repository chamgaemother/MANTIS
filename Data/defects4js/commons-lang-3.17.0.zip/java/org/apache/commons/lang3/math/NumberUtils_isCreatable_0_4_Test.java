package org.apache.commons.lang3.math;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.math.NumberUtils;

public class NumberUtils_isCreatable_0_4_Test {

    @Test
    @DisplayName("isCreatable(\"0x\") returns false when hexadecimal prefix is incomplete")
    void TC16() {
        // GIVEN
        String input = "0x";
        
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        
        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("isCreatable(\"078\") returns false for invalid octal digit '8'")
    void TC17() {
        // GIVEN
        String input = "078";
        
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        
        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("isCreatable(\"+0X1F\") returns true for uppercase hexadecimal prefix")
    void TC18() {
        // GIVEN
        String input = "+0X1F";
        
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        
        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("isCreatable(\"-0\") returns true for negative zero integer")
    void TC19() {
        // GIVEN
        String input = "-0";
        
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        
        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("isCreatable(\"1E10\") returns true for uppercase exponent")
    void TC20() {
        // GIVEN
        String input = "1E10";
        
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        
        // THEN
        assertTrue(result);
    }
}