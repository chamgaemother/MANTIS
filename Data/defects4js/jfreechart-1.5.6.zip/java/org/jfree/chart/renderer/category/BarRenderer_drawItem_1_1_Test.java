import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
// package org.jfree.chart.renderer.category;
// // 
// // import static org.mockito.ArgumentMatchers.any;
// // import static org.mockito.ArgumentMatchers.eq;
// // import static org.mockito.Mockito.doReturn;
// // import static org.mockito.Mockito.mock;
// // import static org.mockito.Mockito.spy;
// // import static org.mockito.Mockito.times;
// // import static org.mockito.Mockito.verify;
// // import static org.mockito.Mockito.when;
// // 
// // import java.awt.Graphics2D;
// // import java.awt.geom.Rectangle2D;
// // 
// // import org.jfree.chart.axis.CategoryAxis;
// // import org.jfree.chart.axis.ValueAxis;
// // import org.jfree.chart.plot.CategoryPlot;
// // import org.jfree.chart.plot.PlotOrientation;
// // import org.jfree.data.category.CategoryDataset;
// // import org.junit.jupiter.api.DisplayName;
// // import org.junit.jupiter.api.Test;
// // 
// public class BarRenderer_drawItem_1_1_Test {
// // 
// //     @Test
// //     @DisplayName("TC16: drawItem handles value equal to base correctly")
// //     public void TC16_drawItemValueEqualsBase() throws Exception {
//         // GIVEN
// //         BarRenderer renderer = new BarRenderer();
// //         Graphics2D g2 = mock(Graphics2D.class);
// //         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
// //         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
// //         CategoryPlot plot = mock(CategoryPlot.class);
// //         CategoryAxis domainAxis = mock(CategoryAxis.class);
// //         ValueAxis rangeAxis = mock(ValueAxis.class);
// //         CategoryDataset dataset = mock(CategoryDataset.class);
// //         int row = 0;
// //         int column = 0;
// // 
// //         when(state.getVisibleSeriesIndex(row)).thenReturn(0);
// //         when(dataset.getValue(row, column)).thenReturn(0.0); // value equals base
// //         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// //         when(rangeAxis.isInverted()).thenReturn(false);
// // 
//         // Spy on renderer to mock protected methods
// //         BarRenderer spyRenderer = spy(renderer);
// //         doReturn(new double[] {0.0, 0.0}).when(spyRenderer).calculateBarL0L1(0.0);
// // 
//         // WHEN
// //         spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
// // 
//         // THEN
// //         verify(spyRenderer.getBarPainter(), times(1)).paintBar(any(Graphics2D.class), eq(spyRenderer), eq(row), eq(column), any(Rectangle2D.class), any());
// //     }
// // 
// //     @Test
// //     @DisplayName("TC17: drawItem handles value slightly above base with non-inverted axis")
// //     public void TC17_drawItemValueSlightlyAboveBaseNonInverted() throws Exception {
//         // GIVEN
// //         BarRenderer renderer = new BarRenderer();
// //         Graphics2D g2 = mock(Graphics2D.class);
// //         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
// //         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
// //         CategoryPlot plot = mock(CategoryPlot.class);
// //         CategoryAxis domainAxis = mock(CategoryAxis.class);
// //         ValueAxis rangeAxis = mock(ValueAxis.class);
// //         CategoryDataset dataset = mock(CategoryDataset.class);
// //         int row = 1;
// //         int column = 1;
// // 
// //         when(state.getVisibleSeriesIndex(row)).thenReturn(row);
// //         when(dataset.getValue(row, column)).thenReturn(0.1); // slightly above base
// //         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// //         when(rangeAxis.isInverted()).thenReturn(false);
// //         when(state.getBarWidth()).thenReturn(10.0);
// // 
//         // Spy on renderer to mock protected methods
// //         BarRenderer spyRenderer = spy(renderer);
// //         doReturn(new double[] {0.0, 0.1}).when(spyRenderer).calculateBarL0L1(0.1);
// // 
//         // WHEN
// //         spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
// // 
//         // THEN
// //         verify(spyRenderer.getBarPainter(), times(1)).paintBar(any(Graphics2D.class), eq(spyRenderer), eq(row), eq(column), any(Rectangle2D.class), any());
// //     }
// // 
// //     @Test
// //     @DisplayName("TC18: drawItem handles value slightly below base with non-inverted axis")
// //     public void TC18_drawItemValueSlightlyBelowBaseNonInverted() throws Exception {
//         // GIVEN
// //         BarRenderer renderer = new BarRenderer();
// //         Graphics2D g2 = mock(Graphics2D.class);
// //         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
// //         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
// //         CategoryPlot plot = mock(CategoryPlot.class);
// //         CategoryAxis domainAxis = mock(CategoryAxis.class);
// //         ValueAxis rangeAxis = mock(ValueAxis.class);
// //         CategoryDataset dataset = mock(CategoryDataset.class);
// //         int row = 2;
// //         int column = 2;
// // 
// //         when(state.getVisibleSeriesIndex(row)).thenReturn(row);
// //         when(dataset.getValue(row, column)).thenReturn(-0.1); // slightly below base
// //         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// //         when(rangeAxis.isInverted()).thenReturn(false);
// //         when(state.getBarWidth()).thenReturn(10.0);
// // 
//         // Spy on renderer to mock protected methods
// //         BarRenderer spyRenderer = spy(renderer);
// //         doReturn(new double[] {-0.1, 0.0}).when(spyRenderer).calculateBarL0L1(-0.1);
// // 
//         // WHEN
// //         spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
// // 
//         // THEN
// //         verify(spyRenderer.getBarPainter(), times(1)).paintBar(any(Graphics2D.class), eq(spyRenderer), eq(row), eq(column), any(Rectangle2D.class), any());
// //     }
// // 
// //     @Test
// //     @DisplayName("TC19: drawItem handles positive value with inverted range axis")
// //     public void TC19_drawItemPositiveValueInvertedAxis() throws Exception {
//         // GIVEN
// //         BarRenderer renderer = new BarRenderer();
// //         Graphics2D g2 = mock(Graphics2D.class);
// //         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
// //         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
// //         CategoryPlot plot = mock(CategoryPlot.class);
// //         CategoryAxis domainAxis = mock(CategoryAxis.class);
// //         ValueAxis rangeAxis = mock(ValueAxis.class);
// //         CategoryDataset dataset = mock(CategoryDataset.class);
// //         int row = 3;
// //         int column = 3;
// // 
// //         when(state.getVisibleSeriesIndex(row)).thenReturn(row);
// //         when(dataset.getValue(row, column)).thenReturn(20.0); // positive value
// //         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// //         when(rangeAxis.isInverted()).thenReturn(true);
// //         when(state.getBarWidth()).thenReturn(10.0);
// // 
//         // Spy on renderer to mock protected methods
// //         BarRenderer spyRenderer = spy(renderer);
// //         doReturn(new double[] {0.0, 20.0}).when(spyRenderer).calculateBarL0L1(20.0);
// // 
//         // WHEN
// //         spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
// // 
//         // THEN
// //         verify(spyRenderer.getBarPainter(), times(1)).paintBar(any(Graphics2D.class), eq(spyRenderer), eq(row), eq(column), any(Rectangle2D.class), any());
// //     }
// // 
// //     @Test
// //     @DisplayName("TC20: drawItem handles negative value with inverted range axis")
// //     public void TC20_drawItemNegativeValueInvertedAxis() throws Exception {
//         // GIVEN
// //         BarRenderer renderer = new BarRenderer();
// //         Graphics2D g2 = mock(Graphics2D.class);
// //         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
// //         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
// //         CategoryPlot plot = mock(CategoryPlot.class);
// //         CategoryAxis domainAxis = mock(CategoryAxis.class);
// //         ValueAxis rangeAxis = mock(ValueAxis.class);
// //         CategoryDataset dataset = mock(CategoryDataset.class);
// //         int row = 4;
// //         int column = 4;
// // 
// //         when(state.getVisibleSeriesIndex(row)).thenReturn(row);
// //         when(dataset.getValue(row, column)).thenReturn(-20.0); // negative value
// //         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// //         when(rangeAxis.isInverted()).thenReturn(true);
// //         when(state.getBarWidth()).thenReturn(10.0);
// // 
//         // Spy on renderer to mock protected methods
// //         BarRenderer spyRenderer = spy(renderer);
// //         doReturn(new double[] {-20.0, 0.0}).when(spyRenderer).calculateBarL0L1(-20.0);
// // 
//         // WHEN
// //         spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
// // 
//         // THEN
// //         verify(spyRenderer.getBarPainter(), times(1)).paintBar(any(Graphics2D.class), eq(spyRenderer), eq(row), eq(column), any(Rectangle2D.class), any());
// //     }
// // 
// // }
// }