package org.jfree.chart.renderer.xy;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;

public class GradientXYBarPainter_paintBar_0_3_Test {

    @Test
    @DisplayName("paintBar with non-Color and non-GradientPaint having non-zero alpha and RectangleEdge.TOP with outline paint present")
    void TC11_paintBar_with_nonColor_nonGradientPaint_nonZeroAlpha_topEdge_withOutline() {
        // Arrange
        GradientXYBarPainter painter = new GradientXYBarPainter();
        Graphics2D g2 = mock(Graphics2D.class);
        XYBarRenderer renderer = mock(XYBarRenderer.class);
        int row = 0;
        int column = 0;
        Rectangle2D bar = new Rectangle2D.Double(0, 0, 10, 20);
        RectangleEdge base = RectangleEdge.TOP;

        Paint customPaint = mock(Paint.class);
        when(renderer.getItemPaint(row, column)).thenReturn(customPaint);
        // Assuming customPaint has alpha != 0
        when(((Color) customPaint).getAlpha()).thenReturn(255);
        when(renderer.isDrawBarOutline()).thenReturn(true);

        Stroke outlineStroke = mock(Stroke.class);
        Paint outlinePaint = mock(Paint.class);
        when(renderer.getItemOutlineStroke(row, column)).thenReturn(outlineStroke);
        when(renderer.getItemOutlinePaint(row, column)).thenReturn(outlinePaint);

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        // Verify that g2.setPaint was called with GradientPaint instances
        verify(g2, times(4)).setPaint(ArgumentMatchers.any(GradientPaint.class));
        verify(g2, times(4)).fill(ArgumentMatchers.any(Rectangle2D.class));
        // Verify that outline was drawn
        verify(g2).setStroke(outlineStroke);
        verify(g2).setPaint(outlinePaint);
        verify(g2).draw(bar);
    }

    @Test
    @DisplayName("paintBar with Color paint having non-zero alpha and RectangleEdge.RIGHT with outline stroke and paint present")
    void TC12_paintBar_with_ColorPaint_nonZeroAlpha_rightEdge_withOutline() {
        // Arrange
        GradientXYBarPainter painter = new GradientXYBarPainter();
        Graphics2D g2 = mock(Graphics2D.class);
        XYBarRenderer renderer = mock(XYBarRenderer.class);
        int row = 1;
        int column = 1;
        Rectangle2D bar = new Rectangle2D.Double(10, 10, 15, 25);
        RectangleEdge base = RectangleEdge.RIGHT;

        Color colorPaint = new Color(0, 0, 255, 255);
        when(renderer.getItemPaint(row, column)).thenReturn(colorPaint);
        when(renderer.isDrawBarOutline()).thenReturn(true);

        Stroke outlineStroke = mock(Stroke.class);
        Paint outlinePaint = mock(Paint.class);
        when(renderer.getItemOutlineStroke(row, column)).thenReturn(outlineStroke);
        when(renderer.getItemOutlinePaint(row, column)).thenReturn(outlinePaint);

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        // Verify that g2.setPaint was called with GradientPaint instances
        verify(g2, times(4)).setPaint(ArgumentMatchers.any(GradientPaint.class));
        verify(g2, times(4)).fill(ArgumentMatchers.any(Rectangle2D.class));
        // Verify that outline was drawn
        verify(g2).setStroke(outlineStroke);
        verify(g2).setPaint(outlinePaint);
        verify(g2).draw(bar);
    }
}