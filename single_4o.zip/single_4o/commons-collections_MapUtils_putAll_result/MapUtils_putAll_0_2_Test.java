package org.apache.commons.collections4;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.apache.commons.collections4.MapUtils;
import org.junit.jupiter.api.Assertions;
import java.util.HashMap;
import java.util.IllegalFormatException;
import java.util.Map;

public class MapUtils_putAll_0_2_Test {

    @Test
    @DisplayName("Verify exception with null map")
    void testVerifyExceptionWithNullMap() {
        Object[] array = {"key1", "value1", "key2", "value2"};

        Assertions.assertThrows(NullPointerException.class, () -> {
            MapUtils.putAll(null, array);
        });
    }

    @Test
    @DisplayName("Verify map updated with basic key-value pairs")
    void testVerifyMapUpdatedWithBasicKeyValuePairs() {
        Map<String, String> map = new HashMap<>();
        Object[] array = {"key1", "value1", "key2", "value2"};

        MapUtils.putAll(map, array);

        Assertions.assertAll(
            () -> Assertions.assertEquals(2, map.size()),
            () -> Assertions.assertEquals("value1", map.get("key1")),
            () -> Assertions.assertEquals("value2", map.get("key2"))
        );
    }

    @Test
    @DisplayName("Verify exception for invalid Object[] elements")
    void testVerifyExceptionForInvalidObjectElements() {
        Map<String, String> map = new HashMap<>();
        Object[] array = { new Object[] { "key1" } }; // Invalid entry

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            MapUtils.putAll(map, array);
        });
    }

    @Test
    @DisplayName("Verify empty map remains empty when array is empty")
    void testVerifyEmptyMapRemainsEmptyWhenArrayIsEmpty() {
        Map<String, String> map = new HashMap<>();
        Object[] array = {};

        Map<String, String> result = MapUtils.putAll(map, array);

        Assertions.assertTrue(result.isEmpty());
    }

    @Test
    @DisplayName("Verify no update for heterogeneous types in array")
    void testVerifyNoUpdateForHeterogeneousTypesInArray() {
        Map<String, String> map = new HashMap<>();
        map.put("existingKey", "existingValue");
        Object[] array = { "key1", 100, true }; // Heterogeneous types

        Map<String, String> result = MapUtils.putAll(map, array);

        Assertions.assertEquals(1, result.size());
        Assertions.assertEquals("existingValue", result.get("existingKey"));
    }
}