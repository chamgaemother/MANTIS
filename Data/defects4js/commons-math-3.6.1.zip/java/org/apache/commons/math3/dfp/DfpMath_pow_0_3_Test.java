package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class DfpMath_pow_0_3_Test {

    @Test
    @DisplayName("pow(-0, y) returns +Infinity when y is even integer < 0")
    public void TC11() {
        // Initialize Dfp x as -0
        DfpField field = new DfpField(20); // The precision must match the Dfp implementation
        Dfp x = new Dfp(field, "-0.0");

        // Initialize Dfp y as an even negative integer
        Dfp y = new Dfp(field, "-2"); // Example of an even negative integer

        // Invoke DfpMath.pow(x, y)
        Dfp result = DfpMath.pow(x, y);

        // Assert that the result is +Infinity
        assertTrue(result.isInfinite(), "Result should be infinite");
        assertEquals(1, result.signum(), "Result sign should be positive");
    }

    @Test
    @DisplayName("pow(x, +Infinity) returns +Infinity when x > 1")
    public void TC12() {
        // Initialize Dfp x > 1
        DfpField field = new DfpField(20);
        Dfp x = new Dfp(field, "2.0");

        // Initialize Dfp y as +Infinity
        Dfp y = field.getOne().newInstance((byte)1, Dfp.INFINITE);

        // Invoke DfpMath.pow(x, y)
        Dfp result = DfpMath.pow(x, y);

        // Assert that the result equals y (+Infinity)
        assertTrue(result.isInfinite(), "Result should be +Infinity");
    }

    @Test
    @DisplayName("pow(x, +Infinity) returns +0 when 0 < x < 1")
    public void TC13() {
        // Initialize Dfp x between 0 and 1
        DfpField field = new DfpField(20);
        Dfp x = new Dfp(field, "0.5");

        // Initialize Dfp y as +Infinity
        Dfp y = field.getOne().newInstance((byte)1, Dfp.INFINITE);

        // Invoke DfpMath.pow(x, y)
        Dfp result = DfpMath.pow(x, y);

        // Assert that the result is +0
        assertEquals(0, result.getReal(), "Result should be +0");
    }

    @Test
    @DisplayName("pow(x, -Infinity) returns +0 when x > 1")
    public void TC14() {
        // Initialize Dfp x > 1
        DfpField field = new DfpField(20);
        Dfp x = new Dfp(field, "2.0");

        // Initialize Dfp y as -Infinity
        Dfp y = field.getOne().newInstance((byte)-1, Dfp.INFINITE);

        // Invoke DfpMath.pow(x, y)
        Dfp result = DfpMath.pow(x, y);

        // Assert that the result is +0
        assertEquals(0, result.getReal(), "Result should be +0");
    }

    @Test
    @DisplayName("pow(x, -Infinity) returns +Infinity when 0 < x < 1")
    public void TC15() {
        // Initialize Dfp x between 0 and 1
        DfpField field = new DfpField(20);
        Dfp x = new Dfp(field, "0.5");

        // Initialize Dfp y as -Infinity
        Dfp y = field.getOne().newInstance((byte)-1, Dfp.INFINITE);

        // Invoke DfpMath.pow(x, y)
        Dfp result = DfpMath.pow(x, y);

        // Assert that the result is +Infinity
        assertTrue(result.isInfinite(), "Result should be infinite");
        assertEquals(1, result.signum(), "Result sign should be positive");
    }
}
