package org.apache.commons.codec.language;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Nysiis_nysiis_0_3_Test {

    @Test
    @DisplayName("nysiis with string containing EV replaces EV with AF")
    void TC11() {
        // GIVEN
        String input = "EVANS";
        Nysiis nysiis = new Nysiis();

        // WHEN
        String result = nysiis.encode(input);

        // THEN
        assertTrue(result.contains("AF"), "Result should contain 'AF'");
    }

    @Test
    @DisplayName("nysiis with string containing Q replaces Q with G")
    void TC12() {
        // GIVEN
        String input = "QUINN";
        Nysiis nysiis = new Nysiis();

        // WHEN
        String result = nysiis.encode(input);

        // THEN
        assertTrue(result.contains("G"), "Result should contain 'G'");
    }

    @Test
    @DisplayName("nysiis with string containing Z replaces Z with S")
    void TC13() {
        // GIVEN
        String input = "ZELDA";
        Nysiis nysiis = new Nysiis();

        // WHEN
        String result = nysiis.encode(input);

        // THEN
        assertTrue(result.contains("S"), "Result should contain 'S'");
    }

    @Test
    @DisplayName("nysiis with string containing M replaces M with N")
    void TC14() {
        // GIVEN
        String input = "MASON";
        Nysiis nysiis = new Nysiis();

        // WHEN
        String result = nysiis.encode(input);

        // THEN
        assertTrue(result.contains("N"), "Result should contain 'N'");
    }

    @Test
    @DisplayName("nysiis removes trailing S from key")
    void TC15() {
        // GIVEN
        String input = "DUNNIS";
        Nysiis nysiis = new Nysiis();

        // WHEN
        String result = nysiis.encode(input);

        // THEN
        assertFalse(result.endsWith("S"), "Result should not end with 'S'");
    }

}