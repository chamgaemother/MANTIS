package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.csv.QuoteMode;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class CSVFormat_toString_0_2_Test {

    @Test
    @DisplayName("toString() with commentMarker unset")
    void TC06() {
        // GIVEN
        CSVFormat format = CSVFormat.DEFAULT
                .builder()
                .setDelimiter(',')
                .setEscape('\\') // Fixed: Use double backslash for a single character
                .setQuote('"')
                .setQuoteMode(QuoteMode.MINIMAL)
                .setCommentMarker(null)
                .build();

        // WHEN
        String result = format.toString();

        // THEN
        assertTrue(result.contains("Delimiter=<,>"), "Delimiter should be <,>");
        assertTrue(result.contains("Escape=<\\>"), "Escape character should be <\\>");
        assertTrue(result.contains("QuoteChar=<\">") ,"Quote character should be <\">");
        assertTrue(result.contains("QuoteMode=<MINIMAL>"), "QuoteMode should be <MINIMAL>");
        assertFalse(result.contains("CommentStart=<"), "CommentStart should be unset");
    }

    @Test
    @DisplayName("toString() with nullString set")
    void TC07() {
        // GIVEN
        CSVFormat format = CSVFormat.DEFAULT
                .builder()
                .setDelimiter(',')
                .setNullString("NULL")
                .build();

        // WHEN
        String result = format.toString();

        // THEN
        assertTrue(result.contains("Delimiter=<,>"), "Delimiter should be <,>");
        assertTrue(result.contains("NullString=<NULL>"), "NullString should be <NULL>");
    }

    @Test
    @DisplayName("toString() with recordSeparator set")
    void TC08() {
        // GIVEN
        CSVFormat format = CSVFormat.DEFAULT
                .builder()
                .setDelimiter(',')
                .setRecordSeparator("\n")
                .build();

        // WHEN
        String result = format.toString();

        // THEN
        assertTrue(result.contains("Delimiter=<,>"), "Delimiter should be <,>");
        assertTrue(result.contains("RecordSeparator=<\n>"), "RecordSeparator should be <\n>");
    }

    @Test
    @DisplayName("toString() with ignoreEmptyLines enabled")
    void TC09() {
        // GIVEN
        CSVFormat format = CSVFormat.DEFAULT
                .builder()
                .setDelimiter(',')
                .setIgnoreEmptyLines(true)
                .build();

        // WHEN
        String result = format.toString();

        // THEN
        assertTrue(result.contains("EmptyLines:ignored"), "EmptyLines should be ignored");
    }

    @Test
    @DisplayName("toString() with ignoreSurroundingSpaces enabled")
    void TC10() {
        // GIVEN
        CSVFormat format = CSVFormat.DEFAULT
                .builder()
                .setDelimiter(',')
                .setIgnoreSurroundingSpaces(true)
                .build();

        // WHEN
        String result = format.toString();

        // THEN
        assertTrue(result.contains("SurroundingSpaces:ignored"), "SurroundingSpaces should be ignored");
    }
}