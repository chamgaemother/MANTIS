package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class UTF32Reader_read_2_1_Test {

    @Test
    @DisplayName("read() with _tmpBuf initially null and read(_tmpBuf, 0, 1) returns a character")
    void testTC16() throws Exception {
        // Arrange
        IOContext context = new IOContext(null, null, false);
        byte[] data = {0x00, 0x00, 0x00, 0x41}; // Represents 'A'
        ByteArrayInputStream in = new ByteArrayInputStream(data);
        UTF32Reader reader = new UTF32Reader(context, in, data, 0, data.length, true);

        // Use reflection to set _tmpBuf to null
        Field tmpBufField = UTF32Reader.class.getDeclaredField("_tmpBuf");
        tmpBufField.setAccessible(true);
        tmpBufField.set(reader, null);

        // Act
        int result = reader.read();

        // Assert
        assertEquals(65, result); // 'A' has ASCII value 65
    }

    @Test
    @DisplayName("read() with _tmpBuf initially null and read(_tmpBuf, 0, 1) returns -1")
    void testTC17() throws Exception {
        // Arrange
        IOContext context = new IOContext(null, null, false);
        byte[] data = new byte[0]; // Empty InputStream to simulate EOF
        ByteArrayInputStream in = new ByteArrayInputStream(data);
        UTF32Reader reader = new UTF32Reader(context, in, data, 0, data.length, true);

        // Use reflection to set _tmpBuf to null
        Field tmpBufField = UTF32Reader.class.getDeclaredField("_tmpBuf");
        tmpBufField.setAccessible(true);
        tmpBufField.set(reader, null);

        // Act
        int result = reader.read();

        // Assert
        assertEquals(-1, result);
    }

    @Test
    @DisplayName("read() with _tmpBuf already initialized and read(_tmpBuf, 0, 1) returns a character")
    void testTC18() throws Exception {
        // Arrange
        IOContext context = new IOContext(null, null, false);
        byte[] data = {0x00, 0x00, 0x00, 0x42}; // Represents 'B'
        ByteArrayInputStream in = new ByteArrayInputStream(data);
        UTF32Reader reader = new UTF32Reader(context, in, data, 0, data.length, true);

        // Use reflection to initialize _tmpBuf with a new char[1]
        Field tmpBufField = UTF32Reader.class.getDeclaredField("_tmpBuf");
        tmpBufField.setAccessible(true);
        tmpBufField.set(reader, new char[1]);

        // Act
        int result = reader.read();

        // Assert
        assertEquals(66, result); // 'B' has ASCII value 66
    }

    @Test
    @DisplayName("read() with _tmpBuf already initialized and read(_tmpBuf, 0, 1) returns -1")
    void testTC19() throws Exception {
        // Arrange
        IOContext context = new IOContext(null, null, false);
        byte[] data = new byte[0]; // Empty InputStream to simulate EOF
        ByteArrayInputStream in = new ByteArrayInputStream(data);
        UTF32Reader reader = new UTF32Reader(context, in, data, 0, data.length, true);

        // Use reflection to initialize _tmpBuf with a new char[1]
        Field tmpBufField = UTF32Reader.class.getDeclaredField("_tmpBuf");
        tmpBufField.setAccessible(true);
        tmpBufField.set(reader, new char[1]);

        // Act
        int result = reader.read();

        // Assert
        assertEquals(-1, result);
    }
}