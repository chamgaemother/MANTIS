import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider;
import com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup;
import com.fasterxml.jackson.dataformat.xml.util.TypeUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import javax.xml.namespace.QName;
import java.io.IOException;

public class XmlSerializerProviderTest {

    private XmlMapper xmlMapper;
    private XmlSerializerProvider xmlSerializerProvider;
    private ToXmlGenerator xmlGenerator;

    @BeforeEach
    void setUp() throws IOException {
        xmlMapper = new XmlMapper();
        xmlSerializerProvider = new XmlSerializerProvider(new XmlRootNameLookup());
        xmlGenerator = mock(ToXmlGenerator.class);
        when(xmlGenerator.getStaxWriter()).thenReturn(mock(com.ctc.wstx.stax.WstxOutputFactory.class));
        doNothing().when(xmlGenerator).initGenerator();
    }

    @Test
    void testSerializePolymorphicNullValue() throws IOException {
        xmlSerializerProvider.serializePolymorphic(xmlGenerator, null, null, null, null);
        verify(xmlGenerator, times(1)).initGenerator();
        verify(xmlGenerator, times(1)).writeStartObject();
        verify(xmlGenerator, times(1)).writeEndObject();
    }

    @Test
    void testSerializePolymorphicIncompatibleType() {
        Exception e = assertThrows(JsonMappingException.class, () -> {
            JavaType incompatibleType = xmlMapper.constructType(Integer.class);
            xmlSerializerProvider.serializePolymorphic(xmlGenerator, "string", incompatibleType, null, null);
        });
        assertTrue(e.getMessage().contains("Incompatible types"));
    }

    @Test
    void testSerializePolymorphicValidRootName() throws IOException {
        JavaType rootType = xmlMapper.constructType(String.class);
        when(xmlGenerator.setNextNameIfMissing(any())).thenReturn(true);
        xmlSerializerProvider.serializePolymorphic(xmlGenerator, "test", rootType, null, mock(TypeSerializer.class));
        verify(xmlGenerator, times(1)).initGenerator();
    }

    @Test
    void testSerializePolymorphicWithRootTypeNull() throws IOException {
        Object value = "Test String";
        when(xmlGenerator.setNextNameIfMissing(any())).thenReturn(true);
        when(xmlGenerator.inRoot()).thenReturn(false);

        xmlSerializerProvider.serializePolymorphic(xmlGenerator, value, null, null, mock(TypeSerializer.class));
        verify(xmlGenerator, times(1)).initGenerator();
    }

    @Test
    void testSerializePolymorphicWithContainerType() throws IOException {
        JavaType containerType = xmlMapper.getTypeFactory()
                .constructCollectionType(java.util.List.class, String.class);
        JsonSerializer<Object> serializer = mock(JsonSerializer.class);
        xmlSerializerProvider.serializePolymorphic(xmlGenerator, java.util.Arrays.asList("item1", "item2"), containerType, serializer, mock(TypeSerializer.class));
        verify(serializer, times(1)).serializeWithType(any(), eq(xmlGenerator), eq(xmlSerializerProvider), any());
    }

    @Test
    void testSerializePolymorphicToggleRootFlag() throws Exception {
        Object value = "Test String";
        JavaType rootType = xmlMapper.constructType(String.class);
        JsonSerializer<Object> serializer = mock(JsonSerializer.class);
        when(xmlGenerator.setNextNameIfMissing(any())).thenReturn(false);
        when(xmlGenerator.inRoot()).thenReturn(true);
        xmlSerializerProvider.serializePolymorphic(xmlGenerator, value, rootType, serializer, mock(TypeSerializer.class));
        verify(xmlGenerator, times(1)).setNextName(new QName("Test String"));
    }

    @Test
    void testSerializePolymorphicThrowsIOException() throws Exception {
        Object value = "Test String";
        JsonSerializer<Object> serializer = mock(JsonSerializer.class);
        doThrow(IOException.class).when(serializer).serializeWithType(value, xmlGenerator, xmlSerializerProvider, mock(TypeSerializer.class));
        assertThrows(IOException.class, () -> {
            xmlSerializerProvider.serializePolymorphic(xmlGenerator, value, null, serializer, mock(TypeSerializer.class));
        });
    }
}