package org.apache.commons.math3.analysis.interpolation;

import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NoDataException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TricubicSplineInterpolator_interpolate_0_5_Test {

    @Test
    @DisplayName("Interpolate with varying fval data to ensure data integrity")
    public void TC21_interpolate_varying_fval_data() throws Exception {
        // Given
        double[] xval = {1.0, 1.5, 2.0};
        double[] yval = {1.0, 1.5, 2.0};
        double[] zval = {1.0, 1.5, 2.0};
        double[][][] fval = { 
            { {1,2,3}, {4,5,6}, {7,8,9} }, 
            { {10,11,12}, {13,14,15}, {16,17,18} }, 
            { {19,20,21}, {22,23,24}, {25,26,27} } 
        };

        // When
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();
        TricubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, zval, fval);

        // Then
        assertNotNull(result, "The interpolating function should not be null.");
        // Example assertion: Verify a specific interpolated value
        double interpolatedValue = result.value(1.5, 1.5, 1.5);
        assertEquals(14.0, interpolatedValue, 1e-6, "Interpolated value should accurately reflect fval patterns.");
    }

    @Test
    @DisplayName("Interpolate with non-uniform spacing in xval, yval, zval arrays")
    public void TC22_interpolate_non_uniform_spacing_arrays() throws Exception {
        // Given
        double[] xval = {1.0, 1.2, 1.5, 2.0};
        double[] yval = {1.0, 1.3, 1.7, 2.5};
        double[] zval = {1.0, 1.4, 2.2, 3.0};
        double[][][] fval = { 
            { {1,2,3,4}, {5,6,7,8}, {9,10,11,12}, {13,14,15,16} },
            { {17,18,19,20}, {21,22,23,24}, {25,26,27,28}, {29,30,31,32} },
            { {33,34,35,36}, {37,38,39,40}, {41,42,43,44}, {45,46,47,48} },
            { {49,50,51,52}, {53,54,55,56}, {57,58,59,60}, {61,62,63,64} }
        };

        // When
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();
        TricubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, zval, fval);

        // Then
        assertNotNull(result, "The interpolating function should not be null.");
        // Example assertion: Verify interpolation at a non-uniform point
        double interpolatedValue = result.value(1.3, 1.7, 2.2);
        assertEquals(27.0, interpolatedValue, 1e-6, "Interpolated value should handle non-uniform spacing correctly.");
    }
}