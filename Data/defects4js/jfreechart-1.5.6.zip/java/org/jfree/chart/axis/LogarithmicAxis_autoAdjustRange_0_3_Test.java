package org.jfree.chart.axis;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.jfree.chart.plot.ValueAxisPlot;
import org.jfree.data.Range;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class LogarithmicAxis_autoAdjustRange_0_3_Test {

    @Test
    @DisplayName("TC11: autoAdjustRange ensures minimum range size by adjusting upper and lower bounds")
    void TC11_autoAdjustRange_enforces_minimum_range_size() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Axis");
        Method setAutoRangeMinimumSize = LogarithmicAxis.class.getMethod("setAutoRangeMinimumSize", double.class);
        setAutoRangeMinimumSize.setAccessible(true);
        setAutoRangeMinimumSize.invoke(axis, 5.0);

        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        Method setPlot = LogarithmicAxis.class.getMethod("setPlot", ValueAxisPlot.class);
        setPlot.setAccessible(true);
        setPlot.invoke(axis, mockPlot);

        Range mockRange = new Range(10.0, 12.0);
        when(mockPlot.getDataRange(axis)).thenReturn(mockRange);

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Method getRange = LogarithmicAxis.class.getMethod("getRange");
        getRange.setAccessible(true);
        Range adjustedRange = (Range) getRange.invoke(axis);
        assertTrue(adjustedRange.getLength() >= 5.0, "Range should be adjusted to meet minimum size");
    }

    @Test
    @DisplayName("TC12: autoAdjustRange adjusts range without modifying bounds when margins are zero and no minRange adjustment needed")
    void TC12_autoAdjustRange_without_margins_and_no_min_range_adjustment() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Axis");
        Method setLowerMargin = LogarithmicAxis.class.getMethod("setLowerMargin", double.class);
        setLowerMargin.setAccessible(true);
        setLowerMargin.invoke(axis, 0.0);

        Method setUpperMargin = LogarithmicAxis.class.getMethod("setUpperMargin", double.class);
        setUpperMargin.setAccessible(true);
        setUpperMargin.invoke(axis, 0.0);

        Method setAutoRangeMinimumSize = LogarithmicAxis.class.getMethod("setAutoRangeMinimumSize", double.class);
        setAutoRangeMinimumSize.setAccessible(true);
        setAutoRangeMinimumSize.invoke(axis, 5.0);

        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        Method setPlot = LogarithmicAxis.class.getMethod("setPlot", ValueAxisPlot.class);
        setPlot.setAccessible(true);
        setPlot.invoke(axis, mockPlot);

        Range mockRange = new Range(10.0, 20.0);
        when(mockPlot.getDataRange(axis)).thenReturn(mockRange);

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Method getRange = LogarithmicAxis.class.getMethod("getRange");
        getRange.setAccessible(true);
        Range adjustedRange = (Range) getRange.invoke(axis);
        assertEquals(10.0, adjustedRange.getLowerBound(), "Lower bound should remain unchanged");
        assertEquals(20.0, adjustedRange.getUpperBound(), "Upper bound should remain unchanged");
    }

    @Test
    @DisplayName("TC13: autoAdjustRange sets range using computeLogFloor and computeLogCeil when flags are set")
    void TC13_autoAdjustRange_uses_computeLogFloor_and_computeLogCeil_with_flags() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Axis");
        Method setAutoRangeNextLogFlag = LogarithmicAxis.class.getMethod("setAutoRangeNextLogFlag", boolean.class);
        setAutoRangeNextLogFlag.setAccessible(true);
        setAutoRangeNextLogFlag.invoke(axis, true);

        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        Method setPlot = LogarithmicAxis.class.getMethod("setPlot", ValueAxisPlot.class);
        setPlot.setAccessible(true);
        setPlot.invoke(axis, mockPlot);

        Range mockRange = new Range(3.0, 30.0);
        when(mockPlot.getDataRange(axis)).thenReturn(mockRange);

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Method getRange = LogarithmicAxis.class.getMethod("getRange");
        getRange.setAccessible(true);
        Range adjustedRange = (Range) getRange.invoke(axis);

        // Assuming computeLogFloor and computeLogCeil adjust bounds to nearest 10^n
        assertEquals(1.0, adjustedRange.getLowerBound(), "Lower bound should use computeLogFloor");
        assertEquals(100.0, adjustedRange.getUpperBound(), "Upper bound should use computeLogCeil");
    }

    @Test
    @DisplayName("TC14: autoAdjustRange handles negative upper bounds when allowNegativesFlag is true")
    void TC14_autoAdjustRange_with_negative_upper_bound_and_negatives_allowed() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Axis");
        Method setAllowNegativesFlag = LogarithmicAxis.class.getMethod("setAllowNegativesFlag", boolean.class);
        setAllowNegativesFlag.setAccessible(true);
        setAllowNegativesFlag.invoke(axis, true);

        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        Method setPlot = LogarithmicAxis.class.getMethod("setPlot", ValueAxisPlot.class);
        setPlot.setAccessible(true);
        setPlot.invoke(axis, mockPlot);

        Range mockRange = new Range(1.0, -10.0);
        when(mockPlot.getDataRange(axis)).thenReturn(mockRange);

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Method getRange = LogarithmicAxis.class.getMethod("getRange");
        getRange.setAccessible(true);
        Range adjustedRange = (Range) getRange.invoke(axis);
        // Assuming the method processes negative upper bounds correctly
        assertEquals(1.0, adjustedRange.getLowerBound(), "Lower bound should remain unchanged");
        assertEquals(-10.0, adjustedRange.getUpperBound(), "Upper bound should be processed correctly with negative value");
    }

    @Test
    @DisplayName("TC15: autoAdjustRange ignores small upper bound when allowNegativesFlag is false and upper is not between 0 and 1")
    void TC15_autoAdjustRange_with_upper_bound_not_between_0_and_1_and_no_negatives_allowed() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Axis");
        Method setAllowNegativesFlag = LogarithmicAxis.class.getMethod("setAllowNegativesFlag", boolean.class);
        setAllowNegativesFlag.setAccessible(true);
        setAllowNegativesFlag.invoke(axis, false);

        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        Method setPlot = LogarithmicAxis.class.getMethod("setPlot", ValueAxisPlot.class);
        setPlot.setAccessible(true);
        setPlot.invoke(axis, mockPlot);

        Range mockRange = new Range(5.0, 15.0);
        when(mockPlot.getDataRange(axis)).thenReturn(mockRange);

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Method getRange = LogarithmicAxis.class.getMethod("getRange");
        getRange.setAccessible(true);
        Range adjustedRange = (Range) getRange.invoke(axis);
        // Assuming upper bound is set to ceiling without modification
        assertEquals(5.0, adjustedRange.getLowerBound(), "Lower bound should remain unchanged");
        assertEquals(15.0, adjustedRange.getUpperBound(), "Upper bound should be set to the ceiling without modification");
    }
}