package com.fasterxml.jackson.databind.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.TimeZone;
import java.util.Locale;
import java.util.Date;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class ISO8601Utils_parse_2_1_Test {

    @Test
    @DisplayName("Parse throws ParseException when date uses invalid '/' separators instead of '-'")
    void TC53_parseInvalidDateSeparators() {
        String date = "2023/10/05T14:30:00Z";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> ISO8601Utils.parse(date, pos));
    }

    @Test
    @DisplayName("Parse throws ParseException when timezone indicator uses lowercase 'z'")
    void TC54_parseLowercaseZTimezoneIndicator() {
        String date = "2023-10-05T14:30:00z";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> ISO8601Utils.parse(date, pos));
    }

    @Test
    @DisplayName("Parse throws IndexOutOfBoundsException when timezone offset hour is missing after '+'")
    void TC55_parseMissingTimezoneOffsetHour() {
        String date = "2023-10-05T14:30:00+";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(IndexOutOfBoundsException.class, () -> ISO8601Utils.parse(date, pos));
    }

    @Test
    @DisplayName("Parse throws ParseException when multiple 'T' characters are present")
    void TC56_parseMultipleTCharacters() {
        String date = "2023-10-05TT14:30:00Z";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> ISO8601Utils.parse(date, pos));
    }

    @Test
    @DisplayName("Parse throws ParseException when timezone offset has non-numeric characters")
    void TC57_parseNonNumericTimezoneOffset() {
        String date = "2023-10-05T14:30:00+02:A0";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> ISO8601Utils.parse(date, pos));
    }
}