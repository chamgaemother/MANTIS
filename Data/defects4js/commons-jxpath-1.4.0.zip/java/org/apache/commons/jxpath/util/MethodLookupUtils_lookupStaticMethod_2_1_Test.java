package org.apache.commons.jxpath.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.apache.commons.jxpath.ExpressionContext;
import org.apache.commons.jxpath.JXPathException;

public class MethodLookupUtils_lookupStaticMethod_2_1_Test {

//     @Test
//     @DisplayName("lookupStaticMethod with ExpressionContext as first parameter and type conversion failure leading to JXPathException")
//     public void TC19() {
        // GIVEN
//         Class<?> targetClass = ClassWithUnsupportedConversion.class;
//         String name = "unsupportedConversionMethod";
//         ExpressionContext context = new ExpressionContext();
//         Object[] parameters = new Object[] { context, new UnsupportedType() };
//         
        // WHEN & THEN
//         assertThrows(JXPathException.class, () -> {
//             Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);
//         }, "Expected JXPathException due to type conversion failure.");
//     }

    @Test
    @DisplayName("lookupStaticMethod with multiple null parameters leading to exact static method match")
    public void TC20() {
        // GIVEN
        Class<?> targetClass = ClassWithMultipleNullParams.class;
        String name = "staticMethodWithMultipleNulls";
        Object[] parameters = new Object[] { null, null };
        
        // WHEN
        Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);
        
        // THEN
        assertNotNull(result, "Expected static method to be found with multiple null parameters.");
        assertEquals("staticMethodWithMultipleNulls", result.getName(), "Method name should match the requested name.");
        assertTrue(Modifier.isStatic(result.getModifiers()), "Method should be static.");
    }

    @Test
    @DisplayName("lookupStaticMethod with parameters requiring approximate type conversion leading to method match")
    public void TC21() {
        // GIVEN
        Class<?> targetClass = ClassWithApproximateConversion.class;
        String name = "staticMethodWithApproximateParams";
        Object[] parameters = new Object[] { "123", 456 };
        
        // WHEN
        Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);
        
        // THEN
        assertNotNull(result, "Expected static method to be found via approximate type conversion.");
        assertEquals("staticMethodWithApproximateParams", result.getName(), "Method name should match the requested name.");
        assertTrue(Modifier.isStatic(result.getModifiers()), "Method should be static.");
    }

    @Test
    @DisplayName("lookupStaticMethod with parameters array containing mixed null and non-null elements leading to partial type conversion")
    public void TC22() {
        // GIVEN
        Class<?> targetClass = ClassWithMixedParameters.class;
        String name = "staticMethodWithMixedParams";
        Object[] parameters = new Object[] { null, "ValidString", 789 };
        
        // WHEN
        Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);
        
        // THEN
        assertNotNull(result, "Expected static method to be found with mixed null and non-null parameters.");
        assertEquals("staticMethodWithMixedParams", result.getName(), "Method name should match the requested name.");
        assertTrue(Modifier.isStatic(result.getModifiers()), "Method should be static.");
    }

    @Test
    @DisplayName("lookupStaticMethod with parameters array length not matching any static method signatures resulting in no match")
    public void TC23() {
        // GIVEN
        Class<?> targetClass = ClassWithDifferentParameterLengths.class;
        String name = "staticMethodWithDifferentParams";
        Object[] parameters = new Object[] { "OnlyOneParameter" };
        
        // WHEN
        Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);
        
        // THEN
        assertNull(result, "Expected no matching static method due to parameter length mismatch.");
    }

    // Supporting classes for testing
    
    // Class used in TC19
    public static class ClassWithUnsupportedConversion {
        public static void unsupportedConversionMethod(ExpressionContext context, UnsupportedType ut) {
            // Method intentionally left blank
        }
    }

    // UnsupportedType used in TC19
    public static class UnsupportedType {
        // Class intentionally left blank
    }

    // Class used in TC20
    public static class ClassWithMultipleNullParams {
        public static void staticMethodWithMultipleNulls(Object param1, Object param2) {
            // Method intentionally left blank
        }
    }

    // Class used in TC21
    public static class ClassWithApproximateConversion {
        public static void staticMethodWithApproximateParams(String param1, Integer param2) {
            // Method intentionally left blank
        }
        
        // Overloaded method to create ambiguity if needed
        public static void staticMethodWithApproximateParams(Object param1, Number param2) {
            // Method intentionally left blank
        }
    }

    // Class used in TC22
    public static class ClassWithMixedParameters {
        public static void staticMethodWithMixedParams(Object param1, String param2, Integer param3) {
            // Method intentionally left blank
        }
    }

    // Class used in TC23
    public static class ClassWithDifferentParameterLengths {
        public static void staticMethodWithDifferentParams(String param1, String param2) {
            // Method intentionally left blank
        }
    }
}