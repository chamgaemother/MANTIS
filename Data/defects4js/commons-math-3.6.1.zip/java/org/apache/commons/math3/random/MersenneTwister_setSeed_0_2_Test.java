package org.apache.commons.math3.random;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Method;
import java.util.Arrays;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class MersenneTwister_setSeed_0_2_Test {

    @Test
    @DisplayName("setSeed with all positive integers in seed array initializes mt array correctly")
    void TC06_setSeed_AllPositiveIntegers() throws Exception {
        // GIVEN
        MersenneTwister mt = new MersenneTwister();
        int[] seed = new int[624];
        for(int i = 0; i < 624; i++) {
            seed[i] = i + 1;
        }

        // WHEN
        mt.setSeed(seed);

        // THEN
        Method getStateMethod = MersenneTwister.class.getDeclaredMethod("getState");
        getStateMethod.setAccessible(true);
        int[] mtArray = (int[]) getStateMethod.invoke(mt);
        for(int i = 0; i < 624; i++) {
            assertTrue(mtArray[i] > 0, "mt[" + i + "] should be positive");
        }
    }

    @Test
    @DisplayName("setSeed with all negative integers in seed array initializes mt array correctly")
    void TC07_setSeed_AllNegativeIntegers() throws Exception {
        // GIVEN
        MersenneTwister mt = new MersenneTwister();
        int[] seed = new int[624];
        for(int i = 0; i < 624; i++) {
            seed[i] = -i - 1;
        }

        // WHEN
        mt.setSeed(seed);

        // THEN
        Method getStateMethod = MersenneTwister.class.getDeclaredMethod("getState");
        getStateMethod.setAccessible(true);
        int[] mtArray = (int[]) getStateMethod.invoke(mt);
        for(int i = 0; i < 624; i++) {
            assertTrue(mtArray[i] < 0, "mt[" + i + "] should be negative");
        }
    }

    @Test
    @DisplayName("setSeed with mixed positive and negative integers in seed array initializes mt array correctly")
    void TC08_setSeed_MixedIntegers() throws Exception {
        // GIVEN
        MersenneTwister mt = new MersenneTwister();
        int[] seed = new int[624];
        for(int i = 0; i < 624; i++) {
            seed[i] = i % 2 == 0 ? i : -i;
        }

        // WHEN
        mt.setSeed(seed);

        // THEN
        Method getStateMethod = MersenneTwister.class.getDeclaredMethod("getState");
        getStateMethod.setAccessible(true);
        int[] mtArray = (int[]) getStateMethod.invoke(mt);
        for(int i = 0; i < 624; i++) {
            if(i % 2 == 0) {
                assertTrue(mtArray[i] >= 0, "mt[" + i + "] should be non-negative");
            } else {
                assertTrue(mtArray[i] < 0, "mt[" + i + "] should be negative");
            }
        }
    }

    @Test
    @DisplayName("setSeed with maximum integer values in seed array initializes mt array correctly")
    void TC09_setSeed_MaximumIntegers() throws Exception {
        // GIVEN
        MersenneTwister mt = new MersenneTwister();
        int[] seed = new int[624];
        Arrays.fill(seed, Integer.MAX_VALUE);

        // WHEN
        mt.setSeed(seed);

        // THEN
        Method getStateMethod = MersenneTwister.class.getDeclaredMethod("getState");
        getStateMethod.setAccessible(true);
        int[] mtArray = (int[]) getStateMethod.invoke(mt);
        for(int i = 0; i < 624; i++) {
            assertEquals(Integer.MAX_VALUE, mtArray[i], "mt[" + i + "] should be Integer.MAX_VALUE");
        }
    }

    @Test
    @DisplayName("setSeed with minimum integer values in seed array initializes mt array correctly")
    void TC10_setSeed_MinimumIntegers() throws Exception {
        // GIVEN
        MersenneTwister mt = new MersenneTwister();
        int[] seed = new int[624];
        Arrays.fill(seed, Integer.MIN_VALUE);

        // WHEN
        mt.setSeed(seed);

        // THEN
        Method getStateMethod = MersenneTwister.class.getDeclaredMethod("getState");
        getStateMethod.setAccessible(true);
        int[] mtArray = (int[]) getStateMethod.invoke(mt);
        for(int i = 0; i < 624; i++) {
            assertEquals(Integer.MIN_VALUE, mtArray[i], "mt[" + i + "] should be Integer.MIN_VALUE");
        }
    }
}