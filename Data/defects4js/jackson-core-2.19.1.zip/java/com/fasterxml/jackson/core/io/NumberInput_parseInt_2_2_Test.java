package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class NumberInput_parseInt_2_2_Test {

    @Test
    @DisplayName("parseInt with length=5 without '+' sign parses correctly")
    public void TC34_parseInt_Length5_NoPlus_Success() {
        // GIVEN
        char[] input = new char[] {'1', '2', '3', '4', '5'};
        int off = 0;
        int len = 5;

        // WHEN
        int result = NumberInput.parseInt(input, off, len);

        // THEN
        assertEquals(12345, result, "Expected parseInt to return 12345");
    }

    @Test
    @DisplayName("parseInt with length=11 and '+' sign parses maximum positive integer")
    public void TC35_parseInt_Length11_WithPlus_MaxInteger() {
        // GIVEN
        char[] input = new char[] {'+', '2', '1', '4', '7', '4', '8', '3', '6', '4', '7'};
        int off = 0;
        int len = 11;

        // WHEN
        int result = NumberInput.parseInt(input, off, len);

        // THEN
        assertEquals(Integer.MAX_VALUE, result, "Expected parseInt to return Integer.MAX_VALUE");
    }

    @Test
    @DisplayName("parseInt with length=10 without '+' sign parses maximum positive integer")
    public void TC36_parseInt_Length10_NoPlus_MaxInteger() {
        // GIVEN
        char[] input = new char[] {'2', '1', '4', '7', '4', '8', '3', '6', '4', '7'};
        int off = 0;
        int len = 10;

        // WHEN
        int result = NumberInput.parseInt(input, off, len);

        // THEN
        assertEquals(Integer.MAX_VALUE, result, "Expected parseInt to return Integer.MAX_VALUE");
    }
}