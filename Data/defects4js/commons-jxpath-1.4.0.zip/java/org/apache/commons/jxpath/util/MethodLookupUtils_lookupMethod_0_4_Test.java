package org.apache.commons.jxpath.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * JUnit 5 test class for MethodLookupUtils.lookupMethod covering scenarios TC16 to TC20.
 */
public class MethodLookupUtils_lookupMethod_0_4_Test {

    /**
     * Dummy SomeClass with necessary methods for testing purposes.
     */
    public static class SomeClass {
        public void methodName(String param1) { }

        public void desiredMethod(String param1, String param2) { }

        public static void staticMethod(String param1) { }

        public void nonStaticMethod(String param1) { }
    }

    /**
     * Scenario TC16:
     * lookupMethod returns null when matchType cannot convert the first parameter.
     */
    @Test
    @DisplayName("lookupMethod returns null when matchType cannot convert the first parameter")
    public void TC16_lookupMethod_returnsNull_whenMatchTypeCannotConvertFirstParameter() {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "methodName";
        Object unconvertibleObject = new Object(); // Assuming Object cannot be converted to targetClass
        Object[] parameters = new Object[]{ unconvertibleObject, "param1" };

        // WHEN
        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        // THEN
        assertNull(result, "Expected lookupMethod to return null when first parameter cannot be converted.");
    }

    /**
     * Scenario TC17:
     * lookupMethod processes parameters correctly when first parameter is already of targetClass.
     */
    @Test
    @DisplayName("lookupMethod processes parameters correctly when first parameter is already of targetClass")
    public void TC17_lookupMethod_processesParameters_whenFirstParameterIsTargetClass() {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "desiredMethod";
        Object[] parameters = new Object[]{ targetClass, "param1", "param2" };

        // WHEN
        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        // THEN
        assertNotNull(result, "Expected lookupMethod to return a Method instance.");
        assertEquals("desiredMethod", result.getName(), "Expected method name to match 'desiredMethod'.");
    }

    /**
     * Scenario TC18:
     * lookupMethod skips static methods during the search.
     */
    @Test
    @DisplayName("lookupMethod skips static methods during the search")
    public void TC18_lookupMethod_skipsStaticMethods_whenSearching() {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "staticMethod";
        Object[] parameters = new Object[]{ targetClass, "param1" };

        // WHEN
        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        // THEN
        assertNull(result, "Expected lookupMethod to return null when matching method is static.");
    }

    /**
     * Scenario TC19:
     * lookupMethod returns null when method name does not match any methods.
     */
    @Test
    @DisplayName("lookupMethod returns null when method name does not match any methods")
    public void TC19_lookupMethod_returnsNull_whenMethodNameDoesNotMatch() {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "unknownMethod";
        Object convertibleObject = new SomeClass(); // Assuming convertibleObject can be converted to targetClass
        Object[] parameters = new Object[]{ convertibleObject, "param1" };

        // WHEN
        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        // THEN
        assertNull(result, "Expected lookupMethod to return null when method name does not match any methods.");
    }

    /**
     * Scenario TC20:
     * lookupMethod correctly identifies and returns a method when first matching method is non-static.
     */
    @Test
    @DisplayName("lookupMethod correctly identifies and returns a method when first matching method is non-static")
    public void TC20_lookupMethod_returnsFirstNonStaticMatchingMethod() {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "nonStaticMethod";
        Object convertibleObject = new SomeClass(); // Assuming convertibleObject can be converted to targetClass
        Object[] parameters = new Object[]{ convertibleObject, "param1" };

        // WHEN
        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        // THEN
        assertNotNull(result, "Expected lookupMethod to return a Method instance.");
        assertFalse(Modifier.isStatic(result.getModifiers()), "Expected the returned method to be non-static.");
        assertEquals("nonStaticMethod", result.getName(), "Expected method name to match 'nonStaticMethod'.");
    }
}