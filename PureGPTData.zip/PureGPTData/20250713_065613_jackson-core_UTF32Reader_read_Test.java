import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.io.UTF32Reader;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.*;
import static org.junit.jupiter.api.Assertions.*;

class UTF32ReaderTest {

    private IOContext context;
    private byte[] buffer;
    
    @BeforeEach
    void setup() {
        context = new IOContext(null, null, false);
    }

    @Test
    void testReadEmptyBuffer() throws IOException {
        buffer = new byte[0];
        UTF32Reader reader = new UTF32Reader(context, new ByteArrayInputStream(buffer), buffer, 0, 0, true);
        assertEquals(-1, reader.read(new char[10], 0, 10));
    }

    @Test
    void testReadBufferLessThanFourBytesEOF() throws IOException {
        buffer = new byte[]{0x00, 0x00};
        UTF32Reader reader = new UTF32Reader(context, new ByteArrayInputStream(buffer), buffer, 0, 2, true);
        assertThrows(EOFException.class, () -> reader.read(new char[10], 0, 10));
    }

    @Test
    void testReadBufferWithExactFourBytes() throws IOException {
        buffer = new byte[]{0x00, 0x00, 0x00, 0x41}; // 'A' character in UTF-32 (big-endian)
        UTF32Reader reader = new UTF32Reader(context, new ByteArrayInputStream(buffer), buffer, 0, 4, true);
        char[] out = new char[1];
        assertEquals(1, reader.read(out, 0, 1));
        assertEquals('A', out[0]);
    }

    @Test
    void testReadWithSurrogates() throws IOException {
        buffer = new byte[]{0x00, 0x01, 0x00, 0x00}; // character 0x10000 (first supplementary character)
        UTF32Reader reader = new UTF32Reader(context, new ByteArrayInputStream(buffer), buffer, 0, 4, true);
        char[] out = new char[2];
        assertEquals(2, reader.read(out, 0, 2));
        assertEquals('\uD800', out[0]);
        assertEquals('\uDC00', out[1]);
    }

    @Test
    void testReadInvalidHigherUnicode() throws IOException {
        buffer = new byte[]{0x00, 0x11, 0x00, 0x00}; // Invalid as it's > 0x10FFFF
        UTF32Reader reader = new UTF32Reader(context, new ByteArrayInputStream(buffer), buffer, 0, 4, true);
        char[] out = new char[2];
        assertThrows(CharConversionException.class, () -> reader.read(out, 0, 1));
    }

    @Test
    void testReadSmallBufferInvalidIndex() throws IOException {
        buffer = new byte[]{0x00, 0x00, 0x00, 0x41}; // 'A' character
        UTF32Reader reader = new UTF32Reader(context, new ByteArrayInputStream(buffer), buffer, 0, 4, true);
        char[] out = new char[1];
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> reader.read(out, 0, 2)); // out bound length
    }

    @Test
    void testManagedBufferFreeOnEOF() throws IOException {
        buffer = new byte[]{0x00, 0x00, 0x00, 0x41};
        ByteArrayInputStream in = new ByteArrayInputStream(buffer);
        UTF32Reader reader = new UTF32Reader(context, in, buffer, 0, 4, true);
        char[] out = new char[1];
        assertEquals(1, reader.read(out, 0, 1));
        assertEquals('A', out[0]);
        assertEquals(-1, reader.read(out, 0, 1));
        assertNotNull(context.releaseReadIOBuffer(null)); // Check managed buffer was released
    }
}