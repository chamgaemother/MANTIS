package org.jfree.chart.renderer.xy;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StackedXYAreaRenderer.StackedXYAreaRendererState;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class XYAreaRenderer_drawItem_0_1_Test {

    @Test
    @DisplayName("Handles NaN Y value by setting y1 to 0 and marking nullPoint as true")
    public void TC01_HandlesNaNYValue() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        StackedXYAreaRendererState state = mock(StackedXYAreaRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
        StackedXYAreaRenderer renderer = new StackedXYAreaRenderer();

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        // Assert
        verify(dataset).getYValue(0, 0);
        // Verifying interactions instead of internal variable states
        verify(state, times(1)).setSeriesArea(any());
    }

    @Test
    @DisplayName("Uses fill paint when getUseFillPaint() returns true")
    public void TC02_UsesFillPaint() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        StackedXYAreaRendererState state = mock(StackedXYAreaRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        StackedXYAreaRenderer renderer = spy(new StackedXYAreaRenderer());
        when(renderer.getUseFillPaint()).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(renderer.getItemFillPaint(0, 0)).thenReturn(mock(Paint.class));

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        // Assert
        verify(renderer, times(1)).getItemFillPaint(0, 0);
    }

    @Test
    @DisplayName("Does not use fill paint when getUseFillPaint() returns false")
    public void TC03_DoesNotUseFillPaint() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        StackedXYAreaRendererState state = mock(StackedXYAreaRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        StackedXYAreaRenderer renderer = spy(new StackedXYAreaRenderer());
        when(renderer.getUseFillPaint()).thenReturn(false);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        // Assert
        verify(renderer, times(1)).getItemPaint(0, 0);
    }

    @Test
    @DisplayName("Executes first pass (pass == 0) and renders areas, lines, and outlines")
    public void TC04_FirstPassRendering() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        StackedXYAreaRendererState state = mock(StackedXYAreaRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        StackedXYAreaRenderer renderer = spy(new StackedXYAreaRenderer());
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(20.0);
        when(renderer.getPlotLines()).thenReturn(true);
        when(renderer.isOutline()).thenReturn(true);
        Stroke mockStroke = mock(Stroke.class);
        Paint mockPaint = mock(Paint.class);
        when(renderer.getItemStroke(0, 0)).thenReturn(mockStroke);
        when(renderer.getItemPaint(0, 0)).thenReturn(mockPaint);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        // Assert
        verify(g2, atLeastOnce()).setPaint(mockPaint);
        verify(g2, atLeastOnce()).setStroke(mockStroke);
        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    @DisplayName("Executes second pass (pass == 1) and renders shapes and collects entity information")
    public void TC05_SecondPassRendering() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        StackedXYAreaRendererState state = mock(StackedXYAreaRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        StackedXYAreaRenderer renderer = spy(new StackedXYAreaRenderer());
        when(renderer.getPlotShapes()).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(renderer.getItemShape(0, 0)).thenReturn(mock(java.awt.Shape.class));

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        // Assert
        verify(g2, atLeastOnce()).draw(any());
        verify(state, atLeastOnce()).getInfo();
    }
}
