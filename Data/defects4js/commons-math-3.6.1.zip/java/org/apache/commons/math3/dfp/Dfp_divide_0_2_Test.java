package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class Dfp_divide_0_2_Test {

    @Test
    @DisplayName("Division where both operands are infinite resulting in NaN")
    public void testTC06() throws Exception {
        // Initialize field via reflection
        DfpField field = new DfpField(10);

        // Create dividend and divisor with INFINITE values
        Dfp dividend = field.newDfp(Double.POSITIVE_INFINITY);
        Dfp divisor = field.newDfp(Double.POSITIVE_INFINITY);

        // Perform division
        Dfp result = dividend.divide(divisor);

        // Assertions
        assertTrue(result.isNaN(), "Result should be NaN");

        // Access the 'field' to check IEEE flags using reflection
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField resultField = (DfpField) fieldField.get(result);

        Field ieeeFlagsField = DfpField.class.getDeclaredField("ieeeFlagsBits");
        ieeeFlagsField.setAccessible(true);
        int ieeeFlags = ieeeFlagsField.getInt(resultField);

        assertTrue((ieeeFlags & DfpField.FLAG_INVALID) != 0, "FLAG_INVALID should be set");
    }

    @Test
    @DisplayName("Division resulting in zero with appropriate exponent adjustment")
    public void testTC07() throws Exception {
        // Initialize field via reflection
        DfpField field = new DfpField(10);

        // Create dividend as zero and divisor as finite value
        Dfp dividend = field.newDfp(0);
        Dfp divisor = field.newDfp(5);

        // Perform division
        Dfp result = dividend.divide(divisor);

        // Assertions
        assertTrue(result.isZero(), "Result should be zero");
        
        // Handling the check for `getSign()` method from Dfp class
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        byte expectedSign = signField.getByte(dividend);
        assertEquals(expectedSign, signField.getByte(result), "Sign should be adjusted correctly");
    }

    @Test
    @DisplayName("Division with rounding mode ROUND_DOWN and maximum significant digits")
    public void testTC08() throws Exception {
        // Initialize field via reflection and set rounding mode to ROUND_DOWN
        DfpField field = new DfpField(10);
        Field roundingModeField = DfpField.class.getDeclaredField("roundingMode");
        roundingModeField.setAccessible(true);
        roundingModeField.set(field, DfpField.RoundingMode.ROUND_DOWN);

        // Create dividend and divisor with finite values
        Dfp dividend = field.newDfp(10.0);
        Dfp divisor = field.newDfp(3.0);

        // Perform division
        Dfp result = dividend.divide(divisor);

        // Assertions
        // Corrected method name from `doubleValue` to `toDouble`
        assertEquals(3.3333333333, result.toDouble(), 1e-10, "Result should be rounded down correctly");
    }

    @Test
    @DisplayName("Division causing overflow resulting in infinite quotient")
    public void testTC09() throws Exception {
        // Initialize field via reflection
        DfpField field = new DfpField(10);

        // Create dividend as very large value and divisor as very small value
        Dfp dividend = field.newDfp(Double.MAX_VALUE);
        Dfp divisor = field.newDfp(1e-10);

        // Perform division
        Dfp result = dividend.divide(divisor);

        // Assertions
        assertTrue(result.isInfinite(), "Result should be infinite");

        // Access the 'field' to check IEEE flags
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField resultField = (DfpField) fieldField.get(result);

        Field ieeeFlagsField = DfpField.class.getDeclaredField("ieeeFlagsBits");
        ieeeFlagsField.setAccessible(true);
        int ieeeFlags = ieeeFlagsField.getInt(resultField);

        assertTrue((ieeeFlags & DfpField.FLAG_OVERFLOW) != 0, "FLAG_OVERFLOW should be set");
    }

    @Test
    @DisplayName("Division causing underflow resulting in zero")
    public void testTC10() throws Exception {
        // Initialize field via reflection
        DfpField field = new DfpField(10);

        // Create dividend as very small value and divisor as very large value
        Dfp dividend = field.newDfp(1e-10);
        Dfp divisor = field.newDfp(1e+10);

        // Perform division
        Dfp result = dividend.divide(divisor);

        // Assertions
        assertTrue(result.isZero(), "Result should be zero");

        // Access the 'field' to check IEEE flags
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField resultField = (DfpField) fieldField.get(result);

        Field ieeeFlagsField = DfpField.class.getDeclaredField("ieeeFlagsBits");
        ieeeFlagsField.setAccessible(true);
        int ieeeFlags = ieeeFlagsField.getInt(resultField);

        assertTrue((ieeeFlags & DfpField.FLAG_UNDERFLOW) != 0, "FLAG_UNDERFLOW should be set");
    }
}