package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.XYItemLabelGenerator;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class XYBarRenderer_drawItem_0_2_Test {

    @Test
    @DisplayName("drawItem returns early when Y1 is NaN")
    public void TC06_drawItem_returnsEarly_whenY1IsNaN() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int series = 0;
        int item = 0;
        int pass = 1;

        // Create a spy of ClusteredXYBarRenderer
        ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer());

        // Mock getItemVisible to return true
        doReturn(true).when(renderer).getItemVisible(series, item);

        // Mock dataset as IntervalXYDataset and getYValue to return NaN
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset instanceof IntervalXYDataset).thenReturn(true);
        when((IntervalXYDataset) dataset).thenReturn(intervalDataset);
        when(renderer.getUseYInterval()).thenReturn(false);
        when(intervalDataset.getYValue(series, item)).thenReturn(Double.NaN);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that method returns early without performing any drawing
        verify(g2, never()).draw(any());
        verify(renderer, never()).getBase();
    }

    @Test
    @DisplayName("drawItem calculates yy0 and yy1 correctly")
    public void TC07_drawItem_calculatesYy0AndYy1Correctly() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int series = 1;
        int item = 2;
        int pass = 1;

        // Create a spy of ClusteredXYBarRenderer
        ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer());

        // Mock getItemVisible to return true
        doReturn(true).when(renderer).getItemVisible(series, item);

        // Mock dataset as IntervalXYDataset and provide valid Y0 and Y1
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset instanceof IntervalXYDataset).thenReturn(true);
        when((IntervalXYDataset) dataset).thenReturn(intervalDataset);
        when(renderer.getUseYInterval()).thenReturn(false);
        when(intervalDataset.getYValue(series, item)).thenReturn(10.0);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(5.0);

        // Mock rangeAxis.valueToJava2D
        when(rangeAxis.valueToJava2D(5.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(100.0);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that valueToJava2D was called correctly
        verify(rangeAxis).valueToJava2D(5.0, dataArea, renderer.getPlot().getRangeAxisEdge());
        verify(rangeAxis).valueToJava2D(10.0, dataArea, renderer.getPlot().getRangeAxisEdge());
    }

    @Test
    @DisplayName("drawItem throws IllegalStateException for unsupported orientation")
    public void TC08_drawItem_throwsException_forUnsupportedOrientation() {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int series = 0;
        int item = 0;
        int pass = 1;

        // Create a spy of ClusteredXYBarRenderer
        ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer());

        // Mock getItemVisible to return true
        try {
            doReturn(true).when(renderer).getItemVisible(series, item);
        } catch (Exception e) {
            fail("Mocking failed");
        }

        // Mock dataset as IntervalXYDataset with valid Y0 and Y1
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset instanceof IntervalXYDataset).thenReturn(true);
        when((IntervalXYDataset) dataset).thenReturn(intervalDataset);
        when(renderer.getUseYInterval()).thenReturn(false);
        when(intervalDataset.getYValue(series, item)).thenReturn(10.0);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(5.0);

        // Mock rangeAxis.valueToJava2D
        when(rangeAxis.valueToJava2D(5.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(100.0);

        // Mock plot orientation to an unsupported value by extending PlotOrientation
        PlotOrientation unsupportedOrientation = mock(PlotOrientation.class);
        when(plot.getOrientation()).thenReturn(unsupportedOrientation);

        // Act & Assert
        assertThrows(IllegalStateException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        });
    }

    @Test
    @DisplayName("drawItem centers bar at start value when centerBarAtStartValue is true")
    public void TC09_drawItem_centersBarAtStartValue_whenFlagIsTrue() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int series = 1;
        int item = 1;
        int pass = 1;

        // Create a spy of ClusteredXYBarRenderer
        ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer());

        // Mock getItemVisible to return true
        doReturn(true).when(renderer).getItemVisible(series, item);

        // Set centerBarAtStartValue to true via reflection if it's private
        java.lang.reflect.Field field = ClusteredXYBarRenderer.class.getDeclaredField("centerBarAtStartValue");
        field.setAccessible(true);
        field.set(renderer, true);

        // Mock dataset as IntervalXYDataset with valid Y0 and Y1
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset instanceof IntervalXYDataset).thenReturn(true);
        when((IntervalXYDataset) dataset).thenReturn(intervalDataset);
        when(renderer.getUseYInterval()).thenReturn(false);
        when(intervalDataset.getYValue(series, item)).thenReturn(15.0);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(5.0);

        // Mock rangeAxis.valueToJava2D
        when(rangeAxis.valueToJava2D(5.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(15.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(150.0);

        // Mock domainAxis.valueToJava2D
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);

        // Mock plot orientation to VERTICAL
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that baseX is adjusted by subtracting half of intervalW
        // This requires capturing the Rectangle2D parameter in paintBar
        // For simplicity, assume paintBar is called with adjusted parameters
        verify(renderer).getBarPainter();
    }

    @Test
    @DisplayName("drawItem applies margin when getMargin() > 0")
    public void TC10_drawItem_appliesMargin_whenMarginGreaterThanZero() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int series = 2;
        int item = 3;
        int pass = 1;

        // Create a spy of ClusteredXYBarRenderer
        ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer());

        // Mock getItemVisible to return true
        doReturn(true).when(renderer).getItemVisible(series, item);

        // Set getMargin() to return a value greater than 0
        when(renderer.getMargin()).thenReturn(0.1);

        // Mock dataset as IntervalXYDataset with valid Y0 and Y1
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset instanceof IntervalXYDataset).thenReturn(true);
        when((IntervalXYDataset) dataset).thenReturn(intervalDataset);
        when(renderer.getUseYInterval()).thenReturn(false);
        when(intervalDataset.getYValue(series, item)).thenReturn(20.0);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(10.0);

        // Mock rangeAxis.valueToJava2D
        when(rangeAxis.valueToJava2D(10.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(200.0);

        // Mock domainAxis.valueToJava2D
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(150.0);

        // Mock plot orientation to HORIZONTAL
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that intervalW and baseX are adjusted based on the margin
        // This requires capturing the Rectangle2D parameter in paintBar
        // For simplicity, assume paintBar is called with adjusted parameters
        verify(renderer).getBarPainter();
    }
}