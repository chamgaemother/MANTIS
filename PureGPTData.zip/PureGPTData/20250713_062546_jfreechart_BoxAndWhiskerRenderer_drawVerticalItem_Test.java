import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset;
import org.jfree.chart.renderer.category.BoxAndWhiskerRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import static org.mockito.Mockito.*;

public class BoxAndWhiskerRendererTest {

    private BoxAndWhiskerRenderer renderer;
    private Graphics2D g2;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private CategoryItemRendererState state;
    private DefaultBoxAndWhiskerCategoryDataset dataset;
    private Rectangle2D dataArea;

    @BeforeEach
    public void setUp() {
        renderer = new BoxAndWhiskerRenderer();
        g2 = mock(Graphics2D.class);
        plot = mock(CategoryPlot.class);
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = new DefaultBoxAndWhiskerCategoryDataset();
        state = new CategoryItemRendererState(null);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.getCategoryEnd(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(75.0);
        when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(25.0);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);

        dataset.add(1, 2, 3, 4, 5, 2.5, new java.util.ArrayList<>(), "Row", "Column");
    }

    @Test
    public void testDrawVerticalItemWithValidData() {
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                .thenReturn(50.0);

        renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        verify(g2, atLeastOnce()).setPaint(any(Paint.class));
        verify(g2, atLeastOnce()).setStroke(any(Stroke.class));
        verify(g2, atLeastOnce()).fill(any(Shape.class));
        verify(g2, atLeastOnce()).draw(any(Shape.class));
    }

    @Test
    public void testDrawVerticalItemWithNullDataset() {
        try {
            renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, null, 0, 0);
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testDrawVerticalItemWithMinMaxOutlierVisible() {
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                .thenReturn(10.0);
        renderer.setMaxOutlierVisible(true);
        renderer.setMinOutlierVisible(true);

        renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        verify(g2, atLeastOnce()).setPaint(any(Paint.class));
        verify(g2, atLeastOnce()).fill(any(Shape.class));
    }

    @Test
    public void testDrawVerticalItemWithMeanAndMedianVisible() {
        renderer.setMeanVisible(true);
        renderer.setMedianVisible(true);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                .thenReturn(50.0);

        renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        verify(g2, atLeastOnce()).setPaint(any(Paint.class));
        verify(g2, atLeastOnce()).draw(any(Shape.class));
    }
}