import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.compiler.Step;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.Expression;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class StepTest {

    @Test
    public void testToStringWithChildAxisAndNodeTest() {
        NodeTest mockNodeTest = mock(NodeTest.class);
        Step step = new Step(Compiler.AXIS_CHILD, mockNodeTest, null);
        assertEquals(mockNodeTest.toString(), step.toString());
    }

    @Test
    public void testToStringWithAttributeAxisAndNodeTest() {
        NodeTest mockNodeTest = mock(NodeTest.class);
        Step step = new Step(Compiler.AXIS_ATTRIBUTE, mockNodeTest, null);
        assertEquals("@" + mockNodeTest.toString(), step.toString());
    }

    @Test
    public void testToStringWithSelfAxisAndNodeTypeNodeTest() {
        NodeTypeTest mockNodeTypeTest = mock(NodeTypeTest.class);
        when(mockNodeTypeTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_NODE);
        Step step = new Step(Compiler.AXIS_SELF, mockNodeTypeTest, null);
        assertEquals(".", step.toString());
    }

    @Test
    public void testToStringWithParentAxisAndNodeTypeNodeTest() {
        NodeTypeTest mockNodeTypeTest = mock(NodeTypeTest.class);
        when(mockNodeTypeTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_NODE);
        Step step = new Step(Compiler.AXIS_PARENT, mockNodeTypeTest, null);
        assertEquals("..", step.toString());
    }
    
    @Test
    public void testToStringWithDescendantOrSelfAxisAndNodeTypeNodeTestNoPredicates() {
        NodeTypeTest mockNodeTypeTest = mock(NodeTypeTest.class);
        when(mockNodeTypeTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_NODE);
        Step step = new Step(Compiler.AXIS_DESCENDANT_OR_SELF, mockNodeTypeTest, null);
        assertEquals("", step.toString());
    }

    @Test
    public void testToStringWithCustomAxis() {
        NodeTest mockNodeTest = mock(NodeTest.class);
        Step step = new Step(Compiler.AXIS_ANCESTOR, mockNodeTest, null);
        assertEquals("ancestor::" + mockNodeTest.toString(), step.toString());
    }

    @Test
    public void testToStringWithPredicates() {
        NodeTest mockNodeTest = mock(NodeTest.class);
        Expression mockPredicate = mock(Expression.class);
        when(mockPredicate.toString()).thenReturn("predicate");
        Step step = new Step(Compiler.AXIS_CHILD, mockNodeTest, new Expression[]{mockPredicate});
        assertEquals(mockNodeTest.toString() + "[predicate]", step.toString());
    }
}