package org.jfree.chart.ui;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.awt.*;
import java.lang.reflect.Field;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class LCBLayout_layoutContainer_0_3_Test {

    @Test
    @DisplayName("layoutContainer with varying labelGap and buttonGap values")
    void TC11() throws Exception {
        // Initialize the parent container
        Container parent = new Container();

        // Create an instance of LCBLayout with maxrows set to 1
        LCBLayout layout = new LCBLayout(1);

        // Using reflection to set custom labelGap and buttonGap
        Class<?> layoutClass = layout.getClass();

        Field labelGapField = layoutClass.getDeclaredField("labelGap");
        labelGapField.setAccessible(true);
        int customLabelGap = 20;
        labelGapField.setInt(layout, customLabelGap);

        Field buttonGapField = layoutClass.getDeclaredField("buttonGap");
        buttonGapField.setAccessible(true);
        int customButtonGap = 30;
        buttonGapField.setInt(layout, customButtonGap);

        // Set the layout to the parent container
        parent.setLayout(layout);

        // Add three components to the parent container
        Component comp1 = new Panel();
        Component comp2 = new Panel();
        Component comp3 = new Panel();
        parent.add(comp1);
        parent.add(comp2);
        parent.add(comp3);

        // Set the parent container size
        parent.setSize(300, 200);

        // Set the insets for the container using reflection
        insetContainer(parent, new Insets(10, 10, 10, 10));

        // Mock preferred sizes for components
        Dimension dim1 = new Dimension(50, 30);
        Dimension dim2 = new Dimension(60, 40);
        Dimension dim3 = new Dimension(70, 50);
        comp1.setPreferredSize(dim1);
        comp2.setPreferredSize(dim2);
        comp3.setPreferredSize(dim3);

        // Invoke the method under test
        layout.layoutContainer(parent);

        // Verify that gaps between columns are set according to labelGap and buttonGap configurations
        // Access the private colWidth field using reflection
        Field colWidthField = layoutClass.getDeclaredField("colWidth");
        colWidthField.setAccessible(true);
        int[] colWidth = (int[]) colWidthField.get(layout);

        // Calculate expected total width before adjustment
        int expectedTotalWidth = colWidth[0] + colWidth[1] + colWidth[2];

        // Available width = parent width - insets left and right - labelGap - buttonGap
        Insets insets = parent.getInsets();
        int available = parent.getWidth() - insets.left - insets.right - customLabelGap - customButtonGap;

        // The second column width should be adjusted by (available - expectedTotalWidth)
        int expectedColWidth1 = dim2.width + (available - expectedTotalWidth);
        assertEquals(expectedColWidth1, colWidth[1], "Column width for the second column should be adjusted correctly based on labelGap and buttonGap");
    }

    // Method to inject insets into Container as Container class doesn't provide a direct method for setting insets
    private void insetContainer(Container container, Insets insets) throws Exception {
        Field insetsField = Container.class.getDeclaredField("insets");
        insetsField.setAccessible(true);
        insetsField.set(container, insets);
    }
}
