package com.fasterxml.jackson.databind.cfg;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.databind.cfg.CoercionConfigs;
import com.fasterxml.jackson.databind.cfg.MutableCoercionConfig;
import com.fasterxml.jackson.databind.DeserializationConfig;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.type.LogicalType;
import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
import com.fasterxml.jackson.databind.cfg.CoercionAction;

import java.lang.reflect.Field;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Test class for targeting the findCoercion method of CoercionConfigs
 */
public class CoercionConfigs_findCoercion_0_5_Test {

    @Test
    @DisplayName("All coercion lookups fail, returns defaultAction")
    public void TC21_AllCoercionLookupsFail_ReturnsDefaultAction() throws Exception {
        // Arrange
        CoercionConfigs coercionConfigs = new CoercionConfigs();

        // Set _perClassCoercions to null
        Field perClassField = CoercionConfigs.class.getDeclaredField("_perClassCoercions");
        perClassField.setAccessible(true);
        perClassField.set(coercionConfigs, null);

        // Set _perTypeCoercions to null
        Field perTypeField = CoercionConfigs.class.getDeclaredField("_perTypeCoercions");
        perTypeField.setAccessible(true);
        perTypeField.set(coercionConfigs, null);

        // Set _defaultCoercions to a config that returns null
        MutableCoercionConfig emptyDefaultCoercions = new MutableCoercionConfig();
        Field defaultCoercionsField = CoercionConfigs.class.getDeclaredField("_defaultCoercions");
        defaultCoercionsField.setAccessible(true);
        defaultCoercionsField.set(coercionConfigs, emptyDefaultCoercions);

        // Set _defaultAction
        Field defaultActionField = CoercionConfigs.class.getDeclaredField("_defaultAction");
        defaultActionField.setAccessible(true);
        defaultActionField.set(coercionConfigs, CoercionAction.Fail);

        // Create DeserializationConfig
        ObjectMapper mapper = new ObjectMapper();
        DeserializationConfig config = mapper.getDeserializationConfig();

        LogicalType targetType = LogicalType.Integer; // Arbitrary type
        Class<?> targetClass = null;
        CoercionInputShape inputShape = CoercionInputShape.Integer;

        // Act
        CoercionAction result = coercionConfigs.findCoercion(config, targetType, targetClass, inputShape);

        // Assert
        assertEquals(CoercionAction.Fail, result, "Should return _defaultAction");
    }

    @Test
    @DisplayName("inputShape is EmptyString and targetType is scalar with ALLOW_COERCION_OF_SCALARS disabled and ACCEPT_EMPTY_STRING_AS_NULL_OBJECT enabled")
    public void TC22_InputShapeEmptyString_ScalarType_CoercionAllowedAsNull() throws Exception {
        // Arrange
        CoercionConfigs coercionConfigs = new CoercionConfigs();

        // Set _perClassCoercions to null
        Field perClassField = CoercionConfigs.class.getDeclaredField("_perClassCoercions");
        perClassField.setAccessible(true);
        perClassField.set(coercionConfigs, null);

        // Set _perTypeCoercions to null
        Field perTypeField = CoercionConfigs.class.getDeclaredField("_perTypeCoercions");
        perTypeField.setAccessible(true);
        perTypeField.set(coercionConfigs, null);

        // Set _defaultCoercions to a config that returns null
        MutableCoercionConfig emptyDefaultCoercions = new MutableCoercionConfig();
        Field defaultCoercionsField = CoercionConfigs.class.getDeclaredField("_defaultCoercions");
        defaultCoercionsField.setAccessible(true);
        defaultCoercionsField.set(coercionConfigs, emptyDefaultCoercions);

        // Set _defaultAction
        Field defaultActionField = CoercionConfigs.class.getDeclaredField("_defaultAction");
        defaultActionField.setAccessible(true);
        defaultActionField.set(coercionConfigs, CoercionAction.Fail);

        // Create DeserializationConfig with specific feature settings
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(MapperFeature.ALLOW_COERCION_OF_SCALARS, false);
        mapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
        DeserializationConfig config = mapper.getDeserializationConfig();

        LogicalType targetType = LogicalType.Boolean; // Scalar type
        Class<?> targetClass = null;
        CoercionInputShape inputShape = CoercionInputShape.EmptyString;

        // Act
        CoercionAction result = coercionConfigs.findCoercion(config, targetType, targetClass, inputShape);

        // Assert
        assertEquals(CoercionAction.AsNull, result, "Should return CoercionAction.AsNull");
    }

//     @Test
//     @DisplayName("_isScalarType returns false, and ALLOW_COERCION_OF_SCALARS is disabled")
//     public void TC23_NonScalarType_CoercionDisabled_ShouldFail() throws Exception {
        // Arrange
//         CoercionConfigs coercionConfigs = new CoercionConfigs();
// 
        // Set _perClassCoercions to null
//         Field perClassField = CoercionConfigs.class.getDeclaredField("_perClassCoercions");
//         perClassField.setAccessible(true);
//         perClassField.set(coercionConfigs, null);
// 
        // Set _perTypeCoercions to null
//         Field perTypeField = CoercionConfigs.class.getDeclaredField("_perTypeCoercions");
//         perTypeField.setAccessible(true);
//         perTypeField.set(coercionConfigs, null);
// 
        // Set _defaultCoercions to a config that returns null
//         MutableCoercionConfig emptyDefaultCoercions = new MutableCoercionConfig();
//         Field defaultCoercionsField = CoercionConfigs.class.getDeclaredField("_defaultCoercions");
//         defaultCoercionsField.setAccessible(true);
//         defaultCoercionsField.set(coercionConfigs, emptyDefaultCoercions);
// 
        // Set _defaultAction
//         Field defaultActionField = CoercionConfigs.class.getDeclaredField("_defaultAction");
//         defaultActionField.setAccessible(true);
//         defaultActionField.set(coercionConfigs, CoercionAction.Fail);
// 
        // Create DeserializationConfig with specific feature settings
//         ObjectMapper mapper = new ObjectMapper();
//         mapper.configure(MapperFeature.ALLOW_COERCION_OF_SCALARS, false);
//         DeserializationConfig config = mapper.getDeserializationConfig();
// 
//         LogicalType targetType = LogicalType.Map; // Non-scalar type
//         Class<?> targetClass = null;
//         CoercionInputShape inputShape = CoercionInputShape.SomeShape; // Arbitrary shape
// 
        // Act
//         CoercionAction result = coercionConfigs.findCoercion(config, targetType, targetClass, inputShape);
// 
        // Assert
//         assertEquals(CoercionAction.Fail, result, "Should return CoercionAction.Fail");
//     }

    @Test
    @DisplayName("_isScalarType returns true, ALLOW_COERCION_OF_SCALARS is enabled, and inputShape is not Integer for Float type")
    public void TC24_ScalarType_CoercionEnabled_InvalidShape_ShouldFail() throws Exception {
        // Arrange
        CoercionConfigs coercionConfigs = new CoercionConfigs();

        // Set _perClassCoercions to null
        Field perClassField = CoercionConfigs.class.getDeclaredField("_perClassCoercions");
        perClassField.setAccessible(true);
        perClassField.set(coercionConfigs, null);

        // Set _perTypeCoercions to null
        Field perTypeField = CoercionConfigs.class.getDeclaredField("_perTypeCoercions");
        perTypeField.setAccessible(true);
        perTypeField.set(coercionConfigs, null);

        // Set _defaultCoercions to a config that returns null
        MutableCoercionConfig emptyDefaultCoercions = new MutableCoercionConfig();
        Field defaultCoercionsField = CoercionConfigs.class.getDeclaredField("_defaultCoercions");
        defaultCoercionsField.setAccessible(true);
        defaultCoercionsField.set(coercionConfigs, emptyDefaultCoercions);

        // Set _defaultAction
        Field defaultActionField = CoercionConfigs.class.getDeclaredField("_defaultAction");
        defaultActionField.setAccessible(true);
        defaultActionField.set(coercionConfigs, CoercionAction.Fail);

        // Create DeserializationConfig with specific feature settings
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(MapperFeature.ALLOW_COERCION_OF_SCALARS, true);
        DeserializationConfig config = mapper.getDeserializationConfig();

        LogicalType targetType = LogicalType.Float; // Scalar type
        Class<?> targetClass = null;
        CoercionInputShape inputShape = CoercionInputShape.Float; // Not Integer shape for Float type

        // Act
        CoercionAction result = coercionConfigs.findCoercion(config, targetType, targetClass, inputShape);

        // Assert
        assertEquals(CoercionAction.Fail, result, "Should return CoercionAction.Fail");
    }
}