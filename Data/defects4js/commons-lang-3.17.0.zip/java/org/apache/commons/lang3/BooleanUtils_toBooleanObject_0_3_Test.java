package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.apache.commons.lang3.BooleanUtils;

import static org.junit.jupiter.api.Assertions.*;

public class BooleanUtils_toBooleanObject_0_3_Test {

    @Test
    @DisplayName("Input string is three characters 'OFF', returns Boolean.FALSE")
    void TC11() {
        // GIVEN
        String input = "OFF";
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        // THEN
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("Input string is four characters 'True', returns Boolean.TRUE")
    void TC12() {
        // GIVEN
        String input = "True";
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        // THEN
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("Input string is five characters 'FALSE', returns Boolean.FALSE")
    void TC13() {
        // GIVEN
        String input = "FALSE";
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        // THEN
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("Input string length is unsupported, returns null")
    void TC14() {
        // GIVEN
        String input = "maybe";
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        // THEN
        assertNull(result);
    }

    @Test
    @DisplayName("Input string is single character 'f', returns Boolean.FALSE")
    void TC15() {
        // GIVEN
        String input = "f";
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        // THEN
        assertEquals(Boolean.FALSE, result);
    }
}