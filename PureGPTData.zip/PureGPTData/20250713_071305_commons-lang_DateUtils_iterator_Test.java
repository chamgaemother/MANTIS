import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.*;

class DateUtilsTest {

    @Test
    void testIteratorWithNullCalendar() {
        assertThrows(NullPointerException.class, () -> DateUtils.iterator((Calendar) null, DateUtils.RANGE_MONTH_SUNDAY));
    }

    @Test
    void testIteratorWithInvalidRangeStyle() {
        Calendar calendar = Calendar.getInstance();
        assertThrows(IllegalArgumentException.class, () -> DateUtils.iterator(calendar, 0));
    }

    @Test
    void testIteratorWithRangeMonthSunday() {
        Calendar calendar = new GregorianCalendar(2022, Calendar.JULY, 15);
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, DateUtils.RANGE_MONTH_SUNDAY);
        // Check that it starts on Sunday
        assertEquals(Calendar.SUNDAY, iterator.next().get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testIteratorWithRangeMonthMonday() {
        Calendar calendar = new GregorianCalendar(2022, Calendar.JULY, 15);
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, DateUtils.RANGE_MONTH_MONDAY);
        // Check that it starts on Monday
        assertEquals(Calendar.MONDAY, iterator.next().get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testIteratorWithRangeWeekSunday() {
        Calendar calendar = new GregorianCalendar(2022, Calendar.JULY, 15);
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, DateUtils.RANGE_WEEK_SUNDAY);
        // Check that it starts on Sunday
        assertEquals(Calendar.SUNDAY, iterator.next().get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testIteratorWithRangeWeekMonday() {
        Calendar calendar = new GregorianCalendar(2022, Calendar.JULY, 15);
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, DateUtils.RANGE_WEEK_MONDAY);
        // Check that it starts on Monday
        assertEquals(Calendar.MONDAY, iterator.next().get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testIteratorWithRangeWeekRelative() {
        Calendar calendar = new GregorianCalendar(2022, Calendar.JULY, 15);
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, DateUtils.RANGE_WEEK_RELATIVE);
        // This should start on the same day
        assertEquals(calendar.get(Calendar.DAY_OF_WEEK), iterator.next().get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testIteratorWithRangeWeekCenter() {
        Calendar calendar = new GregorianCalendar(2022, Calendar.JULY, 15);
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, DateUtils.RANGE_WEEK_CENTER);
        // Centered around the day
        assertEquals(calendar.get(Calendar.DAY_OF_WEEK) - 3, iterator.next().get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testIteratorWithEdgeDate() {
        Calendar calendar = new GregorianCalendar(280000000, Calendar.JANUARY, 1);
        assertThrows(ArithmeticException.class, () -> DateUtils.iterator(calendar, DateUtils.RANGE_MONTH_SUNDAY));
    }

    @Test
    void testIteratorNoSuchElement() {
        Calendar calendar = new GregorianCalendar(2022, Calendar.JULY, 15);
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, DateUtils.RANGE_WEEK_SUNDAY);
        while (iterator.hasNext()) {
            iterator.next();
        }
        assertThrows(NoSuchElementException.class, iterator::next);
    }

    @Test
    void testIteratorUnsupportedOperation() {
        Calendar calendar = new GregorianCalendar(2022, Calendar.JULY, 15);
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, DateUtils.RANGE_WEEK_SUNDAY);
        assertThrows(UnsupportedOperationException.class, iterator::remove);
    }
}