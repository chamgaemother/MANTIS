package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.function.Executable;
import static org.junit.jupiter.api.Assertions.*;

class DfpTest {

    private DfpField field5;
    private DfpField field4;

    @BeforeEach
    void setUp() {
        field5 = new DfpField(5);
        field4 = new DfpField(4);
    }

    @Test
    @DisplayName("Divide finite by finite")
    void testDivideFiniteByFinite() {
        Dfp a = field5.newDfp(10);
        Dfp b = field5.newDfp(2);
        Dfp result = a.divide(b);
        assertEquals(5, result.intValue());
        assertTrue(result.compare(field5.newDfp(5)) == 0);
    }

    @Test
    @DisplayName("Divide finite by zero")
    void testDivideFiniteByZero() {
        Dfp a = field5.newDfp(10);
        Dfp b = field5.newDfp(0);
        Dfp result = a.divide(b);
        assertTrue(result.isInfinite());
        assertEquals(1, result.sign);
    }

    @Test
    @DisplayName("Divide zero by finite")
    void testDivideZeroByFinite() {
        Dfp a = field5.newDfp(0);
        Dfp b = field5.newDfp(10);
        Dfp result = a.divide(b);
        assertTrue(result.isZero());
        assertEquals(1, result.sign);
    }

    @Test
    @DisplayName("Divide infinity by finite")
    void testDivideInfinityByFinite() {
        Dfp a = field5.newInstance((byte)1, Dfp.INFINITE);
        Dfp b = field5.newDfp(2);
        Dfp result = a.divide(b);
        assertTrue(result.isInfinite());
        assertEquals(1, result.sign);
    }

    @Test
    @DisplayName("Divide finite by infinity")
    void testDivideFiniteByInfinity() {
        Dfp a = field5.newDfp(10);
        Dfp b = field5.newInstance((byte)1, Dfp.INFINITE);
        Dfp result = a.divide(b);
        assertTrue(result.isZero());
        assertEquals(1, result.sign);
    }

    @Test
    @DisplayName("Divide infinity by infinity")
    void testDivideInfinityByInfinity() {
        Dfp a = field5.newInstance((byte)1, Dfp.INFINITE);
        Dfp b = field5.newInstance((byte)1, Dfp.INFINITE);
        Dfp result = a.divide(b);
        assertTrue(result.isNaN());
    }

    @Test
    @DisplayName("Divide NaN by finite")
    void testDivideNaNByFinite() {
        Dfp a = field5.newInstance((byte)1, Dfp.QNAN);
        Dfp b = field5.newDfp(2);
        Dfp result = a.divide(b);
        assertTrue(result.isNaN());
    }

    @Test
    @DisplayName("Divide finite by NaN")
    void testDivideFiniteByNaN() {
        Dfp a = field5.newDfp(10);
        Dfp b = field5.newInstance((byte)1, Dfp.QNAN);
        Dfp result = a.divide(b);
        assertTrue(result.isNaN());
    }

    @Test
    @DisplayName("Divide NaN by NaN")
    void testDivideNaNByNaN() {
        Dfp a = field5.newInstance((byte)1, Dfp.QNAN);
        Dfp b = field5.newInstance((byte)1, Dfp.QNAN);
        Dfp result = a.divide(b);
        assertTrue(result.isNaN());
    }

    @Test
    @DisplayName("Divide with different radix digits")
    void testDivideDifferentRadixDigits() {
        Dfp a = field5.newDfp(10);
        Dfp b = field4.newDfp(2);
        Dfp result = a.divide(b);
        assertTrue(result.isNaN());
        assertEquals(Dfp.QNAN, result.classify());
    }

    @Test
    @DisplayName("Divide negative finite by positive finite")
    void testDivideNegativeByPositive() {
        Dfp a = field5.newDfp(-10);
        Dfp b = field5.newDfp(2);
        Dfp result = a.divide(b);
        assertEquals(-5, result.intValue());
        assertTrue(result.compare(field5.newDfp(-5)) == 0);
    }

    @Test
    @DisplayName("Divide positive finite by negative finite")
    void testDividePositiveByNegative() {
        Dfp a = field5.newDfp(10);
        Dfp b = field5.newDfp(-2);
        Dfp result = a.divide(b);
        assertEquals(-5, result.intValue());
        assertTrue(result.compare(field5.newDfp(-5)) == 0);
    }

    @Test
    @DisplayName("Divide negative finite by negative finite")
    void testDivideNegativeByNegative() {
        Dfp a = field5.newDfp(-10);
        Dfp b = field5.newDfp(-2);
        Dfp result = a.divide(b);
        assertEquals(5, result.intValue());
        assertTrue(result.compare(field5.newDfp(5)) == 0);
    }

    @Test
    @DisplayName("Divide zero by zero")
    void testDivideZeroByZero() {
        Dfp a = field5.newDfp(0);
        Dfp b = field5.newDfp(0);
        Dfp result = a.divide(b);
        assertTrue(result.isNaN());
    }

    @Test
    @DisplayName("Divide finite by one")
    void testDivideByOne() {
        Dfp a = field5.newDfp(10);
        Dfp b = field5.getOne();
        Dfp result = a.divide(b);
        assertEquals(10, result.intValue());
        assertTrue(result.compare(a) == 0);
    }

    @Test
    @DisplayName("Divide one by one")
    void testDivideOneByOne() {
        Dfp a = field5.getOne();
        Dfp b = field5.getOne();
        Dfp result = a.divide(b);
        assertEquals(1, result.intValue());
        assertTrue(result.compare(field5.getOne()) == 0);
    }

    @Test
    @DisplayName("Divide one by two")
    void testDivideOneByTwo() {
        Dfp a = field5.getOne();
        Dfp b = field5.newDfp(2);
        Dfp result = a.divide(b);
        assertEquals(0, result.intValue());
        assertTrue(result.compare(field5.newDfp(0)) == 0);
    }

    @Test
    @DisplayName("Divide negative infinity by positive finite")
    void testDivideNegativeInfinityByPositive() {
        Dfp a = field5.newInstance((byte)-1, Dfp.INFINITE);
        Dfp b = field5.newDfp(2);
        Dfp result = a.divide(b);
        assertTrue(result.isInfinite());
        assertEquals(-1, result.sign);
    }

    @Test
    @DisplayName("Divide positive finite by negative infinity")
    void testDividePositiveByNegativeInfinity() {
        Dfp a = field5.newDfp(10);
        Dfp b = field5.newInstance((byte)-1, Dfp.INFINITE);
        Dfp result = a.divide(b);
        assertTrue(result.isZero());
        assertEquals(-1, result.sign);
    }

    @Test
    @DisplayName("Divide positive infinity by positive infinity")
    void testDividePositiveInfinityByPositiveInfinity() {
        Dfp a = field5.newInstance((byte)1, Dfp.INFINITE);
        Dfp b = field5.newInstance((byte)1, Dfp.INFINITE);
        Dfp result = a.divide(b);
        assertTrue(result.isNaN());
    }

    @Test
    @DisplayName("Divide negative infinity by negative infinity")
    void testDivideNegativeInfinityByNegativeInfinity() {
        Dfp a = field5.newInstance((byte)-1, Dfp.INFINITE);
        Dfp b = field5.newInstance((byte)-1, Dfp.INFINITE);
        Dfp result = a.divide(b);
        assertTrue(result.isNaN());
    }

    @Test
    @DisplayName("Divide finite by NaN")
    void testDivideFiniteByNaNQuiet() {
        Dfp a = field5.newDfp(10);
        Dfp b = field5.newInstance((byte)1, Dfp.QNAN);
        Dfp result = a.divide(b);
        assertTrue(result.isNaN());
    }

    @Test
    @DisplayName("Divide NaN by finite")
    void testDivideNaNQuietByFinite() {
        Dfp a = field5.newInstance((byte)1, Dfp.QNAN);
        Dfp b = field5.newDfp(10);
        Dfp result = a.divide(b);
        assertTrue(result.isNaN());
    }

    @Test
    @DisplayName("Divide signaling NaN by finite")
    void testDivideNaNSignalingByFinite() {
        Dfp a = field5.newInstance((byte)1, Dfp.SNAN);
        Dfp b = field5.newDfp(10);
        Dfp result = a.divide(b);
        assertTrue(result.isNaN());
    }

    @Test
    @DisplayName("Divide finite by signaling NaN")
    void testDivideFiniteByNaNSignaling() {
        Dfp a = field5.newDfp(10);
        Dfp b = field5.newInstance((byte)1, Dfp.SNAN);
        Dfp result = a.divide(b);
        assertTrue(result.isNaN());
    }

}