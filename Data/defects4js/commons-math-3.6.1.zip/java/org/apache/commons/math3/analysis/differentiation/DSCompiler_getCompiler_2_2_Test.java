package org.apache.commons.math3.analysis.differentiation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.commons.math3.analysis.differentiation.DSCompiler;
import org.apache.commons.math3.exception.NumberIsTooLargeException;

public class DSCompiler_getCompiler_2_2_Test {

    @Test
    @DisplayName("getCompiler handles multiple cache expansions for increasing parameters and order to parameters=6 and order=6")
    public void TC21_getCompiler_with_parameters6_order6_ShouldExpandCacheCorrectly() throws Exception {
        // Access 'compilers' field via reflection
        Class<DSCompiler> cls = DSCompiler.class;
        Field compilersField = cls.getDeclaredField("compilers");
        compilersField.setAccessible(true);

        // Initialize initialCache with size less than 6 parameters and 6 order
        DSCompiler[][] initialCache = new DSCompiler[6][6]; // indices 0-5
        // Leave all as null to simulate cache size less than required

        // Create AtomicReference with initialCache
        AtomicReference<DSCompiler[][]> compilers = new AtomicReference<>(initialCache);

        // Set 'compilers' field
        compilersField.set(null, compilers);

        // Call getCompiler with parameters=6, order=6
        DSCompiler compiler = DSCompiler.getCompiler(6, 6);

        // Assertions
        Assertions.assertNotNull(compiler, "Compiler should not be null");
        Assertions.assertEquals(6, compiler.getFreeParameters(), "Compiler should have 6 free parameters");
        Assertions.assertEquals(6, compiler.getOrder(), "Compiler should have order 6");

        // Verify that the compiler is cached correctly
        DSCompiler[][] updatedCache = compilers.get();
        Assertions.assertNotNull(updatedCache, "Cache should not be null");
        Assertions.assertTrue(updatedCache.length > 6, "Cache should have been expanded to accommodate 6 parameters");
        Assertions.assertTrue(updatedCache[6].length > 6, "Cache should have been expanded to accommodate order 6");
        Assertions.assertSame(compiler, updatedCache[6][6], "Compiler should be cached at [6][6]");
    }

    @Test
    @DisplayName("getCompiler creates and caches a new DSCompiler when calling with parameters=2 and order=3 exceeding existing cache order")
    public void TC22_getCompiler_with_parameters2_order3_ShouldCreateAndCacheNewCompiler() throws Exception {
        // Access 'compilers' field via reflection
        Class<DSCompiler> cls = DSCompiler.class;
        Field compilersField = cls.getDeclaredField("compilers");
        compilersField.setAccessible(true);

        // Initialize initialCache with cache[2][2] populated and cache[2][3] = null
        DSCompiler[][] initialCache = new DSCompiler[3][4]; // indices 0-2, 0-3

        // Populate cache[2][2] via reflection
        Constructor<DSCompiler> constructor = cls.getDeclaredConstructor(int.class, int.class, DSCompiler.class, DSCompiler.class);
        constructor.setAccessible(true);
        DSCompiler compiler22 = constructor.newInstance(2, 2, null, null);
        initialCache[2][2] = compiler22;

        // Create AtomicReference with initialCache
        AtomicReference<DSCompiler[][]> compilers = new AtomicReference<>(initialCache);

        // Set 'compilers' field
        compilersField.set(null, compilers);

        // Call getCompiler with parameters=2, order=3
        DSCompiler compiler = DSCompiler.getCompiler(2, 3);

        // Assertions
        Assertions.assertNotNull(compiler, "Compiler should not be null");
        Assertions.assertEquals(2, compiler.getFreeParameters(), "Compiler should have 2 free parameters");
        Assertions.assertEquals(3, compiler.getOrder(), "Compiler should have order 3");

        // Verify that the compiler is cached correctly
        DSCompiler[][] updatedCache = compilers.get();
        Assertions.assertNotNull(updatedCache, "Cache should not be null");
        Assertions.assertTrue(updatedCache.length > 2, "Cache should accommodate 2 parameters");
        Assertions.assertTrue(updatedCache[2].length > 3, "Cache should accommodate order 3");
        Assertions.assertSame(compiler, updatedCache[2][3], "Compiler should be cached at [2][3]");
    }

    @Test
    @DisplayName("getCompiler handles cache expansion when calling with parameters=5 and order=1 after initial cache setup")
    public void TC23_getCompiler_with_parameters5_order1_ShouldExpandCacheForHigherParameters() throws Exception {
        // Access 'compilers' field via reflection
        Class<DSCompiler> cls = DSCompiler.class;
        Field compilersField = cls.getDeclaredField("compilers");
        compilersField.setAccessible(true);

        // Initialize initialCache with size less than 5 parameters and 1 order
        DSCompiler[][] initialCache = new DSCompiler[5][2]; // indices 0-4 for parameters, 0-1 for order

        // Populate cache[4][1] via reflection
        Constructor<DSCompiler> constructor = cls.getDeclaredConstructor(int.class, int.class, DSCompiler.class, DSCompiler.class);
        constructor.setAccessible(true);
        DSCompiler compiler41 = constructor.newInstance(4, 1, null, null);
        initialCache[4][1] = compiler41;

        // Create AtomicReference with initialCache
        AtomicReference<DSCompiler[][]> compilers = new AtomicReference<>(initialCache);

        // Set 'compilers' field
        compilersField.set(null, compilers);

        // Call getCompiler with parameters=5, order=1
        DSCompiler compiler = DSCompiler.getCompiler(5, 1);

        // Assertions
        Assertions.assertNotNull(compiler, "Compiler should not be null");
        Assertions.assertEquals(5, compiler.getFreeParameters(), "Compiler should have 5 free parameters");
        Assertions.assertEquals(1, compiler.getOrder(), "Compiler should have order 1");

        // Verify that the compiler is cached correctly
        DSCompiler[][] updatedCache = compilers.get();
        Assertions.assertNotNull(updatedCache, "Cache should not be null");
        Assertions.assertTrue(updatedCache.length > 5, "Cache should have been expanded to accommodate 5 parameters");
        Assertions.assertTrue(updatedCache[5].length > 1, "Cache should have been expanded to accommodate order 1");
        Assertions.assertSame(compiler, updatedCache[5][1], "Compiler should be cached at [5][1]");
    }

    @Test
    @DisplayName("getCompiler handles cache expansion and creation when both parameters and order are incremented beyond existing limits")
    public void TC24_getCompiler_with_parameters7_order7_ShouldExpandCacheMultiplesTimesCorrectly() throws Exception {
        // Access 'compilers' field via reflection
        Class<DSCompiler> cls = DSCompiler.class;
        Field compilersField = cls.getDeclaredField("compilers");
        compilersField.setAccessible(true);

        // Initialize initialCache with size less than 7 parameters and 7 order
        DSCompiler[][] initialCache = new DSCompiler[7][7]; // indices 0-6 for parameters and order

        // Create AtomicReference with initialCache
        AtomicReference<DSCompiler[][]> compilers = new AtomicReference<>(initialCache);

        // Set 'compilers' field
        compilersField.set(null, compilers);

        // Call getCompiler with parameters=7, order=7
        DSCompiler compiler = DSCompiler.getCompiler(7, 7);

        // Assertions
        Assertions.assertNotNull(compiler, "Compiler should not be null");
        Assertions.assertEquals(7, compiler.getFreeParameters(), "Compiler should have 7 free parameters");
        Assertions.assertEquals(7, compiler.getOrder(), "Compiler should have order 7");

        // Verify that the compiler is cached correctly
        DSCompiler[][] updatedCache = compilers.get();
        Assertions.assertNotNull(updatedCache, "Cache should not be null");
        Assertions.assertTrue(updatedCache.length > 7, "Cache should have been expanded to accommodate 7 parameters");
        Assertions.assertTrue(updatedCache[7].length > 7, "Cache should have been expanded to accommodate order 7");
        Assertions.assertSame(compiler, updatedCache[7][7], "Compiler should be cached at [7][7]");
    }

    @Test
    @DisplayName("getCompiler handles request for existing DSCompiler in cache without creating a new one")
    public void TC25_getCompiler_with_existingCache_ShouldReturnCachedCompiler() throws Exception {
        // Access 'compilers' field via reflection
        Class<DSCompiler> cls = DSCompiler.class;
        Field compilersField = cls.getDeclaredField("compilers");
        compilersField.setAccessible(true);

        // Initialize initialCache with cache[2][2] populated
        DSCompiler[][] initialCache = new DSCompiler[3][3]; // indices 0-2

        // Create DSCompiler instance via reflection
        Constructor<DSCompiler> constructor = cls.getDeclaredConstructor(int.class, int.class, DSCompiler.class, DSCompiler.class);
        constructor.setAccessible(true);
        DSCompiler compiler22 = constructor.newInstance(2, 2, null, null);
        initialCache[2][2] = compiler22;

        // Create AtomicReference with initialCache
        AtomicReference<DSCompiler[][]> compilers = new AtomicReference<>(initialCache);

        // Set 'compilers' field
        compilersField.set(null, compilers);

        // Call getCompiler with parameters=2, order=2
        DSCompiler compiler = DSCompiler.getCompiler(2, 2);

        // Assertions
        Assertions.assertSame(compiler22, compiler, "Should return the cached compiler instance");
    }

}