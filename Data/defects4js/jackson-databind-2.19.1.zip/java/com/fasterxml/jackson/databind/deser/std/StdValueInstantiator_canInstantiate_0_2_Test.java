package com.fasterxml.jackson.databind.deser.std;
import com.fasterxml.jackson.databind.JavaType;

import java.lang.reflect.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class StdValueInstantiator_canInstantiate_0_2_Test {

    @Test
    @DisplayName("Only canCreateFromString() returns true, expecting canInstantiate() to return true")
    void TC06() throws Exception {
        // GIVEN
        StdValueInstantiator instantiator = new StdValueInstantiator(null, (JavaType) null);

        // Set _fromStringCreator to non-null
        Field fromStringCreatorField = StdValueInstantiator.class.getDeclaredField("_fromStringCreator");
        fromStringCreatorField.setAccessible(true);
        fromStringCreatorField.set(instantiator, new Object());

        // Set all other creators to null using the helper method
        setField(instantiator, "_defaultCreator", null);
        setField(instantiator, "_delegateType", null);
        setField(instantiator, "_arrayDelegateType", null);
        setField(instantiator, "_withArgsCreator", null);
        setField(instantiator, "_fromIntCreator", null);
        setField(instantiator, "_fromLongCreator", null);
        setField(instantiator, "_fromDoubleCreator", null);
        setField(instantiator, "_fromBooleanCreator", null);

        // WHEN
        boolean result = instantiator.canInstantiate();

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("Only canCreateFromInt() returns true, expecting canInstantiate() to return true")
    void TC07() throws Exception {
        // GIVEN
        StdValueInstantiator instantiator = new StdValueInstantiator(null, (JavaType) null);

        // Set _fromIntCreator to non-null
        Field fromIntCreatorField = StdValueInstantiator.class.getDeclaredField("_fromIntCreator");
        fromIntCreatorField.setAccessible(true);
        fromIntCreatorField.set(instantiator, new Object());

        // Set all other creators to null using the helper method
        setField(instantiator, "_defaultCreator", null);
        setField(instantiator, "_delegateType", null);
        setField(instantiator, "_arrayDelegateType", null);
        setField(instantiator, "_withArgsCreator", null);
        setField(instantiator, "_fromStringCreator", null);
        setField(instantiator, "_fromLongCreator", null);
        setField(instantiator, "_fromDoubleCreator", null);
        setField(instantiator, "_fromBooleanCreator", null);

        // WHEN
        boolean result = instantiator.canInstantiate();

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("canCreateFromInt() and canCreateFromLong() return true, expecting canInstantiate() to return true")
    void TC08() throws Exception {
        // GIVEN
        StdValueInstantiator instantiator = new StdValueInstantiator(null, (JavaType) null);

        // Set _fromIntCreator and _fromLongCreator to non-null using the helper method
        setField(instantiator, "_fromIntCreator", new Object());
        setField(instantiator, "_fromLongCreator", new Object());

        // Set all other creators to null using the helper method
        setField(instantiator, "_defaultCreator", null);
        setField(instantiator, "_delegateType", null);
        setField(instantiator, "_arrayDelegateType", null);
        setField(instantiator, "_withArgsCreator", null);
        setField(instantiator, "_fromStringCreator", null);
        setField(instantiator, "_fromDoubleCreator", null);
        setField(instantiator, "_fromBooleanCreator", null);

        // WHEN
        boolean result = instantiator.canInstantiate();

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("All creator methods except canCreateFromBoolean() return true, expecting canInstantiate() to return true")
    void TC09() throws Exception {
        // GIVEN
        StdValueInstantiator instantiator = new StdValueInstantiator(null, (JavaType) null);

        // Set all creators except _fromBooleanCreator to non-null using the helper method
        setField(instantiator, "_defaultCreator", new Object());
        setField(instantiator, "_delegateType", new Object());
        setField(instantiator, "_arrayDelegateType", new Object());
        setField(instantiator, "_withArgsCreator", new Object());
        setField(instantiator, "_fromStringCreator", new Object());
        setField(instantiator, "_fromIntCreator", new Object());
        setField(instantiator, "_fromLongCreator", new Object());
        setField(instantiator, "_fromDoubleCreator", new Object());

        // Set _fromBooleanCreator to null using the helper method
        setField(instantiator, "_fromBooleanCreator", null);

        // WHEN
        boolean result = instantiator.canInstantiate();

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("All creator methods return true including canCreateFromBoolean(), expecting canInstantiate() to return true")
    void TC10() throws Exception {
        // GIVEN
        StdValueInstantiator instantiator = new StdValueInstantiator(null, (JavaType) null);

        // Set all creators to non-null using the helper method
        setField(instantiator, "_defaultCreator", new Object());
        setField(instantiator, "_delegateType", new Object());
        setField(instantiator, "_arrayDelegateType", new Object());
        setField(instantiator, "_withArgsCreator", new Object());
        setField(instantiator, "_fromStringCreator", new Object());
        setField(instantiator, "_fromIntCreator", new Object());
        setField(instantiator, "_fromLongCreator", new Object());
        setField(instantiator, "_fromDoubleCreator", new Object());
        setField(instantiator, "_fromBooleanCreator", new Object());

        // WHEN
        boolean result = instantiator.canInstantiate();

        // THEN
        assertTrue(result);
    }

    /**
     * Helper method to set a field value via reflection.
     */
    private void setField(StdValueInstantiator instantiator, String fieldName, Object value) throws Exception {
        Field field = StdValueInstantiator.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(instantiator, value);
    }
}