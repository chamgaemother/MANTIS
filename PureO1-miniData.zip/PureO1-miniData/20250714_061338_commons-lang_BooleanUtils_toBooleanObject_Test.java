package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.apache.commons.lang3.BooleanUtils;

class BooleanUtilsTest {

    @Test
    @DisplayName("toBooleanObject should return TRUE when input is the TRUE constant")
    void testToBooleanObject_TRUEConstant() {
        Boolean result = BooleanUtils.toBooleanObject(BooleanUtils.TRUE);
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return TRUE for 'true' string")
    void testToBooleanObject_trueString() {
        Boolean result = BooleanUtils.toBooleanObject("true");
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return TRUE for 'True' string with different instance")
    void testToBooleanObject_trueStringDifferentInstance() {
        String str = new String("true");
        Boolean result = BooleanUtils.toBooleanObject(str);
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return NULL for null input")
    void testToBooleanObject_nullInput() {
        Boolean result = BooleanUtils.toBooleanObject(null);
        assertNull(result);
    }

    @Test
    @DisplayName("toBooleanObject should return TRUE for single character 'y'")
    void testToBooleanObject_singleCharY() {
        Boolean result = BooleanUtils.toBooleanObject("y");
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return TRUE for single character 'Y'")
    void testToBooleanObject_singleCharYUpper() {
        Boolean result = BooleanUtils.toBooleanObject("Y");
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return TRUE for single character 't'")
    void testToBooleanObject_singleCharT() {
        Boolean result = BooleanUtils.toBooleanObject("t");
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return TRUE for single character 'T'")
    void testToBooleanObject_singleCharTUpper() {
        Boolean result = BooleanUtils.toBooleanObject("T");
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return TRUE for single character '1'")
    void testToBooleanObject_singleChar1() {
        Boolean result = BooleanUtils.toBooleanObject("1");
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return FALSE for single character 'n'")
    void testToBooleanObject_singleCharN() {
        Boolean result = BooleanUtils.toBooleanObject("n");
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return FALSE for single character 'N'")
    void testToBooleanObject_singleCharNUpper() {
        Boolean result = BooleanUtils.toBooleanObject("N");
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return FALSE for single character 'f'")
    void testToBooleanObject_singleCharF() {
        Boolean result = BooleanUtils.toBooleanObject("f");
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return FALSE for single character 'F'")
    void testToBooleanObject_singleCharFUpper() {
        Boolean result = BooleanUtils.toBooleanObject("F");
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return FALSE for single character '0'")
    void testToBooleanObject_singleChar0() {
        Boolean result = BooleanUtils.toBooleanObject("0");
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return TRUE for two characters 'on'")
    void testToBooleanObject_twoCharsOn() {
        Boolean result = BooleanUtils.toBooleanObject("on");
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return TRUE for two characters 'ON'")
    void testToBooleanObject_twoCharsONUpper() {
        Boolean result = BooleanUtils.toBooleanObject("ON");
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return FALSE for two characters 'no'")
    void testToBooleanObject_twoCharsNo() {
        Boolean result = BooleanUtils.toBooleanObject("no");
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return FALSE for two characters 'NO'")
    void testToBooleanObject_twoCharsNOUpper() {
        Boolean result = BooleanUtils.toBooleanObject("NO");
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return TRUE for three characters 'yes'")
    void testToBooleanObject_threeCharsYes() {
        Boolean result = BooleanUtils.toBooleanObject("yes");
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return TRUE for three characters 'YES'")
    void testToBooleanObject_threeCharsYESUpper() {
        Boolean result = BooleanUtils.toBooleanObject("YES");
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return FALSE for three characters 'off'")
    void testToBooleanObject_threeCharsOff() {
        Boolean result = BooleanUtils.toBooleanObject("off");
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return FALSE for three characters 'OFF'")
    void testToBooleanObject_threeCharsOFFUpper() {
        Boolean result = BooleanUtils.toBooleanObject("OFF");
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return TRUE for four characters 'true'")
    void testToBooleanObject_fourCharsTrue() {
        Boolean result = BooleanUtils.toBooleanObject("true");
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return TRUE for four characters 'TRUE'")
    void testToBooleanObject_fourCharsTRUEUpper() {
        Boolean result = BooleanUtils.toBooleanObject("TRUE");
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return FALSE for five characters 'false'")
    void testToBooleanObject_fiveCharsFalse() {
        Boolean result = BooleanUtils.toBooleanObject("false");
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return FALSE for five characters 'FALSE'")
    void testToBooleanObject_fiveCharsFALSEUpper() {
        Boolean result = BooleanUtils.toBooleanObject("FALSE");
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("toBooleanObject should return NULL for invalid single character")
    void testToBooleanObject_invalidSingleChar() {
        Boolean result = BooleanUtils.toBooleanObject("a");
        assertNull(result);
    }

    @Test
    @DisplayName("toBooleanObject should return NULL for invalid two characters")
    void testToBooleanObject_invalidTwoChars() {
        Boolean result = BooleanUtils.toBooleanObject("ab");
        assertNull(result);
    }

    @Test
    @DisplayName("toBooleanObject should return NULL for invalid three characters")
    void testToBooleanObject_invalidThreeChars() {
        Boolean result = BooleanUtils.toBooleanObject("abc");
        assertNull(result);
    }

    @Test
    @DisplayName("toBooleanObject should return NULL for invalid four characters")
    void testToBooleanObject_invalidFourChars() {
        Boolean result = BooleanUtils.toBooleanObject("abcd");
        assertNull(result);
    }

    @Test
    @DisplayName("toBooleanObject should return NULL for invalid five characters")
    void testToBooleanObject_invalidFiveChars() {
        Boolean result = BooleanUtils.toBooleanObject("abcde");
        assertNull(result);
    }

    @Test
    @DisplayName("toBooleanObject should return NULL for longer than five characters")
    void testToBooleanObject_longString() {
        Boolean result = BooleanUtils.toBooleanObject("truthy");
        assertNull(result);
    }

    @Test
    @DisplayName("toBooleanObject should return NULL for empty string")
    void testToBooleanObject_emptyString() {
        Boolean result = BooleanUtils.toBooleanObject("");
        assertNull(result);
    }

    @Test
    @DisplayName("toBooleanObject should handle mixed case correctly for 'yEs'")
    void testToBooleanObject_mixedCaseYes() {
        Boolean result = BooleanUtils.toBooleanObject("yEs");
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("toBooleanObject should handle mixed case correctly for 'OfF'")
    void testToBooleanObject_mixedCaseOff() {
        Boolean result = BooleanUtils.toBooleanObject("OfF");
        assertEquals(Boolean.FALSE, result);
    }
}