package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class DateUtilsTest {

    @Test
    void iterator_NullCalendar_ThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> {
            DateUtils.iterator(null, DateUtils.RANGE_WEEK_SUNDAY);
        });
    }

    @Test
    void iterator_InvalidRangeStyle_ThrowsIllegalArgumentException() {
        Calendar calendar = Calendar.getInstance();
        assertThrows(IllegalArgumentException.class, () -> {
            DateUtils.iterator(calendar, 7);
        });
    }

    @Test
    void iterator_RangeWeekSunday_ReturnsCorrectIterator() {
        Calendar focus = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        focus.set(2023, Calendar.AUGUST, 30); // Wednesday, August 30, 2023
        Iterator<Calendar> iterator = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);

        Calendar start = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        start.set(2023, Calendar.AUGUST, 27, 0, 0, 0);
        start.set(Calendar.MILLISECOND, 0);

        Calendar end = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        end.set(2023, Calendar.SEPTEMBER, 2, 23, 59, 59);
        end.set(Calendar.MILLISECOND, 999);

        int count = 0;
        while (iterator.hasNext()) {
            Calendar current = iterator.next();
            assertEquals(start.get(Calendar.YEAR), current.get(Calendar.YEAR));
            assertEquals(start.get(Calendar.MONTH), current.get(Calendar.MONTH));
            assertEquals(start.get(Calendar.DAY_OF_MONTH), current.get(Calendar.DAY_OF_MONTH));
            start.add(Calendar.DATE, 1);
            count++;
        }
        assertEquals(7, count);
    }

    @Test
    void iterator_RangeWeekMonday_ReturnsCorrectIterator() {
        Calendar focus = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        focus.set(2023, Calendar.SEPTEMBER, 6); // Wednesday, September 6, 2023
        Iterator<Calendar> iterator = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_MONDAY);

        Calendar start = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        start.set(2023, Calendar.SEPTEMBER, 4, 0, 0, 0); // Monday
        start.set(Calendar.MILLISECOND, 0);

        Calendar end = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        end.set(2023, Calendar.SEPTEMBER, 10, 23, 59, 59); // Sunday
        end.set(Calendar.MILLISECOND, 999);

        int count = 0;
        while (iterator.hasNext()) {
            Calendar current = iterator.next();
            assertEquals(start.get(Calendar.YEAR), current.get(Calendar.YEAR));
            assertEquals(start.get(Calendar.MONTH), current.get(Calendar.MONTH));
            assertEquals(start.get(Calendar.DAY_OF_MONTH), current.get(Calendar.DAY_OF_MONTH));
            start.add(Calendar.DATE, 1);
            count++;
        }
        assertEquals(7, count);
    }

    @Test
    void iterator_RangeWeekRelative_ReturnsCorrectIterator() {
        Calendar focus = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        focus.set(2023, Calendar.OCTOBER, 5); // Thursday, October 5, 2023
        Iterator<Calendar> iterator = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_RELATIVE);

        int dayOfWeek = focus.get(Calendar.DAY_OF_WEEK);
        Calendar start = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        start.set(2023, Calendar.OCTOBER, 5, 0, 0, 0);
        start.set(Calendar.MILLISECOND, 0);
        start.add(Calendar.DATE, -(dayOfWeek - 1));

        Calendar end = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        end.setTime(start.getTime());
        end.add(Calendar.DATE, 6);

        int count = 0;
        while (iterator.hasNext()) {
            Calendar current = iterator.next();
            assertEquals(start.get(Calendar.YEAR), current.get(Calendar.YEAR));
            assertEquals(start.get(Calendar.MONTH), current.get(Calendar.MONTH));
            assertEquals(start.get(Calendar.DAY_OF_MONTH), current.get(Calendar.DAY_OF_MONTH));
            start.add(Calendar.DATE, 1);
            count++;
        }
        assertEquals(7, count);
    }

    @Test
    void iterator_RangeWeekCenter_ReturnsCorrectIterator() {
        Calendar focus = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        focus.set(2023, Calendar.OCTOBER, 5); // Thursday, October 5, 2023
        Iterator<Calendar> iterator = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_CENTER);

        Calendar start = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        start.set(2023, Calendar.OCTOBER, 2, 0, 0, 0); // Monday
        start.set(Calendar.MILLISECOND, 0);
        start.add(Calendar.DATE, -3);

        Calendar expectedStart = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        expectedStart.set(2023, Calendar.OCTOBER, 2, 0, 0, 0);
        expectedStart.set(Calendar.MILLISECOND, 0);

        Calendar end = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        end.set(2023, Calendar.OCTOBER, 8, 23, 59, 59);
        end.set(Calendar.MILLISECOND, 999);

        int count = 0;
        while (iterator.hasNext()) {
            Calendar current = iterator.next();
            assertEquals(expectedStart.get(Calendar.YEAR), current.get(Calendar.YEAR));
            assertEquals(expectedStart.get(Calendar.MONTH), current.get(Calendar.MONTH));
            assertEquals(expectedStart.get(Calendar.DAY_OF_MONTH), current.get(Calendar.DAY_OF_MONTH));
            expectedStart.add(Calendar.DATE, 1);
            count++;
        }
        assertEquals(7, count);
    }

    @Test
    void iterator_RangeMonthSunday_ReturnsCorrectIterator() {
        Calendar focus = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        focus.set(2023, Calendar.JANUARY, 15); // January 15, 2023
        Iterator<Calendar> iterator = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);

        Calendar start = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        start.set(2023, Calendar.JANUARY, 1, 0, 0, 0);
        start.set(Calendar.MILLISECOND, 0);
        while (start.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
            start.add(Calendar.DATE, -1);
        }

        Calendar end = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        end.set(2023, Calendar.JANUARY, 31, 23, 59, 59);
        end.set(Calendar.MILLISECOND, 999);
        while (end.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY) {
            end.add(Calendar.DATE, 1);
        }

        int count = 0;
        while (iterator.hasNext()) {
            Calendar current = iterator.next();
            assertEquals(start.get(Calendar.YEAR), current.get(Calendar.YEAR));
            assertEquals(start.get(Calendar.MONTH), current.get(Calendar.MONTH));
            assertEquals(start.get(Calendar.DAY_OF_MONTH), current.get(Calendar.DAY_OF_MONTH));
            start.add(Calendar.DATE, 1);
            count++;
        }
        assertTrue(count >= 28 && count <= 35);
    }

    @Test
    void iterator_RangeMonthMonday_ReturnsCorrectIterator() {
        Calendar focus = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        focus.set(2023, Calendar.FEBRUARY, 10); // February 10, 2023
        Iterator<Calendar> iterator = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_MONDAY);

        Calendar start = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        start.set(2023, Calendar.FEBRUARY, 1, 0, 0, 0);
        start.set(Calendar.MILLISECOND, 0);
        while (start.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) {
            start.add(Calendar.DATE, -1);
        }

        Calendar end = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        end.set(2023, Calendar.FEBRUARY, 28, 23, 59, 59);
        end.set(Calendar.MILLISECOND, 999);
        while (end.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
            end.add(Calendar.DATE, 1);
        }

        int count = 0;
        while (iterator.hasNext()) {
            Calendar current = iterator.next();
            assertEquals(start.get(Calendar.YEAR), current.get(Calendar.YEAR));
            assertEquals(start.get(Calendar.MONTH), current.get(Calendar.MONTH));
            assertEquals(start.get(Calendar.DAY_OF_MONTH), current.get(Calendar.DAY_OF_MONTH));
            start.add(Calendar.DATE, 1);
            count++;
        }
        assertTrue(count >= 28 && count <= 35);
    }

    @ParameterizedTest
    @ValueSource(ints = {DateUtils.RANGE_WEEK_SUNDAY, DateUtils.RANGE_WEEK_MONDAY, 
                         DateUtils.RANGE_WEEK_RELATIVE, DateUtils.RANGE_WEEK_CENTER, 
                         DateUtils.RANGE_MONTH_SUNDAY, DateUtils.RANGE_MONTH_MONDAY})
    void iterator_ValidRangeStyles_ReturnsNonNullIterator(int rangeStyle) {
        Calendar calendar = Calendar.getInstance();
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);
        assertNotNull(iterator);
    }

    @Test
    void iterator_RangeWeekSunday_CorrectStartAndEnd() {
        Calendar focus = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        focus.set(2023, Calendar.AUGUST, 30); // Wednesday, August 30, 2023
        Iterator<Calendar> iterator = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);

        Calendar first = iterator.next();
        assertEquals(2023, first.get(Calendar.YEAR));
        assertEquals(Calendar.AUGUST, first.get(Calendar.MONTH));
        assertEquals(27, first.get(Calendar.DAY_OF_MONTH)); // Sunday

        Calendar last = null;
        while (iterator.hasNext()) {
            last = iterator.next();
        }
        assertNotNull(last);
        assertEquals(2, last.get(Calendar.DAY_OF_WEEK));
        assertEquals(2, last.get(Calendar.WEEK_OF_YEAR));
    }
}