package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Method;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

public class MethodUtilsTest {

    // Helper classes for testing
    public static class TestClass {
        public void exactMethod(String param) {}
        public void varArgsMethod(String... params) {}
        protected void protectedMethod(Integer param) {}
        private void privateMethod(Double param) {}
        public void overloadedMethod(String param) {}
        public void overloadedMethod(Object param) {}
        public void overloadedMethod(String param1, String param2) {}
    }

    public static class SubTestClass extends TestClass {
        @Override
        public void exactMethod(String param) {}
        public void subClassMethod() {}
    }

    @Test
    void testGetMatchingAccessibleMethod_ExactMatch() throws Exception {
        Method method = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "exactMethod", String.class);
        assertNotNull(method);
        assertEquals("exactMethod", method.getName());
    }

    @Test
    void testGetMatchingAccessibleMethod_NoExactMatch_SingleAccessibleMethod() throws Exception {
        Method method = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "protectedMethod", Integer.class);
        assertNotNull(method);
        assertEquals("protectedMethod", method.getName());
    }

    @Test
    void testGetMatchingAccessibleMethod_NoExactMatch_NoMatchingMethod() throws Exception {
        Method method = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "nonExistentMethod", String.class);
        assertNull(method);
    }

    @Test
    void testGetMatchingAccessibleMethod_MultipleMatchingMethods_BestMatchSelected() throws Exception {
        Method method = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "overloadedMethod", String.class);
        assertNotNull(method);
        assertEquals("overloadedMethod", method.getName());
        assertEquals(1, method.getParameterCount());
        assertEquals(String.class, method.getParameterTypes()[0]);
    }

    @Test
    void testGetMatchingAccessibleMethod_MultipleMatchingMethods_NoBestMatch() {
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            MethodUtils.getMatchingAccessibleMethod(TestClass.class, "overloadedMethod", null, null, String.class);
        });
        assertTrue(exception.getMessage().contains("Found multiple candidates for method overloadedMethod"));
    }

    @Test
    void testGetMatchingAccessibleMethod_VarArgsMethod_CorrectMatch() throws Exception {
        Method method = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "varArgsMethod", String[].class);
        assertNotNull(method);
        assertTrue(method.isVarArgs());
    }

    @Test
    void testGetMatchingAccessibleMethod_InvalidParameterTypes_NoMatch() throws Exception {
        Method method = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "exactMethod", Integer.class);
        assertNull(method);
    }

    @Test
    void testGetMatchingAccessibleMethod_NullClass() {
        assertThrows(NullPointerException.class, () -> {
            MethodUtils.getMatchingAccessibleMethod(null, "anyMethod", String.class);
        });
    }

    @Test
    void testGetMatchingAccessibleMethod_NullMethodName() {
        assertThrows(NullPointerException.class, () -> {
            MethodUtils.getMatchingAccessibleMethod(TestClass.class, null, String.class);
        });
    }

    @Test
    void testGetMatchingAccessibleMethod_NullParameterTypes() throws Exception {
        Method method = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "exactMethod");
        assertNotNull(method);
        assertEquals("exactMethod", method.getName());
    }

    @Test
    void testGetMatchingAccessibleMethod_PrivateMethod() throws Exception {
        Method method = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "privateMethod", Double.class);
        assertNull(method);
    }

    @Test
    void testGetMatchingAccessibleMethod_SubClassMethod() throws Exception {
        Method method = MethodUtils.getMatchingAccessibleMethod(SubTestClass.class, "subClassMethod");
        assertNotNull(method);
        assertEquals("subClassMethod", method.getName());
    }

    @Test
    void testGetMatchingAccessibleMethod_InheritedMethod() throws Exception {
        Method method = MethodUtils.getMatchingAccessibleMethod(SubTestClass.class, "exactMethod", String.class);
        assertNotNull(method);
        assertEquals("exactMethod", method.getName());
        assertEquals(SubTestClass.class, method.getDeclaringClass());
    }

    @Test
    void testGetMatchingAccessibleMethod_VarArgsWithMultipleParameters() throws Exception {
        Method method = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "varArgsMethod", String.class, String.class);
        assertNotNull(method);
        assertTrue(method.isVarArgs());
    }

    @Test
    void testGetMatchingAccessibleMethod_MethodWithNoParameters() throws Exception {
        Method method = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "subClassMethod");
        assertNotNull(method);
        assertEquals("subClassMethod", method.getName());
        assertEquals(0, method.getParameterCount());
    }

    @Test
    void testGetMatchingAccessibleMethod_MethodWithMultipleParameters() throws Exception {
        Method method = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "overloadedMethod", String.class, String.class);
        assertNotNull(method);
        assertEquals("overloadedMethod", method.getName());
        assertEquals(2, method.getParameterCount());
    }

    @Test
    void testGetMatchingAccessibleMethod_MethodFromInterface() throws Exception {
        Method method = MethodUtils.getMatchingAccessibleMethod(InterfaceImpl.class, "interfaceMethod");
        assertNotNull(method);
        assertEquals("interfaceMethod", method.getName());
    }

    @Test
    void testGetMatchingAccessibleMethod_MethodFromSuperclassInterface() throws Exception {
        Method method = MethodUtils.getMatchingAccessibleMethod(SubInterfaceImpl.class, "interfaceMethod");
        assertNotNull(method);
        assertEquals("interfaceMethod", method.getName());
    }

    @Test
    void testGetMatchingAccessibleMethod_StaticMethod() throws Exception {
        Method method = MethodUtils.getMatchingAccessibleMethod(StaticMethods.class, "staticMethod", String.class);
        assertNotNull(method);
        assertEquals("staticMethod", method.getName());
    }

    @Test
    void testGetMatchingAccessibleMethod_MethodWithPrimitiveParameter() throws Exception {
        Method method = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "exactMethod", String.class);
        assertNotNull(method);
        assertEquals("exactMethod", method.getName());
    }

    // Additional helper interfaces and classes
    public interface TestInterface {
        void interfaceMethod();
    }

    public static class InterfaceImpl implements TestInterface {
        public void interfaceMethod() {}
    }

    public static class SubInterfaceImpl extends InterfaceImpl {
        @Override
        public void interfaceMethod() {}
    }

    public static class StaticMethods {
        public static void staticMethod(String param) {}
    }
}