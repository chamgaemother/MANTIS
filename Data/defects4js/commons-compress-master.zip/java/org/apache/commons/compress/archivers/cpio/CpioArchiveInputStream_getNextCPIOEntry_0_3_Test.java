package org.apache.commons.compress.archivers.cpio;

import org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.utils.IOUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.EOFException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;

public class CpioArchiveInputStream_getNextCPIOEntry_0_3_Test {

    @Test
    @DisplayName("Ensures IOException is thrown when stream is closed")
    public void TC11_EnsuresIOExceptionIsThrownWhenStreamIsClosed() throws Exception {
        // GIVEN
        byte[] emptyData = new byte[0];
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(emptyData);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(byteArrayInputStream);

        // Using reflection to set the 'closed' field to true
        Field closedField = CpioArchiveInputStream.class.getDeclaredField("closed");
        closedField.setAccessible(true);
        closedField.setBoolean(cpioInputStream, true);

        // WHEN & THEN
        IOException exception = assertThrows(IOException.class, () -> {
            cpioInputStream.getNextCPIOEntry();
        });
        assertEquals("Stream closed", exception.getMessage());
    }

    @Test
    @DisplayName("Handles multiple iterations by reading multiple entries sequentially")
    public void TC12_HandlesMultipleIterationsByReadingMultipleEntriesSequentially() throws Exception {
        // GIVEN
        // Simulated data for multiple entries followed by CPIO_TRAILER
        byte[] multipleEntriesData = new byte[] {
            // Entry 1
            0x07, 0x07, 0x01, // MAGIC_NEW
            // Additional bytes to simulate a valid entry
            // Entry 2
            0x07, 0x07, 0x02, // MAGIC_NEW_CRC
            // Additional bytes to simulate a valid entry
            // Trailer
            0x54, 0x52, 0x41, 0x49, 0x4C, 0x45, 0x52, 0x21, 0x21, 0x21 // "TRAILER!!!"
        };
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(multipleEntriesData);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(byteArrayInputStream);

        // WHEN
        CpioArchiveEntry firstEntry = cpioInputStream.getNextCPIOEntry();
        CpioArchiveEntry secondEntry = cpioInputStream.getNextCPIOEntry();
        CpioArchiveEntry trailerEntry = cpioInputStream.getNextCPIOEntry();

        // THEN
        assertNotNull(firstEntry, "First entry should not be null");
        assertNotNull(secondEntry, "Second entry should not be null");
        assertNull(trailerEntry, "Trailer entry should be null");
        
        // Using reflection to check 'entryEOF' field
        Field entryEOFField = CpioArchiveInputStream.class.getDeclaredField("entryEOF");
        entryEOFField.setAccessible(true);
        boolean isEntryEOF = entryEOFField.getBoolean(cpioInputStream);
        assertTrue(isEntryEOF, "entryEOF should be true after reading trailer");
    }

    @Test
    @DisplayName("Throws IOException for entry with mode 0 but name not equal to CPIO_TRAILER")
    public void TC13_ThrowsIOExceptionForEntryWithMode0ButNameNotEqualToCPIO_TRAILER() throws Exception {
        // GIVEN
        // Simulated data with MAGIC_NEW and entry mode 0, name not "TRAILER!!!"
        byte[] invalidModeData = new byte[] {
            0x07, 0x07, 0x01, // MAGIC_NEW
            0x00, 0x00, 0x00, 0x00, // mode = 0
            // Additional bytes to simulate a non-trailer name
            0x66, 0x69, 0x6C, 0x65, 0x31 // "file1"
        };
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(invalidModeData);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(byteArrayInputStream);

        // WHEN & THEN
        IOException exception = assertThrows(IOException.class, () -> {
            cpioInputStream.getNextCPIOEntry();
        });
        assertTrue(exception.getMessage().contains("Mode 0 only allowed in the trailer"), "Exception message should indicate invalid mode for entry name");
    }

    @Test
    @DisplayName("Handles empty buffer2 resulting in EOFException")
    public void TC14_HandlesEmptyBuffer2ResultingInEOFException() throws Exception {
        // GIVEN
        // Simulated empty buffer2
        byte[] emptyBufferData = new byte[0];
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(emptyBufferData);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(byteArrayInputStream);

        // WHEN & THEN
        EOFException exception = assertThrows(EOFException.class, () -> {
            cpioInputStream.getNextCPIOEntry();
        });
        assertEquals("EOFException", exception.getClass().getSimpleName(), "Exception should indicate end of file reached unexpectedly");
    }

    @Test
    @DisplayName("Processes multiple MAGIC_OLD_BINARY entries with alternating byte swap")
    public void TC15_ProcessesMultipleMAGIC_OLD_BINARYEntriesWithAlternatingByteSwap() throws Exception {
        // GIVEN
        // Simulated data with multiple MAGIC_OLD_BINARY entries with alternating byte swap
        byte[] multipleOldBinaryData = new byte[] {
            // Entry 1 with byte swap
            0x00, 0x00, 0x00, 0x01, // MAGIC_OLD_BINARY with byte swap
            // Additional bytes to simulate a valid entry
            // Entry 2 without byte swap
            0x07, 0x07, 0x01, // MAGIC_NEW
            // Additional bytes to simulate a valid entry
        };
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(multipleOldBinaryData);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(byteArrayInputStream);

        // WHEN
        CpioArchiveEntry firstEntry = cpioInputStream.getNextCPIOEntry();
        CpioArchiveEntry secondEntry = cpioInputStream.getNextCPIOEntry();

        // THEN
        assertNotNull(firstEntry, "First MAGIC_OLD_BINARY entry should not be null");
        // Assuming CpioArchiveEntry has a method isByteSwapped() to check byte swap
        Method isByteSwappedMethod = CpioArchiveEntry.class.getDeclaredMethod("isByteSwapped");
        isByteSwappedMethod.setAccessible(true);
        boolean firstEntryByteSwap = (boolean) isByteSwappedMethod.invoke(firstEntry);
        assertTrue(firstEntryByteSwap, "First entry should have byte swap enabled");

        assertNotNull(secondEntry, "Second entry should not be null");
        boolean secondEntryByteSwap = (boolean) isByteSwappedMethod.invoke(secondEntry);
        assertFalse(secondEntryByteSwap, "Second entry should not have byte swap enabled");
    }
}