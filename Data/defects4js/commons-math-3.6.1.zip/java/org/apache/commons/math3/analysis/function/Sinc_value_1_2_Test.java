package org.apache.commons.math3.analysis.function;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.util.FastMath;

public class Sinc_value_1_2_Test {

    @Test
    @DisplayName("value(1.0e-3) with normalized=true and |x| < SHORTCUT/Ï evaluates the Taylor series branch")
    public void TC18() {
        // GIVEN
        Sinc sinc = new Sinc(true);
        // WHEN
        double result = sinc.value(1.0e-3);
        // THEN
        double scaledX = FastMath.PI * 1.0e-3;
        double scaledX2 = scaledX * scaledX;
        double expectedValue = ((scaledX2 - 20) * scaledX2 + 120) / 120;
        assertEquals(expectedValue, result, 1e-10);
    }

    @Test
    @DisplayName("value(1.9098593e-3) with normalized=true and |x| equals SHORTCUT/Ï evaluates the Taylor series branch")
    public void TC19() {
        // GIVEN
        Sinc sinc = new Sinc(true);
        // WHEN
        double result = sinc.value(1.9098593e-3);
        // THEN
        double scaledX = FastMath.PI * 1.9098593e-3;
        double scaledX2 = scaledX * scaledX;
        double expectedValue = ((scaledX2 - 20) * scaledX2 + 120) / 120;
        assertEquals(expectedValue, result, 1e-10);
    }

    @Test
    @DisplayName("value(1.0) with normalized=true and |x| > SHORTCUT/Ï evaluates the sine definition expression branch")
    public void TC20() {
        // GIVEN
        Sinc sinc = new Sinc(true);
        // WHEN
        double result = sinc.value(1.0);
        // THEN
        double expected = FastMath.sin(FastMath.PI) / FastMath.PI;
        assertEquals(expected, result, 1e-10);
    }

    @Test
    @DisplayName("value(NaN) with normalized=false handles NaN input gracefully")
    public void TC21() {
        // GIVEN
        Sinc sinc = new Sinc(false);
        // WHEN
        double result = sinc.value(Double.NaN);
        // THEN
        assertTrue(Double.isNaN(result));
    }

    @Test
    @DisplayName("value(Infinity) with normalized=false handles Infinity input gracefully")
    public void TC22() {
        // GIVEN
        Sinc sinc = new Sinc(false);
        // WHEN
        double result = sinc.value(Double.POSITIVE_INFINITY);
        // THEN
        assertTrue(Double.isNaN(result));
    }
}