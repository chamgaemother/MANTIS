package org.apache.commons.codec.language;

import org.apache.commons.codec.EncoderException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Nysiis_nysiis_0_2_Test {

    @Test
    @DisplayName("nysiis(\"PHILLIP\") correctly transcodes \"PH\" to \"FF\"")
    void TC06_nysiis_prefix_PH() throws EncoderException {
        // Initialize the Nysiis encoder
        Nysiis nysiis = new Nysiis();

        // Given
        String input = "PHILLIP";

        // When
        String result = nysiis.nysiis(input);

        // Then
        assertEquals("FFILLIP", result);
    }

    @Test
    @DisplayName("nysiis(\"SCHOLAR\") correctly transcodes \"SCH\" to \"SSS\"")
    void TC07_nysiis_prefix_SCH() throws EncoderException {
        // Initialize the Nysiis encoder
        Nysiis nysiis = new Nysiis();

        // Given
        String input = "SCHOLAR";

        // When
        String result = nysiis.nysiis(input);

        // Then
        assertEquals("SSSOLAR", result);
    }

    @Test
    @DisplayName("nysiis(\"JEE\") correctly transcodes ending \"EE\" to \"Y\"")
    void TC08_nysiis_suffix_EE() throws EncoderException {
        // Initialize the Nysiis encoder
        Nysiis nysiis = new Nysiis();

        // Given
        String input = "JEE";

        // When
        String result = nysiis.nysiis(input);

        // Then
        assertEquals("JY", result);
    }

    @Test
    @DisplayName("nysiis(\"MARIE\") correctly transcodes ending \"IE\" to \"Y\"")
    void TC09_nysiis_suffix_IE() throws EncoderException {
        // Initialize the Nysiis encoder
        Nysiis nysiis = new Nysiis();

        // Given
        String input = "MARIE";

        // When
        String result = nysiis.nysiis(input);

        // Then
        assertEquals("MARY", result);
    }

    @Test
    @DisplayName("nysiis(\"ROAD\") correctly transcodes ending \"RD\" to \"D\"")
    void TC10_nysiis_suffix_RD() throws EncoderException {
        // Initialize the Nysiis encoder
        Nysiis nysiis = new Nysiis();

        // Given
        String input = "ROAD";

        // When
        String result = nysiis.nysiis(input);

        // Then
        assertEquals("ROAD", result);
    }
}