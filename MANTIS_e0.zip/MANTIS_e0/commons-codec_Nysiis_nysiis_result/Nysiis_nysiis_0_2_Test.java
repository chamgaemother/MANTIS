
package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Nysiis_nysiis_0_2_Test {

    @Test
    @DisplayName("nysiis(\"PHILLIPS\") replaces PH with FF")
    void test_TC06() {
        Nysiis nysiis = new Nysiis();
        String input = "PHILLIPS";
        String result = nysiis.nysiis(input);
        assertTrue(result.contains("FF"));
    }

    @Test
    @DisplayName("nysiis(\"SCHAEFER\") replaces SCH with SSS")
    void test_TC07() {
        Nysiis nysiis = new Nysiis();
        String input = "SCHAEFER";
        String result = nysiis.nysiis(input);
        assertTrue(result.contains("SSS"));
    }

    @Test
    @DisplayName("nysiis(\"LEE\") replaces EE with Y")
    void test_TC08() {
        Nysiis nysiis = new Nysiis();
        String input = "LEE";
        String result = nysiis.nysiis(input);
        assertTrue(result.endsWith("Y"));
    }

    @Test
    @DisplayName("nysiis(\"DIE\") replaces IE with Y")
    void test_TC09() {
        Nysiis nysiis = new Nysiis();
        String input = "DIE";
        String result = nysiis.nysiis(input);
        assertTrue(result.endsWith("Y"));
    }

    @Test
    @DisplayName("nysiis(\"EDWARD\") replaces DT with D")
    void test_TC10() {
        Nysiis nysiis = new Nysiis();
        String input = "EDWARD";
        String result = nysiis.nysiis(input);
        assertTrue(result.endsWith("D"));
    }

}