package org.apache.commons.compress.harmony.pack200;

import org.apache.commons.compress.harmony.pack200.BHSDCodec;
import org.apache.commons.compress.harmony.pack200.Codec;
import org.apache.commons.compress.harmony.pack200.CodecEncoding;
import org.apache.commons.compress.harmony.pack200.Pack200Exception;
import org.apache.commons.compress.harmony.pack200.PopulationCodec;
import org.apache.commons.compress.harmony.pack200.RunCodec;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.EOFException;

import static org.junit.jupiter.api.Assertions.*;

public class CodecEncoding_getCodec_0_2_Test {

    @Test
    @DisplayName("Returns new BHSDCodec on valid stream read for value 116")
    public void testGetCodec_validStreamFor116() throws Exception {
        // GIVEN
        int value = 116;
        int[] streamData = {0x07, 0x05};  // Valid dummy data for BHSDCodec
        InputStream in = new ByteArrayInputStream(new byte[]{(byte) streamData[0], (byte) streamData[1]});
        Codec defaultCodec = new BHSDCodec(1, 256);  // Use an existing codec object instead of new Codec()

        // WHEN
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);

        // THEN
        assertTrue(result instanceof BHSDCodec, "Result should be an instance of BHSDCodec");
    }

    @Test
    @DisplayName("Throws Pack200Exception if value between 117 and 140 and adef and bdef are both true")
    public void testGetCodec_Pack200Exception_dueToBothAdefBdefTrue() throws Exception {
        // GIVEN
        int value = 130;  // Calculated to result in both adef and bdef as true
        InputStream in = new ByteArrayInputStream(new byte[] { 0, 0 });  // No-op to trigger condition in test
        Codec defaultCodec = new BHSDCodec(1, 256);  // Use an existing codec object instead of new Codec()

        // WHEN & THEN
        Pack200Exception exception = assertThrows(Pack200Exception.class, () -> {
            CodecEncoding.getCodec(value, in, defaultCodec);
        });
        assertEquals("ADef and BDef should never both be true", exception.getMessage(), "Exception message should match");
    }

    @Test
    @DisplayName("Returns new RunCodec when conditions are favorable for value between 117 and 140")
    public void testGetCodec_runCodecForBetween117And140() throws Exception {
        // GIVEN
        int value = 125; // Suitable for RunCodec creation
        InputStream in = new ByteArrayInputStream(new byte[]{12, 0});
        Codec defaultCodec = new BHSDCodec(1, 256);  // Use an existing codec object instead of new Codec()

        // WHEN
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);

        // THEN
        assertTrue(result instanceof RunCodec, "Result should be an instance of RunCodec");
    }

    @Test
    @DisplayName("Throws Pack200Exception for invalid value over 188")
    public void testGetCodec_invalidValueOver188() throws Exception {
        // GIVEN
        int value = 189;
        InputStream in = InputStream.nullInputStream();
        Codec defaultCodec = new BHSDCodec(1, 256);  // Use an existing codec object instead of new Codec()

        // WHEN & THEN
        Pack200Exception exception = assertThrows(Pack200Exception.class, () -> {
            CodecEncoding.getCodec(value, in, defaultCodec);
        });
        assertEquals("Invalid codec encoding byte (189) found", exception.getMessage(), "Exception message should match");
    }

    @Test
    @DisplayName("Returns new PopulationCodec when value is between 141 and 188")
    public void testGetCodec_populationCodecForBetween141And188() throws Exception {
        // GIVEN
        int value = 150;
        InputStream in = new ByteArrayInputStream(new byte[]{0, 0, 0});  // Dummy data
        Codec defaultCodec = new BHSDCodec(1, 256);  // Use an existing codec object instead of new Codec()

        // WHEN
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);

        // THEN
        assertTrue(result instanceof PopulationCodec, "Result should be an instance of PopulationCodec");
    }
}
