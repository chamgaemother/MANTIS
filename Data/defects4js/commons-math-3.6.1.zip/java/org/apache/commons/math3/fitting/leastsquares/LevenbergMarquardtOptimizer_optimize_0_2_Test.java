package org.apache.commons.math3.fitting.leastsquares;

import org.apache.commons.math3.linear.RealVector;
import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.optim.ConvergenceChecker;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Test class for LevenbergMarquardtOptimizer.optimize method.
 */
public class LevenbergMarquardtOptimizer_optimize_0_2_Test {

    /**
     * Test TC06: Optimize with non-converging LeastSquaresProblem eventually throws ConvergenceException
     */
    @Test
    @DisplayName("Optimize with non-converging LeastSquaresProblem eventually throws ConvergenceException")
    public void testTC06() {
        // GIVEN
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        LeastSquaresProblem problem = createNonConvergingProblem();

        // WHEN & THEN
        assertThrows(ConvergenceException.class, () -> {
            optimizer.optimize(problem);
        }, "Expected ConvergenceException to be thrown for non-converging problem");
    }

    /**
     * Test TC07: Optimize with LeastSquaresProblem causing rank-deficient Jacobian handled correctly
//     */
//    @Test
//    @DisplayName("Optimize with LeastSquaresProblem causing rank-deficient Jacobian handled correctly")
//    public void testTC07() {
//        // GIVEN
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//        LeastSquaresProblem problem = createProblemWithRankDeficientJacobian();
//
//        // WHEN
//        LeastSquaresOptimizer.Optimum result = optimizer.optimize(problem);
//
//        // THEN
//        assertNotNull(result, "Optimum should not be null for rank-deficient Jacobian");
//        assertTrue(result.getEvaluations() >= 1, "Optimizer should have performed at least one evaluation");
//    }

    /**
     * Test TC08: Optimize with initialStepBoundFactor set to zero initializes delta correctly
     */
    @Test
    @DisplayName("Optimize with initialStepBoundFactor set to zero initializes delta correctly")
    public void testTC08() {
        // GIVEN
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        LeastSquaresProblem problem = createProblemWithInitialStepBoundFactorZero();

        // WHEN
        LeastSquaresOptimizer.Optimum result = optimizer.optimize(problem);

        // THEN
        assertNotNull(result, "Optimum should not be null when initialStepBoundFactor is zero");
        // Use reflection to access 'delta'
        double actualDelta = getDeltaFromOptimizer(optimizer);
        assertEquals(0.0, actualDelta, "Delta should be zero when initialStepBoundFactor is zero");
    }

    /**
     * Test TC09: Optimize with convergenceChecker that immediately accepts convergence
     */
//    @Test
//    @DisplayName("Optimize with convergenceChecker that immediately accepts convergence")
//    public void testTC09() {
//        // GIVEN
//        ConvergenceChecker<LevenbergMarquardtOptimizer_optimize_0_1_Test.Evaluation> checker = createImmediateConvergenceChecker();
//        LeastSquaresProblem problem = createProblemWithCustomChecker(checker);
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//
//        // WHEN
//        LeastSquaresOptimizer.Optimum result = optimizer.optimize(problem);
//
//        // THEN
//        assertNotNull(result, "Optimum should not be null when convergence is immediately accepted");
//        assertEquals(0, result.getEvaluations(), "Optimizer should perform zero evaluations when convergence is immediate");
//    }

    /**
     * Test TC10: Optimize with maximum delta exceeding threshold adjusts lmPar accordingly
     */
    @Test
    @DisplayName("Optimize with maximum delta exceeding threshold adjusts lmPar accordingly")
    public void testTC10() {
        // GIVEN
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        LeastSquaresProblem problem = createProblemWithLargeDelta();

        // WHEN
        LeastSquaresOptimizer.Optimum result = optimizer.optimize(problem);

        // THEN
        assertNotNull(result, "Optimum should not be null when initial delta is large");
        // Use reflection to access 'lmPar'
        double actualLmPar = getLmParFromOptimizer(optimizer);
        assertTrue(actualLmPar >= 0, "lmPar should be non-negative when adjusted correctly");
    }

    // Helper methods for creating test scenarios

    /**
     * Creates a LeastSquaresProblem that does not satisfy convergence criteria within iteration limits.
     *
     * @return a mocked LeastSquaresProblem
     */
    private LeastSquaresProblem createNonConvergingProblem() {
        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
        when(problem.getObservationSize()).thenReturn(10);
        when(problem.getParameterSize()).thenReturn(5);
        when(problem.getStart()).thenReturn(new ArrayRealVector(new double[]{1, 1, 1, 1, 1}));
        when(problem.getConvergenceChecker()).thenReturn((iteration, previous, current) -> false); // Never converges
        return problem;
    }

    /**
     * Creates a LeastSquaresProblem with a rank-deficient Jacobian matrix.
     *
     * @return a mocked LeastSquaresProblem
     */
//    private LeastSquaresProblem createProblemWithRankDeficientJacobian() {
//        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
//        when(problem.getObservationSize()).thenReturn(10);
//        when(problem.getParameterSize()).thenReturn(5);
//        when(problem.getStart()).thenReturn(new ArrayRealVector(new double[]{1, 1, 1, 1, 1}));
//        // Mock a rank-deficient Jacobian
//        LeastSquaresProblem.Evaluation evaluation = mock(LeastSquaresProblem.Evaluation.class);
//        when(evaluation.getJacobian()).thenReturn(mock(ArrayRealVector.class));
//        when(problem.evaluate(any(RealVector.class))).thenReturn(evaluation);
//        return problem;
//    }

    /**
     * Creates a LeastSquaresProblem with initialStepBoundFactor set to zero.
     *
     * @return a mocked LeastSquaresProblem
     */
    private LeastSquaresProblem createProblemWithInitialStepBoundFactorZero() {
        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
        when(problem.getObservationSize()).thenReturn(10);
        when(problem.getParameterSize()).thenReturn(5);
        when(problem.getStart()).thenReturn(new ArrayRealVector(new double[]{0, 0, 0, 0, 0}));
        when(problem.getConvergenceChecker()).thenReturn((iteration, previous, current) -> true); // Immediate convergence for simplicity
        return problem;
    }

    /**
     * Creates a custom ConvergenceChecker that immediately accepts convergence.
     *
     * @return a mocked ConvergenceChecker
     */
    private ConvergenceChecker<LevenbergMarquardtOptimizer_optimize_0_1_Test.Evaluation> createImmediateConvergenceChecker() {
        return (iteration, previous, current) -> true;
    }

    /**
     * Creates a LeastSquaresProblem with a custom convergence checker.
     *
     * @param checker the custom ConvergenceChecker
     * @return a mocked LeastSquaresProblem
     */
//    private LeastSquaresProblem createProblemWithCustomChecker(ConvergenceChecker<LevenbergMarquardtOptimizer_optimize_0_1_Test.Evaluation> checker) {
//        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
//        when(problem.getObservationSize()).thenReturn(10);
//        when(problem.getParameterSize()).thenReturn(5);
//        when(problem.getStart()).thenReturn(new ArrayRealVector(new double[]{1, 2, 3, 4, 5}));
//        when(problem.getConvergenceChecker()).thenReturn(checker);
//        return problem;
//    }

    /**
     * Creates a LeastSquaresProblem with a large initial delta causing lmPar to adjust.
     *
     * @return a mocked LeastSquaresProblem
     */
    private LeastSquaresProblem createProblemWithLargeDelta() {
        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
        when(problem.getObservationSize()).thenReturn(10);
        when(problem.getParameterSize()).thenReturn(5);
        when(problem.getStart()).thenReturn(new ArrayRealVector(new double[]{1000, 1000, 1000, 1000, 1000}));
        when(problem.getConvergenceChecker()).thenReturn((iteration, previous, current) -> false); // To trigger delta adjustment
        return problem;
    }

    /**
     * Retrieves the delta value from the optimizer using reflection.
     *
     * @param optimizer the LevenbergMarquardtOptimizer instance
     * @return the delta value
     */
    private double getDeltaFromOptimizer(LevenbergMarquardtOptimizer optimizer) {
        try {
            Field deltaField = LevenbergMarquardtOptimizer.class.getDeclaredField("delta");
            deltaField.setAccessible(true);
            return deltaField.getDouble(optimizer);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Failed to retrieve delta from optimizer: " + e.getMessage());
            return Double.NaN;
        }
    }

    /**
     * Retrieves the lmPar value from the optimizer using reflection.
     *
     * @param optimizer the LevenbergMarquardtOptimizer instance
     * @return the lmPar value
     */
    private double getLmParFromOptimizer(LevenbergMarquardtOptimizer optimizer) {
        try {
            Field lmParField = LevenbergMarquardtOptimizer.class.getDeclaredField("lmPar");
            lmParField.setAccessible(true);
            return lmParField.getDouble(optimizer);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Failed to retrieve lmPar from optimizer: " + e.getMessage());
            return Double.NaN;
        }
    }
}
