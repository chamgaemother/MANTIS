package org.apache.commons.lang3.math;


import org.apache.commons.lang3.math.NumberUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class NumberUtils_isCreatable_2_2_Test {

    @Test
    @DisplayName("isCreatable(\".\") returns false when input string is only a decimal point")
    public void TC46_isCreatable_decimalOnly() {
        // GIVEN
        String input = ".";
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        // THEN
        assertFalse(result, "Expected isCreatable(\".\") to return false");
    }

    @Test
    @DisplayName("isCreatable(\"1e2e3\") returns false for multiple exponents")
    public void TC47_isCreatable_multipleExponents() {
        // GIVEN
        String input = "1e2e3";
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        // THEN
        assertFalse(result, "Expected isCreatable(\"1e2e3\") to return false");
    }

    @Test
    @DisplayName("isCreatable(\"0x1A3F.\") returns false for trailing decimal point after valid hexadecimal")
    public void TC48_isCreatable_invalidHexTrailingDecimal() {
        // GIVEN
        String input = "0x1A3F.";
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        // THEN
        assertFalse(result, "Expected isCreatable(\"0x1A3F.\") to return false");
    }

    @Test
    @DisplayName("isCreatable(\"1e10f\") returns true for float type qualifier with exponent")
    public void TC49_isCreatable_floatQualifier_withExponent() {
        // GIVEN
        String input = "1e10f";
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        // THEN
        assertTrue(result, "Expected isCreatable(\"1e10f\") to return true");
    }

    @Test
    @DisplayName("isCreatable(\"1e10d\") returns true for double type qualifier with exponent")
    public void TC50_isCreatable_doubleQualifier_withExponent() {
        // GIVEN
        String input = "1e10d";
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        // THEN
        assertTrue(result, "Expected isCreatable(\"1e10d\") to return true");
    }

}