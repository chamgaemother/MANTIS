// package org.apache.commons.math3.geometry.euclidean.threed;
// import java.lang.reflect.*;
// import static org.mockito.Mockito.*;
// import java.io.*;
// import java.util.*;
// // import java.lang.reflect.*;
// // import static org.mockito.Mockito.*;
// // import java.io.*;
// // import java.util.*;
// // import org.apache.commons.math3.geometry.euclidean.threed.CardanEulerSingularityException;
// // 
// // import org.apache.commons.math3.RealFieldElement;
// // import org.apache.commons.math3.exception.CardanEulerSingularityException;
// // import org.apache.commons.math3.util.Decimal64;
// // import org.junit.jupiter.api.DisplayName;
// // import org.junit.jupiter.api.Test;
// // 
// // import static org.junit.jupiter.api.Assertions.*;
// // 
// public class FieldRotation_getAngles_2_3_Test {
// // 
// //     @Test
// //     @DisplayName("getAngles called with RotationOrder.XYX and RotationConvention.FRAME_TRANSFORM, v2.getX() within bounds")
// //     void TC16_testGetAngles_XYX_FRAME_TRANSFORM_withinBounds() {
//         // GIVEN
// //         RotationOrder order = RotationOrder.XYX;
// //         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
//         // Initialize q0, q1, q2, q3 with Decimal64 elements
// //         Decimal64 q0 = new Decimal64(0.7071067811865476);
// //         Decimal64 q1 = new Decimal64(0.0);
// //         Decimal64 q2 = new Decimal64(0.7071067811865475);
// //         Decimal64 q3 = new Decimal64(0.0);
// //         FieldRotation<Decimal64> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// //         
//         // WHEN
// //         Decimal64[] angles = rotation.getAngles(order, convention);
// //         
//         // THEN
// //         assertNotNull(angles, "Angles array should not be null");
// //         assertEquals(3, angles.length, "Angles array should have length 3");
//         // Additional assertions based on expected angle values can be added here
// //     }
// // 
// //     @Test
// //     @DisplayName("getAngles called with RotationOrder.XYX and RotationConvention.FRAME_TRANSFORM, v2.getX() out of bounds triggering exception")
// //     void TC17_testGetAngles_XYX_FRAME_TRANSFORM_outOfBounds_exception() {
//         // GIVEN
// //         RotationOrder order = RotationOrder.XYX;
// //         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
//         // Initialize q0, q1, q2, q3 to cause v2.getX() out of bounds
// //         Decimal64 q0 = new Decimal64(-1.0);
// //         Decimal64 q1 = new Decimal64(0.0);
// //         Decimal64 q2 = new Decimal64(0.0);
// //         Decimal64 q3 = new Decimal64(0.0);
// //         FieldRotation<Decimal64> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// //         
//         // WHEN / THEN
// //         assertThrows(CardanEulerSingularityException.class, () -> rotation.getAngles(order, convention), "Expected CardanEulerSingularityException");
// //     }
// // 
// //     @Test
// //     @DisplayName("getAngles called with RotationOrder.XZX and RotationConvention.FRAME_TRANSFORM, v2.getX() within bounds")
// //     void TC18_testGetAngles_XZX_FRAME_TRANSFORM_withinBounds() {
//         // GIVEN
// //         RotationOrder order = RotationOrder.XZX;
// //         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
//         // Initialize q0, q1, q2, q3 with Decimal64 elements
// //         Decimal64 q0 = new Decimal64(0.8660254037844387);
// //         Decimal64 q1 = new Decimal64(0.0);
// //         Decimal64 q2 = new Decimal64(0.5);
// //         Decimal64 q3 = new Decimal64(0.0);
// //         FieldRotation<Decimal64> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// //         
//         // WHEN
// //         Decimal64[] angles = rotation.getAngles(order, convention);
// //         
//         // THEN
// //         assertNotNull(angles, "Angles array should not be null");
// //         assertEquals(3, angles.length, "Angles array should have length 3");
//         // Additional assertions based on expected angle values can be added here
// //     }
// // 
// //     @Test
// //     @DisplayName("getAngles called with RotationOrder.XZX and RotationConvention.FRAME_TRANSFORM, v2.getX() out of bounds triggering exception")
// //     void TC19_testGetAngles_XZX_FRAME_TRANSFORM_outOfBounds_exception() {
//         // GIVEN
// //         RotationOrder order = RotationOrder.XZX;
// //         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
//         // Initialize q0, q1, q2, q3 to cause v2.getX() out of bounds
// //         Decimal64 q0 = new Decimal64(-1.0);
// //         Decimal64 q1 = new Decimal64(0.0);
// //         Decimal64 q2 = new Decimal64(0.0);
// //         Decimal64 q3 = new Decimal64(0.0);
// //         FieldRotation<Decimal64> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// //         
//         // WHEN / THEN
// //         assertThrows(CardanEulerSingularityException.class, () -> rotation.getAngles(order, convention), "Expected CardanEulerSingularityException");
// //     }
// // 
// //     @Test
// //     @DisplayName("getAngles called with RotationOrder.ZYX and RotationConvention.FRAME_TRANSFORM, v2.getX() within bounds")
// //     void TC20_testGetAngles_ZYX_FRAME_TRANSFORM_withinBounds() {
//         // GIVEN
// //         RotationOrder order = RotationOrder.ZYX;
// //         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
//         // Initialize q0, q1, q2, q3 with Decimal64 elements
// //         Decimal64 q0 = new Decimal64(0.9848077530122081);
// //         Decimal64 q1 = new Decimal64(0.17364817766693041);
// //         Decimal64 q2 = new Decimal64(0.0);
// //         Decimal64 q3 = new Decimal64(0.0);
// //         FieldRotation<Decimal64> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// //         
//         // WHEN
// //         Decimal64[] angles = rotation.getAngles(order, convention);
// //         
//         // THEN
// //         assertNotNull(angles, "Angles array should not be null");
// //         assertEquals(3, angles.length, "Angles array should have length 3");
//         // Additional assertions based on expected angle values can be added here
// //     }
// // }
// }