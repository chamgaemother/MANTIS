package org.apache.commons.jxpath.ri.model.beans;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

import org.apache.commons.jxpath.JXPathBeanInfo;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class BeanPointer_equals_2_1_Test {

    @Test
    @DisplayName("object is BeanPointer with same parent, qName not null and equal, index is specific, beans are different custom objects")
    void TC19_equalsDifferentCustomObjects() throws Exception {
        // GIVEN
        NodePointer parent = mock(NodePointer.class);
        QName qName = new QName("http://example.com", "property");
        Object customBean1 = new Object();
        Object customBean2 = new Object();
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer bp1 = new BeanPointer(parent, qName, customBean1, beanInfo);
        BeanPointer bp2 = new BeanPointer(parent, qName, customBean2, beanInfo);

        // WHEN
        boolean result = bp1.equals(bp2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("object is BeanPointer with different parents, both non-null and equal, qName not null and equal, same indices, beans are same")
    void TC20_equalsDifferentParentsEqual() throws Exception {
        // GIVEN
        NodePointer parent1 = mock(NodePointer.class);
        NodePointer parent2 = mock(NodePointer.class);
        // Assuming parent1.equals(parent2) is true
        org.mockito.Mockito.when(parent1.equals(parent2)).thenReturn(true);
        QName qName = new QName("http://example.com", "property");
        Object customBean = new Object();
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer bp1 = new BeanPointer(parent1, qName, customBean, beanInfo);
        BeanPointer bp2 = new BeanPointer(parent2, qName, customBean, beanInfo);

        // WHEN
        boolean result = bp1.equals(bp2);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("object is BeanPointer with same parent, qName not null and equal, index is WHOLE_COLLECTION, beans are Strings and not equal")
    void TC21_equalsDifferentStringBeansWHOLE_COLLECTION() throws Exception {
        // GIVEN
        NodePointer parent = mock(NodePointer.class);
        QName qName = new QName("http://example.com", "property");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer bp1 = new BeanPointer(parent, qName, "value1", beanInfo);
        BeanPointer bp2 = new BeanPointer(parent, qName, "value2", beanInfo);

        // WHEN
        boolean result = bp1.equals(bp2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("object is BeanPointer with null qName in one and non-null in the other, should return false")
    void TC22_equalsMismatchedQNameNullity() throws Exception {
        // GIVEN
        NodePointer parent = mock(NodePointer.class);
        QName qName1 = new QName("http://example.com", "property");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer bp1 = new BeanPointer(parent, qName1, "value", beanInfo);
        BeanPointer bp2 = new BeanPointer(parent, null, "value", beanInfo);

        // WHEN
        boolean result = bp1.equals(bp2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("object is BeanPointer with same parent, qName not null and equal, index is specific, beans are equal Booleans")
    void TC23_equalsEqualBooleansWithSpecificIndex() throws Exception {
        // GIVEN
        NodePointer parent = mock(NodePointer.class);
        QName qName = new QName("http://example.com", "property");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer bp1 = new BeanPointer(parent, qName, false, beanInfo);
        BeanPointer bp2 = new BeanPointer(parent, qName, false, beanInfo);

        // WHEN
        boolean result = bp1.equals(bp2);

        // THEN
        assertTrue(result);
    }
}