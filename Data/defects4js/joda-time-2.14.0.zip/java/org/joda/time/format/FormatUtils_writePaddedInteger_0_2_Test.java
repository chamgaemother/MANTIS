package org.joda.time.format;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.io.StringWriter;
import java.io.Writer;
import org.joda.time.format.FormatUtils;

public class FormatUtils_writePaddedInteger_0_2_Test {

    @Test
    @DisplayName("writePaddedInteger with value equal to Integer.MIN_VALUE")
    public void TC06() throws Exception {
        Writer writer = new StringWriter();
        int value = Integer.MIN_VALUE;
        int size = 15;
        FormatUtils.writePaddedInteger(writer, value, size);
        assertEquals("-000002147483648", writer.toString());
    }

    @Test
    @DisplayName("writePaddedInteger with negative value >= -9 and size equals 2 (one padding iteration)")
    public void TC07() throws Exception {
        Writer writer = new StringWriter();
        int value = -5;
        int size = 2;
        FormatUtils.writePaddedInteger(writer, value, size);
        assertEquals("-05", writer.toString());
    }

    @Test
    @DisplayName("writePaddedInteger with negative value >= -99 and size equals 4 (two padding iterations)")
    public void TC08() throws Exception {
        Writer writer = new StringWriter();
        int value = -45;
        int size = 4;
        FormatUtils.writePaddedInteger(writer, value, size);
        assertEquals("-0045", writer.toString());
    }

    @Test
    @DisplayName("writePaddedInteger with positive value >=100 and size <=2 (no padding, writes two digits)")
    public void TC09() throws Exception {
        Writer writer = new StringWriter();
        int value = 50;
        int size = 2;
        FormatUtils.writePaddedInteger(writer, value, size);
        assertEquals("50", writer.toString());
    }

    @Test
    @DisplayName("writePaddedInteger with positive value >=100 and size =3 (one padding iteration)")
    public void TC10() throws Exception {
        Writer writer = new StringWriter();
        int value = 123;
        int size = 4;
        FormatUtils.writePaddedInteger(writer, value, size);
        assertEquals("0123", writer.toString());
    }
}