package org.apache.commons.math3.random;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class MersenneTwister_setSeed_0_1_Test {

    @Test
    @DisplayName("setSeed(null) handles null seed array gracefully")
    void TC01_setSeed_nullArray() throws Exception {
        // GIVEN
        MersenneTwister mt = new MersenneTwister();
        int[] seed = null;

        // WHEN
        mt.setSeed(seed);

        // THEN
        // Use reflection to access the private 'mt' field
        Field mtField = MersenneTwister.class.getDeclaredField("mt");
        mtField.setAccessible(true);
        int[] internalMt = (int[]) mtField.get(mt);
        assertNotNull(internalMt, "Internal mt array should not be null");
        // Verify that the first element is set to the default seed value (assuming defaultSeedValue is known)
        // Here, replace 'defaultSeedValue' with the actual default value if known
        // For demonstration, we assume it should be 19650218 as set in the method
        assertEquals(19650218, internalMt[0], "First element of mt array should be the default seed value");
    }

    @Test
    @DisplayName("setSeed with empty seed array initializes with default values")
    void TC02_setSeed_emptyArray() throws Exception {
        // GIVEN
        MersenneTwister mt = new MersenneTwister();
        int[] seed = new int[0];

        // WHEN
        mt.setSeed(seed);

        // THEN
        // Use reflection to access the private 'mt' field
        Field mtField = MersenneTwister.class.getDeclaredField("mt");
        mtField.setAccessible(true);
        int[] internalMt = (int[]) mtField.get(mt);
        assertNotNull(internalMt, "Internal mt array should not be null");
        // Verify that the mt array is initialized with default seed values
        // Replace 'defaultSeedValue' with the actual expected value
        assertEquals(19650218, internalMt[0], "First element of mt array should be the default seed value");
    }

    @Test
    @DisplayName("setSeed with seed array length less than N (100) initializes partially")
    void TC03_setSeed_shortArray() throws Exception {
        // GIVEN
        MersenneTwister mt = new MersenneTwister();
        int[] seed = new int[100];
        for (int i = 0; i < 100; i++) {
            seed[i] = i;
        }

        // WHEN
        mt.setSeed(seed);

        // THEN
        // Use reflection to access the private 'mt' field
        Field mtField = MersenneTwister.class.getDeclaredField("mt");
        mtField.setAccessible(true);
        int[] internalMt = (int[]) mtField.get(mt);
        assertNotNull(internalMt, "Internal mt array should not be null");
        // Verify that the mt array is partially initialized based on provided seed and defaults
        // Assuming N is 624, verify first 100 elements are initialized with seed values
        for (int i = 0; i < 100; i++) {
            assertEquals(i, internalMt[i], "mt[" + i + "] should be initialized with seed value " + i);
        }
        // The rest of the mt array should be initialized with default or calculated values
        // Additional checks can be added as needed
    }

    @Test
    @DisplayName("setSeed with full seed array (624) fully initializes mt array")
    void TC04_setSeed_fullArray() throws Exception {
        // GIVEN
        MersenneTwister mt = new MersenneTwister();
        int[] seed = new int[624];
        for (int i = 0; i < 624; i++) {
            seed[i] = i;
        }

        // WHEN
        mt.setSeed(seed);

        // THEN
        // Use reflection to access the private 'mt' field
        Field mtField = MersenneTwister.class.getDeclaredField("mt");
        mtField.setAccessible(true);
        int[] internalMt = (int[]) mtField.get(mt);
        assertNotNull(internalMt, "Internal mt array should not be null");
        assertEquals(624, internalMt.length, "mt array should have a length of 624");
        for (int i = 0; i < 624; i++) {
            assertEquals(i, internalMt[i], "mt[" + i + "] should be initialized with seed value " + i);
        }
    }

    @Test
    @DisplayName("setSeed with seed array length greater than N (700) initializes mt array and ignores extra seeds")
    void TC05_setSeed_longArray() throws Exception {
        // GIVEN
        MersenneTwister mt = new MersenneTwister();
        int[] seed = new int[700];
        for (int i = 0; i < 700; i++) {
            seed[i] = i;
        }

        // WHEN
        mt.setSeed(seed);

        // THEN
        // Use reflection to access the private 'mt' field
        Field mtField = MersenneTwister.class.getDeclaredField("mt");
        mtField.setAccessible(true);
        int[] internalMt = (int[]) mtField.get(mt);
        assertNotNull(internalMt, "Internal mt array should not be null");
        assertEquals(624, internalMt.length, "mt array should have a length of 624");
        for (int i = 0; i < 624; i++) {
            assertEquals(i, internalMt[i], "mt[" + i + "] should be initialized with seed value " + i);
        }
        // Ensure that extra seeds are ignored by verifying that the length remains 624
    }
}