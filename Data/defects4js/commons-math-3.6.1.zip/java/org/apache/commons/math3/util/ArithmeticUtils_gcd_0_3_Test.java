package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.exception.MathArithmeticException;

public class ArithmeticUtils_gcd_0_3_Test {

    @Test
    @DisplayName("gcd(-48, -18) returns 6 with both operands negative and even")
    void test_TC11() {
        long p = -48L;
        long q = -18L;
        long result = ArithmeticUtils.gcd(p, q);
        Assertions.assertEquals(6L, result);
    }

    @Test
    @DisplayName("gcd(25, -15) returns 5 with one operand positive and one negative")
    void test_TC12() {
        long p = 25L;
        long q = -15L;
        long result = ArithmeticUtils.gcd(p, q);
        Assertions.assertEquals(5L, result);
    }

    @Test
    @DisplayName("gcd(-1024, 256) returns 256 with one operand negative and multiple power of 2 reductions")
    void test_TC13() {
        long p = -1024L;
        long q = 256L;
        long result = ArithmeticUtils.gcd(p, q);
        Assertions.assertEquals(256L, result);
    }

    @Test
    @DisplayName("gcd(1, 1) returns 1 as smallest non-zero GCD")
    void test_TC14() {
        long p = 1L;
        long q = 1L;
        long result = ArithmeticUtils.gcd(p, q);
        Assertions.assertEquals(1L, result);
    }

    @Test
    @DisplayName("gcd(Long.MIN_VALUE, Long.MIN_VALUE) throws MathArithmeticException due to overflow")
    void test_TC15() {
        long p = Long.MIN_VALUE;
        long q = Long.MIN_VALUE;
        Assertions.assertThrows(MathArithmeticException.class, () -> {
            ArithmeticUtils.gcd(p, q);
        });
    }
}