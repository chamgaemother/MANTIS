package org.apache.commons.jxpath.util;

import org.apache.commons.jxpath.JXPathException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.lang.reflect.Method;

public class MethodLookupUtils_lookupMethod_0_3_Test {

    @Test
    @DisplayName("lookupMethod returns null when no matching methods are found after type conversion")
    public void TC11() throws Exception {
        Class<?> targetClass = SomeClass.class;
        String name = "nonExistingMethod";
        Object[] parameters = { new ConvertibleObject(), "invalidParam" };

        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        Assertions.assertNull(result, "Expected null when no matching methods are found after type conversion");
    }

    @Test
    @DisplayName("lookupMethod returns null when a static method matches exactly")
    public void TC12() throws Exception {
        Class<?> targetClass = SomeClass.class;
        String name = "staticMethod";
        Object[] parameters = { targetClass, "param1" };

        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        Assertions.assertNull(result, "Expected null since matching method is static and should be excluded");
    }

    @Test
    @DisplayName("lookupMethod throws JXPathException when first method with higher match priority is ambiguous")
    public void TC13() throws Exception {
        Class<?> targetClass = AmbiguousClass.class;
        String name = "ambiguousHighPriorityMethod";
        Object[] parameters = { new MatchParam1(), new MatchParam2() };

        JXPathException exception = Assertions.assertThrows(JXPathException.class, () -> {
            MethodLookupUtils.lookupMethod(targetClass, name, parameters);
        }, "Expected JXPathException due to ambiguous method call");

        Assertions.assertTrue(exception.getMessage().contains("Ambiguous method call"), "Exception message should contain 'Ambiguous method call'");
    }

    @Test
    @DisplayName("lookupMethod successfully finds the best matching method when multiple methods are present")
    public void TC14() throws Exception {
        Class<?> targetClass = SomeClass.class;
        String name = "bestMatchedMethod";
        Object[] parameters = { new ConvertibleObject(), "param1", "param2" };

        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        Assertions.assertNotNull(result, "Expected a matching method to be found");
        Assertions.assertEquals("bestMatchedMethod", result.getName(), "The returned method should be 'bestMatchedMethod'");
    }

    @Test
    @DisplayName("lookupMethod handles parameters with null values without affecting type matching")
    public void TC15() throws Exception {
        Class<?> targetClass = SomeClass.class;
        String name = "methodWithNullParams";
        Object[] parameters = { new ConvertibleObject(), null, "param2" };

        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        Assertions.assertNotNull(result, "Expected a matching method to be found even with null parameters");
        Assertions.assertEquals("methodWithNullParams", result.getName(), "The returned method should be 'methodWithNullParams'");
    }

    // Dummy classes to support test scenarios
    public static class SomeClass {
        public static void staticMethod(Class<?> cls, String param) {
            // Static method for TC12
        }

        public void bestMatchedMethod(ConvertibleObject obj, String param1, String param2) {
            // Best matched method for TC14
        }

        public void methodWithNullParams(ConvertibleObject obj, Object param1, String param2) {
            // Method handling null parameters for TC15
        }
    }

    public static class AmbiguousClass {
        public void ambiguousHighPriorityMethod(MatchParam1 param1, MatchParam2 param2) {
            // First ambiguous method
        }

        public void ambiguousHighPriorityMethod(MatchParam1 param1, MatchParam2 param2, String extraParam) {
            // Second ambiguous method with same match priority
        }
    }

    public static class ConvertibleObject {
        // Represents an object that can be converted by TypeUtils
    }

    public static class MatchParam1 {
        // Parameter class for TC13
    }

    public static class MatchParam2 {
        // Parameter class for TC13
    }
}