
package org.apache.commons.lang3;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

public class ClassUtils_isAssignable_0_1_Test {

    @Test
    @DisplayName("Both cls and toClass are null; expect false")
    void TC01() {
        Class<?> cls = null;
        Class<?> toClass = null;
        boolean autoboxing = false;
        
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        
        Assertions.assertFalse(result);
    }

    @Test
    @DisplayName("toClass is null and cls is non-null; expect false")
    void TC02() {
        Class<?> cls = String.class;
        Class<?> toClass = null;
        boolean autoboxing = false;
        
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        
        Assertions.assertFalse(result);
    }

    @Test
    @DisplayName("cls is null and toClass is primitive; expect false")
    void TC03() {
        Class<?> cls = null;
        Class<?> toClass = int.class;
        boolean autoboxing = false;
        
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        
        Assertions.assertFalse(result);
    }

    @Test
    @DisplayName("cls is null and toClass is non-primitive; expect true")
    void TC04() {
        Class<?> cls = null;
        Class<?> toClass = Object.class;
        boolean autoboxing = false;
        
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        
        Assertions.assertTrue(result);
    }

    @Test
    @DisplayName("cls equals toClass; expect true")
    void TC05() {
        Class<?> cls = String.class;
        Class<?> toClass = String.class;
        boolean autoboxing = false;
        
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        
        Assertions.assertTrue(result);
    }

}