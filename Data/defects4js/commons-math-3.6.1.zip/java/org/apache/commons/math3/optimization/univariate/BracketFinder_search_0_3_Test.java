//package org.apache.commons.math3.optim.univariate;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.*;
//
//import org.apache.commons.math3.analysis.UnivariateFunction;
//import org.apache.commons.math3.exception.TooManyEvaluationsException;
//import org.apache.commons.math3.optim.nonlinear.scalar.GoalType;
//import org.junit.jupiter.api.DisplayName;
//import org.junit.jupiter.api.Test;
//import java.lang.reflect.Field;
//
//public class BracketFinder_search_0_3_Test {
//
//    @Test
//    @DisplayName("TC11: search method with minimum evaluation count reached, ensuring proper exception handling")
//    void testSearch_MaxEvaluationReached_ThrowsException() throws Exception {
//        // GIVEN
//        GoalType goal = GoalType.MAXIMIZE;
//        double xA = 0.5;
//        double growLimit = 2.0;
//        UnivariateFunction func = mock(UnivariateFunction.class);
//
//        BracketFinder bracketFinder = new BracketFinder();
//
//        // Mock eval method to throw TooManyEvaluationsException after max evaluations
//        when(func.value(anyDouble())).thenThrow(new TooManyEvaluationsException(500));
//
//        // WHEN & THEN
//        assertThrows(TooManyEvaluationsException.class, () -> {
//            bracketFinder.search(func, goal, xA, growLimit);
//        });
//    }
//
//    @Test
//    @DisplayName("TC12: search method with lo > hi initially, triggering swap at the end")
//    void testSearch_LoGreaterThanHi_SwapsLoAndHi() throws Exception {
//        // GIVEN
//        GoalType goal = GoalType.MINIMIZE;
//        double lo = 3.0;
//        double hi = 1.0;
//        double growLimit = 2.0;
//        UnivariateFunction func = mock(UnivariateFunction.class);
//
//        // Mock the eval method to return consistent values
//        when(func.value(3.0)).thenReturn(3.0);
//        when(func.value(1.5)).thenReturn(1.0);
//
//        BracketFinder bracketFinder = new BracketFinder();
//
//        // WHEN
//        bracketFinder.search(func, goal, lo, growLimit);
//
//        // THEN
//        Field loField = BracketFinder.class.getDeclaredField("lo");
//        loField.setAccessible(true);
//        Field hiField = BracketFinder.class.getDeclaredField("hi");
//        hiField.setAccessible(true);
//
//        double finalLo = loField.getDouble(bracketFinder);
//        double finalHi = hiField.getDouble(bracketFinder);
//
//        assertTrue(finalLo <= finalHi, "lo should be less than or equal to hi after swap");
//    }
//
//    @Test
//    @DisplayName("TC13: search method with lo <= hi initially, no swap at the end")
//    void testSearch_LoLessThanOrEqualToHi_NoSwap() throws Exception {
//        // GIVEN
//        GoalType goal = GoalType.MAXIMIZE;
//        double lo = 1.0;
//        double hi = 3.0;
//        double growLimit = 2.0;
//        UnivariateFunction func = mock(UnivariateFunction.class);
//
//        // Mock the eval method to return consistent values
//        when(func.value(1.0)).thenReturn(1.0);
//        when(func.value(3.0)).thenReturn(3.0);
//
//        BracketFinder bracketFinder = new BracketFinder();
//
//        // WHEN
//        bracketFinder.search(func, goal, lo, growLimit);
//
//        // THEN
//        Field loField = BracketFinder.class.getDeclaredField("lo");
//        loField.setAccessible(true);
//        Field hiField = BracketFinder.class.getDeclaredField("hi");
//        hiField.setAccessible(true);
//
//        double finalLo = loField.getDouble(bracketFinder);
//        double finalHi = hiField.getDouble(bracketFinder);
//
//        assertEquals(1.0, finalLo, "lo should remain unchanged");
//        assertEquals(3.0, finalHi, "hi should remain unchanged");
//    }
//
//    @Test
//    @DisplayName("TC14: search method with fW < fC in MINIMIZE goal, updating xA and xB appropriately")
//    void testSearch_fWLessThan_fC_MinimizeGoal_UpdatesXAandXB() throws Exception {
//        // GIVEN
//        GoalType goal = GoalType.MINIMIZE;
//        double xA = 1.0;
//        double xB = 2.0;
//        double growLimit = 1.618034;
//        UnivariateFunction func = mock(UnivariateFunction.class);
//
//        // Mock the eval method to return fW < fC
//        when(func.value(anyDouble())).thenReturn(1.0, 0.5);
//
//        BracketFinder bracketFinder = new BracketFinder();
//
//        // WHEN
//        bracketFinder.search(func, goal, xA, xB);
//
//        // THEN
//        Field xAField = BracketFinder.class.getDeclaredField("lo");
//        xAField.setAccessible(true);
//        Field xBField = BracketFinder.class.getDeclaredField("mid");
//        xBField.setAccessible(true);
//
//        double finalXA = xAField.getDouble(bracketFinder);
//        double finalXB = xBField.getDouble(bracketFinder);
//
//        assertEquals(2.0, finalXA, "xA should be updated to 2.0");
//        assertEquals(1.0, finalXB, "xB should be updated to 1.0");
//    }
//
//    @Test
//    @DisplayName("TC15: search method with fW > fB in MAXIMIZE goal, updating xC and fC")
//    void testSearch_fWGreaterThan_fB_MaximizeGoal_UpdatesXCandFC() throws Exception {
//        // GIVEN
//        GoalType goal = GoalType.MAXIMIZE;
//        double xA = 1.0;
//        double xB = 2.0;
//        double growLimit = 1.618034;
//        UnivariateFunction func = mock(UnivariateFunction.class);
//
//        // Mock the eval method to return fW > fB
//        when(func.value(anyDouble())).thenReturn(1.0, 3.0);
//
//        BracketFinder bracketFinder = new BracketFinder();
//
//        // WHEN
//        bracketFinder.search(func, goal, xA, xB);
//
//        // THEN
//        Field xCField = BracketFinder.class.getDeclaredField("hi");
//        xCField.setAccessible(true);
//        Field fCField = BracketFinder.class.getDeclaredField("fHi");
//        fCField.setAccessible(true);
//
//        double finalXC = xCField.getDouble(bracketFinder);
//        double finalFC = fCField.getDouble(bracketFinder);
//
//        assertEquals(3.0, finalFC, "fC should be updated to 3.0");
//        assertTrue(finalXC > xB, "xC should be updated appropriately");
//    }
//}