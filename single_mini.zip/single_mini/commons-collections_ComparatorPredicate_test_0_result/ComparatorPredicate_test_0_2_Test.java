package org.apache.commons.collections4.functors;

import java.util.Comparator;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.apache.commons.collections4.functors.ComparatorPredicate;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ComparatorPredicate_test_0_2_Test {

    @Test
    @DisplayName("Criterion LESS with comparison result non-negative")
    void TC06() throws Exception {
        // GIVEN
        @SuppressWarnings("unchecked")
        Comparator<Object> comparatorMock = (Comparator<Object>) mock(Comparator.class);
        when(comparatorMock.compare(any(), any())).thenReturn(0);

        // Using the static factory method to create the predicate with Criterion.LESS
        ComparatorPredicate<Object> predicate = ComparatorPredicate.comparatorPredicate(new Object(), comparatorMock, ComparatorPredicate.Criterion.LESS);

        // WHEN
        boolean result = predicate.test(new Object());

        // THEN
        assertEquals(false, result);
    }

    @Test
    @DisplayName("Criterion GREATER_OR_EQUAL with comparison result positive")
    void TC07() throws Exception {
        // GIVEN
        @SuppressWarnings("unchecked")
        Comparator<Object> comparatorMock = (Comparator<Object>) mock(Comparator.class);
        when(comparatorMock.compare(any(), any())).thenReturn(1);

        // Using the static factory method to create the predicate with Criterion.GREATER_OR_EQUAL
        ComparatorPredicate<Object> predicate = ComparatorPredicate.comparatorPredicate(new Object(), comparatorMock, ComparatorPredicate.Criterion.GREATER_OR_EQUAL);

        // WHEN
        boolean result = predicate.test(new Object());

        // THEN
        assertEquals(true, result);
    }

    @Test
    @DisplayName("Criterion GREATER_OR_EQUAL with comparison result zero")
    void TC08() throws Exception {
        // GIVEN
        @SuppressWarnings("unchecked")
        Comparator<Object> comparatorMock = (Comparator<Object>) mock(Comparator.class);
        when(comparatorMock.compare(any(), any())).thenReturn(0);

        // Using the static factory method to create the predicate with Criterion.GREATER_OR_EQUAL
        ComparatorPredicate<Object> predicate = ComparatorPredicate.comparatorPredicate(new Object(), comparatorMock, ComparatorPredicate.Criterion.GREATER_OR_EQUAL);

        // WHEN
        boolean result = predicate.test(new Object());

        // THEN
        assertEquals(true, result);
    }

    @Test
    @DisplayName("Criterion GREATER_OR_EQUAL with comparison result non-positive")
    void TC09() throws Exception {
        // GIVEN
        @SuppressWarnings("unchecked")
        Comparator<Object> comparatorMock = (Comparator<Object>) mock(Comparator.class);
        when(comparatorMock.compare(any(), any())).thenReturn(-1);

        // Using the static factory method to create the predicate with Criterion.GREATER_OR_EQUAL
        ComparatorPredicate<Object> predicate = ComparatorPredicate.comparatorPredicate(new Object(), comparatorMock, ComparatorPredicate.Criterion.GREATER_OR_EQUAL);

        // WHEN
        boolean result = predicate.test(new Object());

        // THEN
        assertEquals(false, result);
    }

    @Test
    @DisplayName("Criterion LESS_OR_EQUAL with comparison result negative")
    void TC10() throws Exception {
        // GIVEN
        @SuppressWarnings("unchecked")
        Comparator<Object> comparatorMock = (Comparator<Object>) mock(Comparator.class);
        when(comparatorMock.compare(any(), any())).thenReturn(-1);

        // Using the static factory method to create the predicate with Criterion.LESS_OR_EQUAL
        ComparatorPredicate<Object> predicate = ComparatorPredicate.comparatorPredicate(new Object(), comparatorMock, ComparatorPredicate.Criterion.LESS_OR_EQUAL);

        // WHEN
        boolean result = predicate.test(new Object());

        // THEN
        assertEquals(true, result);
    }
}