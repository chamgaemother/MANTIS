package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Metaphone_metaphone_1_5_Test {

    @Test
    @DisplayName("metaphone word with 'TIO' sequence converts to 'X'")
    public void TC51() {
        // Given
        String txt = "action";
        Metaphone metaphone = new Metaphone();
        
        // When
        String result = metaphone.metaphone(txt);
        
        // Then
        assertEquals("AKXN", result, "'TIO' sequence should be converted to 'X'");
    }

    @Test
    @DisplayName("metaphone word with 'TCH' sequence makes 'T' silent")
    public void TC52() {
        // Given
        String txt = "watch";
        Metaphone metaphone = new Metaphone();
        
        // When
        String result = metaphone.metaphone(txt);
        
        // Then
        assertEquals("WCH", result, "'TCH' sequence should make 'T' silent");
    }
}