package com.fasterxml.jackson.databind.ser.std;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.PropertyFilter;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class MapSerializer_serializeFilteredAnyProperties_0_1_Test {

    @Test
    @DisplayName("TC01: serializeFilteredAnyProperties with empty map")
    void TC01() throws Exception {
        // Arrange
        Map<Object, Object> value = Collections.emptyMap();

        SerializerProvider provider = mock(SerializerProvider.class);
        JsonGenerator gen = mock(JsonGenerator.class);
        PropertyFilter filter = mock(PropertyFilter.class);

        // Mock Instantation of MapSerializer
        MapSerializer mapSerializer = mock(MapSerializer.class);

        Object bean = new Object();

        // Act: Test the actual method call with mocks
        mapSerializer.serializeFilteredAnyProperties(provider, gen, bean, value, filter, null);

        // Assert: Verify method behavior with mocks
        verify(filter, never()).serializeAsField(any(), any(), any(), any());
    }

    @Test
    @DisplayName("TC02: serializeFilteredAnyProperties with null key")
    void TC02() throws Exception {
        // Arrange
        Map<Object, Object> value = new HashMap<>();
        value.put(null, "value1");

        SerializerProvider provider = mock(SerializerProvider.class);
        JsonGenerator gen = mock(JsonGenerator.class);
        PropertyFilter filter = mock(PropertyFilter.class);

        JsonSerializer<Object> nullKeySerializer = mock(JsonSerializer.class);
        JsonSerializer<Object> valueSerializer = mock(JsonSerializer.class);

        when(provider.findNullKeySerializer(any(), any())).thenReturn(nullKeySerializer);
        when(provider.getDefaultNullValueSerializer()).thenReturn(valueSerializer);

        // Mock Instantation of MapSerializer
        MapSerializer mapSerializer = mock(MapSerializer.class);
        setPrivateField(mapSerializer, "_keySerializer", nullKeySerializer);
        setPrivateField(mapSerializer, "_valueSerializer", valueSerializer);

        Object bean = new Object();

        // Act: Test the actual method call with mocks
        mapSerializer.serializeFilteredAnyProperties(provider, gen, bean, value, filter, null);

        // Assert: Verify method behavior with mocks
        verify(filter, times(1)).serializeAsField(eq(bean), eq(gen), eq(provider), any());
    }

    @Test
    @DisplayName("TC03: serializeFilteredAnyProperties with ignored key")
    void TC03() throws Exception {
        // Arrange
        Map<Object, Object> value = new HashMap<>();
        value.put("key1", "value1");

        SerializerProvider provider = mock(SerializerProvider.class);
        JsonGenerator gen = mock(JsonGenerator.class);
        PropertyFilter filter = mock(PropertyFilter.class);

        InclusionChecker inclusionChecker = mock(InclusionChecker.class);
        when(inclusionChecker.shouldIgnore("key1")).thenReturn(true);

        // Mock Instantation of MapSerializer
        MapSerializer mapSerializer = mock(MapSerializer.class);
        setPrivateField(mapSerializer, "_inclusionChecker", inclusionChecker);

        Object bean = new Object();

        // Act: Test the actual method call with mocks
        mapSerializer.serializeFilteredAnyProperties(provider, gen, bean, value, filter, null);

        // Assert: Verify method behavior with mocks
        verify(filter, never()).serializeAsField(any(), any(), any(), any());
    }

    @Test
    @DisplayName("TC04: serializeFilteredAnyProperties with non-empty value")
    void TC04() throws Exception {
        // Arrange
        Map<Object, Object> value = new HashMap<>();
        value.put("key1", "value1");

        SerializerProvider provider = mock(SerializerProvider.class);
        JsonGenerator gen = mock(JsonGenerator.class);
        PropertyFilter filter = mock(PropertyFilter.class);

        InclusionChecker inclusionChecker = mock(InclusionChecker.class);
        when(inclusionChecker.shouldIgnore("key1")).thenReturn(false);

        JsonSerializer<Object> keySerializer = mock(JsonSerializer.class);
        JsonSerializer<Object> valueSerializer = mock(JsonSerializer.class);
        when(valueSerializer.isEmpty(any(), eq("value1"))).thenReturn(false);

        when(provider.getDefaultNullValueSerializer()).thenReturn(valueSerializer);

        // Mock Instantation of MapSerializer
        MapSerializer mapSerializer = mock(MapSerializer.class);
        setPrivateField(mapSerializer, "_inclusionChecker", inclusionChecker);
        setPrivateField(mapSerializer, "_keySerializer", keySerializer);
        setPrivateField(mapSerializer, "_valueSerializer", valueSerializer);
        setPrivateField(mapSerializer, "_suppressNulls", true);

        Object bean = new Object();

        // Act: Test the actual method call with mocks
        mapSerializer.serializeFilteredAnyProperties(provider, gen, bean, value, filter, null);

        // Assert: Verify method behavior with mocks
        verify(filter, times(1)).serializeAsField(eq(bean), eq(gen), eq(provider), any());
    }

    @Test
    @DisplayName("TC05: serializeFilteredAnyProperties with null value and suppression enabled")
    void TC05() throws Exception {
        // Arrange
        Map<Object, Object> value = new HashMap<>();
        value.put("key1", null);

        SerializerProvider provider = mock(SerializerProvider.class);
        JsonGenerator gen = mock(JsonGenerator.class);
        PropertyFilter filter = mock(PropertyFilter.class);

        JsonSerializer<Object> keySerializer = mock(JsonSerializer.class);
        JsonSerializer<Object> valueSerializer = mock(JsonSerializer.class);

        when(provider.getDefaultNullValueSerializer()).thenReturn(valueSerializer);

        // Mock Instantation of MapSerializer
        MapSerializer mapSerializer = mock(MapSerializer.class);
        setPrivateField(mapSerializer, "_keySerializer", keySerializer);
        setPrivateField(mapSerializer, "_valueSerializer", valueSerializer);
        setPrivateField(mapSerializer, "_suppressNulls", true);

        Object bean = new Object();

        // Act: Test the actual method call with mocks
        mapSerializer.serializeFilteredAnyProperties(provider, gen, bean, value, filter, null);

        // Assert: Verify method behavior with mocks
        verify(filter, never()).serializeAsField(any(), any(), any(), any());
    }

    // Helper method to set private fields via reflection
    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getSuperclass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    // Mocked InclusionChecker used in TC03
    private interface InclusionChecker {
        boolean shouldIgnore(Object key);
    }
}