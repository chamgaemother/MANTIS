package org.jfree.chart;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.Cursor;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.event.MouseEvent;

import java.lang.reflect.Field;
import org.jfree.chart.plot.PlotOrientation;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ChartPanel_mouseReleased_0_1_Test {

    @Test
    @DisplayName("mouseReleased when panLast is not null, verifying pan reset and cursor set to default")
    void TC01_mouseReleased_panActive() throws Exception {
        // Initialize ChartPanel instance
        ChartPanel panel = new ChartPanel(null);

        // Set panLast via reflection
        Field panLastField = ChartPanel.class.getDeclaredField("panLast");
        panLastField.setAccessible(true);
        panLastField.set(panel, new Point2D.Double(100, 100));

        // Create MouseEvent
        MouseEvent event = new MouseEvent(panel, MouseEvent.MOUSE_RELEASED, System.currentTimeMillis(),
                0, 150, 150, 1, false);

        // Invoke mouseReleased
        panel.mouseReleased(event);

        // Verify panLast is null
        Object panLast = panLastField.get(panel);
        assertNull(panLast, "panLast should be null after mouseReleased");

        // Verify cursor is default
        assertEquals(Cursor.getDefaultCursor(), panel.getCursor(), "Cursor should be set to default");
    }

    @Test
    @DisplayName("mouseReleased when zoomRectangle is null and panLast is null, expects no action")
    void TC02_mouseReleased_noPanNoZoomRectangle() throws Exception {
        // Initialize ChartPanel instance
        ChartPanel panel = new ChartPanel(null);

        // Ensure panLast is null
        Field panLastField = ChartPanel.class.getDeclaredField("panLast");
        panLastField.setAccessible(true);
        panLastField.set(panel, null);

        // Ensure zoomRectangle is null
        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        zoomRectangleField.set(panel, null);

        // Create MouseEvent
        MouseEvent event = new MouseEvent(panel, MouseEvent.MOUSE_RELEASED, System.currentTimeMillis(),
                0, 200, 200, 1, false);

        // Invoke mouseReleased
        panel.mouseReleased(event);

        // Since no action is performed, verify that zoomRectangle is still null
        Object zoomRectangle = zoomRectangleField.get(panel);
        assertNull(zoomRectangle, "zoomRectangle should remain null when no action is performed");
    }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, orientation HORIZONTAL, rangeZoomable true, domainZoomable false")
    void TC03_mouseReleased_horizontalRangeZoomable() throws Exception {
        // Initialize ChartPanel instance
        ChartPanel panel = new ChartPanel(null);

        // Set zoomRectangle via reflection
        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        zoomRectangleField.set(panel, new Rectangle2D.Double(50, 50, 100, 100));

        // Set orientation to HORIZONTAL
        Field orientationField = ChartPanel.class.getDeclaredField("orientation");
        orientationField.setAccessible(true);
        orientationField.set(panel, PlotOrientation.HORIZONTAL);

        // Set rangeZoomable to true and domainZoomable to false
        Field rangeZoomableField = ChartPanel.class.getDeclaredField("rangeZoomable");
        rangeZoomableField.setAccessible(true);
        rangeZoomableField.set(panel, true);

        Field domainZoomableField = ChartPanel.class.getDeclaredField("domainZoomable");
        domainZoomableField.setAccessible(true);
        domainZoomableField.set(panel, false);

        // Set zoomPoint via reflection
        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        zoomPointField.set(panel, new Point2D.Double(100, 100));

        // Set zoomTriggerDistance to trigger zoom
        Field zoomTriggerDistanceField = ChartPanel.class.getDeclaredField("zoomTriggerDistance");
        zoomTriggerDistanceField.setAccessible(true);
        zoomTriggerDistanceField.set(panel, 10);

        // Create MouseEvent that triggers zoom
        MouseEvent event = new MouseEvent(panel, MouseEvent.MOUSE_RELEASED, System.currentTimeMillis(),
                0, 120, 100, 1, false);

        // Invoke mouseReleased
        panel.mouseReleased(event);

        // Verify restoreAutoBounds is called by checking zoomPoint and zoomRectangle are null
        Object zoomPoint = zoomPointField.get(panel);
        Object zoomRectangle = zoomRectangleField.get(panel);
        assertNull(zoomPoint, "zoomPoint should be null after restoreAutoBounds is called");
        assertNull(zoomRectangle, "zoomRectangle should be null after restoreAutoBounds is called");
    }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, orientation VERTICAL, domainZoomable true, rangeZoomable false, zoom triggers not met")
    void TC04_mouseReleased_verticalNoZoomTrigger() throws Exception {
        // Initialize ChartPanel instance
        ChartPanel panel = new ChartPanel(null);

        // Set zoomRectangle via reflection
        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        zoomRectangleField.set(panel, new Rectangle2D.Double(50, 50, 100, 100));

        // Set orientation to VERTICAL
        Field orientationField = ChartPanel.class.getDeclaredField("orientation");
        orientationField.setAccessible(true);
        orientationField.set(panel, PlotOrientation.VERTICAL);

        // Set domainZoomable to true and rangeZoomable to false
        Field domainZoomableField = ChartPanel.class.getDeclaredField("domainZoomable");
        domainZoomableField.setAccessible(true);
        domainZoomableField.set(panel, true);

        Field rangeZoomableField = ChartPanel.class.getDeclaredField("rangeZoomable");
        rangeZoomableField.setAccessible(true);
        rangeZoomableField.set(panel, false);

        // Set zoomPoint via reflection
        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        zoomPointField.set(panel, new Point2D.Double(100, 100));

        // Set zoomTriggerDistance to not trigger zoom
        Field zoomTriggerDistanceField = ChartPanel.class.getDeclaredField("zoomTriggerDistance");
        zoomTriggerDistanceField.setAccessible(true);
        zoomTriggerDistanceField.set(panel, 50);

        // Create MouseEvent that does not trigger zoom
        MouseEvent event = new MouseEvent(panel, MouseEvent.MOUSE_RELEASED, System.currentTimeMillis(),
                0, 110, 110, 1, false);

        // Invoke mouseReleased
        panel.mouseReleased(event);

        // Verify that zoom should not occur, implying zoomPoint is still set
        Object zoomPoint = zoomPointField.get(panel);
        assertNotNull(zoomPoint, "zoomPoint should not be null if no zoom occurred");

        // Reset zoomPoint manually for clean state
        zoomPointField.set(panel, null);
    }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, orientation HORIZONTAL, both zoomable true, zoomTrigger1 true, zoomTrigger2 false, zoom direction left and horizontal")
    void TC05_mouseReleased_horizontalZoomTriggeredLeft() throws Exception {
        // Initialize ChartPanel instance
        ChartPanel panel = new ChartPanel(null);

        // Set zoomRectangle via reflection
        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        zoomRectangleField.set(panel, new Rectangle2D.Double(50, 50, 100, 100));

        // Set orientation to HORIZONTAL
        Field orientationField = ChartPanel.class.getDeclaredField("orientation");
        orientationField.setAccessible(true);
        orientationField.set(panel, PlotOrientation.HORIZONTAL);

        // Set rangeZoomable and domainZoomable to true
        Field rangeZoomableField = ChartPanel.class.getDeclaredField("rangeZoomable");
        rangeZoomableField.setAccessible(true);
        rangeZoomableField.set(panel, true);

        Field domainZoomableField = ChartPanel.class.getDeclaredField("domainZoomable");
        domainZoomableField.setAccessible(true);
        domainZoomableField.set(panel, true);

        // Set zoomPoint via reflection
        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        zoomPointField.set(panel, new Point2D.Double(150, 150));

        // Set zoomTriggerDistance
        Field zoomTriggerDistanceField = ChartPanel.class.getDeclaredField("zoomTriggerDistance");
        zoomTriggerDistanceField.setAccessible(true);
        zoomTriggerDistanceField.set(panel, 30);

        // Create MouseEvent that triggers horizontal zoom left
        MouseEvent event = new MouseEvent(panel, MouseEvent.MOUSE_RELEASED, System.currentTimeMillis(),
                0, 100, 150, 1, false);

        // Invoke mouseReleased
        panel.mouseReleased(event);

        // Verify restoreAutoBounds is called by checking zoomPoint and zoomRectangle are null
        Object zoomPoint = zoomPointField.get(panel);
        Object zoomRectangle = zoomRectangleField.get(panel);
        assertNull(zoomPoint, "zoomPoint should be null after restoreAutoBounds is called");
        assertNull(zoomRectangle, "zoomRectangle should be null after restoreAutoBounds is called");
    }
}