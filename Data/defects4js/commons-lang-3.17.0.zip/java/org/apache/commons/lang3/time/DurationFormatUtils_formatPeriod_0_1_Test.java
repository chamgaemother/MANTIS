package org.apache.commons.lang3.time;

import org.apache.commons.lang3.time.DurationFormatUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import java.util.TimeZone;

public class DurationFormatUtils_formatPeriod_0_1_Test {

    @Test
    @DisplayName("startMillis is greater than endMillis, expecting IllegalArgumentException")
    void TC01_formatPeriod_startMillisGreaterThanEndMillis_throwsException() {
        // GIVEN
        long startMillis = 100000L;
        long endMillis = 50000L;
        String format = "y:M:d:H:m:s:S";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        
        // WHEN & THEN
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        });
    }

    @Test
    @DisplayName("startMillis equals endMillis, expecting zero duration")
    void TC02_formatPeriod_startMillisEqualsEndMillis_returnsZeroDuration() {
        // GIVEN
        long startMillis = 100000L;
        long endMillis = 100000L;
        String format = "y:M:d:H:m:s:S";
        boolean padWithZeros = false;
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        
        // WHEN
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        
        // THEN
        Assertions.assertEquals("0:0:0:0:0:0:0", result);
    }

    @Test
    @DisplayName("Normal duration with all tokens present, expecting correct formatting")
    void TC03_formatPeriod_normalDurationAllTokens_correctFormatting() {
        // GIVEN
        long startMillis = 1609459200000L; // Jan 1, 2021
        long endMillis = 1609545600000L;   // Jan 2, 2021
        String format = "y:M:d:H:m:s:S";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        
        // WHEN
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        
        // THEN
        Assertions.assertEquals("0:0:1:0:0:0:0", result);
    }

    @Test
    @DisplayName("Duration spanning multiple years with 'y' token")
    void TC04_formatPeriod_multipleYearsWithYToken_correctFormatting() {
        // GIVEN
        long startMillis = 1577836800000L; // Jan 1, 2020
        long endMillis = 1609459200000L;   // Jan 1, 2021
        String format = "y:M:d:H:m:s:S";
        boolean padWithZeros = false;
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        
        // WHEN
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        
        // THEN
        Assertions.assertEquals("1:0:0:0:0:0:0", result);
    }

    @Test
    @DisplayName("Duration with leap year day included")
    void TC05_formatPeriod_durationWithLeapDay_correctFormatting() {
        // GIVEN
        long startMillis = 1582934400000L; // Feb 29, 2020
        long endMillis = 1583020800000L;   // Mar 1, 2020
        String format = "d:H:m:s:S";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        
        // WHEN
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        
        // THEN
        Assertions.assertEquals("1:0:0:0:0", result);
    }
}