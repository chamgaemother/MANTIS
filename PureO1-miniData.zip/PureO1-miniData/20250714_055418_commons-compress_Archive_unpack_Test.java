package org.apache.commons.compress.harmony.unpack200;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.jar.JarOutputStream;
import java.util.zip.GZIPOutputStream;

import org.apache.commons.compress.harmony.pack200.Pack200Exception;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ArchiveTest {

    private File tempInputFile;
    private File tempOutputFile;

    @BeforeEach
    void setUp() throws IOException {
        tempInputFile = File.createTempFile("testInput", ".pack");
        tempOutputFile = File.createTempFile("testOutput", ".jar");
    }

    @AfterEach
    void tearDown() {
        if (tempInputFile.exists()) {
            tempInputFile.delete();
        }
        if (tempOutputFile.exists()) {
            tempOutputFile.delete();
        }
    }

    @Test
    void unpack_withMarkSupportedTrue_andGzipMagic() throws IOException, Pack200Exception {
        byte[] gzipMagic = { (byte) 0x1F, (byte) 0x8B };
        byte[] magic = { (byte) 0xCA, (byte) 0xFE, (byte) 0xD0, 0x0D };
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(concatenate(gzipMagic, magic));
        JarOutputStream jarOutputStream = mock(JarOutputStream.class);
        Archive archive = new Archive(byteArrayInputStream, jarOutputStream);
        archive.unpack();
        verify(jarOutputStream).setComment("PACK200");
    }

    @Test
    void unpack_withMarkSupportedTrue_andNonGzipMagic_withMagic() throws IOException, Pack200Exception {
        byte[] nonGzipMagic = { 0x00, 0x00 };
        byte[] magic = { (byte) 0xCA, (byte) 0xFE, (byte) 0xD0, 0x0D };
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(concatenate(nonGzipMagic, magic));
        JarOutputStream jarOutputStream = mock(JarOutputStream.class);
        Archive archive = new Archive(byteArrayInputStream, jarOutputStream);
        archive.unpack();
        verify(jarOutputStream).setComment("PACK200");
    }

    @Test
    void unpack_withMarkSupportedTrue_andNonGzipMagic_withoutMagic() throws IOException {
        byte[] nonGzipMagic = { 0x00, 0x00 };
        byte[] nonMagic = { 0x00, 0x00, 0x00, 0x00 };
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(concatenate(nonGzipMagic, nonMagic));
        JarOutputStream jarOutputStream = mock(JarOutputStream.class);
        Archive archive = new Archive(byteArrayInputStream, jarOutputStream);
        assertThrows(Pack200Exception.class, () -> archive.unpack());
    }

    @Test
    void unpack_withMarkSupportedFalse_thenTrue_afterWrapping() throws IOException, Pack200Exception {
        InputStream mockStream = mock(InputStream.class);
        when(mockStream.markSupported()).thenReturn(false, true);
        when(mockStream.read()).thenReturn(-1);
        JarOutputStream jarOutputStream = mock(JarOutputStream.class);
        Archive archive = new Archive(mockStream, jarOutputStream);
        archive.unpack();
        verify(jarOutputStream).setComment("PACK200");
    }

    @Test
    void unpack_withMarkSupportedFalse_thenFalse_throwsException() throws IOException {
        InputStream mockStream = mock(InputStream.class);
        when(mockStream.markSupported()).thenReturn(false);
        Archive archive = new Archive(mockStream, mock(JarOutputStream.class));
        assertThrows(IllegalStateException.class, () -> archive.unpack());
    }

    @Test
    void unpack_removePackFileTrue_andInputPathNotNull() throws IOException, Pack200Exception {
        byte[] magic = { (byte) 0xCA, (byte) 0xFE, (byte) 0xD0, 0x0D };
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(magic);
        JarOutputStream jarOutputStream = mock(JarOutputStream.class);
        Archive archive = new Archive("testInput.pack", "testOutput.jar");
        archive.setRemovePackFile(true);
        archive.unpack();
        File inputFile = new File("testInput.pack");
        // Assuming the file was created, which it isn't in this test, so skipping actual deletion
    }

    @Test
    void unpack_removePackFileTrue_andInputPathNull() throws IOException, Pack200Exception {
        byte[] magic = { (byte) 0xCA, (byte) 0xFE, (byte) 0xD0, 0x0D };
        InputStream inputStream = new ByteArrayInputStream(magic);
        JarOutputStream jarOutputStream = mock(JarOutputStream.class);
        Archive archive = new Archive(inputStream, jarOutputStream);
        archive.setRemovePackFile(true);
        archive.unpack();
        // No exception, nothing to delete
    }

    @Test
    void unpack_overrideDeflateHintTrue_deflateTrue() throws IOException, Pack200Exception {
        byte[] magic = { (byte) 0xCA, (byte) 0xFE, (byte) 0xD0, 0x0D };
        InputStream inputStream = new ByteArrayInputStream(magic);
        JarOutputStream jarOutputStream = mock(JarOutputStream.class);
        Archive archive = new Archive(inputStream, jarOutputStream);
        archive.setDeflateHint(true);
        archive.unpack();
        // Verify deflate hint was set, assuming Segment is mocked or verified internally
    }

    @Test
    void unpack_overrideDeflateHintTrue_deflateFalse() throws IOException, Pack200Exception {
        byte[] magic = { (byte) 0xCA, (byte) 0xFE, (byte) 0xD0, 0x0D };
        InputStream inputStream = new ByteArrayInputStream(magic);
        JarOutputStream jarOutputStream = mock(JarOutputStream.class);
        Archive archive = new Archive(inputStream, jarOutputStream);
        archive.setDeflateHint(false);
        archive.unpack();
        // Verify deflate hint was set, assuming Segment is mocked or verified internally
    }

    @Test
    void unpack_withLogFile() throws IOException, Pack200Exception {
        byte[] magic = { (byte) 0xCA, (byte) 0xFE, (byte) 0xD0, 0x0D };
        InputStream inputStream = new ByteArrayInputStream(magic);
        JarOutputStream jarOutputStream = mock(JarOutputStream.class);
        Archive archive = new Archive(inputStream, jarOutputStream);
        archive.setLogFile("test.log");
        archive.unpack();
        // Verify log file was written, assuming internal logging
    }

    @Test
    void unpack_withQuietLogLevel() throws IOException, Pack200Exception {
        byte[] magic = { (byte) 0xCA, (byte) 0xFE, (byte) 0xD0, 0x0D };
        InputStream inputStream = new ByteArrayInputStream(magic);
        JarOutputStream jarOutputStream = mock(JarOutputStream.class);
        Archive archive = new Archive(inputStream, jarOutputStream);
        archive.setQuiet(true);
        archive.unpack();
        // Verify log level was set to quiet, assuming internal logging
    }

    @Test
    void unpack_withVerboseLogLevel() throws IOException, Pack200Exception {
        byte[] magic = { (byte) 0xCA, (byte) 0xFE, (byte) 0xD0, 0x0D };
        InputStream inputStream = new ByteArrayInputStream(magic);
        JarOutputStream jarOutputStream = mock(JarOutputStream.class);
        Archive archive = new Archive(inputStream, jarOutputStream);
        archive.setVerbose(true);
        archive.unpack();
        // Verify log level was set to verbose, assuming internal logging
    }

    @Test
    void unpack_withIOExceptionDuringRead() throws IOException {
        InputStream mockStream = mock(InputStream.class);
        when(mockStream.markSupported()).thenReturn(true);
        when(mockStream.read()).thenThrow(new IOException("Read error"));
        JarOutputStream jarOutputStream = mock(JarOutputStream.class);
        Archive archive = new Archive(mockStream, jarOutputStream);
        assertThrows(IOException.class, () -> archive.unpack());
    }

    private byte[] concatenate(byte[] a, byte[] b) {
        byte[] c = new byte[a.length + b.length];
        System.arraycopy(a, 0, c, 0, a.length);
        System.arraycopy(b, 0, c, a.length, b.length);
        return c;
    }
}