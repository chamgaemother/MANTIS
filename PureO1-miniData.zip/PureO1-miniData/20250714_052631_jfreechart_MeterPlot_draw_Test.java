import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.text.NumberFormat;

import org.jfree.chart.plot.MeterPlot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.data.Range;
import org.jfree.data.general.ValueDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class MeterPlotTest {

    private MeterPlot plot;
    private Graphics2D g2;
    private Rectangle2D area;
    private Point2D anchor;
    private PlotState parentState;
    private PlotRenderingInfo info;
    private ValueDataset dataset;

    @BeforeEach
    void setUp() {
        plot = new MeterPlot();
        g2 = mock(Graphics2D.class);
        area = new Rectangle2D.Double(0, 0, 200, 200);
        anchor = mock(Point2D.class);
        parentState = mock(PlotState.class);
        info = mock(PlotRenderingInfo.class);
        dataset = mock(ValueDataset.class);
    }

    @Test
    void testDrawInfoNull() {
        plot.setDrawBorder(false);
        plot.draw(g2, area, anchor, parentState, null);
        // Verify that info is not used
        verify(info, never()).setPlotArea(any());
    }

    @Test
    void testDrawWithInfo() {
        plot.setDrawBorder(false);
        plot.draw(g2, area, anchor, parentState, info);
        verify(info).setPlotArea(area);
    }

    @Test
    void testDrawWithBorder() {
        plot.setDrawBorder(true);
        plot.draw(g2, area, anchor, parentState, info);
        // Since Graphics2D operations are mocked, we can verify interactions
        // For example, verify that fill or draw methods are called
        // Here we assume drawBackground is called
        // Cannot verify private method calls
    }

    @Test
    void testDrawWithoutBorder() {
        plot.setDrawBorder(false);
        plot.draw(g2, area, anchor, parentState, info);
        // Similar to above, ensure background is not drawn
    }

    @Test
    void testDrawWithNullDataset() {
        plot.setDataset(null);
        plot.draw(g2, area, anchor, parentState, info);
        // Ensure that data-related drawing is skipped
    }

    @Test
    void testDrawWithDatasetNullValue() {
        plot.setDataset(dataset);
        when(dataset.getValue()).thenReturn(null);
        plot.draw(g2, area, anchor, parentState, info);
        // Ensure value label is "No value"
    }

    @Test
    void testDrawWithDatasetContainsValue() {
        plot.setDataset(dataset);
        when(dataset.getValue()).thenReturn(50.0);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify that needle is drawn
    }

    @Test
    void testDrawWithDialBackgroundPaintNull() {
        plot.setDialBackgroundPaint(null);
        plot.setDataset(dataset);
        when(dataset.getValue()).thenReturn(50.0);
        plot.draw(g2, area, anchor, parentState, info);
        // Ensure fillArc is not called for dial background
    }

    @Test
    void testDrawWithDialBackgroundPaintNotNull() {
        Paint bgPaint = Color.BLUE;
        plot.setDialBackgroundPaint(bgPaint);
        plot.setDataset(dataset);
        when(dataset.getValue()).thenReturn(50.0);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify that fillArc is called with bgPaint
    }

    @Test
    void testDrawWithDifferentDialShapes() {
        plot.setDialShape(DialShape.CHORD);
        plot.draw(g2, area, anchor, parentState, info);
        plot.setDialShape(DialShape.PIE);
        plot.draw(g2, area, anchor, parentState, info);
        plot.setDialShape(DialShape.CIRCLE);
        plot.draw(g2, area, anchor, parentState, info);
        // Each shape should influence arc drawing differently
    }

    @Test
    void testDrawWithMeterAngleBoundaryLower() {
        plot.setMeterAngle(1);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify behavior at lower boundary
    }

    @Test
    void testDrawWithMeterAngleBoundaryUpper() {
        plot.setMeterAngle(360);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify behavior at upper boundary
    }

    @Test
    void testDrawWithIntervalsEmpty() {
        plot.clearIntervals();
        plot.draw(g2, area, anchor, parentState, info);
        // Ensure no intervals are drawn
    }

    @Test
    void testDrawWithIntervalsNonEmpty() {
        plot.addInterval(new MeterInterval("Warning", new Range(70, 90), Color.ORANGE, null, null));
        plot.addInterval(new MeterInterval("Critical", new Range(90, 100), Color.RED, null, null));
        plot.draw(g2, area, anchor, parentState, info);
        // Verify that intervals are drawn
    }

    @Test
    void testDrawRangeContainsValue() {
        plot.setDataset(dataset);
        plot.setRange(new Range(0, 100));
        when(dataset.getValue()).thenReturn(75.0);
        plot.draw(g2, area, anchor, parentState, info);
        // Value within range, needle should be drawn
    }

    @Test
    void testDrawRangeDoesNotContainValue() {
        plot.setDataset(dataset);
        plot.setRange(new Range(0, 50));
        when(dataset.getValue()).thenReturn(75.0);
        plot.draw(g2, area, anchor, parentState, info);
        // Value outside range, needle should not be drawn
    }

    @Test
    void testDrawValueVisibleFalse() {
        plot.setValueVisible(false);
        plot.setDataset(dataset);
        when(dataset.getValue()).thenReturn(50.0);
        plot.draw(g2, area, anchor, parentState, info);
        // Value label should not be drawn
    }

    @Test
    void testDrawTickLabelsVisibleFalse() {
        plot.setTickLabelsVisible(false);
        plot.draw(g2, area, anchor, parentState, info);
        // Tick labels should not be drawn
    }

    @Test
    void testDrawWithCustomTickSize() {
        plot.setTickSize(5.0);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify ticks are drawn with tick size 5
    }

    @Test
    void testDrawWithCustomTickPaint() {
        Paint tickPaint = Color.MAGENTA;
        plot.setTickPaint(tickPaint);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify ticks are drawn with magenta paint
    }

    @Test
    void testDrawWithCustomNeedlePaint() {
        Paint needlePaint = Color.CYAN;
        plot.setNeedlePaint(needlePaint);
        plot.setDataset(dataset);
        when(dataset.getValue()).thenReturn(50.0);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify needle is drawn with cyan paint
    }

    @Test
    void testDrawWithCustomValueFont() {
        Font font = new Font("Serif", Font.PLAIN, 14);
        plot.setValueFont(font);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify value label is drawn with custom font
    }

    @Test
    void testDrawWithCustomValuePaint() {
        Paint valuePaint = Color.GREEN;
        plot.setValuePaint(valuePaint);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify value label is drawn with green paint
    }

    @Test
    void testDrawWithCustomDialOutlinePaint() {
        Paint outlinePaint = Color.YELLOW;
        plot.setDialOutlinePaint(outlinePaint);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify dial outline is drawn with yellow paint
    }

    @Test
    void testDrawWithCustomTickLabelFont() {
        Font tickFont = new Font("Monospaced", Font.BOLD, 10);
        plot.setTickLabelFont(tickFont);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify tick labels are drawn with custom font
    }

    @Test
    void testDrawWithCustomTickLabelPaint() {
        Paint tickLabelPaint = Color.PINK;
        plot.setTickLabelPaint(tickLabelPaint);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify tick labels are drawn with pink paint
    }

    @Test
    void testDrawWithCustomTickLabelFormat() {
        NumberFormat format = NumberFormat.getPercentInstance();
        plot.setTickLabelFormat(format);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify tick labels are formatted as percentages
    }

    @Test
    void testDrawWithNoIntervals() {
        plot.clearIntervals();
        plot.draw(g2, area, anchor, parentState, info);
        // Ensure no interval arcs are drawn
    }

    @Test
    void testDrawWithMultipleIntervals() {
        plot.addInterval(new MeterInterval("Low", new Range(0, 30), Color.GREEN, null, null));
        plot.addInterval(new MeterInterval("Medium", new Range(30, 70), Color.YELLOW, null, null));
        plot.addInterval(new MeterInterval("High", new Range(70, 100), Color.RED, null, null));
        plot.draw(g2, area, anchor, parentState, info);
        // Verify multiple intervals are drawn correctly
    }

    @Test
    void testDrawWithExtremeValues() {
        plot.setRange(new Range(-100, 200));
        plot.setDataset(dataset);
        when(dataset.getValue()).thenReturn(-50.0);
        plot.draw(g2, area, anchor, parentState, info);
        when(dataset.getValue()).thenReturn(250.0);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify drawing with values outside the range
    }

    @Test
    void testDrawWithZeroTickSize() {
        // Setting tick size to a very small positive number
        plot.setTickSize(0.1);
        plot.draw(g2, area, anchor, parentState, info);
        // Ensure ticks are drawn with small intervals
    }

    @Test
    void testDrawWithMaximumTickSize() {
        plot.setTickSize(1000.0);
        plot.draw(g2, area, anchor, parentState, info);
        // Ensure ticks are drawn correctly with large intervals
    }

    @Test
    void testDrawWithFullCircleDialShape() {
        plot.setDialShape(DialShape.CIRCLE);
        plot.setMeterAngle(360);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify full circle is drawn
    }

    @Test
    void testDrawWithPartialCircleDialShape() {
        plot.setDialShape(DialShape.CHORD);
        plot.setMeterAngle(270);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify partial circle is drawn correctly
    }

    @Test
    void testDrawWithPieDialShape() {
        plot.setDialShape(DialShape.PIE);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify pie shape is drawn correctly
    }

    @Test
    void testDrawWithCustomUnits() {
        plot.setUnits("Percent");
        plot.setDataset(dataset);
        when(dataset.getValue()).thenReturn(50.0);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify value label includes "Percent"
    }

    @Test
    void testDrawWithNoUnits() {
        plot.setUnits(null);
        plot.setDataset(dataset);
        when(dataset.getValue()).thenReturn(50.0);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify value label omits units
    }

    @Test
    void testDrawWithMinimalArea() {
        Rectangle2D smallArea = new Rectangle2D.Double(0, 0, 10, 10);
        plot.draw(g2, smallArea, anchor, parentState, info);
        // Verify drawing with minimal area
    }

    @Test
    void testDrawWithLargeArea() {
        Rectangle2D largeArea = new Rectangle2D.Double(0, 0, 1000, 1000);
        plot.draw(g2, largeArea, anchor, parentState, info);
        // Verify drawing with large area
    }

    @Test
    void testDrawWithNegativeArea() {
        Rectangle2D negativeArea = new Rectangle2D.Double(-100, -100, 200, 200);
        plot.draw(g2, negativeArea, anchor, parentState, info);
        // Verify drawing with negative coordinates
    }

    @Test
    void testDrawWithCustomValueFormat() {
        NumberFormat customFormat = NumberFormat.getCurrencyInstance();
        plot.setTickLabelFormat(customFormat);
        plot.setDataset(dataset);
        when(dataset.getValue()).thenReturn(75.5);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify value label is formatted as currency
    }

    @Test
    void testDrawWithMultipleDatasetChanges() {
        plot.setDataset(dataset);
        when(dataset.getValue()).thenReturn(20.0);
        plot.draw(g2, area, anchor, parentState, info);
        when(dataset.getValue()).thenReturn(80.0);
        plot.draw(g2, area, anchor, parentState, info);
        // Verify drawing handles multiple dataset changes
    }
}