package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;

import java.nio.charset.StandardCharsets;

public class JsonStringEncoder_encodeAsUTF8_1_1_Test {

    @Test
    @DisplayName("encodeAsUTF8 with mixed 2-byte and 3-byte characters triggers buffer reallocation")
    void TC20_encodeAsUTF8_mixedEncoding_bufferReallocation() {
        // GIVEN
        JsonStringEncoder encoder = new JsonStringEncoder();
        String text = "Hello ÃÂ© World Ã Â¥Â";
        
        // WHEN
        byte[] result = encoder.encodeAsUTF8(text);
        
        // THEN
        byte[] expected = text.getBytes(StandardCharsets.UTF_8);
        assertArrayEquals(expected, result);
    }

    @Test
    @DisplayName("encodeAsUTF8 with input size exactly at MAX_BYTE_BUFFER_SIZE boundary")
    void TC21_encodeAsUTF8_inputAtMaxBufferSizeBoundary() {
        // GIVEN
        JsonStringEncoder encoder = new JsonStringEncoder();
        String text = "A".repeat(32000);
        
        // WHEN
        byte[] result = encoder.encodeAsUTF8(text);
        
        // THEN
        byte[] expected = text.getBytes(StandardCharsets.UTF_8);
        assertArrayEquals(expected, result);
    }

    @Test
    @DisplayName("encodeAsUTF8 with characters causing multiple buffer reallocations")
    void TC22_encodeAsUTF8_multipleBufferReallocations() {
        // GIVEN
        JsonStringEncoder encoder = new JsonStringEncoder();
        String text = "Ã£Â©Ã£Â©Ã£Â©Ã£Â©Ã£Â©Ã£Â©Ã£Â©Ã£Â©Ã£Â©Ã£Â©Ã£Â©Ã£Â©Ã£Â©Ã£Â©Ã£Â©Ã£Â©Ã£Â©Ã£Â©Ã£Â©Ã£Â©";
        
        // WHEN
        byte[] result = encoder.encodeAsUTF8(text);
        
        // THEN
        byte[] expected = text.getBytes(StandardCharsets.UTF_8);
        assertArrayEquals(expected, result);
    }

    @Test
    @DisplayName("encodeAsUTF8 with consecutive high and low surrogate pairs causing multiple conversions")
    void TC23_encodeAsUTF8_consecutiveSurrogatePairs() {
        // GIVEN
        JsonStringEncoder encoder = new JsonStringEncoder();
        String text = "ðð";
        
        // WHEN
        byte[] result = encoder.encodeAsUTF8(text);
        
        // THEN
        byte[] expected = text.getBytes(StandardCharsets.UTF_8);
        assertArrayEquals(expected, result);
    }
}