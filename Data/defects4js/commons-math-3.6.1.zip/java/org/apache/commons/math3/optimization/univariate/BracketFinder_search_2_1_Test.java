//package org.apache.commons.math3.optimization.univariate;
//
//import org.apache.commons.math3.analysis.UnivariateFunction;
//import org.apache.commons.math3.exception.MaxCountExceededException;
//import org.apache.commons.math3.exception.NotStrictlyPositiveException;
//import org.apache.commons.math3.exception.TooManyEvaluationsException;
//import org.apache.commons.math3.optim.nonlinear.scalar.GoalType;
//import org.junit.jupiter.api.DisplayName;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mockito;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.ArgumentMatchers.anyDouble;
//
//@Deprecated
//public class BracketFinder_search_2_1_Test {
//
//    @Test
//    @DisplayName("search method handles denominator less than EPS_MIN by setting denom to 2 * EPS_MIN")
//    public void TC34() {
//        // GIVEN
//        GoalType goal = GoalType.MINIMIZE;
//        double xA = 1.0;
//        double xB = 2.0;
//        UnivariateFunction func = Mockito.mock(UnivariateFunction.class);
//        // Configure func to produce val < EPS_MIN
//        Mockito.when(func.value(anyDouble())).thenReturn(1.0, 2.0, 0.0);
//        BracketFinder finder = new BracketFinder(1.618034, 50);
//
//        // WHEN
//        finder.search(func, goal, xA, xB);
//
//        // THEN
//        assertEquals(1.0, finder.getLo(), 1e-6, "lo should remain as xA");
//        assertEquals(2.0, finder.getMid(), 1e-6, "mid should remain as xB");
//        assertTrue(finder.getHi() > finder.getMid(), "hi should be greater than mid");
//        assertEquals(1.0, finder.getFLo(), 1e-6, "fLo should remain as fA");
//        assertEquals(2.0, finder.getFMid(), 1e-6, "fMid should remain as fB");
//        assertEquals(0.0, finder.getFHi(), 1e-6, "fHi should be set correctly");
//    }
//
//    @Test
//    @DisplayName("search method correctly handles (w - xC)*(xB - w) equals zero")
//    public void TC35() {
//        // GIVEN
//        GoalType goal = GoalType.MAXIMIZE;
//        double xA = 1.0;
//        double xB = 2.0;
//        UnivariateFunction func = Mockito.mock(UnivariateFunction.class);
//        // Configure func to cause (w - xC)*(xB - w) == 0
//        Mockito.when(func.value(anyDouble())).thenReturn(3.0, 2.0, 4.0);
//        BracketFinder finder = new BracketFinder(1.618034, 50);
//
//        // WHEN
//        finder.search(func, goal, xA, xB);
//
//        // THEN
//        assertEquals(1.0, finder.getLo(), 1e-6, "lo should remain as xA");
//        assertEquals(2.0, finder.getMid(), 1e-6, "mid should remain as xB");
//        assertTrue(finder.getHi() > finder.getMid(), "hi should be greater than mid");
//        assertEquals(3.0, finder.getFLo(), 1e-6, "fLo should be fA");
//        assertEquals(2.0, finder.getFMid(), 1e-6, "fMid should be fB");
//        assertEquals(4.0, finder.getFHi(), 1e-6, "fHi should be set correctly");
//    }
//
//    @Test
//    @DisplayName("search method sets w to wLim when (w - wLim)*(wLim - xC) >= 0")
//    public void TC36() {
//        // GIVEN
//        GoalType goal = GoalType.MINIMIZE;
//        double xA = 1.0;
//        double xB = 2.0;
//        UnivariateFunction func = Mockito.mock(UnivariateFunction.class);
//        // Configure func to satisfy (w - wLim)*(wLim - xC) >= 0
//        Mockito.when(func.value(anyDouble())).thenReturn(1.0, 2.0, 3.0, 4.0);
//        BracketFinder finder = new BracketFinder(1.618034, 50);
//
//        // WHEN
//        finder.search(func, goal, xA, xB);
//
//        // THEN
//        assertEquals(1.0, finder.getLo(), 1e-6, "lo should remain as xA");
//        assertEquals(2.0, finder.getMid(), 1e-6, "mid should remain as xB");
//        assertEquals(2.0 + 1.618034 * (2.0 - 1.0), finder.getHi(), 1e-6, "hi should be set to wLim");
//        assertEquals(1.0, finder.getFLo(), 1e-6, "fLo should be fA");
//        assertEquals(2.0, finder.getFMid(), 1e-6, "fMid should be fB");
//        assertEquals(3.0, finder.getFHi(), 1e-6, "fHi should be set correctly");
//    }
//
//    @Test
//    @DisplayName("search method handles xA equal to xB without swapping and correctly sets the bracket")
//    public void TC37() {
//        // GIVEN
//        GoalType goal = GoalType.MAXIMIZE;
//        double xA = 2.0;
//        double xB = 2.0;
//        UnivariateFunction func = Mockito.mock(UnivariateFunction.class);
//        // Configure func to return the same value for xA and xB
//        Mockito.when(func.value(2.0)).thenReturn(2.0);
//        BracketFinder finder = new BracketFinder(1.618034, 50);
//
//        // WHEN
//        finder.search(func, goal, xA, xB);
//
//        // THEN
//        assertEquals(2.0, finder.getLo(), 1e-6, "lo should remain as xA");
//        assertEquals(2.0, finder.getMid(), 1e-6, "mid should remain as xB");
//        assertTrue(finder.getHi() > finder.getMid(), "hi should be greater than mid");
//        assertEquals(2.0, finder.getFLo(), 1e-6, "fLo should be fA");
//        assertEquals(2.0, finder.getFMid(), 1e-6, "fMid should be fB");
//        // fHi depends on the function evaluation at hi
//        assertEquals(2.0, finder.getFHi(), 1e-6, "fHi should be set correctly");
//    }
//}