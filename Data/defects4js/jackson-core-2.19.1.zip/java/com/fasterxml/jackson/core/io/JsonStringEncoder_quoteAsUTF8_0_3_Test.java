package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class JsonStringEncoder_quoteAsUTF8_0_3_Test {

    @Test
    @DisplayName("quoteAsUTF8 with maximum allowed UTF-8 buffer size")
    public void TC11_max_utf8_size() throws Exception {
        // Initialize JsonStringEncoder
        JsonStringEncoder encoder = new JsonStringEncoder();

        // Access MAX_BYTE_BUFFER_SIZE via reflection
        Field maxBufSizeField = JsonStringEncoder.class.getDeclaredField("_MAX_BYTE_BUFFER_SIZE");
        maxBufSizeField.setAccessible(true);
        int maxByteBufSize = maxBufSizeField.getInt(encoder);

        // Generate a string that approaches MAX_BYTE_BUFFER_SIZE
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < maxByteBufSize / 3; i++) { // Assuming max expansion by factor of 3
            sb.append('a');
        }
        String text = sb.toString();

        // Invoke quoteAsUTF8
        byte[] result = encoder.quoteAsUTF8(text);

        // Assert that the result does not exceed MAX_BYTE_BUFFER_SIZE
        Assertions.assertTrue(result.length <= maxByteBufSize,
                "Encoded byte array exceeds maximum buffer size");
    }

    @Test
    @DisplayName("quoteAsUTF8 with null input throws NullPointerException")
    public void TC12_null_input() {
        // Initialize JsonStringEncoder
        JsonStringEncoder encoder = new JsonStringEncoder();

        // Define null input
        String text = null;

        // Assert that NullPointerException is thrown
        Assertions.assertThrows(NullPointerException.class, () -> {
            encoder.quoteAsUTF8(text);
        }, "Expected quoteAsUTF8(null) to throw NullPointerException");
    }

    @Test
    @DisplayName("quoteAsUTF8 with string ending with an escapable character")
    public void TC13_escape_at_end() throws Exception {
        // Initialize JsonStringEncoder
        JsonStringEncoder encoder = new JsonStringEncoder();

        // Define input string ending with an escapable character
        String text = "HelloWorld\n";

        // Invoke quoteAsUTF8
        byte[] result = encoder.quoteAsUTF8(text);

        // Define expected byte array
        byte[] expected = "HelloWorld\\n".getBytes(StandardCharsets.UTF_8);

        // Assert that the result matches the expected byte array
        Assertions.assertArrayEquals(expected, result,
                "Encoded byte array does not match expected value with escaped end character");
    }

    @Test
    @DisplayName("quoteAsUTF8 with string containing multiple consecutive escapable characters")
    public void TC14_multiple_consecutive_escapes() throws Exception {
        // Initialize JsonStringEncoder
        JsonStringEncoder encoder = new JsonStringEncoder();

        // Define input string with multiple consecutive escapable characters
        String text = "Line1\nLine2\tLine3";

        // Invoke quoteAsUTF8
        byte[] result = encoder.quoteAsUTF8(text);

        // Define expected byte array
        byte[] expected = {76, 105, 110, 101, 49, 92, 110, 76, 105, 110, 101, 50, 92, 116, 76, 105, 110, 101, 51};

        // Assert that the result matches the expected byte array
        Assertions.assertArrayEquals(expected, result,
                "Encoded byte array does not match expected value with multiple consecutive escaped characters");
    }

    @Test
    @DisplayName("quoteAsUTF8 with string containing maximum single escape sequence")
    public void TC15_maximum_escape_sequence() throws Exception {
        // Initialize JsonStringEncoder
        JsonStringEncoder encoder = new JsonStringEncoder();

        // Define input string containing maximum single escape sequence
        String text = "\\uFFFF";

        // Invoke quoteAsUTF8
        byte[] result = encoder.quoteAsUTF8(text);

        // Define expected byte array with proper escaping
        byte[] expected = {92, 92, 117, 70, 70, 70, 70}; // Represents "\uFFFF"

        // Assert that the result matches the expected byte array
        Assertions.assertArrayEquals(expected, result,
                "Encoded byte array does not match expected value with maximum single escape sequence");
    }
}