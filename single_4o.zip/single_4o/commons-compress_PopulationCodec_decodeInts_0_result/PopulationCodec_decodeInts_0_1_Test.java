package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import static org.junit.jupiter.api.Assertions.*;

public class PopulationCodec_decodeInts_0_1_Test {

    @Test
    @DisplayName("Verifies decodeInts with n=0 for zero iterations scenario")
    void testDecodeInts_ZeroIterations() throws Exception {
        // Using a constructor with valid arguments
        Codec dummyCodec = new DummyCodec();
        PopulationCodec codec = new PopulationCodec(dummyCodec, 1, dummyCodec);
        InputStream in = new ByteArrayInputStream(new byte[0]);
        int[] result = codec.decodeInts(0, in);  // Fixed: using zero-length input stream
        assertEquals(0, result.length, "Expected an empty int array");
    }

    @Test
    @DisplayName("Verifies decodeInts with single iteration for the 'favoured' path")
    void testDecodeInts_SingleFavouredIteration() throws Exception {
        Codec dummyCodec = new DummyCodec();
        PopulationCodec codec = new PopulationCodec(dummyCodec, 1, dummyCodec);
        Codec favouredCodecMock = createFavouredCodecMock();
        setFavouredCodec(codec, favouredCodecMock);
        InputStream in = new ByteArrayInputStream(new byte[]{42});  // Mock data that codec understands
        int[] result = codec.decodeInts(1, in);
        assertEquals(1, result.length, "Expected an int array with one element");
    }

    @Test
    @DisplayName("Handles creating tokenCodec when tokenCodec is initially null, k >= 256")
    void testTokenCodecCreationForLargeK() throws Exception {
        Codec dummyCodec = new DummyCodec();
        PopulationCodec codec = new PopulationCodec(dummyCodec, 1, dummyCodec);
        assertNull(codec.getTokenCodec(), "tokenCodec should be null initially");

        InputStream in = new ByteArrayInputStream(new byte[256]); // Simulate k >= 256 with byte[]
        int[] result = codec.decodeInts(256, in);

        assertNotNull(codec.getTokenCodec(), "tokenCodec should not be null after method execution");
        assertEquals(256, result.length, "Expected an int array with 256 elements");
    }

    @Test
    @DisplayName("Exception scenario triggered by invalid tokenCodec calculation")
    void testDecodeInts_ExceptionOnInvalidTokenCodec() {
        Codec dummyCodec = new DummyCodec();
        PopulationCodec codec = new PopulationCodec(dummyCodec, 1, dummyCodec);
        Codec favouredCodecMock = createFavouredCodecMock();
        setFavouredCodec(codec, favouredCodecMock);

        InputStream in = new ByteArrayInputStream(new byte[]{1, 1, 1, 1, 1});
        assertThrows(Pack200Exception.class, () -> {
            codec.decodeInts(5, in);
        }, "Expected a Pack200Exception due to invalid tokenCodec calculation");
    }

    // Dummy implementation of Codec to avoid compilation errors
    private static class DummyCodec extends Codec {
        @Override
        public int decode(InputStream in, long last) throws IOException, Pack200Exception {
            return 42;
        }

        @Override
        public int[] decodeInts(int n, InputStream in) throws IOException, Pack200Exception {
            return new int[n];
        }

        @Override
        public byte[] encode(int value) throws Pack200Exception {
            return new byte[0];
        }

        @Override
        public byte[] encode(int value, int last) throws Pack200Exception {
            return new byte[0];
        }
    }

    private Codec createFavouredCodecMock() {
        return new Codec() {
            @Override
            public int decode(InputStream in, long last) {
                return 42;
            }

            @Override
            public int[] decodeInts(int n, InputStream in) {
                return new int[]{42};
            }

            @Override
            public byte[] encode(int value) throws Pack200Exception {
                return new byte[0];
            }

            @Override
            public byte[] encode(int value, int last) throws Pack200Exception {
                return new byte[0];
            }
        };
    }

    private void setFavouredCodec(PopulationCodec codec, Codec favouredCodec) throws NoSuchFieldException, IllegalAccessException {
        java.lang.reflect.Field field = PopulationCodec.class.getDeclaredField("favouredCodec");
        field.setAccessible(true);
        field.set(codec, favouredCodec);
    }
}