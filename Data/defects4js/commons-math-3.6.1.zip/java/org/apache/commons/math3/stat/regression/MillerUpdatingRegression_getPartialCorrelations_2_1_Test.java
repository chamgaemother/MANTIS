package org.apache.commons.math3.stat.regression;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class MillerUpdatingRegression_getPartialCorrelations_2_1_Test {

    @Test
    @DisplayName("getPartialCorrelations with valid 'in', d[in] > 0, and multiple iterations in the column loop")
    void TC16_getPartialCorrelations_ValidIn_DInGreaterThanZero_MultipleIterations() throws Exception {
        // GIVEN
        int in = 2;
        int nvars = 5;
        MillerUpdatingRegression regression = new MillerUpdatingRegression(nvars, false);

        // Using reflection to set private fields
        Field dField = MillerUpdatingRegression.class.getDeclaredField("d");
        dField.setAccessible(true);
        double[] d = {1.0, 2.0, 4.0, 3.0, 5.0}; // d[in] = 4.0 > 0
        dField.set(regression, d);

        // Set other necessary fields to ensure multiple iterations
        Field sserrField = MillerUpdatingRegression.class.getDeclaredField("sserr");
        sserrField.setAccessible(true);
        sserrField.setDouble(regression, 10.0);

        Field rhsField = MillerUpdatingRegression.class.getDeclaredField("rhs");
        rhsField.setAccessible(true);
        double[] rhs = {2.0, 3.0, 4.0, 5.0, 6.0};
        rhsField.set(regression, rhs);

        // WHEN
        double[] result = regression.getPartialCorrelations(in);

        // THEN
        assertNotNull(result, "Result should not be null");
        int expectedLength = ((nvars - in + 1) * (nvars - in)) / 2;
        assertEquals(expectedLength, result.length, "Result array length mismatch");
        
        // Additional assertions based on expected partial correlations
        // For demonstration, we'll check if all values are finite numbers
        for (double val : result) {
            assertTrue(Double.isFinite(val), "Partial correlation should be a finite number");
        }
    }

    @Test
    @DisplayName("getPartialCorrelations with valid 'in', d[in] > 0, and sumyy equals zero")
    void TC17_getPartialCorrelations_ValidIn_DInGreaterThanZero_SumyyZero() throws Exception {
        // GIVEN
        int in = 1;
        int nvars = 4;
        MillerUpdatingRegression regression = new MillerUpdatingRegression(nvars, false);

        // Using reflection to set private fields
        Field dField = MillerUpdatingRegression.class.getDeclaredField("d");
        dField.setAccessible(true);
        double[] d = {1.0, 2.0, 4.0, 3.0}; // d[in] = 2.0 > 0
        dField.set(regression, d);

        Field sserrField = MillerUpdatingRegression.class.getDeclaredField("sserr");
        sserrField.setAccessible(true);
        sserrField.setDouble(regression, 0.0); // sumyy = 0

        Field rhsField = MillerUpdatingRegression.class.getDeclaredField("rhs");
        rhsField.setAccessible(true);
        double[] rhs = {0.0, 0.0, 0.0, 0.0};
        rhsField.set(regression, rhs);

        // WHEN
        double[] result = regression.getPartialCorrelations(in);

        // THEN
        assertNotNull(result, "Result should not be null");
        
        // Verify that partial correlations are scaled appropriately
        for(double val : result) {
            assertEquals(0.0, val, "Partial correlations should be zero when sumyy is zero");
        }
    }
}