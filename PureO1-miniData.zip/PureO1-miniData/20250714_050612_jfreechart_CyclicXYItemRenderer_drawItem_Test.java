package org.jfree.chart.renderer.xy;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CyclicNumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.urls.XYURLGenerator;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
import org.mockito.Mockito;

class CyclicXYItemRendererTest {

    private CyclicXYItemRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private CrosshairState crosshairState;

    @BeforeEach
    void setUp() {
        renderer = new CyclicXYItemRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = mock(Rectangle2D.class);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(XYDataset.class);
        crosshairState = mock(CrosshairState.class);
    }

    @Test
    void testDrawItem_PlotLinesFalse() {
        renderer.setPlotLines(false);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(renderer, never()).superDrawItem(any(), any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), any(), anyInt());
    }

    @Test
    void testDrawItem_NonCyclicDomainAxis() {
        when(domainAxis instanceof CyclicNumberAxis).thenReturn(false);
        when(rangeAxis instanceof CyclicNumberAxis).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(renderer, times(1)).superDrawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }

    @Test
    void testDrawItem_NonCyclicRangeAxis() {
        when(domainAxis instanceof CyclicNumberAxis).thenReturn(true);
        when(rangeAxis instanceof CyclicNumberAxis).thenReturn(false);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 1)).thenReturn(2.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(renderer, times(1)).superDrawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }

    @Test
    void testDrawItem_ItemLessThanOrEqualZero() {
        when(domainAxis instanceof CyclicNumberAxis).thenReturn(true);
        when(rangeAxis instanceof CyclicNumberAxis).thenReturn(true);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 0, crosshairState, 0);
        verify(renderer, times(1)).superDrawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
    }

    @Test
    void testDrawItem_PreviousYValueNaN() {
        when(domainAxis instanceof CyclicNumberAxis).thenReturn(true);
        when(rangeAxis instanceof CyclicNumberAxis).thenReturn(true);
        when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(renderer, times(1)).superDrawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }

    @Test
    void testDrawItem_CurrentYValueNaN() {
        when(domainAxis instanceof CyclicNumberAxis).thenReturn(true);
        when(rangeAxis instanceof CyclicNumberAxis).thenReturn(true);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 1)).thenReturn(Double.NaN);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(renderer, never()).superDrawItem(any(), any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), any(), anyInt());
    }

    @Test
    void testDrawItem_DomainAxisNotCyclic() {
        when(domainAxis instanceof CyclicNumberAxis).thenReturn(false);
        when(rangeAxis instanceof CyclicNumberAxis).thenReturn(true);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 1)).thenReturn(2.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(renderer, times(1)).superDrawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }

    @Test
    void testDrawItem_BothAxesCyclic_NoSplit() {
        when(domainAxis instanceof CyclicNumberAxis).thenReturn(true);
        when(rangeAxis instanceof CyclicNumberAxis).thenReturn(true);
        CyclicNumberAxis cyclicDomain = mock(CyclicNumberAxis.class);
        CyclicNumberAxis cyclicRange = mock(CyclicNumberAxis.class);
        when(domainAxis).thenReturn(cyclicDomain);
        when(rangeAxis).thenReturn(cyclicRange);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 1)).thenReturn(2.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(renderer, times(1)).superDrawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }

    @Test
    void testDrawItem_DomainAxisSplit() {
        when(domainAxis instanceof CyclicNumberAxis).thenReturn(true);
        when(rangeAxis instanceof CyclicNumberAxis).thenReturn(false);
        CyclicNumberAxis cyclicDomain = mock(CyclicNumberAxis.class);
        when(domainAxis).thenReturn(cyclicDomain);
        when(cyclicDomain.getCycleBound()).thenReturn(5.0);
        when(cyclicDomain.isBoundMappedToLastCycle()).thenReturn(false);
        when(dataset.getXValue(0, 0)).thenReturn(4.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(6.0);
        when(dataset.getYValue(0, 1)).thenReturn(2.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(cyclicDomain, times(1)).getCycleBound();
        verify(renderer, times(2)).superDrawItem(any(), any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), any(), anyInt());
    }

    @Test
    void testDrawItem_RangeAxisSplit() {
        when(domainAxis instanceof CyclicNumberAxis).thenReturn(false);
        when(rangeAxis instanceof CyclicNumberAxis).thenReturn(true);
        CyclicNumberAxis cyclicRange = mock(CyclicNumberAxis.class);
        when(rangeAxis).thenReturn(cyclicRange);
        when(cyclicRange.getCycleBound()).thenReturn(10.0);
        when(cyclicRange.isBoundMappedToLastCycle()).thenReturn(false);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(9.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(11.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(cyclicRange, times(1)).getCycleBound();
        verify(renderer, times(2)).superDrawItem(any(), any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), any(), anyInt());
    }

    @Test
    void testDrawItem_BothAxesSplit() {
        when(domainAxis instanceof CyclicNumberAxis).thenReturn(true);
        when(rangeAxis instanceof CyclicNumberAxis).thenReturn(true);
        CyclicNumberAxis cyclicDomain = mock(CyclicNumberAxis.class);
        CyclicNumberAxis cyclicRange = mock(CyclicNumberAxis.class);
        when(domainAxis).thenReturn(cyclicDomain);
        when(rangeAxis).thenReturn(cyclicRange);
        when(cyclicDomain.getCycleBound()).thenReturn(5.0);
        when(cyclicDomain.isBoundMappedToLastCycle()).thenReturn(false);
        when(cyclicRange.getCycleBound()).thenReturn(10.0);
        when(cyclicRange.isBoundMappedToLastCycle()).thenReturn(false);
        when(dataset.getXValue(0, 0)).thenReturn(4.0);
        when(dataset.getYValue(0, 0)).thenReturn(9.0);
        when(dataset.getXValue(0, 1)).thenReturn(6.0);
        when(dataset.getYValue(0, 1)).thenReturn(11.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(cyclicDomain, times(1)).getCycleBound();
        verify(cyclicRange, times(1)).getCycleBound();
        verify(renderer, times(3)).superDrawItem(any(), any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), any(), anyInt());
    }

    @Test
    void testDrawItem_NullInputs() {
        renderer.drawItem(null, null, null, null, null, null, null, null, 0, 1, null, 0);
        // Expect no exception, but super.drawItem should not be called as conditions fail
        verify(renderer, never()).superDrawItem(any(), any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), any(), anyInt());
    }

    @Test
    void testDrawItem_ItemWithSinglePoint() {
        when(domainAxis instanceof CyclicNumberAxis).thenReturn(true);
        when(rangeAxis instanceof CyclicNumberAxis).thenReturn(true);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 1)).thenReturn(2.0);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(1.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(renderer, times(1)).superDrawItem(any(), any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), any(), anyInt());
    }

    @Test
    void testDrawItem_MultipleSplits() {
        when(domainAxis instanceof CyclicNumberAxis).thenReturn(true);
        when(rangeAxis instanceof CyclicNumberAxis).thenReturn(true);
        CyclicNumberAxis cyclicDomain = mock(CyclicNumberAxis.class);
        CyclicNumberAxis cyclicRange = mock(CyclicNumberAxis.class);
        when(domainAxis).thenReturn(cyclicDomain);
        when(rangeAxis).thenReturn(cyclicRange);
        when(cyclicDomain.getCycleBound()).thenReturn(5.0);
        when(cyclicRange.getCycleBound()).thenReturn(10.0);
        when(cyclicDomain.isBoundMappedToLastCycle()).thenReturn(false);
        when(cyclicRange.isBoundMappedToLastCycle()).thenReturn(false);
        when(dataset.getXValue(0, 0)).thenReturn(4.0);
        when(dataset.getYValue(0, 0)).thenReturn(9.0);
        when(dataset.getXValue(0, 1)).thenReturn(6.0);
        when(dataset.getYValue(0, 1)).thenReturn(11.0);
        when(dataset.getXValue(0, 2)).thenReturn(8.0);
        when(dataset.getYValue(0, 2)).thenReturn(12.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 2, crosshairState, 0);
        verify(renderer, times(3)).superDrawItem(any(), any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), any(), anyInt());
    }
}