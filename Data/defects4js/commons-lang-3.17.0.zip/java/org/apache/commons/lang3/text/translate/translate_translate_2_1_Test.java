package org.apache.commons.lang3.text.translate;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.mockito.Mockito;

import org.apache.commons.lang3.text.translate.AggregateTranslator;
import org.apache.commons.lang3.text.translate.CharSequenceTranslator;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

public class translate_translate_2_1_Test {

    @Test
    @DisplayName("translate method propagates IOException thrown by a translator")
    public void testTranslate_methodPropagatesIOException() throws IOException {
        // Arrange
        CharSequenceTranslator exceptionTranslator = Mockito.mock(CharSequenceTranslator.class);
        Mockito.when(exceptionTranslator.translate(Mockito.any(), Mockito.anyInt(), Mockito.any(Writer.class)))
            .thenThrow(new IOException("Test exception"));
        AggregateTranslator translator = new AggregateTranslator(exceptionTranslator);
        CharSequence input = "Test input";
        int index = 0;
        Writer out = new StringWriter();

        // Act & Assert
        Assertions.assertThrows(IOException.class, () -> {
            translator.translate(input, index, out);
        });
    }

    @Test
    @DisplayName("translate method handles negative index by returning 0")
    public void testTranslate_handlesNegativeIndex() throws IOException {
        // Arrange
        CharSequenceTranslator stubTranslator = Mockito.mock(CharSequenceTranslator.class);
        Mockito.when(stubTranslator.translate(Mockito.any(), Mockito.anyInt(), Mockito.any(Writer.class)))
            .thenReturn(0);
        AggregateTranslator translator = new AggregateTranslator(stubTranslator);
        CharSequence input = "Test input";
        int index = -1;
        Writer out = new StringWriter();

        // Act
        int result = translator.translate(input, index, out);

        // Assert
        Assertions.assertEquals(0, result);
    }
}