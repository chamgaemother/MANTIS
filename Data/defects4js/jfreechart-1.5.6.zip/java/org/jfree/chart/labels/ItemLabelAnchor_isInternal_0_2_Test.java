package org.jfree.chart.labels;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.jfree.chart.labels.ItemLabelAnchor;

public class ItemLabelAnchor_isInternal_0_2_Test {

    @Test
    @DisplayName("isInternal() returns true when the anchor is INSIDE5")
    void TC06_isInternal_INSIDE5() {
        // Given
        ItemLabelAnchor anchor = ItemLabelAnchor.INSIDE5;

        // When
        boolean result = anchor.isInternal();

        // Then
        assertTrue(result);
    }

    @Test
    @DisplayName("isInternal() returns true when the anchor is INSIDE6")
    void TC07_isInternal_INSIDE6() {
        // Given
        ItemLabelAnchor anchor = ItemLabelAnchor.INSIDE6;

        // When
        boolean result = anchor.isInternal();

        // Then
        assertTrue(result);
    }

    @Test
    @DisplayName("isInternal() returns true when the anchor is INSIDE7")
    void TC08_isInternal_INSIDE7() {
        // Given
        ItemLabelAnchor anchor = ItemLabelAnchor.INSIDE7;

        // When
        boolean result = anchor.isInternal();

        // Then
        assertTrue(result);
    }

    @Test
    @DisplayName("isInternal() returns true when the anchor is INSIDE8")
    void TC09_isInternal_INSIDE8() {
        // Given
        ItemLabelAnchor anchor = ItemLabelAnchor.INSIDE8;

        // When
        boolean result = anchor.isInternal();

        // Then
        assertTrue(result);
    }

    @Test
    @DisplayName("isInternal() returns true when the anchor is INSIDE9")
    void TC10_isInternal_INSIDE9() {
        // Given
        ItemLabelAnchor anchor = ItemLabelAnchor.INSIDE9;

        // When
        boolean result = anchor.isInternal();

        // Then
        assertTrue(result);
    }
}