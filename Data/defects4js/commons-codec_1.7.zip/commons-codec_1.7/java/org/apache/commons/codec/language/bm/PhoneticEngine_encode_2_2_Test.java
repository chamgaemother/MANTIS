package org.apache.commons.codec.language.bm;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Collections;

public class PhoneticEngine_encode_2_2_Test {

    @Test
    @DisplayName("encode with non-GENERIC NameType and input containing special characters to test handling of non-alphabetic characters")
    public void TC24_encode_with_special_characters_in_input() {
        // GIVEN
        PhoneticEngine engine = new PhoneticEngine(NameType.SEPHARDIC, RuleType.EXACT, false);
        String input = "Cohen!@#";
        Languages.LanguageSet languageSet = Languages.LanguageSet.from(Collections.singleton("hebrew"));

        // WHEN
        String result = engine.encode(input, languageSet);

        // THEN
        assertEquals("expectedEncodingWithoutSpecialChars", result);
    }
}