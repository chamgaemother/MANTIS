package org.jfree.chart.renderer.xy;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.data.xy.XYDataset;
import org.mockito.Mockito;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class XYAreaRenderer_drawItem_0_2_Test {

    @Test
    @DisplayName("Handles vertical plot orientation during rendering")
    void TC06_HandlesVerticalPlotOrientationDuringRendering() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getItemCount(anyInt())).thenReturn(5);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(2.0);

        CrosshairState crosshairState = mock(CrosshairState.class);
        int series = 0;
        int item = 0;
        int pass = 0;

        XYAreaRenderer renderer = new XYAreaRenderer();

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(g2, atLeastOnce()).draw(any(Shape.class));
    }

    @Test
    @DisplayName("Handles horizontal plot orientation during rendering")
    void TC07_HandlesHorizontalPlotOrientationDuringRendering() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getItemCount(anyInt())).thenReturn(5);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(2.0);

        CrosshairState crosshairState = mock(CrosshairState.class);
        int series = 0;
        int item = 0;
        int pass = 0;

        XYAreaRenderer renderer = new XYAreaRenderer();

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(g2, atLeastOnce()).draw(any(Shape.class));
    }

    @Test
    @DisplayName("Renders area correctly when item is the first in the series")
    void TC08_RendersAreaCorrectlyWhenItemIsFirstInSeries() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getItemCount(anyInt())).thenReturn(5);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(2.0);

        CrosshairState crosshairState = mock(CrosshairState.class);
        int series = 0;
        int item = 0;
        int pass = 0;

        XYAreaRenderer renderer = new XYAreaRenderer();

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(g2, atLeastOnce()).draw(any(Shape.class));
    }

    @Test
    @DisplayName("Does not render area for single point series")
    void TC09_DoesNotRenderAreaForSinglePointSeries() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getItemCount(anyInt())).thenReturn(1);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(2.0);

        CrosshairState crosshairState = mock(CrosshairState.class);
        int series = 0;
        int item = 0;
        int pass = 0;

        XYAreaRenderer renderer = new XYAreaRenderer();

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that fill and draw are not called for single point series
        verify(g2, never()).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
    }

    @Test
    @DisplayName("Handles multiple iterations in loops for calculating previous height")
    void TC10_HandlesMultipleIterationsInLoopsForCalculatingPreviousHeight() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 200);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getItemCount(anyInt())).thenReturn(10);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(2.0);

        CrosshairState crosshairState = mock(CrosshairState.class);
        int series = 1;
        int item = 5;
        int pass = 0;

        XYAreaRenderer renderer = new XYAreaRenderer();

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Here, you would verify that previous heights are accumulated correctly
        // For simplicity, we'll assume no exceptions mean success
        assertTrue(true, "Multiple iterations for previous height handled correctly");
    }
}
