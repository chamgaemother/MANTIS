import static org.junit.jupiter.api.Assertions.*;

import java.awt.geom.Rectangle2D;

import org.jfree.chart.ui.RectangleAnchor;
import org.jfree.chart.ui.Size2D;
import org.junit.jupiter.api.Test;

class RectangleAnchorTest {

    @Test
    void testCreateRectangleCenter() {
        Size2D size = new Size2D(10, 20);
        Rectangle2D rect = RectangleAnchor.createRectangle(size, 5, 10, RectangleAnchor.CENTER);
        assertEquals(new Rectangle2D.Double(0, 0, 10, 20), rect);
    }

    @Test
    void testCreateRectangleTop() {
        Size2D size = new Size2D(10, 20);
        Rectangle2D rect = RectangleAnchor.createRectangle(size, 5, 10, RectangleAnchor.TOP);
        assertEquals(new Rectangle2D.Double(0, 10, 10, 20), rect);
    }

    @Test
    void testCreateRectangleBottom() {
        Size2D size = new Size2D(10, 20);
        Rectangle2D rect = RectangleAnchor.createRectangle(size, 5, 10, RectangleAnchor.BOTTOM);
        assertEquals(new Rectangle2D.Double(0, -10, 10, 20), rect);
    }

    @Test
    void testCreateRectangleLeft() {
        Size2D size = new Size2D(10, 20);
        Rectangle2D rect = RectangleAnchor.createRectangle(size, 5, 10, RectangleAnchor.LEFT);
        assertEquals(new Rectangle2D.Double(5, 0, 10, 20), rect);
    }

    @Test
    void testCreateRectangleRight() {
        Size2D size = new Size2D(10, 20);
        Rectangle2D rect = RectangleAnchor.createRectangle(size, 5, 10, RectangleAnchor.RIGHT);
        assertEquals(new Rectangle2D.Double(-5, 0, 10, 20), rect);
    }

    @Test
    void testCreateRectangleTopLeft() {
        Size2D size = new Size2D(10, 20);
        Rectangle2D rect = RectangleAnchor.createRectangle(size, 5, 10, RectangleAnchor.TOP_LEFT);
        assertEquals(new Rectangle2D.Double(5, 10, 10, 20), rect);
    }

    @Test
    void testCreateRectangleTopRight() {
        Size2D size = new Size2D(10, 20);
        Rectangle2D rect = RectangleAnchor.createRectangle(size, 5, 10, RectangleAnchor.TOP_RIGHT);
        assertEquals(new Rectangle2D.Double(-5, 10, 10, 20), rect);
    }

    @Test
    void testCreateRectangleBottomLeft() {
        Size2D size = new Size2D(10, 20);
        Rectangle2D rect = RectangleAnchor.createRectangle(size, 5, 10, RectangleAnchor.BOTTOM_LEFT);
        assertEquals(new Rectangle2D.Double(5, -10, 10, 20), rect);
    }

    @Test
    void testCreateRectangleBottomRight() {
        Size2D size = new Size2D(10, 20);
        Rectangle2D rect = RectangleAnchor.createRectangle(size, 5, 10, RectangleAnchor.BOTTOM_RIGHT);
        assertEquals(new Rectangle2D.Double(-5, -10, 10, 20), rect);
    }
    
    @Test
    void testInvalidSize2DThrowsException() {
        assertThrows(NullPointerException.class, () -> {
            RectangleAnchor.createRectangle(null, 5, 10, RectangleAnchor.CENTER);
        });
    }
    
    @Test
    void testInvalidAnchorThrowsException() {
        Size2D size = new Size2D(10, 20);
        assertThrows(NullPointerException.class, () -> {
            RectangleAnchor.createRectangle(size, 5, 10, null);
        });
    }
}