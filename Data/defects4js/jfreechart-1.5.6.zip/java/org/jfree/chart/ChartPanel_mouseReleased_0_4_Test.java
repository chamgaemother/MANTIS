package org.jfree.chart;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.jfree.chart.plot.PlotOrientation;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.*;

public class ChartPanel_mouseReleased_0_4_Test {

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, orientation HORIZONTAL, zoomTrigger1 and zoomTrigger2 both false")
    void TC16() throws Exception {
        // Arrange
        ChartPanel panel = new ChartPanel(null);

        // Use reflection to set private fields
        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        zoomRectangleField.set(panel, new Rectangle2D.Double(0, 0, 100, 100));

        Field orientationField = ChartPanel.class.getDeclaredField("orientation");
        orientationField.setAccessible(true);
        orientationField.set(panel, PlotOrientation.HORIZONTAL);

        Field rangeZoomableField = ChartPanel.class.getDeclaredField("rangeZoomable");
        rangeZoomableField.setAccessible(true);
        rangeZoomableField.setBoolean(panel, true);

        Field domainZoomableField = ChartPanel.class.getDeclaredField("domainZoomable");
        domainZoomableField.setAccessible(true);
        domainZoomableField.setBoolean(panel, true);

        Field zoomTriggerDistanceField = ChartPanel.class.getDeclaredField("zoomTriggerDistance");
        zoomTriggerDistanceField.setAccessible(true);
        zoomTriggerDistanceField.setInt(panel, 150); // Set distance greater than mouse movement to make triggers false

        MouseEvent event = mock(MouseEvent.class);
        when(event.getX()).thenReturn(50);
        when(event.getY()).thenReturn(50);

        // Act
        panel.mouseReleased(event);

        // Assert
        // Verify that zoomRectangle and zoomPoint are null
        assertNull(zoomRectangleField.get(panel));
        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        assertNull(zoomPointField.get(panel));
    }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, orientation VERTICAL, only domainZoomable true, zoomTrigger1 true")
    void TC17() throws Exception {
        // Arrange
        ChartPanel panel = new ChartPanel(null);

        // Use reflection to set private fields
        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        zoomRectangleField.set(panel, new Rectangle2D.Double(0, 0, 100, 100));

        Field orientationField = ChartPanel.class.getDeclaredField("orientation");
        orientationField.setAccessible(true);
        orientationField.set(panel, PlotOrientation.VERTICAL);

        Field rangeZoomableField = ChartPanel.class.getDeclaredField("rangeZoomable");
        rangeZoomableField.setAccessible(true);
        rangeZoomableField.setBoolean(panel, false);

        Field domainZoomableField = ChartPanel.class.getDeclaredField("domainZoomable");
        domainZoomableField.setAccessible(true);
        domainZoomableField.setBoolean(panel, true);

        Field zoomTriggerDistanceField = ChartPanel.class.getDeclaredField("zoomTriggerDistance");
        zoomTriggerDistanceField.setAccessible(true);
        zoomTriggerDistanceField.setInt(panel, 10); // Set distance less than mouse movement to make zoomTrigger1 true

        MouseEvent event = mock(MouseEvent.class);
        when(event.getX()).thenReturn(30);
        when(event.getY()).thenReturn(50);
        when(event.isPopupTrigger()).thenReturn(false);

        // Act
        panel.mouseReleased(event);

        // Assert
        // Verify that zoomRectangle and zoomPoint are null
        assertNull(zoomRectangleField.get(panel));
        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        assertNull(zoomPointField.get(panel));
    }

    @Test
    @DisplayName("mouseReleased triggers both restoreAutoBounds and zoom with proper zoomArea calculations")
    void TC18() throws Exception {
        // Arrange
        ChartPanel panel = new ChartPanel(null);

        // Use reflection to set private fields
        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        zoomRectangleField.set(panel, new Rectangle2D.Double(0, 0, 200, 200));

        Field orientationField = ChartPanel.class.getDeclaredField("orientation");
        orientationField.setAccessible(true);
        orientationField.set(panel, PlotOrientation.HORIZONTAL);

        Field rangeZoomableField = ChartPanel.class.getDeclaredField("rangeZoomable");
        rangeZoomableField.setAccessible(true);
        rangeZoomableField.setBoolean(panel, true);

        Field domainZoomableField = ChartPanel.class.getDeclaredField("domainZoomable");
        domainZoomableField.setAccessible(true);
        domainZoomableField.setBoolean(panel, true);

        Field zoomTriggerDistanceField = ChartPanel.class.getDeclaredField("zoomTriggerDistance");
        zoomTriggerDistanceField.setAccessible(true);
        zoomTriggerDistanceField.setInt(panel, 10); // Set distance less than trigger to meet both actions

        MouseEvent event = mock(MouseEvent.class);
        when(event.getX()).thenReturn(5);
        when(event.getY()).thenReturn(5);
        when(event.isPopupTrigger()).thenReturn(false);

        // Mock methods
        ChartPanel spyPanel = spy(panel);
        doNothing().when(spyPanel).restoreAutoBounds();
        doNothing().when(spyPanel).zoom(any());

        // Act
        spyPanel.mouseReleased(event);

        // Assert
        // Verify that zoomRectangle and zoomPoint are null
        assertNull(zoomRectangleField.get(spyPanel));
        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        assertNull(zoomPointField.get(spyPanel));
    }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, orientation HORIZONTAL, zoomTrigger1 true, zoomTrigger2 true, both zoom triggers on different axes")
    void TC19() throws Exception {
        // Arrange
        ChartPanel panel = new ChartPanel(null);

        // Use reflection to set private fields
        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        zoomRectangleField.set(panel, new Rectangle2D.Double(0, 0, 150, 150));

        Field orientationField = ChartPanel.class.getDeclaredField("orientation");
        orientationField.setAccessible(true);
        orientationField.set(panel, PlotOrientation.HORIZONTAL);

        Field rangeZoomableField = ChartPanel.class.getDeclaredField("rangeZoomable");
        rangeZoomableField.setAccessible(true);
        rangeZoomableField.setBoolean(panel, true);

        Field domainZoomableField = ChartPanel.class.getDeclaredField("domainZoomable");
        domainZoomableField.setAccessible(true);
        domainZoomableField.setBoolean(panel, true);

        Field zoomTriggerDistanceField = ChartPanel.class.getDeclaredField("zoomTriggerDistance");
        zoomTriggerDistanceField.setAccessible(true);
        zoomTriggerDistanceField.setInt(panel, 10); // Set distance less than trigger to make both triggers true

        MouseEvent event = mock(MouseEvent.class);
        when(event.getX()).thenReturn(20);
        when(event.getY()).thenReturn(20);
        when(event.isPopupTrigger()).thenReturn(false);

        // Mock methods
        ChartPanel spyPanel = spy(panel);
        doNothing().when(spyPanel).restoreAutoBounds();
        doNothing().when(spyPanel).zoom(any());

        // Act
        spyPanel.mouseReleased(event);

        // Assert
        // Verify that zoomRectangle and zoomPoint are null
        assertNull(zoomRectangleField.get(spyPanel));
        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        assertNull(zoomPointField.get(spyPanel));
    }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, orientation VERTICAL, both zoomTrigger1 and zoomTrigger2 true, zoom direction up and right")
    void TC20() throws Exception {
        // Arrange
        ChartPanel panel = new ChartPanel(null);

        // Use reflection to set private fields
        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        zoomRectangleField.set(panel, new Rectangle2D.Double(0, 0, 200, 200));

        Field orientationField = ChartPanel.class.getDeclaredField("orientation");
        orientationField.setAccessible(true);
        orientationField.set(panel, PlotOrientation.VERTICAL);

        Field rangeZoomableField = ChartPanel.class.getDeclaredField("rangeZoomable");
        rangeZoomableField.setAccessible(true);
        rangeZoomableField.setBoolean(panel, true);

        Field domainZoomableField = ChartPanel.class.getDeclaredField("domainZoomable");
        domainZoomableField.setAccessible(true);
        domainZoomableField.setBoolean(panel, true);

        Field zoomTriggerDistanceField = ChartPanel.class.getDeclaredField("zoomTriggerDistance");
        zoomTriggerDistanceField.setAccessible(true);
        zoomTriggerDistanceField.setInt(panel, 10); // Set distance less than trigger to make both triggers true

        MouseEvent event = mock(MouseEvent.class);
        when(event.getX()).thenReturn(220);
        when(event.getY()).thenReturn(220);
        when(event.isPopupTrigger()).thenReturn(false);

        // Mock methods
        ChartPanel spyPanel = spy(panel);
        doNothing().when(spyPanel).restoreAutoBounds();
        doNothing().when(spyPanel).zoom(any());

        // Act
        spyPanel.mouseReleased(event);

        // Assert
        // Verify that zoomRectangle and zoomPoint are null
        assertNull(zoomRectangleField.get(spyPanel));
        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        assertNull(zoomPointField.get(spyPanel));
    }
}