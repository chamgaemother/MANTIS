package org.jfree.chart.renderer.category;
import org.jfree.chart.ui.RectangleEdge;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BoxAndWhiskerRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

public class BoxAndWhiskerRenderer_drawHorizontalItem_0_5_Test {

    @Test
    @DisplayName("Handles addItemEntity when box shape is null")
    public void testTC21() throws Exception {
        // Given
        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerCategoryDataset bawDataset = mock(BoxAndWhiskerCategoryDataset.class);
        EntityCollection entities = mock(EntityCollection.class);

        when(state.getEntityCollection()).thenReturn(entities);
        when(bawDataset.getQ1Value(anyInt(), anyInt())).thenReturn(null);

        // When
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, bawDataset, 8, 1);

        // Then
        verify(entities, never()).add(any());
    }

    @Test
    @DisplayName("Handles zero itemMargin resulting in maximum possible series width")
    public void testTC22() throws Exception {
        // Given
        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();

        // Use reflection to set itemMargin to 0
        Field itemMarginField = BoxAndWhiskerRenderer.class.getDeclaredField("itemMargin");
        itemMarginField.setAccessible(true);
        itemMarginField.set(renderer, 0.0);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerCategoryDataset bawDataset = mock(BoxAndWhiskerCategoryDataset.class);

        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(domainAxis.getCategoryEnd(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(100.0);
        when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(0.0);
        when(bawDataset.getRowCount()).thenReturn(3); // multiple series

        // When
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, bawDataset, 9, 1);

        // Then
        // Verify that no exception has been thrown, handling max width correctly
        assertTrue(true);
    }

    @Test
    @DisplayName("Handles maximum itemMargin resulting in minimum possible series width")
    public void testTC23() throws Exception {
        // Given
        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();

        // Use reflection to set itemMargin to 1
        Field itemMarginField = BoxAndWhiskerRenderer.class.getDeclaredField("itemMargin");
        itemMarginField.setAccessible(true);
        itemMarginField.set(renderer, 1.0);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerCategoryDataset bawDataset = mock(BoxAndWhiskerCategoryDataset.class);

        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(domainAxis.getCategoryEnd(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(100.0);
        when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(0.0);
        when(bawDataset.getRowCount()).thenReturn(3); // multiple series

        // When
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, bawDataset, 10, 1);

        // Then
        // Verify the renderer can handle minimum width with max margin
        assertTrue(true);
    }

    @Test
    @DisplayName("Handles extremely large barWidth causing overlapping graphics")
    public void testTC24() throws Exception {
        // Given
        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        EntityCollection entities = mock(EntityCollection.class);
        BoxAndWhiskerCategoryDataset bawDataset = mock(BoxAndWhiskerCategoryDataset.class);

        when(state.getEntityCollection()).thenReturn(entities);
        Field barWidthField = CategoryItemRendererState.class.getDeclaredField("barWidth");
        barWidthField.setAccessible(true);
        barWidthField.set(state, 1000.0);

        when(bawDataset.getQ1Value(anyInt(), anyInt())).thenReturn(10.0);
        when(bawDataset.getQ3Value(anyInt(), anyInt())).thenReturn(20.0);
        when(bawDataset.getMaxRegularValue(anyInt(), anyInt())).thenReturn(30.0);
        when(bawDataset.getMinRegularValue(anyInt(), anyInt())).thenReturn(5.0);
        when(bawDataset.getMeanValue(anyInt(), anyInt())).thenReturn(15.0);
        when(bawDataset.getMedianValue(anyInt(), anyInt())).thenReturn(15.0);

        // When
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, bawDataset, 11, 1);

        // Then
        assertTrue(true);
    }

    @Test
    @DisplayName("Handles negative barWidth gracefully")
    public void testTC25() throws Exception {
        // Given
        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        EntityCollection entities = mock(EntityCollection.class);
        BoxAndWhiskerCategoryDataset bawDataset = mock(BoxAndWhiskerCategoryDataset.class);

        when(state.getEntityCollection()).thenReturn(entities);
        Field barWidthField = CategoryItemRendererState.class.getDeclaredField("barWidth");
        barWidthField.setAccessible(true);
        barWidthField.set(state, -10.0);

        when(bawDataset.getQ1Value(anyInt(), anyInt())).thenReturn(null); // To simulate no box drawn

        // When
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, bawDataset, 12, 1);

        // Then
        verify(g2, never()).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
    }
}