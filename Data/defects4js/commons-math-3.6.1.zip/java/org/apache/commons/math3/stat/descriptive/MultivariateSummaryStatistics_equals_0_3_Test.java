package org.apache.commons.math3.stat.descriptive;

import org.apache.commons.math3.stat.descriptive.moment.GeometricMean;
import org.apache.commons.math3.stat.descriptive.moment.Mean;
import org.apache.commons.math3.stat.descriptive.moment.VectorialCovariance;
import org.apache.commons.math3.stat.descriptive.rank.Max;
import org.apache.commons.math3.stat.descriptive.rank.Min;
import org.apache.commons.math3.stat.descriptive.summary.Sum;
import org.apache.commons.math3.stat.descriptive.summary.SumOfLogs;
import org.apache.commons.math3.stat.descriptive.summary.SumOfSquares;
import org.apache.commons.math3.util.MathArrays;
import org.apache.commons.math3.util.Precision;
import org.apache.commons.math3.util.FastMath;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertFalse;

public class MultivariateSummaryStatistics_equals_0_3_Test {

    @Test
    @DisplayName("Equals returns false when sum of logarithms are not equal")
    public void TC11_equals_with_different_sum_of_logarithms() throws Exception {
        // GIVEN
        MultivariateSummaryStatistics stats1 = new MultivariateSummaryStatistics(2, true);
        MultivariateSummaryStatistics stats2 = new MultivariateSummaryStatistics(2, true);

        // Using reflection to set private fields
        Field sumLogField = MultivariateSummaryStatistics.class.getDeclaredField("sumLogImpl");
        sumLogField.setAccessible(true);

        SumOfLogs[] sumLogImpl1 = {new SumOfLogs(), new SumOfLogs()};
        SumOfLogs[] sumLogImpl2 = {new SumOfLogs(), new SumOfLogs()};
        sumLogImpl1[0].increment(3.0);
        sumLogImpl1[1].increment(4.0);
        sumLogImpl2[0].increment(3.0);
        sumLogImpl2[1].increment(5.0);

        sumLogField.set(stats1, sumLogImpl1);
        sumLogField.set(stats2, sumLogImpl2);

        // WHEN
        boolean result = stats1.equals(stats2);

        // THEN
        assertFalse(result, "Expected equals to return false when sumLog arrays are different");
    }

    @Test
    @DisplayName("Equals returns false when covariance matrices are not equal")
    public void TC12_equals_with_different_covariance_matrices() throws Exception {
        // GIVEN
        MultivariateSummaryStatistics stats1 = new MultivariateSummaryStatistics(2, true);
        MultivariateSummaryStatistics stats2 = new MultivariateSummaryStatistics(2, true);

        // Using reflection to set private fields
        Field covarianceField = MultivariateSummaryStatistics.class.getDeclaredField("covarianceImpl");
        covarianceField.setAccessible(true);

        VectorialCovariance covMatrix1 = new VectorialCovariance(2, true);
        VectorialCovariance covMatrix2 = new VectorialCovariance(2, true);

        covMatrix1.increment(new double[]{1, 0});
        covMatrix1.increment(new double[]{0, 1});

        covMatrix2.increment(new double[]{1, 0.1});
        covMatrix2.increment(new double[]{0.1, 1});

        covarianceField.set(stats1, covMatrix1);
        covarianceField.set(stats2, covMatrix2);

        // WHEN
        boolean result = stats1.equals(stats2);

        // THEN
        assertFalse(result, "Expected equals to return false when covariance matrices are different");
    }
}
