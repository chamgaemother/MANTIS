package org.apache.commons.codec.language;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class Nysiis_nysiis_0_1_Test {

    @Test
    @DisplayName("nysiis(null) returns null when input is null")
    void TC01_nysiis_null_input() {
        // GIVEN
        String input = null;
        Nysiis nysiis = new Nysiis();
        
        // WHEN
        String result = nysiis.nysiis(input);
        
        // THEN
        assertNull(result, "Expected result to be null");
    }

    @Test
    @DisplayName("nysiis(\"\") returns empty string when input is empty")
    void TC02_nysiis_empty_string() {
        // GIVEN
        String input = "";
        Nysiis nysiis = new Nysiis();
        
        // WHEN
        String result = nysiis.nysiis(input);
        
        // THEN
        assertEquals("", result, "Expected result to be an empty string");
    }

    @Test
    @DisplayName("nysiis(\"MAC\") correctly transcodes to \"MCC\"")
    void TC03_nysiis_prefix_MAC() {
        // GIVEN
        String input = "MAC";
        Nysiis nysiis = new Nysiis();
        
        // WHEN
        String result = nysiis.nysiis(input);
        
        // THEN
        assertEquals("MCC", result, "Expected result to be \"MCC\"");
    }

    @Test
    @DisplayName("nysiis(\"KNIGHT\") correctly transcodes \"KN\" to \"NN\"")
    void TC04_nysiis_prefix_KN() {
        // GIVEN
        String input = "KNIGHT";
        Nysiis nysiis = new Nysiis();
        
        // WHEN
        String result = nysiis.nysiis(input);
        
        // THEN
        assertEquals("NNIGHT", result, "Expected result to be \"NNIGHT\"");
    }

    @Test
    @DisplayName("nysiis(\"KELLY\") correctly transcodes \"K\" to \"C\"")
    void TC05_nysiis_prefix_K() {
        // GIVEN
        String input = "KELLY";
        Nysiis nysiis = new Nysiis();
        
        // WHEN
        String result = nysiis.nysiis(input);
        
        // THEN
        assertEquals("CELLY", result, "Expected result to be \"CELLY\"");
    }

}