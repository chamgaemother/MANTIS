package org.apache.commons.codec.digest;

import org.apache.commons.codec.Charsets;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Md5Crypt_md5Crypt_0_3_Test {

    @Test
    @DisplayName("md5Crypt completes all ROUNDS iterations and generates the final hash")
    public void TC11_md5CryptCompletesAllRounds() {
        // GIVEN
        byte[] keyBytes = "complexpassword".getBytes(Charsets.UTF_8);
        String salt = "$1$complex";
        String prefix = "$1$";

        // WHEN
        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);

        // THEN
        assertNotNull(hash, "Hash should not be null");
        assertTrue(hash.startsWith("$1$complex$"), "Hash should start with the specified prefix and salt");
        // Additional checks can be added here if the expected hash value is known
    }

    @Test
    @DisplayName("md5Crypt throws IllegalArgumentException when salt pattern does not match")
    public void TC12_md5CryptInvalidSaltPattern() {
        // GIVEN
        byte[] keyBytes = "password".getBytes(Charsets.UTF_8);
        String salt = "$1$invalid*salt";
        String prefix = "$1$";

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> {
            Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        }, "Expected IllegalArgumentException for invalid salt pattern");
    }

    @Test
    @DisplayName("md5Crypt with different prefix generates hash with specified prefix")
    public void TC13_md5CryptWithCustomPrefix() {
        // GIVEN
        byte[] keyBytes = "password".getBytes(Charsets.UTF_8);
        String salt = "$custom$salt123";
        String prefix = "$custom$";

        // WHEN
        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);

        // THEN
        assertNotNull(hash, "Hash should not be null");
        assertTrue(hash.startsWith("$custom$salt123$"), "Hash should start with the specified custom prefix and salt");
    }

    @Test
    @DisplayName("md5Crypt with maximum allowed salt length processes correctly")
    public void TC14_md5CryptWithMaxSaltLength() {
        // GIVEN
        byte[] keyBytes = "password".getBytes(Charsets.UTF_8);
        String salt = "$1$maxsalt8";
        String prefix = "$1$";

        // WHEN
        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);

        // THEN
        assertNotNull(hash, "Hash should not be null");
        assertTrue(hash.startsWith("$1$maxsalt8$"), "Hash should start with the specified prefix and maximum salt length");
    }

    @Test
    @DisplayName("md5Crypt with salt length exceeding maximum throws IllegalArgumentException")
    public void TC15_md5CryptSaltLengthExceedsMaximum() {
        // GIVEN
        byte[] keyBytes = "password".getBytes(Charsets.UTF_8);
        String salt = "$1$toolongsalt12345";
        String prefix = "$1$";

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> {
            Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        }, "Expected IllegalArgumentException for salt length exceeding maximum");
    }
}