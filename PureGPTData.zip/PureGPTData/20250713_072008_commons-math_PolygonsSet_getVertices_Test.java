import org.apache.commons.math3.geometry.euclidean.twod.Line;
import org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet;
import org.apache.commons.math3.geometry.euclidean.twod.Vector2D;
import org.apache.commons.math3.geometry.partitioning.BSPTree;
import org.apache.commons.math3.geometry.partitioning.BoundaryAttribute;
import org.apache.commons.math3.geometry.partitioning.SubHyperplane;
import org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet;
import org.apache.commons.math3.geometry.euclidean.oned.Interval;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class PolygonsSetTest {

    @Test
    public void testGetVerticesEmptyTree() {
        PolygonsSet polygonsSet = new PolygonsSet(0.01);
        Vector2D[][] vertices = polygonsSet.getVertices();
        assertEquals(0, vertices.length);
    }

    @Test
    public void testGetVerticesWholeSpace() {
        BSPTree<Euclidean2D> tree = new BSPTree<>(Boolean.TRUE);
        PolygonsSet polygonsSet = new PolygonsSet(tree, 0.01);
        Vector2D[][] vertices = polygonsSet.getVertices();
        assertEquals(0, vertices.length);
    }

    @Test
    public void testGetVerticesSingleEdge() {
        Vector2D point1 = new Vector2D(0, 0);
        Vector2D point2 = new Vector2D(1, 0);
        Line line = new Line(point1, point2, 0.01);
        BSPTree<Euclidean2D> node1 = new BSPTree<>(null);
        BSPTree<Euclidean2D> node2 = new BSPTree<>(null);
        
        List<Interval> intervals = new ArrayList<>();
        intervals.add(new Interval(0, 1));
        IntervalsSet intervalsSet = new IntervalsSet(intervals);
        
        SubHyperplane<Euclidean2D> sub = line.wholeHyperplane().wholeHyperplane(intervalsSet);
        BoundaryAttribute<Euclidean2D> attribute = new BoundaryAttribute<>(sub, null, null);
        
        BSPTree<Euclidean2D> root = new BSPTree<>(line, node1, node2, attribute);
        PolygonsSet polygonsSet = new PolygonsSet(root, 0.01);
        Vector2D[][] vertices = polygonsSet.getVertices();
        
        assertEquals(1, vertices.length);
        assertEquals(3, vertices[0].length);
        assertNull(vertices[0][0]);
        assertEquals(point1, vertices[0][1]);
        assertEquals(point2, vertices[0][2]);
    }

    @Test
    public void testGetVerticesClosedSquare() {
        Vector2D point1 = new Vector2D(0, 0);
        Vector2D point2 = new Vector2D(0, 1);
        Vector2D point3 = new Vector2D(1, 1);
        Vector2D point4 = new Vector2D(1, 0);
        
        BSPTree<Euclidean2D> tree = PolygonsSet.verticesToTree(0.01, point1, point2, point3, point4);
        PolygonsSet polygonsSet = new PolygonsSet(tree, 0.01);
        Vector2D[][] vertices = polygonsSet.getVertices();
        
        assertEquals(1, vertices.length);
        assertEquals(4, vertices[0].length);
        assertArrayEquals(new Vector2D[]{point1, point2, point3, point4}, vertices[0]);
    }

    @Test
    public void testGetVerticesDisconnectedSegments() {
        Vector2D point1 = new Vector2D(0, 0);
        Vector2D point2 = new Vector2D(1, 0);
        Vector2D point3 = new Vector2D(2, 0);
        
        BSPTree<Euclidean2D> tree = PolygonsSet.verticesToTree(0.01, point1, point2, point2, point3);
        PolygonsSet polygonsSet = new PolygonsSet(tree, 0.01);
        Vector2D[][] vertices = polygonsSet.getVertices();
        
        assertEquals(1, vertices.length);
        assertEquals(3, vertices[0].length);
        assertArrayEquals(new Vector2D[]{point1, point2, point3}, vertices[0]);
    }
}