package org.joda.time.format;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.joda.time.DateTimeFieldType;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

public class ISODateTimeFormat_forFields_1_1_Test {

    @Test
    @DisplayName("forFields with only dayOfWeek field, extended=true and strictISO=true, expecting '-W-D' format")
    public void TC13() {
        // GIVEN
        Collection<DateTimeFieldType> fields = Collections.singletonList(DateTimeFieldType.dayOfWeek());
        boolean extended = true;
        boolean strictISO = true;
        
        // WHEN
        DateTimeFormatter formatter = ISODateTimeFormat.forFields(fields, extended, strictISO);
        
        // THEN
        Assertions.assertTrue(formatter.toString().contains("-W-"), "Formatter should contain '-W-' for week date format");
    }

    @Test
    @DisplayName("forFields with only dayOfWeek field, extended=false and strictISO=false, expecting '-W-D' format without separators")
    public void TC14() {
        // GIVEN
        Collection<DateTimeFieldType> fields = Collections.singletonList(DateTimeFieldType.dayOfWeek());
        boolean extended = false;
        boolean strictISO = false;
        
        // WHEN
        DateTimeFormatter formatter = ISODateTimeFormat.forFields(fields, extended, strictISO);
        
        // THEN
        Assertions.assertTrue(formatter.toString().contains("-W-"), "Formatter should contain '-W-' without separators");
    }

    @Test
    @DisplayName("forFields with only time fields (hourOfDay and minuteOfHour), extended=true and strictISO=true, expecting 'HH:mm' format")
    public void TC15() {
        // GIVEN
        Collection<DateTimeFieldType> fields = Arrays.asList(DateTimeFieldType.hourOfDay(), DateTimeFieldType.minuteOfHour());
        boolean extended = true;
        boolean strictISO = true;
        
        // WHEN
        DateTimeFormatter formatter = ISODateTimeFormat.forFields(fields, extended, strictISO);
        
        // THEN
        Assertions.assertTrue(formatter.toString().contains("HH:mm"), "Formatter should contain 'HH:mm' for time format");
    }

    @Test
    @DisplayName("forFields with only time fields (hourOfDay and minuteOfHour), extended=false and strictISO=false, expecting 'HHmm' format")
    public void TC16() {
        // GIVEN
        Collection<DateTimeFieldType> fields = Arrays.asList(DateTimeFieldType.hourOfDay(), DateTimeFieldType.minuteOfHour());
        boolean extended = false;
        boolean strictISO = false;
        
        // WHEN
        DateTimeFormatter formatter = ISODateTimeFormat.forFields(fields, extended, strictISO);
        
        // THEN
        Assertions.assertTrue(formatter.toString().contains("HHmm"), "Formatter should contain 'HHmm' without separators");
    }

}