// package org.apache.commons.compress.archivers.sevenz;
// 
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.DisplayName;
// import static org.junit.jupiter.api.Assertions.*;
// import java.lang.reflect.Field;
// import java.util.Arrays;
// import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
// import org.apache.commons.compress.archivers.sevenz.SevenZMethodConfiguration;
// import org.apache.commons.compress.archivers.sevenz.SevenZMethod;
// 
// public class SevenZArchiveEntry_equals_1_5_Test {
// 
//     @Test
//     @DisplayName("equals(obj) returns false when compressedSize fields differ")
//     public void equals_different_compressedSize_returns_false() throws Exception {
//         SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
//         SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
//         
//         Field compressedSizeField = SevenZArchiveEntry.class.getDeclaredField("compressedSize");
//         compressedSizeField.setAccessible(true);
//         compressedSizeField.set(entry1, 7000L);
//         compressedSizeField.set(entry2, 8000L);
//         
//         boolean result = entry1.equals(entry2);
//         assertFalse(result);
//     }
//     
//     @Test
//     @DisplayName("equals(obj) returns false when contentMethods fields differ")
//     public void equals_different_contentMethods_returns_false() throws Exception {
//         SevenZMethodConfiguration method1 = new SevenZMethodConfiguration(SevenZMethod.LZMA2, 1, null);
//         SevenZMethodConfiguration method2 = new SevenZMethodConfiguration(SevenZMethod.DEFLATE, 2, null);
//         
//         SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
//         SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
//         
//         Field contentMethodsField = SevenZArchiveEntry.class.getDeclaredField("contentMethods");
//         contentMethodsField.setAccessible(true);
//         contentMethodsField.set(entry1, Arrays.asList(method1));
//         contentMethodsField.set(entry2, Arrays.asList(method2));
//         
//         boolean result = entry1.equals(entry2);
//         assertFalse(result);
//     }
//     
//     @Test
//     @DisplayName("equals(obj) handles contentMethods being null in both entries")
//     public void equals_both_contentMethods_null_returns_true() throws Exception {
//         SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
//         SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
//         
//         Field contentMethodsField = SevenZArchiveEntry.class.getDeclaredField("contentMethods");
//         contentMethodsField.setAccessible(true);
//         contentMethodsField.set(entry1, null);
//         contentMethodsField.set(entry2, null);
//         
//         boolean result = entry1.equals(entry2);
//         assertTrue(result);
//     }
//     
//     @Test
//     @DisplayName("equals(obj) returns false when one contentMethods is null and the other is not")
//     public void equals_one_contentMethods_null_returns_false() throws Exception {
//         SevenZMethodConfiguration method = new SevenZMethodConfiguration(SevenZMethod.LZMA2, 1, null);
//         
//         SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
//         SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
//         
//         Field contentMethodsField = SevenZArchiveEntry.class.getDeclaredField("contentMethods");
//         contentMethodsField.setAccessible(true);
//         contentMethodsField.set(entry1, Arrays.asList(method));
//         contentMethodsField.set(entry2, null);
//         
//         boolean result = entry1.equals(entry2);
//         assertFalse(result);
//     }
//     
//     @Test
//     @DisplayName("equals(obj) returns false when contentMethods lists have different sizes")
//     public void equals_different_contentMethods_size_returns_false() throws Exception {
//         SevenZMethodConfiguration method1 = new SevenZMethodConfiguration(SevenZMethod.LZMA2, 1, null);
//         SevenZMethodConfiguration method2 = new SevenZMethodConfiguration(SevenZMethod.DEFLATE, 2, null);
//         
//         SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
//         SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
//         
//         Field contentMethodsField = SevenZArchiveEntry.class.getDeclaredField("contentMethods");
//         contentMethodsField.setAccessible(true);
//         contentMethodsField.set(entry1, Arrays.asList(method1, method2));
//         contentMethodsField.set(entry2, Arrays.asList(method1));
//         
//         boolean result = entry1.equals(entry2);
//         assertFalse(result);
//     }
// }