package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class Nysiis_nysiis_0_3_Test {

    @Test
    @DisplayName("nysiis handles vowels by replacing them with 'A'")
    void TC11_nysiis_handles_vowels_by_replacing_with_A() throws Exception {
        // GIVEN
        String input = "AEIOU";
        Nysiis nysiis = new Nysiis();

        // WHEN
        String result = nysiis.encode(input);

        // THEN
        assertEquals("AAAAA", result);
    }

    @Test
    @DisplayName("nysiis handles 'Q' by replacing it with 'G'")
    void TC12_nysiis_handles_Q_by_replacing_with_G() throws Exception {
        // GIVEN
        String input = "QUIET";
        Nysiis nysiis = new Nysiis();

        // WHEN
        String result = nysiis.encode(input);

        // THEN
        assertEquals("GUAGT", result);
    }

    @Test
    @DisplayName("nysiis handles 'Z' by replacing it with 'S'")
    void TC13_nysiis_handles_Z_by_replacing_with_S() throws Exception {
        // GIVEN
        String input = "ZEBRA";
        Nysiis nysiis = new Nysiis();

        // WHEN
        String result = nysiis.encode(input);

        // THEN
        assertEquals("SEBRA", result);
    }

    @Test
    @DisplayName("nysiis handles 'M' by replacing it with 'N'")
    void TC14_nysiis_handles_M_by_replacing_with_N() throws Exception {
        // GIVEN
        String input = "MARY";
        Nysiis nysiis = new Nysiis();

        // WHEN
        String result = nysiis.encode(input);

        // THEN
        assertEquals("NARY", result);
    }

    @Test
    @DisplayName("nysiis removes trailing 'S' from the encoded string")
    void TC15_nysiis_removes_trailing_S_from_encoded_string() throws Exception {
        // GIVEN
        String input = "ROSS";
        Nysiis nysiis = new Nysiis();

        // WHEN
        String result = nysiis.encode(input);

        // THEN
        assertEquals("ROD", result);
    }
}