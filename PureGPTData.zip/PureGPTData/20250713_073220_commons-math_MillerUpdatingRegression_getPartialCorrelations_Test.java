import org.apache.commons.math3.stat.regression.MillerUpdatingRegression;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.exception.ModelSpecificationException;
import org.apache.commons.math3.util.Precision;
import org.apache.commons.math3.util.MathArrays;
import org.apache.commons.math3.util.FastMath;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

public class MillerUpdatingRegressionTest {

    @Test
    void testGetPartialCorrelationsValidInput() throws ModelSpecificationException {
        MillerUpdatingRegression regression = new MillerUpdatingRegression(2, false);
        regression.addObservation(new double[]{1, 2}, 3);
        regression.addObservation(new double[]{2, 1}, 2);
        double[] result = regression.getPartialCorrelations(0);
        Assertions.assertNotNull(result);
    }

    @Test
    void testGetPartialCorrelationsWithNegativeIn() {
        MillerUpdatingRegression regression = new MillerUpdatingRegression(2, false);
        Assertions.assertNull(regression.getPartialCorrelations(-2));
    }

    @Test
    void testGetPartialCorrelationsWithInEqualsNvars() {
        MillerUpdatingRegression regression = new MillerUpdatingRegression(2, false);
        Assertions.assertNull(regression.getPartialCorrelations(2));
    }

    @Test
    void testGetPartialCorrelationsWithValidDataAfterAdditions() throws ModelSpecificationException {
        MillerUpdatingRegression regression = new MillerUpdatingRegression(3, false);
        regression.addObservation(new double[]{1, 2, 3}, 4);
        regression.addObservation(new double[]{2, 3, 4}, 5);
        double[] result = regression.getPartialCorrelations(1);
        Assertions.assertNotNull(result);
    }

    @Test
    void testGetPartialCorrelationsEdgeCaseZeroObservations() {
        MillerUpdatingRegression regression = new MillerUpdatingRegression(2, false);
        double[] result = regression.getPartialCorrelations(0);
        Assertions.assertNotNull(result);
    }
}