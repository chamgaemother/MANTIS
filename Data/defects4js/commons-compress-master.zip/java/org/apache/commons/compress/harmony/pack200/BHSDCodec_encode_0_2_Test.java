package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class BHSDCodec_encode_0_2_Test {

    @Test
    @DisplayName("encode processes negative z with isSigned")
    void TC06_encodeProcessesNegativeZWithIsSigned() throws Exception {
        // Arrange
        BHSDCodec codec = new BHSDCodec(3, 10, 2, 1); // Constructor args added

        // Act
        byte[] result = codec.encode(30, 50);

        // Assert
        assertNotNull(result, "Resulting byte array should not be null");
    }

    @Test
    @DisplayName("encode shifts z left by 1 when isSigned and s equals 1")
    void TC07_encodeShiftsZLeftBy1WhenIsSignedAndSEquals1() throws Exception {
        // Arrange
        BHSDCodec codec = new BHSDCodec(2, 10, 1, 1); // Constructor args added

        // Act
        byte[] result = codec.encode(20, 0);

        // Assert
        assertNotNull(result, "Resulting byte array should not be null");
    }

    @Test
    @DisplayName("encode adjusts z with non-1 shift when isSigned and s != 1")
    void TC08_encodeAdjustsZWithNon1ShiftWhenIsSignedAndSNot1() throws Exception {
        // Arrange
        BHSDCodec codec = new BHSDCodec(2, 10, 2, 1); // Constructor args added

        // Act
        byte[] result = codec.encode(25, 0);

        // Assert
        assertNotNull(result, "Resulting byte array should not be null");
    }

    @Test
    @DisplayName("encode processes z with integer overflow for unsigned encoding")
    void TC09_encodeProcessesZWithIntegerOverflowForUnsignedEncoding() throws Exception {
        // Arrange
        BHSDCodec codec = new BHSDCodec(3, 10, 2, 0); // Constructor args added

        // Act
        byte[] result = codec.encode(-50, 0);

        // Assert
        assertNotNull(result, "Resulting byte array should not be null");
    }

    @Test
    @DisplayName("encode throws exception when z is still negative after adjustments")
    void TC10_encodeThrowsExceptionWhenZStillNegativeAfterAdjustments() throws Exception {
        // Arrange
        BHSDCodec codec = new BHSDCodec(2, 10, 2, 1); // Constructor args added

        // Act & Assert
        Pack200Exception exception = assertThrows(Pack200Exception.class, () -> {
            codec.encode(-150, 0);
        }, "Expected encode to throw Pack200Exception");
    }

    // Note: Private field setting via reflection is replaced with constructor initialization
    // as fields d, s, smallest, largest, last, and cardinality can be set via the constructor
}