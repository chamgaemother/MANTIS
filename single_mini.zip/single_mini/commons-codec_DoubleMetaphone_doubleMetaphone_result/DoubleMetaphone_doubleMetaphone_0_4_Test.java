package org.apache.commons.codec.language;

import org.apache.commons.codec.language.DoubleMetaphone;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class DoubleMetaphone_doubleMetaphone_0_4_Test {

    @Test
    @DisplayName("doubleMetaphone processes 'PH' as 'F' in 'PHIL'")
    void TC16_doubleMetaphone_PHIL() {
        // Given
        String value = "PHIL";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        assertTrue(result.contains("F"), "Expected 'F' to be in the encoded result");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'Q' followed by 'Q' in 'QUIQ'")
    void TC17_doubleMetaphone_QUIQ() {
        // Given
        String value = "QUIQ";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        assertTrue(result.contains("K"), "Expected 'K' to be in the encoded result");
    }

    @Test
    @DisplayName("doubleMetaphone processes 'Z' followed by 'H' in 'ZHO'")
    void TC18_doubleMetaphone_ZHO() {
        // Given
        String value = "ZHO";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        assertTrue(result.contains("J"), "Expected 'J' to be in the encoded result");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'X' at the beginning in 'XAN'")
    void TC19_doubleMetaphone_XAN() {
        // Given
        String value = "XAN";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        assertTrue(result.startsWith("S"), "Expected encoded result to start with 'S'");
    }

    @Test
    @DisplayName("doubleMetaphone processes 'SIO' sequence in 'SION'")
    void TC20_doubleMetaphone_SION() {
        // Given
        String value = "SION";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        assertTrue(result.contains("S") || result.contains("X"), "Expected 'S' or 'X' to be in the encoded result");
    }
}