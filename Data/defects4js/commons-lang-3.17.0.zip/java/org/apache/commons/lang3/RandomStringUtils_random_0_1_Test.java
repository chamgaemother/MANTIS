package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import java.util.Random;

public class RandomStringUtils_random_0_1_Test {

    @Test
    @DisplayName("random(0, start, end, letters, numbers, chars, random) returns empty string")
    public void TC01_randomReturnsEmptyString() {
        // Given
        int count = 0;
        int start = 65; // Any value
        int end = 90; // Any value
        boolean letters = true;
        boolean numbers = true;
        char[] chars = {'a', 'b', 'c'}; // Any value
        Random random = new Random();

        // When
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // Then
        assertEquals(StringUtils.EMPTY, result);
    }

    @Test
    @DisplayName("random(-5, start, end, letters, numbers, chars, random) throws IllegalArgumentException for negative count")
    public void TC02_randomThrowsExceptionForNegativeCount() {
        // Given
        int count = -5;
        int start = 65; // Any value
        int end = 90; // Any value
        boolean letters = true;
        boolean numbers = true;
        char[] chars = {'a', 'b', 'c'}; // Any value
        Random random = new Random();

        // When & Then
        assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        });
    }

    @Test
    @DisplayName("random(count, start, end, letters, numbers, empty chars, random) throws IllegalArgumentException when chars array is empty")
    public void TC03_randomThrowsExceptionForEmptyCharsArray() {
        // Given
        int count = 5; // Any positive value
        int start = 65; // Any value
        int end = 90; // Any value
        boolean letters = true;
        boolean numbers = true;
        char[] chars = new char[0];
        Random random = new Random();

        // When & Then
        assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        });
    }

    @Test
    @DisplayName("random(count, 0, 0, letters, numbers, chars, random) sets end based on chars array length when chars is not null")
    public void TC04_randomSetsEndBasedOnCharsArray() {
        // Given
        int count = 10;
        int start = 0;
        int end = 0;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = new char[]{'a', 'b', 'c'};
        Random random = new Random();

        // When
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // Then
        assertEquals(10, result.length());
        for(char c : result.toCharArray()) {
            assertTrue(new String(chars).indexOf(c) >= 0, "Character " + c + " is not in the chars array");
        }
    }

    @Test
    @DisplayName("random(count, 0, 0, false, false, null, random) sets start and end to default when letters and numbers are false")
    public void TC05_randomSetsDefaultRangeWhenLettersAndNumbersFalse() {
        // Given
        int count = 15;
        int start = 0;
        int end = 0;
        boolean letters = false;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();

        // When
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // Then
        assertEquals(15, result.length());
        for(char c : result.toCharArray()) {
            int codePoint = c;
            assertTrue(codePoint >= 0 && codePoint <= Character.MAX_CODE_POINT, "Character " + c + " is out of Unicode range");
        }
    }
}