package org.jsoup.nodes;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.jsoup.helper.HttpConnection;
import org.jsoup.parser.Tag;
import org.jsoup.select.Elements;
import org.jsoup.Connection.KeyVal;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class FormElement_formData_0_1_Test {

    @Test
    @DisplayName("formData returns empty list when there are no form control elements")
    public void TC01() {
        // GIVEN
        Tag formTag = Tag.valueOf("form");
        FormElement form = new FormElement(formTag, "", null);

        // WHEN
        List<KeyVal> data = form.formData();

        // THEN
        assertTrue(data.isEmpty(), "Expected the data list to be empty when there are no form control elements.");
    }

    @Test
    @DisplayName("formData skips non-submittable form elements")
    public void TC02() {
        // GIVEN
        Tag formTag = Tag.valueOf("form");
        FormElement form = new FormElement(formTag, "", null);
        Element input = new Element(Tag.valueOf("div"), "");
        form.addElement(input);

        // WHEN
        List<KeyVal> data = form.formData();

        // THEN
        assertTrue(data.isEmpty(), "Expected the data list to be empty when non-submittable elements are present.");
    }

    @Test
    @DisplayName("formData skips disabled form inputs")
    public void TC03() {
        // GIVEN
        Tag formTag = Tag.valueOf("form");
        FormElement form = new FormElement(formTag, "", null);
        Element input = new Element(Tag.valueOf("input"), "").attr("disabled", "disabled");
        form.addElement(input);

        // WHEN
        List<KeyVal> data = form.formData();

        // THEN
        assertTrue(data.isEmpty(), "Expected the data list to be empty when disabled form inputs are present.");
    }

    @Test
    @DisplayName("formData skips elements with empty name attribute")
    public void TC04() {
        // GIVEN
        Tag formTag = Tag.valueOf("form");
        FormElement form = new FormElement(formTag, "", null);
        Element input = new Element(Tag.valueOf("input"), "").attr("name", "");
        form.addElement(input);

        // WHEN
        List<KeyVal> data = form.formData();

        // THEN
        assertTrue(data.isEmpty(), "Expected the data list to be empty when elements have empty name attributes.");
    }

    @Test
    @DisplayName("formData skips elements of type button")
    public void TC05() {
        // GIVEN
        Tag formTag = Tag.valueOf("form");
        FormElement form = new FormElement(formTag, "", null);
        Element button = new Element(Tag.valueOf("input"), "").attr("type", "button");
        form.addElement(button);

        // WHEN
        List<KeyVal> data = form.formData();

        // THEN
        assertTrue(data.isEmpty(), "Expected the data list to be empty when elements of type button are present.");
    }
}