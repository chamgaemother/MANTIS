package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ClassBands_addAnnotation_0_3_Test {

    @Test
    @DisplayName("addAnnotation with CONTEXT_METHOD and visible=false where flag22 is not set")
    public void TC11_addAnnotation_CONTEXT_METHOD_visible_false_flag22_false() throws Exception {
        // Setup
        Segment segment = mock(Segment.class);
        ClassBands classBands = new ClassBands(segment, 1, 1, false);

        // Mock method_RIA_bands
        MetadataBandGroup mockMethodRIABands = mock(MetadataBandGroup.class);
        setInternalState(classBands, "method_RIA_bands", mockMethodRIABands);

        // Initialize tempMethodFlags without 22nd bit set
        List<Long> tempMethodFlags = new ArrayList<>();
        tempMethodFlags.add(0L); // 22nd bit not set
        setInternalState(classBands, "tempMethodFlags", tempMethodFlags);

        // Initialize class_flags without 22nd bit
        long[] class_flags = {0L}; // 22nd bit not set
        setInternalState(classBands, "class_flags", class_flags);

        // Define method parameters
        int context = MetadataBandGroup.CONTEXT_METHOD;
        boolean visible = false;
        String desc = "desc";
        List<String> nameRU = Arrays.asList("nameRU");
        List<String> tags = Arrays.asList("tag1");
        List<Object> values = Arrays.asList("value1");
        List<Integer> caseArrayN = Arrays.asList(1);
        List<String> nestTypeRS = Arrays.asList("nestType1");
        List<String> nestNameRU = Arrays.asList("nestName1");
        List<Integer> nestPairN = Arrays.asList(1);

        // When
        classBands.addAnnotation(context, desc, visible, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        // Then
        verify(mockMethodRIABands, times(1)).newEntryInAnnoN();
        assertEquals(1, tempMethodFlags.size());
        assertTrue((tempMethodFlags.get(tempMethodFlags.size() - 1) & (1L << 22)) != 0);
    }

    @Test
    @DisplayName("addAnnotation with CONTEXT_METHOD and visible=false where flag22 is set")
    public void TC12_addAnnotation_CONTEXT_METHOD_visible_false_flag22_true() throws Exception {
        // Setup
        Segment segment = mock(Segment.class);
        ClassBands classBands = new ClassBands(segment, 1, 1, false);

        // Mock method_RIA_bands
        MetadataBandGroup mockMethodRIABands = mock(MetadataBandGroup.class);
        setInternalState(classBands, "method_RIA_bands", mockMethodRIABands);

        // Initialize tempMethodFlags with 22nd bit set
        List<Long> tempMethodFlags = new ArrayList<>();
        tempMethodFlags.add(1L << 22); // 22nd bit set
        setInternalState(classBands, "tempMethodFlags", tempMethodFlags);

        // Initialize class_flags with 22nd bit set
        long[] class_flags = {1L << 22}; // 22nd bit set
        setInternalState(classBands, "class_flags", class_flags);

        // Define method parameters
        int context = MetadataBandGroup.CONTEXT_METHOD;
        boolean visible = false;
        String desc = "desc";
        List<String> nameRU = Arrays.asList("nameRU");
        List<String> tags = Arrays.asList("tag1");
        List<Object> values = Arrays.asList("value1");
        List<Integer> caseArrayN = Arrays.asList(1);
        List<String> nestTypeRS = Arrays.asList("nestType1");
        List<String> nestNameRU = Arrays.asList("nestName1");
        List<Integer> nestPairN = Arrays.asList(1);

        // When
        classBands.addAnnotation(context, desc, visible, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        // Then
        verify(mockMethodRIABands, times(1)).incrementAnnoN();
        assertEquals(1, tempMethodFlags.size());
        assertTrue((tempMethodFlags.get(tempMethodFlags.size() - 1) & (1L << 22)) != 0);
    }

    @Test
    @DisplayName("addAnnotation with invalid context leading to no operation")
    public void TC13_addAnnotation_invalid_context_no_operation() throws Exception {
        // Setup
        Segment segment = mock(Segment.class);
        ClassBands classBands = new ClassBands(segment, 1, 1, false);

        // Mock internal bands to verify no interactions
        MetadataBandGroup mockClassRVA = mock(MetadataBandGroup.class);
        MetadataBandGroup mockClassRIA = mock(MetadataBandGroup.class);
        setInternalState(classBands, "class_RVA_bands", mockClassRVA);
        setInternalState(classBands, "class_RIA_bands", mockClassRIA);

        // Initialize class_flags
        long[] class_flags = {0L};
        setInternalState(classBands, "class_flags", class_flags);

        // Define method parameters with invalid context
        int context = -1; // INVALID_CONTEXT
        boolean visible = true;
        String desc = "desc";
        List<String> nameRU = Arrays.asList("nameRU");
        List<String> tags = Arrays.asList("tag1");
        List<Object> values = Arrays.asList("value1");
        List<Integer> caseArrayN = Arrays.asList(1);
        List<String> nestTypeRS = Arrays.asList("nestType1");
        List<String> nestNameRU = Arrays.asList("nestName1");
        List<Integer> nestPairN = Arrays.asList(1);

        // When
        classBands.addAnnotation(context, desc, visible, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        // Then
        verifyNoInteractions(mockClassRVA);
        verifyNoInteractions(mockClassRIA);
    }

    @Test
    @DisplayName("addAnnotation with null annotation parameters leading to potential NullPointerException")
    public void TC14_addAnnotation_null_parameters_no_exception() {
        // Setup
        Segment segment = mock(Segment.class);
        ClassBands classBands = new ClassBands(segment, 1, 1, false);

        // Define method parameters with nulls
        int context = MetadataBandGroup.CONTEXT_CLASS;
        boolean visible = true;
        String desc = null;
        List<String> nameRU = null;
        List<String> tags = null;
        List<Object> values = null;
        List<Integer> caseArrayN = null;
        List<String> nestTypeRS = null;
        List<String> nestNameRU = null;
        List<Integer> nestPairN = null;

        // When & Then
        assertDoesNotThrow(() -> {
            classBands.addAnnotation(context, desc, visible, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);
        });
    }

    private void setInternalState(Object target, String fieldName, Object value) throws Exception {
        Field field = ClassBands.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }
}
