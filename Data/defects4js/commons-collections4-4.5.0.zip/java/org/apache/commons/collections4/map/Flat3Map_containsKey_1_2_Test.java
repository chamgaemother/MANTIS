package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.assertFalse;

public class Flat3Map_containsKey_1_2_Test {

    @Test
    @DisplayName("When delegateMap is null, key is not null, size=2, neither hash2 nor hash1 match")
    public void TC19_containsKey_returnsFalse() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Use reflection to set 'size' to 2
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        // Set 'hash1' and 'hash2' to values that do not match the key's hashCode
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, 12345); // Arbitrary hash code that does not match

        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, 67890); // Another arbitrary hash code that does not match

        // Set 'key1' and 'key2' to different keys
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        Object differentKey1 = new Object();
        key1Field.set(map, differentKey1);

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        Object differentKey2 = new Object();
        key2Field.set(map, differentKey2);

        // Ensure 'delegateMap' is null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Create a key that is not present in the map
        Object key = new Object();

        // Act
        boolean result = map.containsKey(key);

        // Assert
        assertFalse(result);
    }
}