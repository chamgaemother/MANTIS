package org.apache.commons.math3.stat.inference;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.stat.inference.KolmogorovSmirnovTest;

/**
 * Test class for KolmogorovSmirnovTest.pelzGood method.
 */
public class KolmogorovSmirnovTest_pelzGood_1_2_Test {

    @Test
    @DisplayName("TC24 pelzGood with d=1e-20 and n=2 to test boundary condition with very small d")
    public void TC24_pelzGood_VerySmallD_BoundaryCondition() {
        // GIVEN
        double d = 1e-20;
        int n = 2;
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        
        // WHEN
        double result = ksTest.pelzGood(d, n);
        
        // THEN
        assertTrue(Double.isFinite(result), "pelzGood should return a finite double value");
    }
}