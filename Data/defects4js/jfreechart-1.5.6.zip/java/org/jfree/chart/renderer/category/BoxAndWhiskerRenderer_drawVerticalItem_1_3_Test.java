// package org.jfree.chart.renderer.category;
// import java.lang.reflect.*;
// import java.io.*;
// import java.util.*;
// import org.jfree.chart.ui.RectangleEdge;
// 
// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.ArgumentMatchers.anyDouble;
// import static org.mockito.ArgumentMatchers.anyInt;
// import static org.mockito.Mockito.*;
// 
// import java.awt.Graphics2D;
// import java.awt.geom.Rectangle2D;
// import java.util.Arrays;
// import java.util.List;
// 
// import org.jfree.chart.axis.CategoryAxis;
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.entity.EntityCollection;
// import org.jfree.chart.plot.CategoryPlot;
// import org.jfree.chart.plot.RectangleEdge;
// import org.jfree.data.category.CategoryDataset;
// import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.Mockito;
// 
// public class BoxAndWhiskerRenderer_drawVerticalItem_1_3_Test {
// 
//     @Test
//     @DisplayName("TC11: drawVerticalItem with multiple series and item margin zero")
//     void testDrawVerticalItem_MultipleSeries_ItemMarginZero() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = new CategoryItemRendererState();
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
// 
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDataset(0)).thenReturn(dataset);
//         when(dataset.getRowCount()).thenReturn(3);
//         when(dataset.getColumnCount()).thenReturn(2);
//         when(dataset.getQ1Value(anyInt(), anyInt())).thenReturn(10);
//         when(dataset.getQ3Value(anyInt(), anyInt())).thenReturn(20);
//         when(dataset.getMaxRegularValue(anyInt(), anyInt())).thenReturn(25);
//         when(dataset.getMinRegularValue(anyInt(), anyInt())).thenReturn(5);
//         when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(15.0);
//         when(dataset.getMedianValue(anyInt(), anyInt())).thenReturn(15.0);
//         when(dataset.getOutliers(anyInt(), anyInt())).thenReturn(null);
// 
//         // Act
//         BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
//         renderer.setFillBox(true);
//         renderer.setItemMargin(0.0);
//         renderer.setMeanVisible(true);
//         renderer.setMedianVisible(true);
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 0);
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 2, 0);
// 
//         // Assert
//         verify(g2, times(3)).fill(any(Rectangle2D.class));
//         verify(g2, times(3)).draw(any(java.awt.Shape.class));
//         verify(g2, times(3)).draw(any(java.awt.Shape.class)); // For Ellipse2D
//     }
// 
//     @Test
//     @DisplayName("TC12: drawVerticalItem with multiple outliers and far out indicators")
//     void testDrawVerticalItem_MultipleOutliers_FarOutIndicators() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = new CategoryItemRendererState();
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
// 
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDataset(0)).thenReturn(dataset);
//         when(dataset.getQ1Value(1, 1)).thenReturn(15);
//         when(dataset.getQ3Value(1, 1)).thenReturn(25);
//         when(dataset.getMaxRegularValue(1, 1)).thenReturn(30);
//         when(dataset.getMinRegularValue(1, 1)).thenReturn(10);
//         when(dataset.getMeanValue(1, 1)).thenReturn(20.0);
//         when(dataset.getMedianValue(1, 1)).thenReturn(20.0);
//         List<Double> outliers = Arrays.asList(35.0, 40.0, 5.0, 3.0, 50.0);
//         when(dataset.getOutliers(1, 1)).thenReturn(outliers);
//         when(dataset.getMinOutlier(1, 1)).thenReturn(3.0);
//         when(dataset.getMaxOutlier(1, 1)).thenReturn(45.0);
// 
//         // Act
//         BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
//         renderer.setFillBox(true);
//         renderer.setUseOutlinePaintForWhiskers(true);
//         renderer.setMeanVisible(true);
//         renderer.setMedianVisible(true);
//         renderer.setMaxOutlierVisible(true);
//         renderer.setMinOutlierVisible(true);
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1);
// 
//         // Assert
//         verify(g2, atLeast(5)).draw(any(java.awt.Shape.class)); // Ellipse2D and Line2D
//         verify(renderer, atLeastOnce()).drawHighFarOut(anyDouble(), any(Graphics2D.class), anyDouble(), anyDouble());
//         verify(renderer, atLeastOnce()).drawLowFarOut(anyDouble(), any(Graphics2D.class), anyDouble(), anyDouble());
//     }
// }