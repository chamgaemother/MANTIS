package org.apache.commons.math3.stat.regression;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.*;

public class MillerUpdatingRegression_regress_0_3_Test {

    @Test
    @DisplayName("regress handles regression with intercept")
    void TC11_regress_with_intercept() throws Exception {
        // GIVEN
        MillerUpdatingRegression regression = new MillerUpdatingRegression(5, true);
        int[] regressors = {0, 1, 2, 3, 4};

        // Adding some dummy observations to prevent ModelSpecificationException
        regression.addObservation(new double[]{1, 2, 3, 4, 5}, 5);

        // WHEN
        RegressionResults results = regression.regress(regressors);

        // THEN
        assertNotNull(results, "RegressionResults should not be null");
        assertTrue(results.hasIntercept(), "Intercept should be included");
    }

    @Test
    @DisplayName("regress handles regression without intercept")
    void TC12_regress_without_intercept() throws Exception {
        // GIVEN
        MillerUpdatingRegression regression = new MillerUpdatingRegression(5, false);
        int[] regressors = {0, 1, 2, 3, 4};

        // Adding some dummy observations to prevent ModelSpecificationException
        regression.addObservation(new double[]{1, 2, 3, 4, 5}, 5);

        // WHEN
        RegressionResults results = regression.regress(regressors);

        // THEN
        assertNotNull(results, "RegressionResults should not be null");
        assertFalse(results.hasIntercept(), "Intercept should not be included");
    }

    @Test
    @DisplayName("regress handles empty regressors array")
    void TC13_regress_empty_regressors() throws Exception {
        // GIVEN
        MillerUpdatingRegression regression = new MillerUpdatingRegression(5, true);
        int[] regressors = {};

        // Adding some dummy observations to prevent ModelSpecificationException
        regression.addObservation(new double[]{1, 2, 3, 4, 5}, 5);

        // WHEN
        RegressionResults results = regression.regress(regressors);

        // THEN
        assertNotNull(results, "RegressionResults should not be null");
        double[] beta = results.getParameterEstimates();
        assertNotNull(beta, "Beta coefficients should not be null");
        assertEquals(0, beta.length, "Beta coefficients array should be empty");
    }

    @Test
    @DisplayName("regress handles negative regressors values")
    void TC14_regress_negative_regressors() throws Exception {
        // GIVEN
        MillerUpdatingRegression regression = new MillerUpdatingRegression(5, true);
        int[] regressors = {-1, -2, -3, -4, -5};

        // Adding some dummy observations to prevent ModelSpecificationException
        regression.addObservation(new double[]{1, 2, 3, 4, 5}, 5);

        // WHEN & THEN
        assertThrows(ModelSpecificationException.class, () -> regression.regress(regressors));
    }

    @Test
    @DisplayName("regress handles maximum loop iterations")
    void TC15_regress_maximum_iterations() throws Exception {
        // GIVEN
        MillerUpdatingRegression regression = new MillerUpdatingRegression(100, true);
        int[] regressors = new int[100];
        for (int i = 0; i < 100; i++) {
            regressors[i] = i;
        }

        // Adding dummy observation to avoid exception
        for (int i = 0; i < 100; i++) {
            regression.addObservation(new double[100], i);
        }

        // WHEN
        RegressionResults results = regression.regress(regressors);

        // THEN
        assertNotNull(results, "RegressionResults should not be null");
    }

    /**
     * Utility method to access private fields using reflection.
     */
    @SuppressWarnings("unchecked")
    private <T> T getPrivateField(Object instance, String fieldName, Class<T> fieldType) throws Exception {
        java.lang.reflect.Field field = instance.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        return (T) field.get(instance);
    }

}