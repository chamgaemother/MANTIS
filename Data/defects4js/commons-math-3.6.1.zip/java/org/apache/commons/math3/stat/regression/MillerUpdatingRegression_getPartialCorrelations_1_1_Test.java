package org.apache.commons.math3.stat.regression;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class MillerUpdatingRegression_getPartialCorrelations_1_1_Test {

    @Test
    @DisplayName("getPartialCorrelations with valid in, d[in] > 0, and some regressors are linearly dependent resulting in NaN partial correlations")
    void TC14_getPartialCorrelations_WithLinearlyDependentRegressors() throws Exception {
        // GIVEN
        MillerUpdatingRegression regression = new MillerUpdatingRegression(5, false);

        // Use reflection to set 'd' array
        double[] d = {1.0, 2.0, 4.0, 3.0, 5.0};
        Field dField = MillerUpdatingRegression.class.getDeclaredField("d");
        dField.setAccessible(true);
        dField.set(regression, d);

        // Use reflection to set 'lindep' array
        boolean[] lindep = {false, true, false, true, false};
        Field lindepField = MillerUpdatingRegression.class.getDeclaredField("lindep");
        lindepField.setAccessible(true);
        lindepField.set(regression, lindep);

        // WHEN
        double[] result = regression.getPartialCorrelations(2);

        // THEN
        assertNotNull(result, "Result should not be null");
        assertEquals(2, result.length, "Result array should have length 2");
        assertTrue(Double.isNaN(result[0]), "Partial correlation for dependent regressor should be NaN");
        assertTrue(Double.isNaN(result[1]), "Partial correlation for dependent regressor should be NaN");
        
        // Additional assertions for non-dependent regressors can be added if needed
    }

    @Test
    @DisplayName("getPartialCorrelations with valid in, d[in] > 0, no linear dependencies, and sumyy equals zero resulting in scaled partial correlations")
    void TC15_getPartialCorrelations_WithSumyyZero() throws Exception {
        // GIVEN
        MillerUpdatingRegression regression = new MillerUpdatingRegression(4, false);

        // Use reflection to set 'd' array with d[in] > 0
        double[] d = {1.0, 2.0, 3.0, 4.0};
        Field dField = MillerUpdatingRegression.class.getDeclaredField("d");
        dField.setAccessible(true);
        dField.set(regression, d);

        // Use reflection to set 'rhs' array and 'sserr' to ensure sumyy=0
        double[] rhs = {0.0, 0.0, 0.0, 0.0};
        Field rhsField = MillerUpdatingRegression.class.getDeclaredField("rhs");
        rhsField.setAccessible(true);
        rhsField.set(regression, rhs);

        Field sserrField = MillerUpdatingRegression.class.getDeclaredField("sserr");
        sserrField.setAccessible(true);
        sserrField.setDouble(regression, 0.0);

        // Ensure 'lindep' array has no dependencies
        boolean[] lindep = {false, false, false, false};
        Field lindepField = MillerUpdatingRegression.class.getDeclaredField("lindep");
        lindepField.setAccessible(true);
        lindepField.set(regression, lindep);

        // Initialize 'r' array with non-zero values
        double[] r = {0.5, 0.6, 0.7};
        Field rField = MillerUpdatingRegression.class.getDeclaredField("r");
        rField.setAccessible(true);
        rField.set(regression, r);

        // WHEN
        double[] result = regression.getPartialCorrelations(1);

        // THEN
        assertNotNull(result, "Result should not be null");
        for(double val : result) {
            assertEquals(0.0, val, "Partial correlations should be scaled to zero when sumyy is zero");
        }
    }
}