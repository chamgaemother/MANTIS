package org.jfree.chart.plot;

import org.jfree.chart.util.SortOrder;

import java.io.*;

import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.DatasetUtils;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

public class CategoryPlot_render_0_4_Test {

    @Test
    @DisplayName("render method handles well-defined dataset and renderer")
    void testRenderWithValidDatasetAndRenderer() throws Exception {
        // Arrange
        CategoryPlot plot = new CategoryPlot();

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        int index = 0;
        PlotRenderingInfo info = null;  // Testing with null PlotRenderingInfo
        CategoryCrosshairState crosshairState = mock(CategoryCrosshairState.class);

        // Mock dataset and renderer
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(1);
        plot.setDataset(index, dataset);

        CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
        CategoryItemRendererState rendererState = mock(CategoryItemRendererState.class);
        when(renderer.initialise(eq(g2), eq(dataArea), eq(plot), eq(index), eq(info))).thenReturn(rendererState);
        when(renderer.getPassCount()).thenReturn(1);
        plot.setRenderer(index, renderer);

        // Act
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // Assert
        assertTrue(result, "Expected render to return true");
        verify(renderer, times(1)).drawItem(
                eq(g2),
                eq(rendererState),
                eq(dataArea),
                eq(plot),
                any(CategoryAxis.class),
                any(ValueAxis.class),
                eq(dataset),
                anyInt(),
                anyInt(),
                anyInt()
        );
    }

    @Test
    @DisplayName("render method handles null CategoryCrosshairState")
    void testRenderWithNullCategoryCrosshairState() throws Exception {
        // Arrange
        CategoryPlot plot = new CategoryPlot();

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        int index = 0;
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CategoryCrosshairState crosshairState = null;  // Testing with null CategoryCrosshairState

        // Mock dataset and renderer
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(1);
        plot.setDataset(index, dataset);

        CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
        CategoryItemRendererState rendererState = mock(CategoryItemRendererState.class);
        when(renderer.initialise(eq(g2), eq(dataArea), eq(plot), eq(index), eq(info))).thenReturn(rendererState);
        when(renderer.getPassCount()).thenReturn(1);
        plot.setRenderer(index, renderer);

        // Act
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // Assert
        assertTrue(result, "Expected render to return true");
        verify(renderer, times(1)).drawItem(
                eq(g2),
                eq(rendererState),
                eq(dataArea),
                eq(plot),
                any(CategoryAxis.class),
                any(ValueAxis.class),
                eq(dataset),
                anyInt(),
                anyInt(),
                anyInt()
        );
    }

    @Test
    @DisplayName("render method handles maximum integer index")
    void testRenderHandlesMaximumIntegerIndex() throws Exception {
        // Arrange
        CategoryPlot plot = new CategoryPlot();

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        int index = Integer.MAX_VALUE;
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CategoryCrosshairState crosshairState = mock(CategoryCrosshairState.class);

        // Act
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // Assert
        assertFalse(result, "Expected render to return false due to dataset not found");
    }

    @Test
    @DisplayName("render method handles minimum integer index")
    void testRenderHandlesMinimumIntegerIndex() throws Exception {
        // Arrange
        CategoryPlot plot = new CategoryPlot();

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        int index = Integer.MIN_VALUE;
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CategoryCrosshairState crosshairState = mock(CategoryCrosshairState.class);

        // Act
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // Assert
        assertFalse(result, "Expected render to return false due to dataset not found");
    }

    @Test
    @DisplayName("render method handles single column and multiple rows in ascending order")
    void testRenderSingleColumnMultipleRowsAscending() throws Exception {
        // Arrange
        CategoryPlot plot = new CategoryPlot();
        plot.setColumnRenderingOrder(SortOrder.ASCENDING);
        plot.setRowRenderingOrder(SortOrder.ASCENDING);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        int index = 0;
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CategoryCrosshairState crosshairState = mock(CategoryCrosshairState.class);

        // Mock dataset and renderer
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(3); // Multiple rows
        plot.setDataset(index, dataset);

        CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
        CategoryItemRendererState rendererState = mock(CategoryItemRendererState.class);
        when(renderer.initialise(eq(g2), eq(dataArea), eq(plot), eq(index), eq(info))).thenReturn(rendererState);
        when(renderer.getPassCount()).thenReturn(1);
        plot.setRenderer(index, renderer);

        // Act
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // Assert
        assertTrue(result, "Expected render to return true");
        verify(renderer, times(3)).drawItem(
                eq(g2),
                eq(rendererState),
                eq(dataArea),
                eq(plot),
                any(CategoryAxis.class),
                any(ValueAxis.class),
                eq(dataset),
                anyInt(),
                eq(0),
                anyInt()
        );
    }
}
