package org.apache.commons.math3.stat.ranking;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class NaturalRanking_rank_1_1_Test {

    @Test
    @DisplayName("rank with multiple NaNs using FIXED strategy preserves all NaN positions")
    void test_TC15_rankWithMultipleNaNsUsingFixedStrategy() {
        double[] data = new double[]{Double.NaN, 2.0, Double.NaN, 4.0};
        NaturalRanking ranking = new NaturalRanking(NaNStrategy.FIXED, TiesStrategy.AVERAGE);
        double[] result = ranking.rank(data);
        assertTrue(Double.isNaN(result[0]), "First element should be NaN");
        assertEquals(1.0, result[1], "Second element should have rank 1.0");
        assertTrue(Double.isNaN(result[2]), "Third element should be NaN");
        assertEquals(2.0, result[3], "Fourth element should have rank 2.0");
    }

    @Test
    @DisplayName("rank with no NaNs and multiple iterations correctly assigns unique ranks")
    void test_TC16_rankWithNoNaNsAndUniqueElements() {
        double[] data = new double[]{5.0, 3.0, 8.0, 1.0, 7.0};
        NaturalRanking ranking = new NaturalRanking();
        double[] result = ranking.rank(data);
        assertEquals(3.0, result[0], "First element should have rank 3.0");
        assertEquals(2.0, result[1], "Second element should have rank 2.0");
        assertEquals(5.0, result[2], "Third element should have rank 5.0");
        assertEquals(1.0, result[3], "Fourth element should have rank 1.0");
        assertEquals(4.0, result[4], "Fifth element should have rank 4.0");
    }

    @Test
    @DisplayName("rank with all elements equal using AVERAGE strategy assigns identical ranks")
    void test_TC17_rankWithAllElementsEqualUsingAverageStrategy() {
        double[] data = new double[]{4.0, 4.0, 4.0, 4.0};
        NaturalRanking ranking = new NaturalRanking(NaNStrategy.REMOVED, TiesStrategy.AVERAGE);
        double[] result = ranking.rank(data);
        assertEquals(2.5, result[0], "First element should have rank 2.5");
        assertEquals(2.5, result[1], "Second element should have rank 2.5");
        assertEquals(2.5, result[2], "Third element should have rank 2.5");
        assertEquals(2.5, result[3], "Fourth element should have rank 2.5");
    }

    @Test
    @DisplayName("rank with NaNStrategy.REMOVED and multiple NaNs correctly removes all NaNs")
    void test_TC18_rankWithRemovedNaNsAndMultipleNaNs() {
        double[] data = new double[]{Double.NaN, 3.0, Double.NaN, 1.0, 2.0};
        NaturalRanking ranking = new NaturalRanking(NaNStrategy.REMOVED, TiesStrategy.AVERAGE);
        double[] result = ranking.rank(data);
        assertEquals(3, result.length, "Result array should have three elements after removing NaNs");
        assertEquals(2.0, result[0], "First rank should be 2.0");
        assertEquals(1.0, result[1], "Second rank should be 1.0");
        assertEquals(3.0, result[2], "Third rank should be 3.0");
    }
}