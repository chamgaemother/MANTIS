package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.codec.language.ColognePhonetic;

public class ColognePhonetic_colognePhonetic_0_1_Test {

    @Test
    @DisplayName("Input is null, should return null")
    public void testTC01() {
        // Given
        String input = null;
        ColognePhonetic colognePhonetic = new ColognePhonetic();

        // When
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertNull(result);
    }

    @Test
    @DisplayName("Input is empty string, should return empty string")
    public void testTC02() {
        // Given
        String input = "";
        ColognePhonetic colognePhonetic = new ColognePhonetic();

        // When
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertEquals("", result);
    }

    @Test
    @DisplayName("Input with only vowels, should return string of '0's")
    public void testTC03() {
        // Given
        String input = "AEIOUYaeiouy";
        ColognePhonetic colognePhonetic = new ColognePhonetic();

        // When
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertEquals("000000000000", result);
    }

    @Test
    @DisplayName("Input with consonant 'H', should handle 'H' with code '-'")
    public void testTC04() {
        // Given
        String input = "Harry";
        ColognePhonetic colognePhonetic = new ColognePhonetic();

        // When
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertTrue(result.contains("-"));
    }

    @Test
    @DisplayName("Input with 'P' not before 'H', should assign code '1'")
    public void testTC05() {
        // Given
        String input = "Parker";
        ColognePhonetic colognePhonetic = new ColognePhonetic();

        // When
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertTrue(result.contains("1"));
    }
}