import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.ri.NamespaceResolver;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.dom.DOMNodePointer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.w3c.dom.*;

import java.util.Locale;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DOMNodePointerTest {

    private Document document;
    private Element element;
    private Text textNode;
    private ProcessingInstruction pi;
    private DOMNodePointer domNodePointer;
    private DOMNodePointer domNodePointerWithParent;
    private DOMNodePointer domNodePointerWithId;
    private NamespaceResolver namespaceResolver;

    @BeforeEach
    void setUp() {
        document = mock(Document.class);
        element = mock(Element.class);
        textNode = mock(Text.class);
        pi = mock(ProcessingInstruction.class);
        namespaceResolver = mock(NamespaceResolver.class);

        when(document.getNodeType()).thenReturn(Node.DOCUMENT_NODE);
        when(element.getNodeType()).thenReturn(Node.ELEMENT_NODE);
        when(textNode.getNodeType()).thenReturn(Node.TEXT_NODE);
        when(pi.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);

        when(document.getDocumentElement()).thenReturn(element);
        when(element.getParentNode()).thenReturn(document);

        domNodePointer = new DOMNodePointer(document, Locale.getDefault());
        domNodePointerWithParent = new DOMNodePointer(domNodePointer, element);
        domNodePointerWithId = new DOMNodePointer(element, Locale.getDefault(), "testId");

        when(namespaceResolver.getPrefix(anyString())).thenReturn("prefix");
    }

    @Test
    void testAsPathForDocumentNode() {
        assertEquals("", domNodePointer.asPath());
    }

    @Test
    void testAsPathForElementNodeWithId() {
        assertEquals("id('testId')", domNodePointerWithId.asPath());
    }

    @Test
    void testAsPathForElementNodeNoId() {
        NodePointer parentPointer = mock(DOMNodePointer.class, RETURNS_DEEP_STUBS);
        DOMNodePointer pointer = new DOMNodePointer(parentPointer, element);
        QName testQName = new QName(null, "testElement");

        when(parentPointer.asPath()).thenReturn("/parent");
        when(element.getLocalName()).thenReturn("testElement");
        when(element.getNamespaceURI()).thenReturn(null);
        when(pointer.getRelativePositionByQName()).thenReturn(1);

        assertEquals("/parent/testElement[1]", pointer.asPath());
    }

    @Test
    void testAsPathForTextNode() {
        NodePointer parentPointer = mock(DOMNodePointer.class, RETURNS_DEEP_STUBS);
        DOMNodePointer pointer = new DOMNodePointer(parentPointer, textNode);

        when(parentPointer.asPath()).thenReturn("/parent");
        when(pointer.getRelativePositionOfTextNode()).thenReturn(1);

        assertEquals("/parent/text()[1]", pointer.asPath());
    }

    @Test
    void testAsPathForProcessingInstructionNode() {
        NodePointer parentPointer = mock(DOMNodePointer.class, RETURNS_DEEP_STUBS);
        DOMNodePointer pointer = new DOMNodePointer(parentPointer, pi);

        when(parentPointer.asPath()).thenReturn("/parent");
        when(pi.getTarget()).thenReturn("piTarget");
        when(pointer.getRelativePositionOfPI()).thenReturn(1);

        assertEquals("/parent/processing-instruction('piTarget')[1]", pointer.asPath());
    }

    @Test
    void testAsPathForNodeTypesWithoutSpecialHandling() {
        Comment commentNode = mock(Comment.class);
        when(commentNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
        DOMNodePointer pointer = new DOMNodePointer(null, commentNode);
        assertEquals("", pointer.asPath());
    }
}