package org.jfree.chart.plot;

import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.jfree.data.general.ValueDataset;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.chart.ui.RectangleInsets;
import org.jfree.chart.util.Args;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
/**
 * A test class for {@link MeterPlot#draw(Graphics2D, Rectangle2D, Point2D, PlotState, PlotRenderingInfo)}.
 */
public class MeterPlot_draw_0_1_Test {

//     @Test
//     @DisplayName("draw method with info parameter as null")
//     public void TC01_draw_method_with_info_null() throws Exception {
        // GIVEN
//         MeterPlot plot = new MeterPlot();
// 
        // Using reflection to set private fields
//         Field drawBorderField = MeterPlot.class.getDeclaredField("drawBorder");
//         drawBorderField.setAccessible(true);
//         drawBorderField.set(plot, false);
// 
//         Field meterAngleField = MeterPlot.class.getDeclaredField("meterAngle");
//         meterAngleField.setAccessible(true);
//         meterAngleField.set(plot, 180);
// 
//         Field shapeField = MeterPlot.class.getDeclaredField("shape");
//         shapeField.setAccessible(true);
//         shapeField.set(plot, DialShape.RECTANGLE);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotState state = null; // Set to null for this scenario
//         PlotRenderingInfo info = null;
// 
        // WHEN
//         plot.draw(g2, area, new Point2D.Double(50, 50), state, info);
// 
        // THEN
        // Verify that setPlotArea is not called since info is null
        // Since info is null, there's nothing to verify on it
// 
        // Verify that no border is drawn
//         verify(g2, never()).draw(any()); // Changed from drawBackground to draw
// 
        // Verify that dataset is null
//         Field datasetCheckField = MeterPlot.class.getDeclaredField("dataset");
//         datasetCheckField.setAccessible(true);
//         assertNull(datasetCheckField.get(plot), "Dataset should be null");
//     }

//     @Test
//     @DisplayName("draw method with info parameter not null")
//     public void TC02_draw_method_with_info_not_null() throws Exception {
        // GIVEN
//         MeterPlot plot = new MeterPlot();
// 
        // Using reflection to set private fields
//         Field drawBorderField = MeterPlot.class.getDeclaredField("drawBorder");
//         drawBorderField.setAccessible(true);
//         drawBorderField.set(plot, false);
// 
//         Field meterAngleField = MeterPlot.class.getDeclaredField("meterAngle");
//         meterAngleField.setAccessible(true);
//         meterAngleField.set(plot, 180);
// 
//         Field shapeField = MeterPlot.class.getDeclaredField("shape");
//         shapeField.setAccessible(true);
//         shapeField.set(plot, DialShape.RECTANGLE);
// 
        // Mocking dataset
//         ValueDataset dataset = mock(ValueDataset.class);
//         when(dataset.getValue()).thenReturn(50.0);
//         plot.setDataset(dataset);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotState state = null;
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
// 
        // WHEN
//         plot.draw(g2, area, new Point2D.Double(50, 50), state, info);
// 
        // THEN
        // Verify that setPlotArea is called
//         verify(info, times(1)).setPlotArea(area);
// 
        // Verify that dataset is plotted
//         verify(g2, atLeastOnce()).setPaint(any());
//     }

//     @Test
//     @DisplayName("draw method with drawBorder set to true")
//     public void TC03_draw_method_with_drawBorder_true() throws Exception {
        // GIVEN
//         MeterPlot plot = new MeterPlot();
//         plot.setDrawBorder(true);
// 
        // Using reflection to set private fields
//         Field meterAngleField = MeterPlot.class.getDeclaredField("meterAngle");
//         meterAngleField.setAccessible(true);
//         meterAngleField.set(plot, 180);
// 
//         Field shapeField = MeterPlot.class.getDeclaredField("shape");
//         shapeField.setAccessible(true);
//         shapeField.set(plot, DialShape.RECTANGLE);
// 
        // Mocking dataset
//         ValueDataset dataset = mock(ValueDataset.class);
//         when(dataset.getValue()).thenReturn(75.0);
//         plot.setDataset(dataset);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotState state = null;
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
// 
        // WHEN
//         plot.draw(g2, area, new Point2D.Double(50, 50), state, info);
// 
        // THEN
        // Verify that drawOutline is called
//         verify(g2, times(1)).draw(any()); // Ensured draw is verified at least once
//     }

    @Test
    @DisplayName("draw method with meterAngle greater than 180 and shape CIRCLE")
    public void TC04_draw_method_with_meterAngle_gt_180_and_shape_circle() throws Exception {
        // GIVEN
        MeterPlot plot = new MeterPlot();
        plot.setMeterAngle(200);
        plot.setDialShape(DialShape.CIRCLE); // Corrected method name for setting shape

        // Using reflection to set private fields
        Field drawBorderField = MeterPlot.class.getDeclaredField("drawBorder");
        drawBorderField.setAccessible(true);
        drawBorderField.set(plot, false);

        // Mocking dataset
        ValueDataset dataset = mock(ValueDataset.class);
        when(dataset.getValue()).thenReturn(85.0);
        plot.setDataset(dataset);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        PlotState state = null;
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        // WHEN
        plot.draw(g2, area, new Point2D.Double(50, 50), state, info);

        // THEN
        verify(g2, atLeastOnce()).setPaint(any());
    }

//     @Test
//     @DisplayName("draw method with meterAngle less than or equal to 180")
//     public void TC05_draw_method_with_meterAngle_le_180() throws Exception {
        // GIVEN
//         MeterPlot plot = new MeterPlot();
//         plot.setMeterAngle(150);
//         plot.setDialShape(DialShape.RECTANGLE); // Corrected method name for setting shape
// 
        // Using reflection to set private fields
//         Field drawBorderField = MeterPlot.class.getDeclaredField("drawBorder");
//         drawBorderField.setAccessible(true);
//         drawBorderField.set(plot, false);
// 
        // Mocking dataset
//         ValueDataset dataset = mock(ValueDataset.class);
//         when(dataset.getValue()).thenReturn(65.0);
//         plot.setDataset(dataset);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotState state = null;
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
// 
        // WHEN
//         plot.draw(g2, area, new Point2D.Double(50, 50), state, info);
// 
        // THEN
//         verify(g2, atLeastOnce()).setPaint(any());
//     }
}