package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class Nysiis_nysiis_0_3_Test {

    @Test
    @DisplayName("String with multiple replacements is processed correctly")
    public void testMultipleReplacements() {
        // Scenario TC11 setup
        String input = "PHILOOMACSCH";
        Nysiis nysiis = new Nysiis();

        // Invoke method
        String result = nysiis.nysiis(input);

        // Assert the expected result
        assertEquals("FFALAMAC", result);
    }
}