import org.apache.commons.math3.RealFieldElement;
import org.apache.commons.math3.exception.CardanEulerSingularityException;
import org.apache.commons.math3.geometry.euclidean.threed.FieldRotation;
import org.apache.commons.math3.geometry.euclidean.threed.FieldVector3D;
import org.apache.commons.math3.geometry.euclidean.threed.RotationConvention;
import org.apache.commons.math3.geometry.euclidean.threed.RotationOrder;
import org.apache.commons.math3.util.Decimal64;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.*;

public class FieldRotationTest {

    private static final Decimal64 ONE = new Decimal64(1.0);
    private static final Decimal64 ZERO = new Decimal64(0.0);

    @Test
    public void testGetAnglesXYZ_VectorOperator() {
        FieldRotation<Decimal64> rotation = new FieldRotation<>(ONE, ZERO, ZERO, ZERO, true);
        try {
            RealFieldElement[] angles = rotation.getAngles(RotationOrder.XYZ, RotationConvention.VECTOR_OPERATOR);
            assertArrayEquals(new Decimal64[]{ZERO, ZERO, ZERO}, angles);
        } catch (CardanEulerSingularityException e) {
            fail("Should not throw a singularity exception");
        }
    }

    @Test
    public void testGetAnglesXYZ_Singularity_VectorOperator() {
        FieldRotation<Decimal64> rotation = new FieldRotation<>(ZERO, ONE, ZERO, ZERO, true);
        assertThrows(CardanEulerSingularityException.class, () ->
                rotation.getAngles(RotationOrder.XYZ, RotationConvention.VECTOR_OPERATOR));
    }

    @Test
    public void testGetAnglesZYX_VectorOperator() {
        FieldRotation<Decimal64> rotation = new FieldRotation<>(ONE, ZERO, ZERO, ZERO, true);
        try {
            RealFieldElement[] angles = rotation.getAngles(RotationOrder.ZYX, RotationConvention.VECTOR_OPERATOR);
            assertArrayEquals(new Decimal64[]{ZERO, ZERO, ZERO}, angles);
        } catch (CardanEulerSingularityException e) {
            fail("Should not throw a singularity exception");
        }
    }

    @Test
    public void testGetAnglesZYX_Singularity_VectorOperator() {
        FieldRotation<Decimal64> rotation = new FieldRotation<>(ZERO, ZERO, ZERO, ONE, true);
        assertThrows(CardanEulerSingularityException.class, () ->
                rotation.getAngles(RotationOrder.ZYX, RotationConvention.VECTOR_OPERATOR));
    }

    @Test
    public void testGetAnglesXYZ_FrameTransform() {
        FieldRotation<Decimal64> rotation = new FieldRotation<>(ONE, ZERO, ZERO, ZERO, true);
        try {
            RealFieldElement[] angles = rotation.getAngles(RotationOrder.XYZ, RotationConvention.FRAME_TRANSFORM);
            assertArrayEquals(new Decimal64[]{ZERO, ZERO, ZERO}, angles);
        } catch (CardanEulerSingularityException e) {
            fail("Should not throw a singularity exception");
        }
    }

    @Test
    public void testGetAnglesXYZ_Singularity_FrameTransform() {
        FieldRotation<Decimal64> rotation = new FieldRotation<>(ZERO, ONE, ZERO, ZERO, true);
        assertThrows(CardanEulerSingularityException.class, () ->
                rotation.getAngles(RotationOrder.XYZ, RotationConvention.FRAME_TRANSFORM));
    }

    @Test
    public void testGetAnglesZYX_FrameTransform() {
        FieldRotation<Decimal64> rotation = new FieldRotation<>(ONE, ZERO, ZERO, ZERO, true);
        try {
            RealFieldElement[] angles = rotation.getAngles(RotationOrder.ZYX, RotationConvention.FRAME_TRANSFORM);
            assertArrayEquals(new Decimal64[]{ZERO, ZERO, ZERO}, angles);
        } catch (CardanEulerSingularityException e) {
            fail("Should not throw a singularity exception");
        }
    }

    @Test
    public void testGetAnglesZYX_Singularity_FrameTransform() {
        FieldRotation<Decimal64> rotation = new FieldRotation<>(ZERO, ZERO, ZERO, ONE, true);
        assertThrows(CardanEulerSingularityException.class, () ->
                rotation.getAngles(RotationOrder.ZYX, RotationConvention.FRAME_TRANSFORM));
    }

    @Test
    public void testNullConvention() {
        FieldRotation<Decimal64> rotation = new FieldRotation<>(ONE, ZERO, ZERO, ZERO, true);
        assertThrows(NullPointerException.class, () -> rotation.getAngles(RotationOrder.ZYX, null));
    }

    @Test
    public void testNullOrder() {
        FieldRotation<Decimal64> rotation = new FieldRotation<>(ONE, ZERO, ZERO, ZERO, true);
        Executable testExecutable = () -> rotation.getAngles(null, RotationConvention.FRAME_TRANSFORM);
        NullPointerException exception = assertThrows(NullPointerException.class, testExecutable);
        assertNotNull(exception.getMessage());
    }
}