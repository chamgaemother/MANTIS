package org.joda.time.tz;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.io.BufferedReader;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ZoneInfoCompiler_parseDataFile_0_1_Test {

    @Test
    @DisplayName("parseDataFile with empty BufferedReader completes without processing")
    public void TC01_parseDataFile_emptyBufferedReader() throws Exception {
        // GIVEN
        BufferedReader in = new BufferedReader(new StringReader(""));
        boolean z9 = false;
        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // WHEN
        compiler.parseDataFile(in, z9);

        // THEN
        // Access iZones via reflection
        Field iZonesField = ZoneInfoCompiler.class.getDeclaredField("iZones");
        iZonesField.setAccessible(true);
        List<?> iZones = (List<?>) iZonesField.get(compiler);
        Assertions.assertTrue(iZones.isEmpty(), "iZones should be empty");

        // Access iRuleSets via reflection
        Field iRuleSetsField = ZoneInfoCompiler.class.getDeclaredField("iRuleSets");
        iRuleSetsField.setAccessible(true);
        Map<?, ?> iRuleSets = (Map<?, ?>) iRuleSetsField.get(compiler);
        Assertions.assertTrue(iRuleSets.isEmpty(), "iRuleSets should be empty");
    }

    @Test
    @DisplayName("parseDataFile skips lines that are only whitespace")
    public void TC02_parseDataFile_whitespaceOnlyLines() throws Exception {
        // GIVEN
        BufferedReader in = new BufferedReader(new StringReader("   \n\t\r"));
        boolean z9 = false;
        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // WHEN
        compiler.parseDataFile(in, z9);

        // THEN
        // Access iZones via reflection
        Field iZonesField = ZoneInfoCompiler.class.getDeclaredField("iZones");
        iZonesField.setAccessible(true);
        List<?> iZones = (List<?>) iZonesField.get(compiler);
        Assertions.assertTrue(iZones.isEmpty(), "iZones should be empty");

        // Access iRuleSets via reflection
        Field iRuleSetsField = ZoneInfoCompiler.class.getDeclaredField("iRuleSets");
        iRuleSetsField.setAccessible(true);
        Map<?, ?> iRuleSets = (Map<?, ?>) iRuleSetsField.get(compiler);
        Assertions.assertTrue(iRuleSets.isEmpty(), "iRuleSets should be empty");
    }

    @Test
    @DisplayName("parseDataFile skips lines starting with '#' as comments")
    public void TC03_parseDataFile_commentLines() throws Exception {
        // GIVEN
        BufferedReader in = new BufferedReader(new StringReader("# This is a comment\n# Another comment"));
        boolean z9 = false;
        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // WHEN
        compiler.parseDataFile(in, z9);

        // THEN
        // Access iZones via reflection
        Field iZonesField = ZoneInfoCompiler.class.getDeclaredField("iZones");
        iZonesField.setAccessible(true);
        List<?> iZones = (List<?>) iZonesField.get(compiler);
        Assertions.assertTrue(iZones.isEmpty(), "iZones should be empty");

        // Access iRuleSets via reflection
        Field iRuleSetsField = ZoneInfoCompiler.class.getDeclaredField("iRuleSets");
        iRuleSetsField.setAccessible(true);
        Map<?, ?> iRuleSets = (Map<?, ?>) iRuleSetsField.get(compiler);
        Assertions.assertTrue(iRuleSets.isEmpty(), "iRuleSets should be empty");
    }

    @Test
    @DisplayName("parseDataFile handles lines with RULE_LOOKUP tokens")
    public void TC04_parseDataFile_ruleLookupToken() throws Exception {
        // GIVEN
        BufferedReader in = new BufferedReader(new StringReader("summer start\n"));
        boolean z9 = false;
        ZoneInfoCompiler compiler = new ZoneInfoCompiler();
        // Assume RULE_LOOKUP contains 'summer'

        // Access RULE_LOOKUP field via reflection and add 'summer'
        Field ruleLookupField = ZoneInfoCompiler.class.getDeclaredField("RULE_LOOKUP");
        ruleLookupField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Set<String> RULE_LOOKUP = (Set<String>) ruleLookupField.get(null);
        RULE_LOOKUP.add("summer");

        // WHEN
        compiler.parseDataFile(in, z9);

        // THEN
        // Access iRuleSets via reflection
        Field iRuleSetsField = ZoneInfoCompiler.class.getDeclaredField("iRuleSets");
        iRuleSetsField.setAccessible(true);
        Map<?, ?> iRuleSets = (Map<?, ?>) iRuleSetsField.get(compiler);
        Assertions.assertTrue(iRuleSets.containsKey("summer"), "iRuleSets should contain 'summer'");
    }

    @Test
    @DisplayName("parseDataFile processes ZONE_LOOKUP token with sufficient tokens")
    public void TC05_parseDataFile_validZoneLookupToken() throws Exception {
        // GIVEN
        BufferedReader in = new BufferedReader(new StringReader("Europe/London GMT0"));
        boolean z9 = false;
        ZoneInfoCompiler compiler = new ZoneInfoCompiler();
        // Assume ZONE_LOOKUP contains 'europe/london'

        // Access ZONE_LOOKUP field via reflection and add 'europe/london'
        Field zoneLookupField = ZoneInfoCompiler.class.getDeclaredField("ZONE_LOOKUP");
        zoneLookupField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Set<String> ZONE_LOOKUP = (Set<String>) zoneLookupField.get(null);
        ZONE_LOOKUP.add("europe/london");

        // WHEN
        compiler.parseDataFile(in, z9);

        // THEN
        // Access iZones via reflection
        Field iZonesField = ZoneInfoCompiler.class.getDeclaredField("iZones");
        iZonesField.setAccessible(true);
        List<?> iZones = (List<?>) iZonesField.get(compiler);
        boolean zoneAdded = iZones.stream().anyMatch(zone -> {
            try {
                Field nameField = zone.getClass().getDeclaredField("iName");
                nameField.setAccessible(true);
                return "Europe/London".equals(nameField.get(zone));
            } catch (Exception e) {
                return false;
            }
        });
        Assertions.assertTrue(zoneAdded, "Zone 'Europe/London' should be added to iZones");
    }
}