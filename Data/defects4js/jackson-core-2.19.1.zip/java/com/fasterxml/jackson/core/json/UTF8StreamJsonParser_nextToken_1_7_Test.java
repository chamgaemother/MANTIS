package com.fasterxml.jackson.core.json;

import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.Constructor;

public class UTF8StreamJsonParser_nextToken_1_7_Test {

    @Test
    @DisplayName("nextToken throws exception when parsing 'Infinity' and ALLOW_NON_NUMERIC_NUMBERS is disabled")
    public void testNextTokenInfinityWithoutNonNumericNumbers() throws Exception {
        // Initialize input
        String json = "Infinity";
        byte[] inputBytes = json.getBytes("UTF-8");
        InputStream inputStream = new ByteArrayInputStream(inputBytes);

        // Initialize IOContext - using default settings
        IOContext ctxt = new IOContext(null, inputStream, false);

        // Initialize ByteQuadsCanonicalizer - default settings
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();

        // Disable the ALLOW_NON_NUMERIC_NUMBERS feature
        int features = 0;

        // Initialize input buffer
        byte[] inputBuffer = new byte[inputBytes.length];
        System.arraycopy(inputBytes, 0, inputBuffer, 0, inputBytes.length);

        // Instantiate the parser via reflection
        Constructor<UTF8StreamJsonParser> constructor = UTF8StreamJsonParser.class.getDeclaredConstructor(
                IOContext.class,
                int.class,
                InputStream.class,
                ObjectCodec.class,
                ByteQuadsCanonicalizer.class,
                byte[].class,
                int.class,
                int.class,
                int.class,
                boolean.class);
        constructor.setAccessible(true);
        UTF8StreamJsonParser parser = constructor.newInstance(
                ctxt,
                features,
                inputStream,
                null, // ObjectCodec can be null for this test
                sym,
                inputBuffer,
                0,
                inputBytes.length,
                0,
                false // bufferRecyclable
        );

        // Execute and assert exception
        assertThrows(JsonParseException.class, () -> {
            parser.nextToken();
        });
    }
}
