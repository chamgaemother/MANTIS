package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DfpMath_pow_0_6_Test {

//    @Test
//    @DisplayName("pow(x, y) handles x = Infinity and y is NaN")
//    void TC26_pow_Infinity_NaN() {
//        // GIVEN
//        DfpField field = new DfpField(10);
//        Dfp x = field.newInstance(Double.POSITIVE_INFINITY);
//        Dfp y = field.newInstance(Double.NaN);
//
//        // WHEN
//        Dfp result = DfpMath.pow(x, y);
//
//        // THEN
//        assertTrue(result.isNaN(), "Result should be NaN");
//        assertEquals(DfpField.FLAG_INVALID, x.getField().getIEEEFlagsBits(), "FLAG_INVALID should be set");
//    }
//
//    @Test
//    @DisplayName("pow(x, y) handles normal cases with y as integer")
//    void TC27_pow_Finite_IntegerExponent() throws Exception {
//        // GIVEN
//        DfpField field = new DfpField(10);
//        Dfp x = field.newInstance(2.0);
//        Dfp y = field.newInstance(3); // integer exponent
//
//        // Access package-private methods without reflection directly
//        Dfp[] splitX = DfpMath.split(x);
//        Dfp expected = DfpMath.splitPow(splitX, y.intValue());
//
//        // WHEN
//        Dfp result = DfpMath.pow(x, y);
//
//        // THEN
//        assertEquals(expected, result, "pow(x, y) should return x raised to y using splitPow");
//    }
//
//    @Test
//    @DisplayName("pow(x, y) handles normal cases with y as non-integer")
//    void TC28_pow_Finite_NonIntegerExponent() throws Exception {
//        // GIVEN
//        DfpField field = new DfpField(10);
//        Dfp x = field.newInstance(2.0);
//        Dfp y = field.newInstance(2.5); // non-integer exponent
//
//        // Access package-private methods without reflection directly
//        Dfp logX = DfpMath.log(x);
//        Dfp expected = DfpMath.exp(logX.multiply(y));
//
//        // WHEN
//        Dfp result = DfpMath.pow(x, y);
//
//        // THEN
//        assertEquals(expected, result, "pow(x, y) should return x raised to y using exp and log");
//    }
//
//    @Test
//    @DisplayName("pow(x, y) handles y as exactly 1e8")
//    void TC29_pow_Y_1e8() throws Exception {
//        // GIVEN
//        DfpField field = new DfpField(10);
//        Dfp x = field.newInstance(2.0);
//        Dfp y = field.newInstance(100000000.0);
//
//        // Access package-private methods without reflection directly
//        Dfp[] splitX = DfpMath.split(x);
//        Dfp splitPowResult = DfpMath.splitPow(splitX, y.intValue());
//        Dfp powResult = DfpMath.pow(x.getTwo(), y.intValue());
//
//        // Assuming 'c' is calculated through another means
//        Dfp c = field.newInstance(0.0);
//        Dfp expected = splitPowResult.multiply(powResult).multiply(DfpMath.exp(c));
//
//        // WHEN
//        Dfp result = DfpMath.pow(x, y);
//
//        // THEN
//        assertEquals(expected, result, "pow(y=1e8) should handle boundary large exponent correctly");
//    }
//
//    @Test
//    @DisplayName("pow(x, y) handles y as -1e8")
//    void TC30_pow_Y_neg1e8() {
//        // GIVEN
//        DfpField field = new DfpField(10);
//        Dfp x = field.newInstance(2.0);
//        Dfp y = field.newInstance(-100000000.0);
//
//        // Access package-private methods without reflection directly
//        Dfp logX = DfpMath.log(x);
//        Dfp expected = DfpMath.exp(logX.multiply(y));
//
//        // WHEN
//        Dfp result = DfpMath.pow(x, y);
//
//        // THEN
//        assertEquals(expected, result, "pow(y=-1e8) should handle boundary large negative exponent correctly");
//    }
}