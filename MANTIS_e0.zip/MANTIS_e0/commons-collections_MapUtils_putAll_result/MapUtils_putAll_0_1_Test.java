package org.apache.commons.collections4;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import java.util.AbstractMap;
import java.util.HashMap;
import java.util.Map;

public class MapUtils_putAll_0_1_Test {

    @Test
    @DisplayName("putAll throws NullPointerException when the map argument is null")
    void test_putAll_nullMap() {
        // GIVEN
        Map<Object, Object> map = null;
        Object[] array = new Object[] { };

        // WHEN & THEN
        NullPointerException exception = assertThrows(NullPointerException.class, () -> {
            MapUtils.putAll(map, array);
        });
        assertEquals("map", exception.getMessage());
    }

    @Test
    @DisplayName("putAll returns the original map when the array is null")
    void test_putAll_nullArray() {
        // GIVEN
        Map<Object, Object> map = new HashMap<>();
        Object[] array = null;

        // WHEN
        Map<Object, Object> result = MapUtils.putAll(map, array);

        // THEN
        assertSame(map, result);
        assertTrue(result.isEmpty(), "Map should remain empty");
    }

    @Test
    @DisplayName("putAll returns the original map when the array is empty")
    void test_putAll_emptyArray() {
        // GIVEN
        Map<Object, Object> map = new HashMap<>();
        Object[] array = new Object[] { };

        // WHEN
        Map<Object, Object> result = MapUtils.putAll(map, array);

        // THEN
        assertSame(map, result);
        assertTrue(result.isEmpty(), "Map should remain empty");
    }

    @Test
    @DisplayName("putAll processes a single Map.Entry element correctly")
    void test_putAll_singleMapEntry() {
        // GIVEN
        Map<Object, Object> map = new HashMap<>();
        Object key1 = "key1";
        Object value1 = "value1";
        Map.Entry<Object, Object> entry = new AbstractMap.SimpleEntry<>(key1, value1);
        Object[] array = new Object[] { entry };

        // WHEN
        Map<Object, Object> result = MapUtils.putAll(map, array);

        // THEN
        assertTrue(result.containsKey(key1), "Map should contain key1");
        assertEquals(value1, result.get(key1), "Value for key1 should be value1");
    }

    @Test
    @DisplayName("putAll processes multiple Map.Entry elements correctly")
    void test_putAll_multipleMapEntries() {
        // GIVEN
        Map<Object, Object> map = new HashMap<>();
        Object key1 = "key1";
        Object value1 = "value1";
        Object key2 = "key2";
        Object value2 = "value2";
        Map.Entry<Object, Object> entry1 = new AbstractMap.SimpleEntry<>(key1, value1);
        Map.Entry<Object, Object> entry2 = new AbstractMap.SimpleEntry<>(key2, value2);
        Object[] array = new Object[] { entry1, entry2 };

        // WHEN
        Map<Object, Object> result = MapUtils.putAll(map, array);

        // THEN
        assertAll(
            () -> assertTrue(result.containsKey(key1), "Map should contain key1"),
            () -> assertEquals(value1, result.get(key1), "Value for key1 should be value1"),
            () -> assertTrue(result.containsKey(key2), "Map should contain key2"),
            () -> assertEquals(value2, result.get(key2), "Value for key2 should be value2")
        );
    }
}