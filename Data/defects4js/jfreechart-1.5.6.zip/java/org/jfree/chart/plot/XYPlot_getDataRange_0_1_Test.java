package org.jfree.chart.plot;

import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CombinedDomainXYPlot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.Range;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class XYPlot_getDataRange_0_1_Test {

//     @Test
//     @DisplayName("getDataRange returns null when subplots is null")
//     void TC01_getDataRange_with_null_subplots() {
        // GIVEN
//         CombinedDomainXYPlot plot = new CombinedDomainXYPlot((List<XYPlot>) null);
//         ValueAxis axis = new NumberAxis();
// 
        // WHEN
//         Range result = plot.getDataRange(axis);
// 
        // THEN
//         assertNull(result);
//     }

//     @Test
//     @DisplayName("getDataRange returns null when subplots is empty")
//     void TC02_getDataRange_with_empty_subplots() {
        // GIVEN
//         List<XYPlot> subplots = new ArrayList<>();
//         CombinedDomainXYPlot plot = new CombinedDomainXYPlot(subplots);
//         ValueAxis axis = new NumberAxis();
// 
        // WHEN
//         Range result = plot.getDataRange(axis);
// 
        // THEN
//         assertNull(result);
//     }

//     @Test
//     @DisplayName("getDataRange returns null when subplots has one plot with p.getDataRange(axis) returning null")
//     void TC03_getDataRange_with_one_subplot_returning_null() {
        // GIVEN
//         XYPlot plot1 = mock(XYPlot.class);
//         when(plot1.getDataRange(any(ValueAxis.class))).thenReturn(null);
//         List<XYPlot> subplots = Arrays.asList(plot1);
//         CombinedDomainXYPlot combinedPlot = new CombinedDomainXYPlot(subplots);
//         ValueAxis axis = new NumberAxis();
// 
        // WHEN
//         Range result = combinedPlot.getDataRange(axis);
// 
        // THEN
//         assertNull(result);
//     }

//     @Test
//     @DisplayName("getDataRange returns the Range from a single subplot")
//     void TC04_getDataRange_with_one_subplot_returning_valid_Range() {
        // GIVEN
//         Range expectedRange = new Range(0.0, 10.0);
//         XYPlot plot1 = mock(XYPlot.class);
//         when(plot1.getDataRange(any(ValueAxis.class))).thenReturn(expectedRange);
//         List<XYPlot> subplots = Arrays.asList(plot1);
//         CombinedDomainXYPlot combinedPlot = new CombinedDomainXYPlot(subplots);
//         ValueAxis axis = new NumberAxis();
// 
        // WHEN
//         Range result = combinedPlot.getDataRange(axis);
// 
        // THEN
//         assertEquals(expectedRange, result);
//     }

//     @Test
//     @DisplayName("getDataRange combines null and valid Range from two subplots")
//     void TC05_getDataRange_with_two_subplots_mixed_return_values() {
        // GIVEN
//         Range expectedRange = new Range(5.0, 15.0);
//         XYPlot plot1 = mock(XYPlot.class);
//         XYPlot plot2 = mock(XYPlot.class);
//         when(plot1.getDataRange(any(ValueAxis.class))).thenReturn(null);
//         when(plot2.getDataRange(any(ValueAxis.class))).thenReturn(expectedRange);
//         List<XYPlot> subplots = Arrays.asList(plot1, plot2);
//         CombinedDomainXYPlot combinedPlot = new CombinedDomainXYPlot(subplots);
//         ValueAxis axis = new NumberAxis();
// 
        // WHEN
//         Range result = combinedPlot.getDataRange(axis);
// 
        // THEN
//         assertEquals(expectedRange, result);
//     }
}