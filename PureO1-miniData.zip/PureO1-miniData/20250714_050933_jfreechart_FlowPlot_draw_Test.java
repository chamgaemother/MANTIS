import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;
import java.util.Collections;

import org.jfree.chart.labels.StandardFlowLabelGenerator;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.chart.plot.flow.FlowDataset;
import org.jfree.chart.plot.flow.FlowPlot;
import org.jfree.chart.util.VerticalAlignment;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class FlowPlotTest {

    private FlowDataset dataset;
    private FlowPlot plot;
    private Graphics2D g2;
    private Rectangle2D area;
    private Point2D anchor;
    private PlotState parentState;
    private PlotRenderingInfo info;

    @BeforeEach
    void setUp() {
        dataset = mock(FlowDataset.class);
        plot = new FlowPlot(dataset);
        g2 = mock(Graphics2D.class);
        area = new Rectangle2D.Double(0, 0, 800, 600);
        anchor = mock(Point2D.class);
        parentState = mock(PlotState.class);
        info = mock(PlotRenderingInfo.class);
    }

    @Test
    void testDraw_NullGraphics2D() {
        assertThrows(NullPointerException.class, () -> {
            plot.draw(null, area, anchor, parentState, info);
        });
    }

    @Test
    void testDraw_NullArea() {
        assertThrows(NullPointerException.class, () -> {
            plot.draw(g2, null, anchor, parentState, info);
        });
    }

    @Test
    void testDraw_NullDataset() {
        plot.setDataset(null);
        plot.draw(g2, area, anchor, parentState, info);
        // No exception expected
    }

    @Test
    void testDraw_InfoNull() {
        when(dataset.getStageCount()).thenReturn(0);
        plot.draw(g2, area, anchor, parentState, null);
        // No exception expected
    }

    @Test
    void testDraw_EmptyDataset() {
        when(dataset.getStageCount()).thenReturn(0);
        plot.draw(g2, area, anchor, parentState, info);
        // No exception expected
    }

    @Test
    void testDraw_SingleStage_NoFlows() {
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Collections.singletonList("Source1"));
        when(dataset.getDestinations(0)).thenReturn(Collections.singletonList("Destination1"));
        when(dataset.calculateInflow("Source1", 0)).thenReturn(0.0);
        when(dataset.calculateOutflow("Source1", 0)).thenReturn(0.0);
        plot.draw(g2, area, anchor, parentState, info);
        // No exception expected
    }

    @Test
    void testDraw_WithFlows() {
        when(dataset.getStageCount()).thenReturn(2);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1", "S2"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1", "D2"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.getFlow(0, "S1", "D2")).thenReturn(5.0);
        when(dataset.getFlow(0, "S2", "D1")).thenReturn(7.0);
        when(dataset.getFlow(0, "S2", "D2")).thenReturn(3.0);
        when(dataset.getDestinations(1)).thenReturn(Arrays.asList("D3", "D4"));
        when(dataset.calculateInflow("D3", 1)).thenReturn(12.0);
        when(dataset.calculateOutflow("D3", 1)).thenReturn(0.0);
        when(dataset.calculateInflow("D4", 1)).thenReturn(8.0);
        when(dataset.calculateOutflow("D4", 1)).thenReturn(0.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(15.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(15.0);
        when(dataset.calculateInflow("S2", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S2", 0)).thenReturn(10.0);
        plot.draw(g2, area, anchor, parentState, info);
        // No exception expected
    }

    @Test
    void testDraw_NodeColorSwatchEmpty() {
        plot.setNodeColorSwatch(Collections.emptyList());
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        plot.draw(g2, area, anchor, parentState, info);
        verify(g2).setPaint(Color.GRAY);
    }

    @Test
    void testDraw_NodeColorSwatchNonEmpty() {
        plot.setNodeColorSwatch(Arrays.asList(Color.RED, Color.GREEN));
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1", "S2"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1", "D2"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.getFlow(0, "S1", "D2")).thenReturn(5.0);
        when(dataset.getFlow(0, "S2", "D1")).thenReturn(7.0);
        when(dataset.getFlow(0, "S2", "D2")).thenReturn(3.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(15.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(15.0);
        when(dataset.calculateInflow("S2", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S2", 0)).thenReturn(10.0);
        plot.draw(g2, area, anchor, parentState, info);
        verify(g2, times(2)).setPaint(any(Color.class));
    }

    @Test
    void testDraw_WithToolTipGenerator() {
        plot.setToolTipGenerator(new StandardFlowLabelGenerator());
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        plot.draw(g2, area, anchor, parentState, info);
        verify(info.getOwner()).getEntityCollection();
    }

    @Test
    void testDraw_WithNullToolTipGenerator() {
        plot.setToolTipGenerator(null);
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        plot.draw(g2, area, anchor, parentState, info);
        verify(info.getOwner(), never()).getEntityCollection();
    }

    @Test
    void testDraw_VerticalAlignmentTop() {
        plot.setNodeLabelAlignment(VerticalAlignment.TOP);
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        plot.draw(g2, area, anchor, parentState, info);
        // Verification can be added for label position
    }

    @Test
    void testDraw_VerticalAlignmentBottom() {
        plot.setNodeLabelAlignment(VerticalAlignment.BOTTOM);
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        plot.draw(g2, area, anchor, parentState, info);
        // Verification can be added for label position
    }

    @Test
    void testDraw_WithNodeSelections_Selected() {
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        when(dataset.hasNodeSelections()).thenReturn(true);
        when(dataset.getNodeProperty(any(), eq(NodeKey.SELECTED_PROPERTY_KEY))).thenReturn(true);
        plot.draw(g2, area, anchor, parentState, info);
        // Verification can be added for node color
    }

    @Test
    void testDraw_WithNodeSelections_NotSelected() {
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        when(dataset.hasNodeSelections()).thenReturn(true);
        when(dataset.getNodeProperty(any(), eq(NodeKey.SELECTED_PROPERTY_KEY))).thenReturn(false);
        plot.draw(g2, area, anchor, parentState, info);
        // Verification can be added for node color
    }

    @Test
    void testDraw_WithFlowSelections_Selected() {
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        when(dataset.hasFlowSelections()).thenReturn(true);
        when(dataset.getFlowProperty(any(), eq(FlowKey.SELECTED_PROPERTY_KEY))).thenReturn(true);
        plot.draw(g2, area, anchor, parentState, info);
        // Verification can be added for flow color
    }

    @Test
    void testDraw_WithFlowSelections_NotSelected() {
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        when(dataset.hasFlowSelections()).thenReturn(true);
        when(dataset.getFlowProperty(any(), eq(FlowKey.SELECTED_PROPERTY_KEY))).thenReturn(false);
        plot.draw(g2, area, anchor, parentState, info);
        // Verification can be added for flow color
    }

    @Test
    void testDraw_NullFlowMargin() {
        plot.setFlowMargin(0.0);
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        plot.draw(g2, area, anchor, parentState, info);
        // No exception expected
    }

    @Test
    void testDraw_NodeLabelOffsets() {
        plot.setNodeLabelOffsetX(5.0);
        plot.setNodeLabelOffsetY(10.0);
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        plot.draw(g2, area, anchor, parentState, info);
        // Verification can be added for label positions
    }

    @Test
    void testDraw_DefaultNodeColor() {
        plot.setNodeColorSwatch(Collections.emptyList());
        plot.setDefaultNodeColor(Color.BLUE);
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        plot.draw(g2, area, anchor, parentState, info);
        verify(g2).setPaint(Color.BLUE);
    }

    @Test
    void testDraw_WithCustomNodeColor() {
        plot.setNodeFillColor(new org.jfree.data.flow.NodeKey<>(0, "S1"), Color.MAGENTA);
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        plot.draw(g2, area, anchor, parentState, info);
        verify(g2).setPaint(Color.MAGENTA);
    }

    @Test
    void testDraw_WithEmptyNodeColorSwatchAndDefaultColor() {
        plot.setNodeColorSwatch(Collections.emptyList());
        plot.setDefaultNodeColor(Color.YELLOW);
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1", "S2"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1", "D2"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(5.0);
        when(dataset.getFlow(0, "S1", "D2")).thenReturn(5.0);
        when(dataset.getFlow(0, "S2", "D1")).thenReturn(5.0);
        when(dataset.getFlow(0, "S2", "D2")).thenReturn(5.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateInflow("S2", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S2", 0)).thenReturn(10.0);
        plot.draw(g2, area, anchor, parentState, info);
        verify(g2, times(2)).setPaint(Color.YELLOW);
    }

    @Test
    void testDraw_WithMultipleStages() {
        when(dataset.getStageCount()).thenReturn(3);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.getSources(1)).thenReturn(Arrays.asList("S2"));
        when(dataset.getDestinations(1)).thenReturn(Arrays.asList("D2"));
        when(dataset.getFlow(1, "S2", "D2")).thenReturn(5.0);
        when(dataset.getSources(2)).thenReturn(Arrays.asList("S3"));
        when(dataset.getDestinations(2)).thenReturn(Arrays.asList("D3"));
        when(dataset.getFlow(2, "S3", "D3")).thenReturn(2.5);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateInflow("S2", 1)).thenReturn(5.0);
        when(dataset.calculateOutflow("S2", 1)).thenReturn(5.0);
        when(dataset.calculateInflow("S3", 2)).thenReturn(2.5);
        when(dataset.calculateOutflow("S3", 2)).thenReturn(2.5);
        plot.draw(g2, area, anchor, parentState, info);
        // No exception expected
    }

    @Test
    void testDraw_InvalidFlowValues() {
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(-10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(-10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(-10.0);
        plot.draw(g2, area, anchor, parentState, info);
        // No exception expected, but negative flows might be handled differently
    }

    @Test
    void testDraw_WithCustomFont() {
        Font customFont = new Font("Arial", Font.ITALIC, 14);
        plot.setDefaultNodeLabelFont(customFont);
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        plot.draw(g2, area, anchor, parentState, info);
        verify(g2).setFont(customFont);
    }

    @Test
    void testDraw_WithCustomLabelPaint() {
        Paint customPaint = Color.CYAN;
        plot.setDefaultNodeLabelPaint(customPaint);
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        plot.draw(g2, area, anchor, parentState, info);
        verify(g2).setPaint(customPaint);
    }

    @Test
    void testDraw_LabelAlignmentCenter() {
        plot.setNodeLabelAlignment(VerticalAlignment.CENTER);
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        plot.draw(g2, area, anchor, parentState, info);
        // Verification can be added for label position
    }

    @Test
    void testDraw_NullNodeKeyColor() {
        plot.setNodeFillColor(null, null);
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        plot.draw(g2, area, anchor, parentState, info);
        verify(g2).setPaint(Color.GRAY);
    }

    @Test
    void testDraw_NodeColorMapWithExistingColor() {
        plot.setNodeFillColor(new org.jfree.data.flow.NodeKey<>(0, "S1"), Color.ORANGE);
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("S1"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("D1"));
        when(dataset.getFlow(0, "S1", "D1")).thenReturn(10.0);
        when(dataset.calculateInflow("S1", 0)).thenReturn(10.0);
        when(dataset.calculateOutflow("S1", 0)).thenReturn(10.0);
        plot.draw(g2, area, anchor, parentState, info);
        verify(g2).setPaint(Color.ORANGE);
    }
}