package org.apache.commons.math3.ode.sampling;

import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.ode.sampling.StepInterpolator;
import org.apache.commons.math3.ode.sampling.StepHandler;
import org.apache.commons.math3.ode.sampling.StepNormalizer;
import org.apache.commons.math3.ode.sampling.StepNormalizerMode;
import org.apache.commons.math3.ode.sampling.StepNormalizerBounds;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class StepNormalizer_handleStep_0_1_Test {

    @Test
    @DisplayName("Handle step when lastState is null, mode is INCREMENT, forward is true, with multiple loop iterations")
    public void TC01_handleStep_initial_INCREMENT_multiple_iterations_forward() throws Exception {
        StepInterpolator interpolator = Mockito.mock(StepInterpolator.class);
        when(interpolator.getPreviousTime()).thenReturn(0.0, 0.1);
        when(interpolator.getCurrentTime()).thenReturn(1.0);
        double[] initialState = new double[]{1.0, 2.0};
        double[] initialDerivatives = new double[]{0.1, 0.2};
        when(interpolator.getInterpolatedState()).thenReturn(initialState);
        when(interpolator.getInterpolatedDerivatives()).thenReturn(initialDerivatives);

        FixedStepHandler handler = Mockito.mock(FixedStepHandler.class);
        StepNormalizer normalizer = new StepNormalizer(0.1, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.FIRST);

        normalizer.handleStep(interpolator, false);

        verify(handler, atLeastOnce()).handleStep(anyDouble(), any(double[].class), any(double[].class), anyBoolean());
    }

    @Test
    @DisplayName("Handle step when lastState is null, mode is INCREMENT, forward is false, with multiple loop iterations")
    public void TC02_handleStep_initial_INCREMENT_multiple_iterations_reverse() throws Exception {
        StepInterpolator interpolator = Mockito.mock(StepInterpolator.class);
        when(interpolator.getPreviousTime()).thenReturn(1.0, 0.9);
        when(interpolator.getCurrentTime()).thenReturn(0.0);
        double[] initialState = new double[]{2.0, 3.0};
        double[] initialDerivatives = new double[]{0.2, 0.3};
        when(interpolator.getInterpolatedState()).thenReturn(initialState);
        when(interpolator.getInterpolatedDerivatives()).thenReturn(initialDerivatives);

        FixedStepHandler handler = Mockito.mock(FixedStepHandler.class);
        StepNormalizer normalizer = new StepNormalizer(0.1, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.FIRST);

        normalizer.handleStep(interpolator, false);

        verify(handler, atLeastOnce()).handleStep(anyDouble(), any(double[].class), any(double[].class), anyBoolean());
    }

    @Test
    @DisplayName("Handle step when lastState is not null, mode is INCREMENT, forward is true, with single loop iteration")
    public void TC03_handleStep_existing_state_INCREMENT_single_iteration_forward() throws Exception {
        StepInterpolator interpolator = Mockito.mock(StepInterpolator.class);
        when(interpolator.getPreviousTime()).thenReturn(0.1);
        when(interpolator.getCurrentTime()).thenReturn(0.2);
        double[] existingState = new double[]{1.0, 2.0};
        double[] existingDerivatives = new double[]{0.1, 0.2};
        when(interpolator.getInterpolatedState()).thenReturn(existingState);
        when(interpolator.getInterpolatedDerivatives()).thenReturn(existingDerivatives);

        FixedStepHandler handler = Mockito.mock(FixedStepHandler.class);
        StepNormalizer normalizer = new StepNormalizer(0.1, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.FIRST);

        Field lastStateField = StepNormalizer.class.getDeclaredField("lastState");
        lastStateField.setAccessible(true);
        lastStateField.set(normalizer, existingState.clone());

        Field lastDerivativesField = StepNormalizer.class.getDeclaredField("lastDerivatives");
        lastDerivativesField.setAccessible(true);
        lastDerivativesField.set(normalizer, existingDerivatives.clone());

        normalizer.handleStep(interpolator, false);

        verify(handler, times(1)).handleStep(anyDouble(), any(double[].class), any(double[].class), anyBoolean());
    }

    @Test
    @DisplayName("Handle step when lastState is not null, mode is INCREMENT, forward is false, with single loop iteration")
    public void TC04_handleStep_existing_state_INCREMENT_single_iteration_reverse() throws Exception {
        StepInterpolator interpolator = Mockito.mock(StepInterpolator.class);
        when(interpolator.getPreviousTime()).thenReturn(0.9);
        when(interpolator.getCurrentTime()).thenReturn(0.8);
        double[] existingState = new double[]{2.0, 3.0};
        double[] existingDerivatives = new double[]{0.2, 0.3};
        when(interpolator.getInterpolatedState()).thenReturn(existingState);
        when(interpolator.getInterpolatedDerivatives()).thenReturn(existingDerivatives);

        FixedStepHandler handler = Mockito.mock(FixedStepHandler.class);
        StepNormalizer normalizer = new StepNormalizer(0.1, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.FIRST);

        Field lastStateField = StepNormalizer.class.getDeclaredField("lastState");
        lastStateField.setAccessible(true);
        lastStateField.set(normalizer, existingState.clone());

        Field lastDerivativesField = StepNormalizer.class.getDeclaredField("lastDerivatives");
        lastDerivativesField.setAccessible(true);
        lastDerivativesField.set(normalizer, existingDerivatives.clone());

        normalizer.handleStep(interpolator, false);

        verify(handler, times(1)).handleStep(anyDouble(), any(double[].class), any(double[].class), anyBoolean());
    }

    @Test
    @DisplayName("Handle step when lastState is null, mode is MULTIPLES, Precision.equals returns true")
    public void TC05_handleStep_initial_MULTIPLES_Precision_true_final_step() throws Exception {
        StepInterpolator interpolator = Mockito.mock(StepInterpolator.class);
        when(interpolator.getPreviousTime()).thenReturn(0.0, 1.0);
        when(interpolator.getCurrentTime()).thenReturn(1.0);
        double[] initialState = new double[]{1.0, 2.0};
        double[] initialDerivatives = new double[]{0.1, 0.2};
        when(interpolator.getInterpolatedState()).thenReturn(initialState);
        when(interpolator.getInterpolatedDerivatives()).thenReturn(initialDerivatives);

        FixedStepHandler handler = Mockito.mock(FixedStepHandler.class);
        StepNormalizer normalizer = new StepNormalizer(0.1, handler, StepNormalizerMode.MULTIPLES, StepNormalizerBounds.FIRST);

        normalizer.handleStep(interpolator, true);

        verify(handler, atLeastOnce()).handleStep(anyDouble(), any(double[].class), any(double[].class), anyBoolean());
    }
}