import org.apache.commons.math3.optim.PointValuePair;
import org.apache.commons.math3.analysis.MultivariateFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.util.Comparator;

import static org.junit.jupiter.api.Assertions.*;

class NelderMeadSimplexTest {

    private NelderMeadSimplex simplex;
    private MultivariateFunction function;
    private Comparator<PointValuePair> comparator;

    @BeforeEach
    void setUp() {
        function = point -> {
            double sum = 0;
            for (double x : point) {
                sum += x * x;
            }
            return sum;
        };

        comparator = Comparator.comparingDouble(PointValuePair::getValue);
    }

    @Test
    void testReflectionAccepted() {
        simplex = new NelderMeadSimplex(new double[][]{
                {0.0, 0.0}, {1.0, 1.0}, {0.5, 0.5}
        });
        simplex.evaluate(function, comparator);
        assertDoesNotThrow(() -> simplex.iterate(function, comparator));
    }

    @Test
    void testExpansionAccepted() {
        simplex = new NelderMeadSimplex(new double[][]{
                {5.0, 5.0}, {4.0, 4.0}, {3.0, 3.0}
        });
        simplex.evaluate(function, comparator);
        assertDoesNotThrow(() -> simplex.iterate(function, comparator));
    }

    @Test
    void testOutsideContractionAccepted() {
        simplex = new NelderMeadSimplex(new double[][]{
                {1.0, 0.0}, {0.0, 1.0}, {100.0, 100.0}
        });
        simplex.evaluate(function, comparator);
        assertDoesNotThrow(() -> simplex.iterate(function, comparator));
    }

    @Test
    void testInsideContractionAccepted() {
        simplex = new NelderMeadSimplex(new double[][]{
                {1.0, 0.0}, {0.0, 1.0}, {1.0, 1.0}
        });
        simplex.evaluate(function, comparator);
        assertDoesNotThrow(() -> simplex.iterate(function, comparator));
    }

    @Test
    void testShrink() {
        simplex = new NelderMeadSimplex(new double[][]{
                {1.0, 1.0}, {2.0, 2.0}, {3.0, 3.0}
        });
        simplex.evaluate(function, comparator);
        assertDoesNotThrow(() -> simplex.iterate(function, comparator));
    }

    @Test
    void testNullFunction() {
        simplex = new NelderMeadSimplex(new double[][]{
                {1.0, 1.0}, {2.0, 2.0}, {3.0, 3.0}
        });
        assertThrows(NullPointerException.class, () -> simplex.iterate(null, comparator));
    }

    @Test
    void testNullComparator() {
        simplex = new NelderMeadSimplex(new double[][]{
                {1.0, 1.0}, {2.0, 2.0}, {3.0, 3.0}
        });
        assertThrows(NullPointerException.class, () -> simplex.iterate(function, null));
    }

    @Test
    void testInvalidReferenceSimplex() {
        assertThrows(NotStrictlyPositiveException.class, () -> 
            new NelderMeadSimplex(new double[][]{})
        );
    }

    @Test
    void testDimensionMismatchException() {
        double[][] badSimplex = {{1.0, 2.0}, {3.0, 4.0, 5.0}};
        assertThrows(DimensionMismatchException.class, () -> 
            new NelderMeadSimplex(badSimplex)
        );
    }
}