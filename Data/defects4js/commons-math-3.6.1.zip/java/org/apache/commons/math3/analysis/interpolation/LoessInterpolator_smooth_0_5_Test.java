package org.apache.commons.math3.analysis.interpolation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoessInterpolator_smooth_0_5_Test {

    @Test
    @DisplayName("Throws IllegalArgumentException when all bandwidth weights become zero during iterations.")
    void TC21_testThrowsIllegalArgumentExceptionWhenBandwidthWeightsZero() {
        // GIVEN
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {2.0, 2.0, 2.0};
        double[] weights = {1.0, 1.0, 1.0};
        double bandwidth = 0.8;
        int robustnessIters = 2;
        LoessInterpolator interpolator = new LoessInterpolator(bandwidth, robustnessIters);
        
        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> {
            interpolator.smooth(xval, yval, weights);
        });
    }

    @Test
    @DisplayName("Handles scenario where median residual is zero, terminating iterations early.")
    void TC22_testMedianResidualZeroTerminatesIterationsEarly() {
        // GIVEN
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {2.0, 2.0, 2.0};
        double[] weights = {1.0, 1.0, 1.0};
        double bandwidth = 0.8;
        int robustnessIters = 3;
        LoessInterpolator interpolator = new LoessInterpolator(bandwidth, robustnessIters);
        
        // WHEN
        double[] result = interpolator.smooth(xval, yval, weights);
        
        // THEN
        assertNotNull(result, "Resulting array should not be null.");
        assertEquals(3, result.length, "Resulting array should have length 3.");
        // Additional assertions to verify early termination can be added here if accessible.
    }

    @Test
    @DisplayName("Returns correctly smoothed array when all robustness weights remain unchanged after iterations.")
    void TC23_testRobustnessWeightsUnchangedAfterIterations() {
        // GIVEN
        double[] xval = {1.0, 2.0, 3.0, 4.0};
        double[] yval = {2.0, 2.0, 2.0, 2.0};
        double[] weights = {1.0, 1.0, 1.0, 1.0};
        double bandwidth = 0.8;
        int robustnessIters = 2;
        LoessInterpolator interpolator = new LoessInterpolator(bandwidth, robustnessIters);
        
        // WHEN
        double[] result = interpolator.smooth(xval, yval, weights);
        
        // THEN
        assertNotNull(result, "Resulting array should not be null.");
        assertEquals(4, result.length, "Resulting array should have length 4.");
        // Additional assertions to verify robustnessWeights remain as 1 can be added here if accessible.
    }

    @Test
    @DisplayName("Handles extreme values in xval without affecting smoothing accuracy.")
    void TC24_testHandlesExtremeXvalValues() {
        // GIVEN
        double[] xval = {1e-10, 1e10, 1e20, 1e30};
        double[] yval = {2.0, 3.0, 4.0, 5.0};
        double[] weights = {1.0, 1.0, 1.0, 1.0};
        double bandwidth = 1.0;
        int robustnessIters = 2;
        LoessInterpolator interpolator = new LoessInterpolator(bandwidth, robustnessIters);
        
        // WHEN
        double[] result = interpolator.smooth(xval, yval, weights);
        
        // THEN
        assertNotNull(result, "Resulting array should not be null.");
        assertEquals(4, result.length, "Resulting array should have length 4.");
        // Additional assertions to verify handling of extreme xval values can be added here.
    }

    @Test
    @DisplayName("Successfully handles varying weights, emphasizing certain data points in smoothing.")
    void TC25_testHandlesVaryingWeightsEmphasizingDataPoints() {
        // GIVEN
        double[] xval = {1.0, 2.0, 3.0, 4.0, 5.0};
        double[] yval = {2.0, 4.0, 6.0, 8.0, 10.0};
        double[] weights = {1.0, 10.0, 1.0, 10.0, 1.0};
        double bandwidth = 0.8;
        int robustnessIters = 2;
        LoessInterpolator interpolator = new LoessInterpolator(bandwidth, robustnessIters);
        
        // WHEN
        double[] result = interpolator.smooth(xval, yval, weights);
        
        // THEN
        assertNotNull(result, "Resulting array should not be null.");
        assertEquals(5, result.length, "Resulting array should have length 5.");
        // Additional assertions to verify emphasis based on weights can be added here.
    }
}