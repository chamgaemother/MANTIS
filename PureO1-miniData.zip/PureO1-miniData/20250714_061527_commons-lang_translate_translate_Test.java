package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

class NumericEntityUnescaperTest {

    @Test
    void translate_NullInput_ThrowsNullPointerException() {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        Writer writer = new StringWriter();
        assertThrows(NullPointerException.class, () -> unescaper.translate(null, 0, writer));
    }

    @Test
    void translate_NullWriter_ThrowsNullPointerException() {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "&#65;";
        assertThrows(NullPointerException.class, () -> unescaper.translate(input, 0, null));
    }

    @Test
    void translate_IndexNegative_ReturnsZero() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "Test";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, -1, writer);
        assertEquals(0, result);
        assertEquals("", writer.toString());
    }

    @Test
    void translate_IndexOutOfBounds_ReturnsZero() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "Test";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 10, writer);
        assertEquals(0, result);
        assertEquals("", writer.toString());
    }

    @Test
    void translate_DoesNotStartWithNumericEntity_ReturnsZero() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "&amp;#65;";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(0, result);
        assertEquals("", writer.toString());
    }

    @Test
    void translate_ValidDecimalWithSemicolon_WritesCharacter() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "&#65;";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(5, result);
        assertEquals("A", writer.toString());
    }

    @Test
    void translate_ValidHexWithSemicolon_WritesCharacter() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "&#x41;";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(6, result);
        assertEquals("A", writer.toString());
    }

    @Test
    void translate_ValidHexUpperCaseWithSemicolon_WritesCharacter() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "&#X41;";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(6, result);
        assertEquals("A", writer.toString());
    }

    @Test
    void translate_ValidDecimalWithoutSemicolon_SemiColonRequired_ReturnsZero() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "&#65";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(0, result);
        assertEquals("", writer.toString());
    }

    @Test
    void translate_ValidDecimalWithoutSemicolon_SemiColonOptional_WritesCharacter() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        CharSequence input = "&#65";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(4, result);
        assertEquals("A", writer.toString());
    }

    @Test
    void translate_ValidDecimalWithoutSemicolon_ErrorIfNoSemiColon_ThrowsException() {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        CharSequence input = "&#65";
        Writer writer = new StringWriter();
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            unescaper.translate(input, 0, writer);
        });
        assertEquals("Semi-colon required at end of numeric entity", exception.getMessage());
    }

    @Test
    void translate_ValidHexWithoutSemicolon_SemiColonRequired_ReturnsZero() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "&#x41";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(0, result);
        assertEquals("", writer.toString());
    }

    @Test
    void translate_ValidHexWithoutSemicolon_SemiColonOptional_WritesCharacter() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        CharSequence input = "&#x41";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(5, result);
        assertEquals("A", writer.toString());
    }

    @Test
    void translate_ValidHexWithoutSemicolon_ErrorIfNoSemiColon_ThrowsException() {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        CharSequence input = "&#x41";
        Writer writer = new StringWriter();
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            unescaper.translate(input, 0, writer);
        });
        assertEquals("Semi-colon required at end of numeric entity", exception.getMessage());
    }

    @Test
    void translate_InvalidDecimal_ReturnsZero() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "&#abc;";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(0, result);
        assertEquals("", writer.toString());
    }

    @Test
    void translate_InvalidHex_ReturnsZero() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "&#xZZ;";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(0, result);
        assertEquals("", writer.toString());
    }

    @Test
    void translate_EntityValueAboveFFFF_WritesSurrogatePair() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "&#128512;";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(9, result);
        assertEquals("\uD83D\uDE00", writer.toString());
    }

    @Test
    void translate_EntityValueAtFFFF_WritesSingleCharacter() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "&#65535;";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(7, result);
        assertEquals("\uFFFF", writer.toString());
    }

    @Test
    void translate_NoHexIndicator_WithSemicolon_WritesCharacter() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "&#66;";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(4, result);
        assertEquals("B", writer.toString());
    }

    @Test
    void translate_NoHexIndicator_WithoutSemicolon_SemiColonRequired_ReturnsZero() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "&#66";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(0, result);
        assertEquals("", writer.toString());
    }

    @Test
    void translate_NoHexIndicator_WithoutSemicolon_SemiColonOptional_WritesCharacter() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        CharSequence input = "&#66";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(3, result);
        assertEquals("B", writer.toString());
    }

    @Test
    void translate_TextWithMultipleEntities_WritesFirstEntity() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "Hello &#87;orld";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 6, writer);
        assertEquals(4, result);
        assertEquals("W", writer.toString());
    }

    @Test
    void translate_MultipleEntitiesSequentially_WritesEachEntity() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "&#72;&#101;&#108;&#108;&#111;";
        Writer writer = new StringWriter();
        int index = 0;
        StringBuilder expected = new StringBuilder();
        while (index < input.length()) {
            int translated = unescaper.translate(input, index, writer);
            if (translated > 0) {
                expected.append(writer.toString());
                writer.getBuffer().setLength(0);
                index += translated;
            } else {
                index++;
            }
        }
        assertEquals("Hello", expected.toString());
    }

    @Test
    void translate_EmptyInput_ReturnsZero() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(0, result);
        assertEquals("", writer.toString());
    }

    @Test
    void translate_OnlyAmpersand_ReturnsZero() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "&";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(0, result);
        assertEquals("", writer.toString());
    }

    @Test
    void translate_AmpersandHashOnly_ReturnsZero() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "&#";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(0, result);
        assertEquals("", writer.toString());
    }

    @Test
    void translate_HashWithoutAmpersand_ReturnsZero() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        CharSequence input = "#65;";
        Writer writer = new StringWriter();
        int result = unescaper.translate(input, 0, writer);
        assertEquals(0, result);
        assertEquals("", writer.toString());
    }
}