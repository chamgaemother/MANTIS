package org.jfree.chart.renderer.category;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.WaterfallBarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mockito;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class WaterfallBarRenderer_drawItem_0_1_Test {

    private Graphics2D g2;
    private CategoryItemRendererState state;
    private Rectangle2D dataArea;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private CategoryDataset dataset;
    private WaterfallBarRenderer renderer;

    @BeforeEach
    public void setUp() {
        g2 = mock(Graphics2D.class);
        state = mock(CategoryItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        plot = mock(CategoryPlot.class);
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(CategoryDataset.class);
        renderer = new WaterfallBarRenderer();
    }

    @Test
    @DisplayName("drawItem with column not the last column and dataset value is non-null positive")
    public void TC01_drawItem_positiveValue_nonLastColumn() throws Exception {
        // GIVEN
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Setting necessary paints via reflection
        java.lang.reflect.Field positiveBarPaintField = WaterfallBarRenderer.class.getDeclaredField("positiveBarPaint");
        positiveBarPaintField.setAccessible(true);
        positiveBarPaintField.set(renderer, Color.GREEN);

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);

        // THEN
        verify(g2).fill(any(Rectangle2D.class));
        verify(state).setSeriesRunningTotal(5.0);
    }

    @Test
    @DisplayName("drawItem with column as the last column, ensuring previous is reset to 0.0")
    public void TC02_drawItem_lastColumn_negativeValue() throws Exception {
        // GIVEN
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(2, 2)).thenReturn(-3.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Setting necessary paints via reflection
        java.lang.reflect.Field lastBarPaintField = WaterfallBarRenderer.class.getDeclaredField("lastBarPaint");
        lastBarPaintField.setAccessible(true);
        lastBarPaintField.set(renderer, Color.RED);

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 2, 2, 0);

        // THEN
        verify(g2).fill(any(Rectangle2D.class));
        verify(state).setSeriesRunningTotal(-3.0);
    }

    @Test
    @DisplayName("drawItem with dataset value as null, ensuring current remains previous")
    public void TC03_drawItem_nullValue_nonLastColumn() throws Exception {
        // GIVEN
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(null);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Setting necessary paints via reflection
        java.lang.reflect.Field positiveBarPaintField = WaterfallBarRenderer.class.getDeclaredField("positiveBarPaint");
        positiveBarPaintField.setAccessible(true);
        positiveBarPaintField.set(renderer, Color.GREEN);

        // Assuming default return value before being set
        when(state.getSeriesRunningTotal()).thenReturn(0.0);

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);

        // THEN
        verify(g2).fill(any(Rectangle2D.class));
        verify(state).setSeriesRunningTotal(0.0);
    }

    @Test
    @DisplayName("drawItem with horizontal orientation and positive value")
    public void TC04_drawItem_horizontalOrientation_positiveValue() throws Exception {
        // GIVEN
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(4.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);

        // Setting necessary paints via reflection
        java.lang.reflect.Field positiveBarPaintField = WaterfallBarRenderer.class.getDeclaredField("positiveBarPaint");
        positiveBarPaintField.setAccessible(true);
        positiveBarPaintField.set(renderer, Color.GREEN);

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);

        // THEN
        verify(g2).fill(any(Rectangle2D.class));
        verify(state).setSeriesRunningTotal(4.0);
    }

    @Test
    @DisplayName("drawItem with gradient paint transformer applied")
    public void TC05_drawItem_withGradientPaintTransformer() throws Exception {
        // GIVEN
        org.jfree.chart.ui.GradientPaintTransformer transformer = mock(org.jfree.chart.ui.GradientPaintTransformer.class);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Setting GradientPaintTransformer via reflection
        java.lang.reflect.Method setTransformerMethod = WaterfallBarRenderer.class.getMethod("setGradientPaintTransformer", org.jfree.chart.ui.GradientPaintTransformer.class);
        setTransformerMethod.invoke(renderer, transformer);

        // Setting positiveBarPaint via reflection
        GradientPaint gp = new GradientPaint(0, 0, Color.RED, 1, 1, Color.BLUE);
        java.lang.reflect.Field positiveBarPaintField = WaterfallBarRenderer.class.getDeclaredField("positiveBarPaint");
        positiveBarPaintField.setAccessible(true);
        positiveBarPaintField.set(renderer, gp);

        when(transformer.transform(any(GradientPaint.class), any(Rectangle2D.class))).thenReturn(gp);

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);

        // THEN
        verify(transformer).transform(gp, any(Rectangle2D.class));
        verify(g2).setPaint(gp);
        verify(g2).fill(any(Rectangle2D.class));
    }
}
