package com.fasterxml.jackson.core.io;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class UTF8WriterTest {

    private IOContext ioContext;
    private ByteArrayOutputStream outputStream;
    private UTF8Writer utf8Writer;

    @BeforeEach
    void setUp() {
        ioContext = new IOContext(null, null, null, 0, null, null);
        outputStream = new ByteArrayOutputStream();
        utf8Writer = new UTF8Writer(ioContext, outputStream);
    }

    @Test
    void write_NullCharArray_ShouldThrowNullPointerException() {
        assertThrows(NullPointerException.class, () -> {
            utf8Writer.write(null, 0, 10);
        });
    }

    @Test
    void write_InvalidOffset_ShouldThrowIndexOutOfBoundsException() {
        char[] cbuf = {'a', 'b', 'c'};
        assertThrows(IndexOutOfBoundsException.class, () -> {
            utf8Writer.write(cbuf, -1, 2);
        });
    }

    @Test
    void write_InvalidLength_ShouldThrowIndexOutOfBoundsException() {
        char[] cbuf = {'a', 'b', 'c'};
        assertThrows(IndexOutOfBoundsException.class, () -> {
            utf8Writer.write(cbuf, 1, 5);
        });
    }

    @Test
    void write_LengthZero_ShouldNotWriteAnything() throws IOException {
        char[] cbuf = {'a', 'b', 'c'};
        utf8Writer.write(cbuf, 1, 0);
        utf8Writer.flush();
        assertEquals(0, outputStream.size());
    }

    @Test
    void write_LengthOne_AsciiCharacter_ShouldWriteSingleByte() throws IOException {
        char[] cbuf = {'a'};
        utf8Writer.write(cbuf, 0, 1);
        utf8Writer.flush();
        assertArrayEquals(new byte[]{'a'}, outputStream.toByteArray());
    }

    @Test
    void write_LengthOne_NonAsciiCharacter_ShouldWriteTwoBytes() throws IOException {
        char[] cbuf = {'é'};
        utf8Writer.write(cbuf, 0, 1);
        utf8Writer.flush();
        assertArrayEquals(new byte[]{(byte) 0xC3, (byte) 0xA9}, outputStream.toByteArray());
    }

    @Test
    void write_ValidAsciiSequence_ShouldWriteCorrectBytes() throws IOException {
        char[] cbuf = "Hello, World!".toCharArray();
        utf8Writer.write(cbuf, 0, cbuf.length);
        utf8Writer.flush();
        assertArrayEquals("Hello, World!".getBytes("UTF-8"), outputStream.toByteArray());
    }

    @Test
    void write_ValidNonAsciiSequence_ShouldWriteCorrectBytes() throws IOException {
        char[] cbuf = "Café Münster 🎉".toCharArray();
        utf8Writer.write(cbuf, 0, cbuf.length);
        utf8Writer.flush();
        assertArrayEquals("Café Münster 🎉".getBytes("UTF-8"), outputStream.toByteArray());
    }

    @Test
    void write_SurrogatePair_ShouldWriteFourBytes() throws IOException {
        char[] cbuf = {'\uD83D', '\uDE00'}; // 😀
        utf8Writer.write(cbuf, 0, cbuf.length);
        utf8Writer.flush();
        assertArrayEquals(new byte[]{(byte) 0xF0, (byte) 0x9F, (byte) 0x98, (byte) 0x80}, outputStream.toByteArray());
    }

    @Test
    void write_UnmatchedHighSurrogate_ShouldThrowIOExceptionOnClose() throws IOException {
        char[] cbuf = {'\uD83D'};
        utf8Writer.write(cbuf, 0, cbuf.length);
        assertThrows(IOException.class, () -> {
            utf8Writer.close();
        });
    }

    @Test
    void write_UnmatchedLowSurrogate_ShouldThrowIOException() throws IOException {
        char[] cbuf = {'\uDE00'};
        IOException exception = assertThrows(IOException.class, () -> {
            utf8Writer.write(cbuf, 0, cbuf.length);
        });
        assertTrue(exception.getMessage().contains("Unmatched second part of surrogate pair"));
    }

    @Test
    void write_SurrogateFollowedByNonLowSurrogate_ShouldThrowIOException() throws IOException {
        char[] cbuf = {'\uD83D', 'A'};
        IOException exception = assertThrows(IOException.class, () -> {
            utf8Writer.write(cbuf, 0, cbuf.length);
        });
        assertTrue(exception.getMessage().contains("Broken surrogate pair"));
    }

    @Test
    void write_InvalidCodePointAboveMax_ShouldThrowIOException() throws IOException {
        char[] cbuf = {'\uDBFF', '\uDFFF', 'A'}; // Valid surrogate pair followed by 'A'
        utf8Writer.write(cbuf, 0, cbuf.length);
        utf8Writer.write(0x110000); // Invalid code point
        IOException exception = assertThrows(IOException.class, () -> {
            utf8Writer.flush();
        });
        assertTrue(exception.getMessage().contains("Illegal character point"));
    }

    @Test
    void write_BufferBoundary_ShouldFlushAutomatically() throws IOException {
        // Assuming buffer size is small for test purposes
        IOContext smallContext = new IOContext(null, null, null, 10, null, null);
        ByteArrayOutputStream smallOutput = new ByteArrayOutputStream();
        UTF8Writer smallWriter = new UTF8Writer(smallContext, smallOutput);
        char[] cbuf = "This is a long string to exceed buffer size.".toCharArray();
        smallWriter.write(cbuf, 0, cbuf.length);
        smallWriter.flush();
        assertEquals("This is a long string to exceed buffer size.", new String(smallOutput.toByteArray(), "UTF-8"));
    }

    @Test
    void write_EmptyCharArray_ShouldNotWriteAnything() throws IOException {
        char[] cbuf = {};
        utf8Writer.write(cbuf, 0, 0);
        utf8Writer.flush();
        assertEquals(0, outputStream.size());
    }

    @Test
    void write_SurrogateAtEnd_ShouldStoreSurrogate() throws IOException {
        char[] cbuf = {'A', '\uD83D'};
        utf8Writer.write(cbuf, 0, cbuf.length);
        // No exception yet
        utf8Writer.flush();
        // On close, should throw exception due to unmatched surrogate
        assertThrows(IOException.class, () -> {
            utf8Writer.close();
        });
    }

    @Test
    void write_MultipleSurrogatePairs_ShouldWriteCorrectBytes() throws IOException {
        char[] cbuf = {'\uD83D', '\uDE00', '\uD83D', '\uDC4B'}; // 😀👋
        utf8Writer.write(cbuf, 0, cbuf.length);
        utf8Writer.flush();
        assertArrayEquals(new byte[]{
                (byte) 0xF0, (byte) 0x9F, (byte) 0x98, (byte) 0x80,
                (byte) 0xF0, (byte) 0x9F, (byte) 0x91, (byte) 0x8B
        }, outputStream.toByteArray());
    }
}