import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.statistics.DefaultBoxAndWhiskerXYDataset;
import org.jfree.data.time.Millisecond;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;
import java.util.Date;

import static org.mockito.Mockito.*;

class XYBoxAndWhiskerRendererTest {

    private XYBoxAndWhiskerRenderer renderer;
    private Graphics2D graphics2D;
    private Rectangle2D dataArea;
    private PlotRenderingInfo plotRenderingInfo;
    private XYPlot plot;
    private NumberAxis domainAxis;
    private NumberAxis rangeAxis;
    private XYDataset dataset;
    private CrosshairState crosshairState;

    @BeforeEach
    void setUp() {
        renderer = new XYBoxAndWhiskerRenderer();
        graphics2D = mock(Graphics2D.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        plotRenderingInfo = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = new NumberAxis();
        rangeAxis = new NumberAxis();
        dataset = createSampleDataset();
        crosshairState = mock(CrosshairState.class);
    }

    private XYDataset createSampleDataset() {
        DefaultBoxAndWhiskerXYDataset data = new DefaultBoxAndWhiskerXYDataset("Series1");
        Date date = new Date();
        data.add(new Millisecond(date), 1.0, 5.0, 4.0, 2.0, 2.5, 3.5,
                Arrays.asList(1.1, 1.2, 1.3), Arrays.asList(4.5));
        return data;
    }

    @Test
    void testDrawHorizontalItemWithNormalConditions() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);

        renderer.drawHorizontalItem(graphics2D, dataArea, plotRenderingInfo, plot, domainAxis, 
                                    rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(graphics2D, atLeastOnce()).draw(any(Shape.class));
    }

    @Test
    void testDrawHorizontalItemWithVerticalOrientation() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        renderer.drawHorizontalItem(graphics2D, dataArea, plotRenderingInfo, plot, domainAxis, 
                                    rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(graphics2D, never()).draw(any(Line2D.class));
    }

    @Test
    void testDrawHorizontalItemWithNullEntities() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(plotRenderingInfo.getOwner()).thenReturn(null);

        renderer.drawHorizontalItem(graphics2D, dataArea, null, plot, domainAxis, 
                                    rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(graphics2D, atLeastOnce()).draw(any(Line2D.class));
    }

    @Test
    void testDrawHorizontalItemWithNullDataset() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);

        renderer.drawHorizontalItem(graphics2D, dataArea, plotRenderingInfo, plot, domainAxis,
                                    rangeAxis, null, 0, 0, crosshairState, 0);

        verify(graphics2D, never()).draw(any(Line2D.class));
    }
}