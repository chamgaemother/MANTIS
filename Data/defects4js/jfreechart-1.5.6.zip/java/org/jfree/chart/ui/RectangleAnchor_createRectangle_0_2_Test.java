package org.jfree.chart.ui;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.awt.geom.Rectangle2D;

import org.jfree.chart.ui.RectangleAnchor;
import org.jfree.chart.ui.Size2D;

public class RectangleAnchor_createRectangle_0_2_Test {

    @Test
    @DisplayName("createRectangle with RectangleAnchor.TOP_LEFT sets rectangle top-left aligned at (anchorX, anchorY)")
    public void TC06_createRectangle_TOP_LEFT() {
        // GIVEN
        Size2D dimensions = new Size2D(100.0, 200.0);
        double anchorX = 350.0;
        double anchorY = 450.0;
        RectangleAnchor anchor = RectangleAnchor.TOP_LEFT;

        // WHEN
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // THEN
        assertEquals(anchorX, result.getX(), 0.0001);
        assertEquals(anchorY, result.getY(), 0.0001);
        assertEquals(100.0, result.getWidth(), 0.0001);
        assertEquals(200.0, result.getHeight(), 0.0001);
    }

    @Test
    @DisplayName("createRectangle with RectangleAnchor.TOP_RIGHT sets rectangle top-right aligned at (anchorX, anchorY)")
    public void TC07_createRectangle_TOP_RIGHT() {
        // GIVEN
        Size2D dimensions = new Size2D(120.0, 220.0);
        double anchorX = 400.0;
        double anchorY = 500.0;
        RectangleAnchor anchor = RectangleAnchor.TOP_RIGHT;

        // WHEN
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // THEN
        assertEquals(anchorX - dimensions.getWidth(), result.getX(), 0.0001);
        assertEquals(anchorY, result.getY(), 0.0001);
        assertEquals(120.0, result.getWidth(), 0.0001);
        assertEquals(220.0, result.getHeight(), 0.0001);
    }

    @Test
    @DisplayName("createRectangle with RectangleAnchor.BOTTOM_LEFT sets rectangle bottom-left aligned at (anchorX, anchorY)")
    public void TC08_createRectangle_BOTTOM_LEFT() {
        // GIVEN
        Size2D dimensions = new Size2D(130.0, 230.0);
        double anchorX = 450.0;
        double anchorY = 550.0;
        RectangleAnchor anchor = RectangleAnchor.BOTTOM_LEFT;

        // WHEN
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // THEN
        assertEquals(anchorX, result.getX(), 0.0001);
        assertEquals(anchorY - dimensions.getHeight(), result.getY(), 0.0001);
        assertEquals(130.0, result.getWidth(), 0.0001);
        assertEquals(230.0, result.getHeight(), 0.0001);
    }

    @Test
    @DisplayName("createRectangle with RectangleAnchor.BOTTOM_RIGHT sets rectangle bottom-right aligned at (anchorX, anchorY)")
    public void TC09_createRectangle_BOTTOM_RIGHT() {
        // GIVEN
        Size2D dimensions = new Size2D(140.0, 240.0);
        double anchorX = 500.0;
        double anchorY = 600.0;
        RectangleAnchor anchor = RectangleAnchor.BOTTOM_RIGHT;

        // WHEN
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // THEN
        assertEquals(anchorX - dimensions.getWidth(), result.getX(), 0.0001);
        assertEquals(anchorY - dimensions.getHeight(), result.getY(), 0.0001);
        assertEquals(140.0, result.getWidth(), 0.0001);
        assertEquals(240.0, result.getHeight(), 0.0001);
    }

    @Test
    @DisplayName("createRectangle with null dimensions throws NullPointerException")
    public void TC10_createRectangle_nullDimensions() {
        // GIVEN
        Size2D dimensions = null;
        double anchorX = 100.0;
        double anchorY = 200.0;
        RectangleAnchor anchor = RectangleAnchor.CENTER;

        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> {
            RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);
        });
    }

}