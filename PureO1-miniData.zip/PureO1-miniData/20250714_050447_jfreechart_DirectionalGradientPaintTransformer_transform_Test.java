package org.jfree.chart.util;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Rectangle;
import java.awt.Shape;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class DirectionalGradientPaintTransformerTest {

    private DirectionalGradientPaintTransformer transformer;

    @BeforeEach
    public void setUp() {
        transformer = new DirectionalGradientPaintTransformer();
    }

    @Test
    public void testTransform_NullPaint_ShouldThrowNullPointerException() {
        Shape target = new Rectangle(0, 0, 100, 100);
        assertThrows(NullPointerException.class, () -> {
            transformer.transform(null, target);
        });
    }

    @Test
    public void testTransform_NullTarget_ShouldThrowNullPointerException() {
        GradientPaint paint = new GradientPaint(0, 0, Color.BLACK, 50, 50, Color.WHITE, false);
        assertThrows(NullPointerException.class, () -> {
            transformer.transform(paint, null);
        });
    }

    @Test
    public void testTransform_StartAtOrigin_Diagonal_Cyclic() {
        GradientPaint paint = new GradientPaint(0, 0, Color.BLACK, 50, 50, Color.WHITE, true);
        Shape target = new Rectangle(10, 20, 100, 100);
        GradientPaint result = transformer.transform(paint, target);
        
        assertEquals(10f, result.getPoint1().getX());
        assertEquals(20f, result.getPoint1().getY());
        assertEquals(10f + (100f + 100f) / 4.0f, result.getPoint2().getX(), 0.0001);
        assertEquals(20f + (100f + 100f) / 4.0f, result.getPoint2().getY(), 0.0001);
        assertEquals(Color.BLACK, result.getColor1());
        assertEquals(Color.WHITE, result.getColor2());
        assertTrue(result.isCyclic());
    }

    @Test
    public void testTransform_StartAtOrigin_Diagonal_NonCyclic() {
        GradientPaint paint = new GradientPaint(0, 0, Color.BLACK, 50, 50, Color.WHITE, false);
        Shape target = new Rectangle(5, 15, 80, 120);
        GradientPaint result = transformer.transform(paint, target);
        
        assertEquals(5f, result.getPoint1().getX());
        assertEquals(15f, result.getPoint1().getY());
        assertEquals(5f + (80f + 120f) / 2.0f, result.getPoint2().getX(), 0.0001);
        assertEquals(15f + (80f + 120f) / 2.0f, result.getPoint2().getY(), 0.0001);
        assertEquals(Color.BLACK, result.getColor1());
        assertEquals(Color.WHITE, result.getColor2());
        assertFalse(result.isCyclic());
    }

    @Test
    public void testTransform_StartAtOrigin_Vertical_Cyclic() {
        GradientPaint paint = new GradientPaint(0, 0, Color.RED, 0, 50, Color.BLUE, true);
        Shape target = new Rectangle(0, 0, 200, 300);
        GradientPaint result = transformer.transform(paint, target);
        
        assertEquals(0f, result.getPoint1().getX());
        assertEquals(0f, result.getPoint1().getY());
        assertEquals(0f, result.getPoint2().getX());
        assertEquals(0f + (300f) / 4.0f, result.getPoint2().getY(), 0.0001);
        assertEquals(Color.RED, result.getColor1());
        assertEquals(Color.BLUE, result.getColor2());
        assertTrue(result.isCyclic());
    }

    @Test
    public void testTransform_StartAtOrigin_Vertical_NonCyclic() {
        GradientPaint paint = new GradientPaint(0, 0, Color.RED, 0, 50, Color.BLUE, false);
        Shape target = new Rectangle(10, 10, 100, 200);
        GradientPaint result = transformer.transform(paint, target);
        
        assertEquals(10f, result.getPoint1().getX());
        assertEquals(10f, result.getPoint1().getY());
        assertEquals(10f, result.getPoint2().getX());
        assertEquals(10f + 200f, result.getPoint2().getY(), 0.0001);
        assertEquals(Color.RED, result.getColor1());
        assertEquals(Color.BLUE, result.getColor2());
        assertFalse(result.isCyclic());
    }

    @Test
    public void testTransform_StartAtOrigin_Horizontal_Cyclic() {
        GradientPaint paint = new GradientPaint(0, 0, Color.GREEN, 50, 0, Color.YELLOW, true);
        Shape target = new Rectangle(20, 30, 150, 150);
        GradientPaint result = transformer.transform(paint, target);
        
        assertEquals(20f, result.getPoint1().getX());
        assertEquals(30f, result.getPoint1().getY());
        assertEquals(20f + 150f / 2.0f, result.getPoint2().getX(), 0.0001);
        assertEquals(30f, result.getPoint2().getY(), 0.0001);
        assertEquals(Color.GREEN, result.getColor1());
        assertEquals(Color.YELLOW, result.getColor2());
        assertTrue(result.isCyclic());
    }

    @Test
    public void testTransform_StartAtOrigin_Horizontal_NonCyclic() {
        GradientPaint paint = new GradientPaint(0, 0, Color.GREEN, 50, 0, Color.YELLOW, false);
        Shape target = new Rectangle(25, 25, 200, 100);
        GradientPaint result = transformer.transform(paint, target);
        
        assertEquals(25f, result.getPoint1().getX());
        assertEquals(25f, result.getPoint1().getY());
        assertEquals(25f + 200f, result.getPoint2().getX(), 0.0001);
        assertEquals(25f, result.getPoint2().getY(), 0.0001);
        assertEquals(Color.GREEN, result.getColor1());
        assertEquals(Color.YELLOW, result.getColor2());
        assertFalse(result.isCyclic());
    }

    @Test
    public void testTransform_StartNotAtOrigin_Cyclic() {
        GradientPaint paint = new GradientPaint(10, 10, Color.PINK, 20, 30, Color.ORANGE, true);
        Shape target = new Rectangle(0, 0, 100, 100);
        GradientPaint result = transformer.transform(paint, target);
        
        float offset = (100f + 100f) / 4.0f;
        assertEquals(0f, result.getPoint1().getX());
        assertEquals(100f, result.getPoint1().getY());
        assertEquals(0f + offset, result.getPoint2().getX(), 0.0001);
        assertEquals(100f - offset, result.getPoint2().getY(), 0.0001);
        assertEquals(Color.PINK, result.getColor1());
        assertEquals(Color.ORANGE, result.getColor2());
        assertTrue(result.isCyclic());
    }

    @Test
    public void testTransform_StartNotAtOrigin_NonCyclic() {
        GradientPaint paint = new GradientPaint(5, 5, Color.MAGENTA, 15, 25, Color.CYAN, false);
        Shape target = new Rectangle(10, 10, 80, 120);
        GradientPaint result = transformer.transform(paint, target);
        
        float offset = (80f + 120f) / 2.0f;
        assertEquals(10f, result.getPoint1().getX());
        assertEquals(10f + 120f, result.getPoint1().getY());
        assertEquals(10f + offset, result.getPoint2().getX(), 0.0001);
        assertEquals(10f + 120f - offset, result.getPoint2().getY(), 0.0001);
        assertEquals(Color.MAGENTA, result.getColor1());
        assertEquals(Color.CYAN, result.getColor2());
        assertFalse(result.isCyclic());
    }

    @Test
    public void testTransform_StartAtOrigin_SamePoint() {
        GradientPaint paint = new GradientPaint(0, 0, Color.BLACK, 0, 0, Color.WHITE, false);
        Shape target = new Rectangle(0, 0, 50, 50);
        GradientPaint result = transformer.transform(paint, target);
        
        assertEquals(0f, result.getPoint1().getX());
        assertEquals(0f, result.getPoint1().getY());
        assertEquals(0f, result.getPoint2().getX(), 0.0001);
        assertEquals(0f, result.getPoint2().getY(), 0.0001);
        assertEquals(Color.BLACK, result.getColor1());
        assertEquals(Color.WHITE, result.getColor2());
        assertFalse(result.isCyclic());
    }
}