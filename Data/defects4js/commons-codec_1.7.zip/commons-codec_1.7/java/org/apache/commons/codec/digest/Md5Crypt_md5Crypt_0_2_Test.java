package org.apache.commons.codec.digest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class Md5Crypt_md5Crypt_0_2_Test {

    @Test
    @DisplayName("md5Crypt with keyBytes length less than 16 processes loop correctly")
    public void TC06_md5Crypt_keyBytes_length_less_than_16() {
        // GIVEN
        byte[] keyBytes = "shortkey".getBytes(java.nio.charset.StandardCharsets.UTF_8);
        String salt = "$1$salt1234";
        String prefix = "$1$";

        // WHEN
        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);

        // THEN
        String expectedHash = "$1$salt1234$eXampleHashValue1";
        assertEquals(expectedHash, hash, "Hash should be generated correctly when keyBytes length <= 16");
    }

    @Test
    @DisplayName("md5Crypt with keyBytes length greater than 16 processes loop correctly")
    public void TC07_md5Crypt_keyBytes_length_greater_than_16() {
        // GIVEN
        byte[] keyBytes = "thisisaverylongpassword".getBytes(java.nio.charset.StandardCharsets.UTF_8);
        String salt = "$1$longsalt";
        String prefix = "$1$";

        // WHEN
        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);

        // THEN
        String expectedHash = "$1$longsalt$ExampleHashValue2";
        assertEquals(expectedHash, hash, "Hash should be generated correctly when keyBytes length > 16");
    }

    @Test
    @DisplayName("md5Crypt loop exits immediately when keyBytes length is zero")
    public void TC08_md5Crypt_keyBytes_length_zero() {
        // GIVEN
        byte[] keyBytes = new byte[0];
        String salt = "$1$salt1234";
        String prefix = "$1$";

        // WHEN
        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);

        // THEN
        String expectedHash = "$1$salt1234$EmptyHashValue";
        assertEquals(expectedHash, hash, "Hash should be generated correctly when keyBytes length is zero");
    }

    @Test
    @DisplayName("md5Crypt loop executes one iteration when keyBytes length is 16")
    public void TC09_md5Crypt_keyBytes_length_exactly_16() {
        // GIVEN
        byte[] keyBytes = new byte[16]; // exactly 16 bytes
        for (int i = 0; i < 16; i++) {
            keyBytes[i] = (byte) i;
        }
        String salt = "$1$salt1234";
        String prefix = "$1$";

        // WHEN
        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);

        // THEN
        String expectedHash = "$1$salt1234$Exact16BytesHash";
        assertEquals(expectedHash, hash, "Hash should be generated correctly when keyBytes length is exactly 16");
    }

    @Test
    @DisplayName("md5Crypt loop executes multiple iterations when keyBytes length > 16")
    public void TC10_md5Crypt_keyBytes_length_multiple_iterations() {
        // GIVEN
        byte[] keyBytes = new byte[32]; // greater than 16 bytes
        for (int i = 0; i < 32; i++) {
            keyBytes[i] = (byte) (i + 1);
        }
        String salt = "$1$longsalt";
        String prefix = "$1$";

        // WHEN
        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);

        // THEN
        String expectedHash = "$1$longsalt$MultipleIterationsHash";
        assertEquals(expectedHash, hash, "Hash should be generated correctly when keyBytes length > 16 with multiple iterations");
    }
}
