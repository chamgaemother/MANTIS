package org.jfree.chart.renderer.xy;

import org.jfree.data.general.DatasetUtils;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.ui.RectangleEdge;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class StackedXYBarRenderer_drawItem_0_3_Test {

    @Test
    @DisplayName("drawItem renders horizontal bar with positive value and axis not inverted")
    public void TC11() throws Exception {
        StackedXYBarRenderer renderer = new StackedXYBarRenderer();
        renderer.setRenderAsPercentages(false);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class, withSettings().extraInterfaces(TableXYDataset.class));
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 1;
        int item = 1;
        int pass = 1;

        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getYValue(series, item)).thenReturn(10.0);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.RIGHT);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);

        // Assert
        ArgumentCaptor<Rectangle2D> rectCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        verify(renderer.getBarPainter()).paintBar(eq(g2), eq(renderer), eq(series), eq(item), rectCaptor.capture(), eq(RectangleEdge.RIGHT));
        Rectangle2D bar = rectCaptor.getValue();
        assertNotNull(bar);
    }

    @Test
    @DisplayName("drawItem renders vertical bar with negative value and axis inverted")
    public void TC12() throws Exception {
        StackedXYBarRenderer renderer = new StackedXYBarRenderer();
        renderer.setRenderAsPercentages(false);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class, withSettings().extraInterfaces(TableXYDataset.class));
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 2;
        int item = 2;
        int pass = 1;

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getYValue(series, item)).thenReturn(-5.0);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);

        // Assert
        ArgumentCaptor<Rectangle2D> rectCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        verify(renderer.getBarPainter()).paintBar(eq(g2), eq(renderer), eq(series), eq(item), rectCaptor.capture(), eq(RectangleEdge.LEFT));
        Rectangle2D bar = rectCaptor.getValue();
        assertNotNull(bar);
    }

    @Test
    @DisplayName("drawItem paints shadows when pass is 0 and shadows are visible")
    public void TC13() throws Exception {
        StackedXYBarRenderer renderer = new StackedXYBarRenderer();

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class, withSettings().extraInterfaces(TableXYDataset.class));
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 0;
        int pass = 0;

        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getYValue(series, item)).thenReturn(15.0);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.RIGHT);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(renderer.getShadowsVisible()).thenReturn(true);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(renderer.getBarPainter(), times(1)).paintBarShadow(eq(g2), eq(renderer), eq(series), eq(item), any(Rectangle2D.class), eq(RectangleEdge.RIGHT), eq(false));
    }

    @Test
    @DisplayName("drawItem skips painting shadows when pass is 0 but shadows are not visible")
    public void TC14() throws Exception {
        StackedXYBarRenderer renderer = new StackedXYBarRenderer();

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class, withSettings().extraInterfaces(TableXYDataset.class));
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 0;
        int pass = 0;

        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getYValue(series, item)).thenReturn(15.0);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.RIGHT);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(renderer.getShadowsVisible()).thenReturn(false);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(renderer.getBarPainter(), never()).paintBarShadow(any(), any(), anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class), anyBoolean());
    }

//     @Test
//     @DisplayName("drawItem paints bar and adds entity when pass is 1 and entity collection is not null")
//     public void TC15() throws Exception {
//         StackedXYBarRenderer renderer = new StackedXYBarRenderer();
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class, withSettings().extraInterfaces(TableXYDataset.class));
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         EntityCollection entities = mock(EntityCollection.class);
// 
//         int series = 3;
//         int item = 3;
//         int pass = 1;
// 
//         when(renderer.getItemVisible(series, item)).thenReturn(true);
//         when(dataset.getYValue(series, item)).thenReturn(20.0);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.RIGHT);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(info.getOwner()).thenReturn(plot);
        // Corrected access to entity collection
//         when(plot.getEntityCollection()).thenReturn(entities);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);
// 
        // Assert
//         verify(renderer.getBarPainter(), times(1)).paintBar(eq(g2), eq(renderer), eq(series), eq(item), any(Rectangle2D.class), eq(RectangleEdge.RIGHT));
//         verify(renderer, times(1)).addEntity(eq(entities), any(Rectangle2D.class), eq(dataset), eq(series), eq(item), anyDouble(), anyDouble());
//     }
}