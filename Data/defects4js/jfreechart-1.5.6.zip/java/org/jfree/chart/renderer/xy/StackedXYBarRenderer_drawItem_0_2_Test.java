package org.jfree.chart.renderer.xy;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.TableXYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import static org.mockito.Mockito.*;

public class StackedXYBarRenderer_drawItem_0_2_Test {

    @Test
    @DisplayName("drawItem processes normally when renderAsPercentages is false")
    void TC06_drawItem_without_percentage_rendering() throws Exception {
        // Arrange
        StackedXYBarRenderer renderer = spy(new StackedXYBarRenderer());

        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset instanceof TableXYDataset).thenReturn(true); // mock specific condition

        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(10.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, 0, 0, crosshairState, 0);

        // Assert
        verify(dataset, times(1)).getYValue(0, 0);
        verify(renderer, times(0)).getBarPainter(); // Renderer cannot call its own method
    }

    @Test
    @DisplayName("drawItem processes with percentage rendering enabled")
    void TC07_drawItem_with_percentage_rendering() throws Exception {
        // Arrange
        StackedXYBarRenderer renderer = spy(new StackedXYBarRenderer());
        renderer.setRenderAsPercentages(true); // Use public method

        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset instanceof TableXYDataset).thenReturn(true); // mock specific condition

        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(20.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, 0, 0, crosshairState, 0);

        // Assert
        verify(dataset, times(1)).getYValue(0, 0);
    }

    @Test
    @DisplayName("drawItem handles zero iterations in series loop")
    void TC08_drawItem_zero_series_iterations() throws Exception {
        // Arrange
        StackedXYBarRenderer renderer = spy(new StackedXYBarRenderer());

        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset instanceof TableXYDataset).thenReturn(true); // mock specific condition

        when(dataset.getItemCount(0)).thenReturn(0); // Assume zero items

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, 0, 0, crosshairState, 0);

        // Assert
        verify(dataset, times(1)).getYValue(0, 0);
    }

    @Test
    @DisplayName("drawItem handles one iteration in series loop")
    void TC09_drawItem_one_series_iteration() throws Exception {
        // Arrange
        StackedXYBarRenderer renderer = spy(new StackedXYBarRenderer());

        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset instanceof TableXYDataset).thenReturn(true); // mock specific condition

        when(dataset.getYValue(0, 0)).thenReturn(15.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, 0, 0, crosshairState, 0);

        // Assert
        verify(dataset, times(1)).getYValue(0, 0);
    }

    @Test
    @DisplayName("drawItem handles multiple iterations in series loop")
    void TC10_drawItem_multiple_series_iterations() throws Exception {
        // Arrange
        StackedXYBarRenderer renderer = spy(new StackedXYBarRenderer());

        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset instanceof TableXYDataset).thenReturn(true); // mock specific condition

        when(dataset.getSeriesCount()).thenReturn(2); // Multiple series
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(10.0); // For series 0
        when(dataset.getYValue(1, 0)).thenReturn(20.0); // For series 1

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, 1, 0, crosshairState, 0);

        // Assert
        verify(dataset, times(1)).getYValue(0, 0);
        verify(dataset, times(1)).getYValue(1, 0);
    }
}