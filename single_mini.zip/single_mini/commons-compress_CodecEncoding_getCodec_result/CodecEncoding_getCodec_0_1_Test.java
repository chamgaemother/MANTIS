package org.apache.commons.compress.harmony.pack200;

import java.lang.reflect.Field;
import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.InputStream;
import java.lang.reflect.Modifier;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class CodecEncoding_getCodec_0_1_Test {

    @Test
    @DisplayName("Throws Error when canonicalCodec length is not 116")
    void TC01_ThrowsErrorWhenCanonicalCodecLengthIsNot116() throws Exception {
        // Arrange
        int value = 50;
        byte[] emptyData = new byte[] {};
        InputStream in = new ByteArrayInputStream(emptyData);
        Codec defaultCodec = Mockito.mock(Codec.class);

        // Modify the static canonicalCodec field to have length 115
        Field canonicalCodecField = CodecEncoding.class.getDeclaredField("canonicalCodec");
        canonicalCodecField.setAccessible(true);

        // Remove final modifier if necessary
        Field modifiersField = Field.class.getDeclaredField("modifiers");
        modifiersField.setAccessible(true);
        modifiersField.setInt(canonicalCodecField, canonicalCodecField.getModifiers() & ~Modifier.FINAL);

        // Set canonicalCodec to a new array of length 115
        canonicalCodecField.set(null, new BHSDCodec[115]);

        // Act & Assert
        Error thrown = assertThrows(Error.class, () -> {
            CodecEncoding.getCodec(value, in, defaultCodec);
        });
        assertEquals("Canonical encodings have been incorrectly modified", thrown.getMessage());
    }

    @Test
    @DisplayName("Throws IllegalArgumentException when value is negative")
    void TC02_ThrowsIllegalArgumentExceptionWhenValueIsNegative() throws Exception {
        // Arrange
        int value = -1;
        byte[] emptyData = new byte[] {};
        InputStream in = new ByteArrayInputStream(emptyData);
        Codec defaultCodec = Mockito.mock(Codec.class);

        // Ensure canonicalCodec has length 116
        Field canonicalCodecField = CodecEncoding.class.getDeclaredField("canonicalCodec");
        canonicalCodecField.setAccessible(true);

        // Remove final modifier if necessary
        Field modifiersField = Field.class.getDeclaredField("modifiers");
        modifiersField.setAccessible(true);
        modifiersField.setInt(canonicalCodecField, canonicalCodecField.getModifiers() & ~Modifier.FINAL);

        // Set canonicalCodec to a new array of length 116
        canonicalCodecField.set(null, new BHSDCodec[116]);

        // Act & Assert
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            CodecEncoding.getCodec(value, in, defaultCodec);
        });
        assertEquals("Encoding cannot be less than zero", thrown.getMessage());
    }

    @Test
    @DisplayName("Returns defaultCodec when value is zero")
    void TC03_ReturnsDefaultCodecWhenValueIsZero() throws Exception {
        // Arrange
        int value = 0;
        byte[] emptyData = new byte[] {};
        InputStream in = new ByteArrayInputStream(emptyData);
        Codec defaultCodec = Mockito.mock(Codec.class);

        // Ensure canonicalCodec has length 116
        Field canonicalCodecField = CodecEncoding.class.getDeclaredField("canonicalCodec");
        canonicalCodecField.setAccessible(true);

        // Remove final modifier if necessary
        Field modifiersField = Field.class.getDeclaredField("modifiers");
        modifiersField.setAccessible(true);
        modifiersField.setInt(canonicalCodecField, canonicalCodecField.getModifiers() & ~Modifier.FINAL);

        // Set canonicalCodec to a new array of length 116
        canonicalCodecField.set(null, new BHSDCodec[116]);

        // Act
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);

        // Assert
        assertSame(defaultCodec, result);
    }

    @Test
    @DisplayName("Returns canonicalCodec[value] when value is between 1 and 115")
    void TC04_ReturnsCanonicalCodecValueWhenValueInRange() throws Exception {
        // Arrange
        int value = 50;
        byte[] emptyData = new byte[] {};
        InputStream in = new ByteArrayInputStream(emptyData);
        Codec defaultCodec = Mockito.mock(Codec.class);
        BHSDCodec expectedCodec = Mockito.mock(BHSDCodec.class);

        // Ensure canonicalCodec has length 116 and set index 50
        Field canonicalCodecField = CodecEncoding.class.getDeclaredField("canonicalCodec");
        canonicalCodecField.setAccessible(true);

        // Remove final modifier if necessary
        Field modifiersField = Field.class.getDeclaredField("modifiers");
        modifiersField.setAccessible(true);
        modifiersField.setInt(canonicalCodecField, canonicalCodecField.getModifiers() & ~Modifier.FINAL);

        BHSDCodec[] mockedCanonicalCodec = new BHSDCodec[116];
        mockedCanonicalCodec[50] = expectedCodec;
        canonicalCodecField.set(null, mockedCanonicalCodec);

        // Act
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);

        // Assert
        assertSame(expectedCodec, result);
    }

    @Test
    @DisplayName("Returns BHSDCodec when value is 116 and InputStream provides valid data")
    void TC05_ReturnsBHSDCodecWhenValue116AndInputStreamValid() throws Exception {
        // Arrange
        int value = 116;
        byte[] data = { 0x0F, 0x10 };
        InputStream in = new ByteArrayInputStream(data);
        Codec defaultCodec = Mockito.mock(Codec.class);

        // Ensure canonicalCodec has length 116
        Field canonicalCodecField = CodecEncoding.class.getDeclaredField("canonicalCodec");
        canonicalCodecField.setAccessible(true);

        // Remove final modifier if necessary
        Field modifiersField = Field.class.getDeclaredField("modifiers");
        modifiersField.setAccessible(true);
        modifiersField.setInt(canonicalCodecField, canonicalCodecField.getModifiers() & ~Modifier.FINAL);

        canonicalCodecField.set(null, new BHSDCodec[116]);

        // Act
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);

        // Assert
        assertTrue(result instanceof BHSDCodec, "Result should be instance of BHSDCodec");
        // Additional assertions for BHSDCodec parameters can be added here
    }
}