package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.KeyToGroupMap;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.mockito.ArgumentCaptor;

public class StackedBarRenderer_drawItem_0_2_Test {

    @Test
    @DisplayName("Draw item with group having no prior contributions")
    void TC06_drawItem_new_group_no_prior_contribution() throws Exception {
        // Arrange
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getValue(5, 7)).thenReturn(20);

        GroupedStackedBarRenderer renderer = spy(new GroupedStackedBarRenderer());
        KeyToGroupMap seriesToGroupMap = new KeyToGroupMap();

        seriesToGroupMap.mapKeyToGroup("Series5", "Group5");

        // Reflection to set private field
        Field field = GroupedStackedBarRenderer.class.getDeclaredField("seriesToGroupMap");
        field.setAccessible(true);
        field.set(renderer, seriesToGroupMap);

        CategoryPlot plot = mock(CategoryPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.isInverted()).thenReturn(false);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(), any())).thenReturn(0.0);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(), any())).thenReturn(0.0);
        when(state.getBarWidth()).thenReturn(10.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 5, 7, 0);

        // Assert
        ArgumentCaptor<Rectangle2D> captor = ArgumentCaptor.forClass(Rectangle2D.class);
        verify(renderer.getBarPainter()).paintBar(eq(g2), eq(renderer), eq(5), eq(7), captor.capture(), eq(org.jfree.chart.ui.RectangleEdge.BOTTOM));
    }

    @Test
    @DisplayName("Draw item with generator present and label visible")
    void TC07_drawItem_with_label_generator_visible() throws Exception {
        // Arrange
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getValue(6, 8)).thenReturn(25);

        GroupedStackedBarRenderer renderer = spy(new GroupedStackedBarRenderer());
        KeyToGroupMap seriesToGroupMap = new KeyToGroupMap();

        seriesToGroupMap.mapKeyToGroup("Series6", "Group6");

        // Reflection to set private field
        Field field = GroupedStackedBarRenderer.class.getDeclaredField("seriesToGroupMap");
        field.setAccessible(true);
        field.set(renderer, seriesToGroupMap);

        CategoryPlot plot = mock(CategoryPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.isInverted()).thenReturn(false);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(), any())).thenReturn(0.0);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(), any())).thenReturn(0.0);
        when(state.getBarWidth()).thenReturn(10.0);

        CategoryItemLabelGenerator generator = mock(CategoryItemLabelGenerator.class);
        when(renderer.getItemLabelGenerator(6, 8)).thenReturn(generator);
        when(renderer.isItemLabelVisible(6, 8)).thenReturn(true);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 6, 8, 0);

        // Assert
        verify(renderer).drawItemLabel(eq(g2), eq(dataset), eq(6), eq(8), eq(plot), eq(generator), any(Rectangle2D.class), eq(false));
    }

    @Test
    @DisplayName("Do not draw item label when generator is null")
    void TC08_drawItem_with_null_label_generator() throws Exception {
        // Arrange
        CategoryDataset dataset = mock(CategoryDataset.class);

        GroupedStackedBarRenderer renderer = spy(new GroupedStackedBarRenderer());
        KeyToGroupMap seriesToGroupMap = new KeyToGroupMap();

        seriesToGroupMap.mapKeyToGroup("Series7", "Group7");

        // Reflection to set private field
        Field field = GroupedStackedBarRenderer.class.getDeclaredField("seriesToGroupMap");
        field.setAccessible(true);
        field.set(renderer, seriesToGroupMap);

        // Mock methods
        when(renderer.getItemLabelGenerator(7, 9)).thenReturn(null);

        // Necessary mock objects
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 7, 9, 0);

        // Assert
        verify(renderer, never()).drawItemLabel(any(Graphics2D.class), any(CategoryDataset.class), anyInt(), anyInt(), any(CategoryPlot.class), any(CategoryItemLabelGenerator.class), any(Rectangle2D.class), anyBoolean());
    }

    @Test
    @DisplayName("Do not draw item label when visibility is false")
    void TC09_drawItem_with_label_generator_invisible() throws Exception {
        // Arrange
        CategoryDataset dataset = mock(CategoryDataset.class);

        GroupedStackedBarRenderer renderer = spy(new GroupedStackedBarRenderer());
        KeyToGroupMap seriesToGroupMap = new KeyToGroupMap();

        seriesToGroupMap.mapKeyToGroup("Series8", "Group8");

        // Reflection to set private field
        Field field = GroupedStackedBarRenderer.class.getDeclaredField("seriesToGroupMap");
        field.setAccessible(true);
        field.set(renderer, seriesToGroupMap);

        CategoryItemLabelGenerator generator = mock(CategoryItemLabelGenerator.class);
        when(renderer.getItemLabelGenerator(8, 10)).thenReturn(generator);
        when(renderer.isItemLabelVisible(8, 10)).thenReturn(false);

        // Mock objects
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 8, 10, 0);

        // Assert
        verify(renderer, never()).drawItemLabel(any(Graphics2D.class), any(CategoryDataset.class), anyInt(), anyInt(), any(CategoryPlot.class), any(CategoryItemLabelGenerator.class), any(Rectangle2D.class), anyBoolean());
    }

    @Test
    @DisplayName("Add item entity when state info and entity collection are present")
    void TC10_drawItem_with_entity_collection_present() throws Exception {
        // Arrange
        CategoryDataset dataset = mock(CategoryDataset.class);

        GroupedStackedBarRenderer renderer = new GroupedStackedBarRenderer();
        KeyToGroupMap seriesToGroupMap = new KeyToGroupMap();

        seriesToGroupMap.mapKeyToGroup("Series9", "Group9");

        // Reflection to set private field
        Field field = GroupedStackedBarRenderer.class.getDeclaredField("seriesToGroupMap");
        field.setAccessible(true);
        field.set(renderer, seriesToGroupMap);

        EntityCollection entities = mock(EntityCollection.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        when(state.getEntityCollection()).thenReturn(entities);

        // Mock objects
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 9, 11, 0);

        // Assert
        verify(renderer).addItemEntity(eq(entities), eq(dataset), eq(9), eq(11), any(Rectangle2D.class));
    }
}