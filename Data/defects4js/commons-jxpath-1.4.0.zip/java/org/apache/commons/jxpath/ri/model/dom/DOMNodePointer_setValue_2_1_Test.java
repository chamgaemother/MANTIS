package org.apache.commons.jxpath.ri.model.dom;

import org.apache.commons.jxpath.ri.model.dom.DOMNodePointer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.apache.commons.jxpath.JXPathException;
import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilderFactory;
import java.lang.reflect.Field;
import java.util.Locale;

import static org.junit.jupiter.api.Assertions.*;

public class DOMNodePointer_setValue_2_1_Test {

    @Test
    @DisplayName("setValue with non-text node and value as Element with zero children removes all existing children")
    void TC26() throws Exception {
        // Arrange
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        Document document = factory.newDocumentBuilder().newDocument();
        Element node = document.createElement("parent");
        // Add existing children
        Element child1 = document.createElement("child1");
        node.appendChild(child1);
        Element child2 = document.createElement("child2");
        node.appendChild(child2);
        DOMNodePointer domNodePointer = new DOMNodePointer(node, Locale.ENGLISH);
        // Create empty element as value
        Element emptyElement = document.createElement("empty");
        // Act
        domNodePointer.setValue(emptyElement);
        // Assert
        // Access node via reflection
        Field nodeField = DOMNodePointer.class.getDeclaredField("node");
        nodeField.setAccessible(true);
        Node innerNode = (Node) nodeField.get(domNodePointer);
        NodeList children = innerNode.getChildNodes();
        assertEquals(0, children.getLength());
    }

    @Test
    @DisplayName("setValue on non-text node without a parent throws JXPathException")
    void TC27() throws Exception {
        // Arrange
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        Document document = factory.newDocumentBuilder().newDocument();
        Element node = document.createElement("orphan");
        // node has no parent
        DOMNodePointer domNodePointer = new DOMNodePointer(node, Locale.ENGLISH);
        // Act & Assert
        assertThrows(JXPathException.class, () -> domNodePointer.setValue("New Value"));
    }

    @Test
    @DisplayName("setValue with non-text node and value as Document with zero children removes all existing children and appends none")
    void TC28() throws Exception {
        // Arrange
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        Document document = factory.newDocumentBuilder().newDocument();
        Element node = document.createElement("parent");
        // Add existing children
        Element child1 = document.createElement("child1");
        node.appendChild(child1);
        Element child2 = document.createElement("child2");
        node.appendChild(child2);
        DOMNodePointer domNodePointer = new DOMNodePointer(node, Locale.ENGLISH);
        // Create empty Document as value
        Document emptyDocument = factory.newDocumentBuilder().newDocument();
        // Act
        domNodePointer.setValue(emptyDocument);
        // Assert
        // Access node via reflection
        Field nodeField = DOMNodePointer.class.getDeclaredField("node");
        nodeField.setAccessible(true);
        Node innerNode = (Node) nodeField.get(domNodePointer);
        NodeList children = innerNode.getChildNodes();
        assertEquals(0, children.getLength());
    }

    @Test
    @DisplayName("setValue with non-text node and value as a non-Node, non-String object throws ClassCastException")
    void TC29() throws Exception {
        // Arrange
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        Document document = factory.newDocumentBuilder().newDocument();
        Element node = document.createElement("parent");
        DOMNodePointer domNodePointer = new DOMNodePointer(node, Locale.ENGLISH);
        Object invalidValue = new Object();
        // Act & Assert
        assertThrows(ClassCastException.class, () -> domNodePointer.setValue(invalidValue));
    }
}