package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.mockito.Mockito;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class BarRenderer_drawItem_0_1_Test {
    
    @Test
    @DisplayName("drawItem returns early when visibleRow index is negative")
    public void TC01_drawItem_returnsEarlyWhenVisibleRowIndexIsNegative() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        BarRenderer barRenderer = new BarRenderer();
        
        int row = 0;
        int column = 0;
        
        when(state.getVisibleSeriesIndex(row)).thenReturn(-1);

        // Act
        barRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        // Assert
        // Since visibleRow is negative, no drawing should occur. Verify that no interactions with plot or dataset occur.
        verify(state, never()).getBarWidth();
        verify(dataset, never()).getValue(row, column);
        // Add more verifications as needed to ensure early return
    }

    @Test
    @DisplayName("drawItem returns early when dataValue is null")
    public void TC02_drawItem_returnsEarlyWhenDataValueIsNull() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        BarRenderer barRenderer = new BarRenderer();
        
        int row = 1;
        int column = 1;
        
        when(state.getVisibleSeriesIndex(row)).thenReturn(0);
        when(dataset.getValue(row, column)).thenReturn(null);

        // Act
        barRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        // Assert
        // Since dataValue is null, no drawing should occur. Verify that no further interactions happen.
        verify(rangeAxis, never()).valueToJava2D(anyDouble(), eq(dataArea), any());
        // Add more verifications as needed to ensure early return
    }

    @Test
    @DisplayName("drawItem returns early when calculateBarL0L1 returns null")
    public void TC03_drawItem_returnsEarlyWhenCalculateBarL0L1ReturnsNull() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        BarRenderer barRenderer = Mockito.spy(new BarRenderer());
        
        int row = 2;
        int column = 2;
        
        when(state.getVisibleSeriesIndex(row)).thenReturn(1);
        Number mockNumber = mock(Number.class);
        when(mockNumber.doubleValue()).thenReturn(100.0);
        when(dataset.getValue(row, column)).thenReturn(mockNumber);
        doReturn(null).when(barRenderer).calculateBarL0L1(100.0);

        // Act
        barRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        // Assert
        // Since calculateBarL0L1 returns null, no drawing should occur.
        verify(rangeAxis, never()).valueToJava2D(anyDouble(), eq(dataArea), any());
        // Add more verifications as needed to ensure early return
    }

    @Test
    @DisplayName("drawItem processes horizontal orientation with positive value and non-inverted axis")
    public void TC04_drawItem_horizontalPositiveNonInverted() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        BarRenderer barRenderer = Mockito.spy(new BarRenderer());
        
        int row = 3;
        int column = 3;
        
        when(state.getVisibleSeriesIndex(row)).thenReturn(2);
        Number mockNumber = mock(Number.class);
        when(mockNumber.doubleValue()).thenReturn(150.0);
        when(dataset.getValue(row, column)).thenReturn(mockNumber);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(rangeAxis.isInverted()).thenReturn(false);
        doReturn(new double[] {0.0, 150.0}).when(barRenderer).calculateBarL0L1(150.0);
        
        // Act
        barRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        // Assert
        // Verify that bar is drawn with RectangleEdge.RIGHT
        // Since paintBar method uses package-private visibility or is non-existent, verifying that it processes accordingly
        verify(g2, times(1)).setPaint(any());
    }

    @Test
    @DisplayName("drawItem processes vertical orientation with negative value and inverted axis")
    public void TC05_drawItem_verticalNegativeInverted() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        BarRenderer barRenderer = Mockito.spy(new BarRenderer());
        
        int row = 4;
        int column = 4;
        
        when(state.getVisibleSeriesIndex(row)).thenReturn(3);
        Number mockNumber = mock(Number.class);
        when(mockNumber.doubleValue()).thenReturn(-200.0);
        when(dataset.getValue(row, column)).thenReturn(mockNumber);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(true);
        doReturn(new double[] {-200.0, 0.0}).when(barRenderer).calculateBarL0L1(-200.0);
        
        // Act
        barRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        // Assert
        // Verify that bar is drawn with RectangleEdge.TOP
        // Since paintBar method uses package-private visibility or is non-existent, verifying that it processes accordingly
        verify(g2, times(1)).setPaint(any());
    }
}