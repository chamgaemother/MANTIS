package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class DfpMath_pow_0_8_Test {

    @Test
    @DisplayName("pow(x, y) handles small exponents y close to zero")
    void TC37() {
        DfpField field = new DfpField(20);
        Dfp x = new Dfp(field, 2.5);
        Dfp y = new Dfp(field, 1e-10);
        Dfp result = DfpMath.pow(x, y);
        Dfp expected = DfpMath.exp(DfpMath.log(x).multiply(y));
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("pow(x=1, y=1e8) returns 1")
    void TC38() {
        DfpField field = new DfpField(20);
        Dfp x = field.getOne();
        Dfp y = new Dfp(field, 1e8);
        Dfp result = DfpMath.pow(x, y);
        Dfp expected = field.getOne();
        assertEquals(expected, result);
    }
}