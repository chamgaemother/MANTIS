package org.apache.commons.math3.analysis.differentiation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import java.lang.reflect.Field;
import java.util.concurrent.atomic.AtomicReference;

public class DSCompiler_getCompiler_0_4_Test {

    private void resetCompilersField() throws NoSuchFieldException, IllegalAccessException {
        Field compilersField = DSCompiler.class.getDeclaredField("compilers");
        compilersField.setAccessible(true);
        @SuppressWarnings("unchecked")
        AtomicReference<DSCompiler[][]> compilers = (AtomicReference<DSCompiler[][]>) compilersField.get(null);
        compilers.set(null);
    }

    @Test
    @DisplayName("getCompiler handles minimal integer values for parameters and order")
    void TC16_getCompiler_handles_min_values() throws Exception {
        // Arrange
        resetCompilersField();

        int parameters = Integer.MIN_VALUE;
        int order = Integer.MIN_VALUE;

        // Act & Assert
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            DSCompiler.getCompiler(parameters, order);
        });
    }

    @Test
    @DisplayName("getCompiler handles zero parameters and positive order")
    void TC17_getCompiler_zero_parameters_positive_order() throws Exception {
        // Arrange
        resetCompilersField();

        int parameters = 0;
        int order = 2;

        // Act
        DSCompiler result = DSCompiler.getCompiler(parameters, order);

        // Assert
        Assertions.assertNotNull(result, "Result should not be null");

        // Access 'parameters' and 'order' via reflection
        Field parametersField = DSCompiler.class.getDeclaredField("parameters");
        parametersField.setAccessible(true);
        int actualParameters = parametersField.getInt(result);

        Field orderField = DSCompiler.class.getDeclaredField("order");
        orderField.setAccessible(true);
        int actualOrder = orderField.getInt(result);

        Assertions.assertEquals(0, actualParameters, "Parameters should be 0");
        Assertions.assertEquals(2, actualOrder, "Order should be 2");
    }

    @Test
    @DisplayName("getCompiler handles positive parameters and zero order")
    void TC18_getCompiler_positive_parameters_zero_order() throws Exception {
        // Arrange
        resetCompilersField();

        int parameters = 3;
        int order = 0;

        // Act
        DSCompiler result = DSCompiler.getCompiler(parameters, order);

        // Assert
        Assertions.assertNotNull(result, "Result should not be null");

        // Access 'parameters' and 'order' via reflection
        Field parametersField = DSCompiler.class.getDeclaredField("parameters");
        parametersField.setAccessible(true);
        int actualParameters = parametersField.getInt(result);

        Field orderField = DSCompiler.class.getDeclaredField("order");
        orderField.setAccessible(true);
        int actualOrder = orderField.getInt(result);

        Assertions.assertEquals(3, actualParameters, "Parameters should be 3");
        Assertions.assertEquals(0, actualOrder, "Order should be 0");
    }

    @Test
    @DisplayName("getCompiler handles arraycopy with existing cache entries")
    void TC19_getCompiler_cache_arraycopy_existing_entries() throws Exception {
        // Arrange
        resetCompilersField();

        int parameters = 2;
        int order = 2;

        // Act
        DSCompiler result = DSCompiler.getCompiler(parameters, order);

        // Assert
        Assertions.assertNotNull(result, "Result should not be null");
    }

    @Test
    @DisplayName("getCompiler handles retry on compareAndSet failure")
    void TC20_getCompiler_retry_compareAndSet_failure() throws Exception {
        // Arrange
        resetCompilersField();

        // The concurrent execution is hard to simulate accurately;
        // hence we focus on the fact that eventually new cache should be created successfully.

        int parameters = 2;
        int order = 2;

        // Act
        DSCompiler result = DSCompiler.getCompiler(parameters, order);

        // Assert
        Assertions.assertNotNull(result, "Result should not be null after retry");
    }
}