package com.fasterxml.jackson.databind.ser.std;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.PropertyFilter;
import com.fasterxml.jackson.databind.ser.std.MapSerializer;

public class MapSerializer_serializeFilteredAnyProperties_2_1_Test {

    @Test
    @DisplayName("serializeFilteredAnyProperties with null key and null value, _suppressNulls=false")
    void TC18_serializeFilteredAnyProperties_NullKeyNullValue_SuppressNullsFalse() throws Exception {
        // GIVEN
        Map<Object, Object> value = new HashMap<>();
        value.put(null, null);

        SerializerProvider provider = mock(SerializerProvider.class);
        JsonGenerator gen = mock(JsonGenerator.class);
        PropertyFilter filter = mock(PropertyFilter.class);
        com.fasterxml.jackson.databind.JsonSerializer<Object> nullKeySerializer = mock(com.fasterxml.jackson.databind.JsonSerializer.class);
        com.fasterxml.jackson.databind.JsonSerializer<Object> nullValueSerializer = mock(com.fasterxml.jackson.databind.JsonSerializer.class);

        when(provider.findNullKeySerializer(any(), any())).thenReturn(nullKeySerializer);
        when(provider.getDefaultNullValueSerializer()).thenReturn(nullValueSerializer);

        MapSerializer mapSerializer = new MapSerializer(null, null, null, null, false, null, null, null);
        Field suppressNullsField = MapSerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        suppressNullsField.setBoolean(mapSerializer, false);

        // WHEN
        mapSerializer.serializeFilteredAnyProperties(provider, gen, new Object(), value, filter, null);

        // THEN
        verify(filter, times(1)).serializeAsField(eq(new Object()), eq(gen), eq(provider), Mockito.any());
        verify(nullKeySerializer, times(1)).serialize(eq(null), eq(gen), eq(provider));
        verify(nullValueSerializer, times(1)).serialize(eq(null), eq(gen), eq(provider));
    }

    @Test
    @DisplayName("serializeFilteredAnyProperties with null key and null value, _suppressNulls=true")
    void TC19_serializeFilteredAnyProperties_NullKeyNullValue_SuppressNullsTrue() throws Exception {
        // GIVEN
        Map<Object, Object> value = new HashMap<>();
        value.put(null, null);

        SerializerProvider provider = mock(SerializerProvider.class);
        JsonGenerator gen = mock(JsonGenerator.class);
        PropertyFilter filter = mock(PropertyFilter.class);
        com.fasterxml.jackson.databind.JsonSerializer<Object> nullKeySerializer = mock(com.fasterxml.jackson.databind.JsonSerializer.class);
        com.fasterxml.jackson.databind.JsonSerializer<Object> nullValueSerializer = mock(com.fasterxml.jackson.databind.JsonSerializer.class);

        when(provider.findNullKeySerializer(any(), any())).thenReturn(nullKeySerializer);
        when(provider.getDefaultNullValueSerializer()).thenReturn(nullValueSerializer);

        MapSerializer mapSerializer = new MapSerializer(null, null, null, null, false, null, null, null);
        Field suppressNullsField = MapSerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        suppressNullsField.setBoolean(mapSerializer, true);

        // WHEN
        mapSerializer.serializeFilteredAnyProperties(provider, gen, new Object(), value, filter, null);

        // THEN
        verify(filter, never()).serializeAsField(any(), any(), any(), any());
        verify(nullKeySerializer, never()).serialize(any(), any(), any());
        verify(nullValueSerializer, never()).serialize(any(), any(), any());
    }
}