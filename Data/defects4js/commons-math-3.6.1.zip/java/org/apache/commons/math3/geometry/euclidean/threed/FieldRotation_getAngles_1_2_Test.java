package org.apache.commons.math3.geometry.euclidean.threed;
// import java.lang.reflect.*;
// import static org.mockito.Mockito.*;
// import java.io.*;
// import java.util.*;
// import org.apache.commons.math3.geometry.euclidean.threed.CardanEulerSingularityException;
// 
// import org.apache.commons.math3.RealFieldElement;
// import org.apache.commons.math3.exception.CardanEulerSingularityException;
// import org.apache.commons.math3.util.Decimal64;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import static org.junit.jupiter.api.Assertions.*;
// 
public class FieldRotation_getAngles_1_2_Test {
// 
//     @Test
//     @DisplayName("TC31: getAngles with RotationOrder.ZYX and FRAME_TRANSFORM, expect CardanEulerSingularityException")
//     public void TC31_getAngles_ZYX_FRAME_TRANSFORM_v2_z_out_of_bounds() {
//         Decimal64 angle = new Decimal64(Math.PI / 2 - 1e-10);
//         FieldVector3D<Decimal64> axis = new FieldVector3D<>(new Decimal64(1.0), new Decimal64(0.0), new Decimal64(0.0));
//         FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.FRAME_TRANSFORM);
// 
//         RotationOrder order = RotationOrder.ZYX;
//         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
// 
//         assertThrows(CardanEulerSingularityException.class, () -> {
//             rotation.getAngles(order, convention);
//         });
//     }
// 
//     @Test
//     @DisplayName("TC32: getAngles with RotationOrder.XYX and FRAME_TRANSFORM")
//     public void TC32_getAngles_XYX_FRAME_TRANSFORM_v2_x_within_bounds() {
//         Decimal64 angle = new Decimal64(Math.PI / 4);
//         FieldVector3D<Decimal64> axis = new FieldVector3D<>(new Decimal64(0.0), new Decimal64(1.0), new Decimal64(0.0));
//         FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.FRAME_TRANSFORM);
// 
//         RotationOrder order = RotationOrder.XYX;
//         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
// 
//         RealFieldElement<?>[] angles = rotation.getAngles(order, convention);
//         assertNotNull(angles, "Angles array should not be null");
//         assertEquals(3, angles.length, "Angles array should have length 3");
//     }
// 
//     @Test
//     @DisplayName("TC33: getAngles with RotationOrder.XYX and FRAME_TRANSFORM, expect CardanEulerSingularityException")
//     public void TC33_getAngles_XYX_FRAME_TRANSFORM_v2_x_out_of_bounds() {
//         Decimal64 angle = new Decimal64(Math.PI);
//         FieldVector3D<Decimal64> axis = new FieldVector3D<>(new Decimal64(0.0), new Decimal64(1.0), new Decimal64(0.0));
//         FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.FRAME_TRANSFORM);
// 
//         RotationOrder order = RotationOrder.XYX;
//         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
// 
//         assertThrows(CardanEulerSingularityException.class, () -> {
//             rotation.getAngles(order, convention);
//         });
//     }
// 
//     @Test
//     @DisplayName("TC34: getAngles with RotationOrder.XZX and FRAME_TRANSFORM")
//     public void TC34_getAngles_XZX_FRAME_TRANSFORM_v2_x_within_bounds() {
//         Decimal64 angle = new Decimal64(Math.PI / 6);
//         FieldVector3D<Decimal64> axis = new FieldVector3D<>(new Decimal64(0.0), new Decimal64(0.0), new Decimal64(1.0));
//         FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.FRAME_TRANSFORM);
// 
//         RotationOrder order = RotationOrder.XZX;
//         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
// 
//         RealFieldElement<?>[] angles = rotation.getAngles(order, convention);
//         assertNotNull(angles, "Angles array should not be null");
//         assertEquals(3, angles.length, "Angles array should have length 3");
//     }
// 
//     @Test
//     @DisplayName("TC35: getAngles with RotationOrder.XZX and FRAME_TRANSFORM, expect CardanEulerSingularityException")
//     public void TC35_getAngles_XZX_FRAME_TRANSFORM_v2_x_out_of_bounds() {
//         Decimal64 angle = new Decimal64(Math.PI);
//         FieldVector3D<Decimal64> axis = new FieldVector3D<>(new Decimal64(0.0), new Decimal64(0.0), new Decimal64(1.0));
//         FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.FRAME_TRANSFORM);
// 
//         RotationOrder order = RotationOrder.XZX;
//         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
// 
//         assertThrows(CardanEulerSingularityException.class, () -> {
//             rotation.getAngles(order, convention);
//         });
//     }
// }
}